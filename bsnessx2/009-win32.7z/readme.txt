bsnes-sx2 v009 (bsnes-bsx) (32/64-bit Compatibility+Debugger)
(based on bsnes v082)
by LuigiBlood/Seru-kun

------
Facts
------
- Super Famicom Box isn't well emulated, mostly because of the non support of Z80, which won't be done in bsnes-sx2.
- XBAND is partially emulated, but I've yet to update how the registers work and give the data it expects.
But it's not a priority there so it ain't gonna happen for now.
- From now on (v007), the Time can be "downloaded" from Satellaview Stream 1 & 2.
To have the Time data, ask the Hardware Channel 0x0000 and get 22 bytes (1 packet).
Note that BSX0000-0.bin won't be read because of this change.
- Cartridge Tilt and Swap are only there for fun.
- From now on (v008), BSX files have a new format that only contains the Download Data.
The emulator itself will do the rest.

------
Changelog
------
v009:
- Debugger removed for faster emulation
- Proper BS-X Memory Mapping added. (Note: This version isn't tested.)

v008:
- New format of BSX data files supported.
- Added Year data to Time Channel.
- Fixed Day data to Time Channel.
- Fixed Crash when erasing full Flash data.

v007:
- Super Famicom Box emulation (which doesn't work) added.
- Fixed Page Erase Memory Pack command.
- Added Satellaview Second Stream support. ($218E-$2193)
- Added Hardcoded Time Stream Channel (0x0000)
- Time Stream Channel now have Month and Day data.

v006:
- XBAND is now supported. (Without Online features)
- Added Cartridge Tilt and Swap features.
- New name. "sx2" stands for "Seru's bs-X and Xband".

v005:
- Fixed some Memory Pack Erase commands.
- Added Memory Pack saving support.
(It will make a MEMPACK.bs file, and will replace the contents EVERY TIME you save, be careful.)
- Removed Memory Pack Logging feature that slows down emulation.

v004:
- Added more Memory Pack commands support
- Fixed XML BS-X Slot support! (Try RPG Maker 2 and others now!)

v003:
- Signal Type Filter support (Registers $2188-$2189)
- BSX files have different filenames.

v002:
- Better Customizable files that the BS-X BIOS downloads.
- Better detection of file change.
- Added a folder for the BSX?.bin files.

v001:
- Initial release

------
Thanks to
------
Byuu - For making bsnes.
nocash - For his well made documentation (of BS-X, XBAND...)
ikari_01 - For his Memory Pack documentation (and adding BS-X support for sd2snes)
d4s - For his Satellaview Register Testing Doc, mostly.
p4plus2 - For his BS-X BIOS disassembly.
Kiddo - If he wasn't here, i wouldn't do all this, and thanks for making the SatellaBlog.
Matthew Callis - For hosting the BS-X Project website, and for doing superfamicom.org.

(Probably forgot some... I only made this part in the Readme in class ^^')

------
NEW BSX????-?.bin FILE FORMAT
------
Only contains the $218B/$2191 Data.
Max File Size is 2794 bytes.


------
OLD BSX????-???.bin FILE FORMAT
------
Kept it for archiving purposes.

BSX<Channel>-<Number>.bin
<Channel>: Must be 4 HEXADECIMAL DIGITS.
<Number>: From 0 to 255 decimal numbers.

Offset - Size (Bytes) - Description
0x00 - 50 - UNUSED (You can put anything in there.)
0x32 - 1 - $218A/$2190 Data (Packet Queue)
0x33 - 1 - $218D/$2193 Data (Status Data) [UNUSED SINCE V007]
0x34 - 20 - $218B/$2191 Data (Queue Status Data)
0x48 - 440 - $218C/$2192 Data (MAIN DOWNLOAD)

Note: It "downloads" all of them in a infinite loop. You can add them if you want.
The limit is BSX????-255.bin.
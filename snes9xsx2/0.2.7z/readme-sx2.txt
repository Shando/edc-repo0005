snes9x-sx2 v0.2 (core 1.53)
by LuigiBlood
---------

Changelog:
0.2:
- Added MultiCart Memory Pack support (now RPG Maker 2 and others can load a Memory Pack!)
- Fixed Download Freeze.
- Changed the Memory Pack saved file to "<filename>.save.bs".

0.1:
- Initial release


FAQ:
- What do snes9x-sx2 need to run?
Mostly DirectX9 Runtime, and FMOD dlls (which should be included in this release).

- How to run BS games?
You must have the BS-X BIOS to be able to do that.
Create a BIOS folder, copy the BS-X BIOS there, and rename it to "BS-X.bin".
Then, load a BS game via Load ROM, the BS-X BIOS will boot.
Go then to the house you appear to, and select the 1st menu.
Your game should appear.

- How to run the BS-X BIOS with an empty Memory Pack?
Simply load the BS-X BIOS file via Load ROM.

- How to run <game> with a Memory Pack?
You must choose File > Load MultiCart...
Don't worry, "stbios.bin" isn't needed.
The Slot A should be the game, and the Slot B, the Memory Pack itself.
Please note that if you don't load one, it will not make an empty Memory Pack.
You need to load the "Empty Memory Pack.bs" file for this.

- How to save my Memory Pack?
Simply go to File > Save Other > Save Memory Pack.
A .save.bs file with the ROM name will be created at the snes9x-sx2 folder. Please note that doing the operation again will REPLACE the same Memory Pack you saved.



Notes:
So, I have finally done snes9x-sx2. The first and second versions, tested by myself, and compiled by OV2 (because my PC is so buggy I can't seem to do it right).
It can do some of the things that bsnes-sx2 (or maybe higan-sx2 at this time you're reading) can do, as in Satellaview Data Downloads (bsxdat folder, with the exact same files as for the other), proper Memory Pack support, which was a pain to add, and proper Memory Map for BS-X BIOS. Soundlink isn't supported yet, I'm still not sure how that works, it's a bit confusing.
I made this because some people can't use bsnes/higan, and thus, I want this Satellaview emulation to be accessible by everyone, I still plan to do much more things, but for now, enjoy.

Thanks to:
- Kiddo (for being the one who motivated me to do this)
- Matthew Callis (not only for the website but it'll be too long)
- byuu (well, I had to begin somewhere, I used bsnes at first)
- OV2 (for compiling and actually helping me to compile snes9x at least for debugging)
- nocash (because he deserves some recognition as I used his documentation)
- ikari_01 (Proper Memory Map emulation and tons of other things)
- snes9x team (duh, for making snes9x)
- some others I maybe forgot...

No thanks to GitHub for being an ass to me.

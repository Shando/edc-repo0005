OSWAN 0.70 for Windows

This is a Bandai Wonderswan mono and color emulator.

To access gui while playing a game, press ESC key. Keys are:

        - Arrows for movement
        - X for button A
        - C for button B
	

Here  is what's new:

 - Better CPU timing
 - Sound support
 - Fixed mono games states saves bug
 - Fixed green color scheme bug
 - Joystick support


Special thanks to :

- Dox for his nice tech info and having released cygne source code
- Toshi (wscamp emu) for its help (timing and sound)



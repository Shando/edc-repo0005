neutrinoSX2 v0.08 - a PS2 Emulator by Muad & nSX2 team
email : atreides.muaddib@caramail.com
site: nsx2.emulation64.com
date: 27/06/2003

This emu is OpenSource under the GNU License.

CHANGES v0.08
	GUI:	Full rewrite with Win32 API
		-Plugin Config Dialog
		-Run CDVD ( Load and run ) / Run Elf
		-Multilanguage Support
		-Sentence View ( in About Dialog )
		-CPU r5900 speed Monitor
		-Main window Picture by Muad
		-About Picture by Myth
	
	CPU:	-Add opcodes : BGEZAL, BGEZALL, BLTZAL, BLTZALL
		-Bug fix in J-JAL opcodes

	DMAC:	-Full rewrite
		-Generic Source Chained Transfer for all Channels
	
	INTC:	-Full rewrite
	
	TIMER:	-Full rewrite
		-Add Opcodes Cycles for presice count
		-Add H-Sync and V-Sync
	
	GIF:
		-Function for the different Path

	VIF:	-Full rewrite
		-Generic VIF Transfer for the two VIF

	VU:	-Add VU0 Micromode
		-Add a lot of VU opcodes

	BIOS:	-Full rewrite of HLE Thread
		-Rewrite Deci2 syscall. 
		-Preliminary Original Bios support

	LOADER:	-Add test to check valid elf

	OTHERS:	-Emulation is done in a Win32 Thread
		-Many splits of files.
	
	DEBUGGER:
		-remote Debugger ( no comments... )
		-standard Debugger 
			-BreakPoint Support
			-CORE/COP0/COP1/COP2/DMAC/INT/TIMERS/VIF/VU0/VI1 Registers
			-Memory Viewer
			-inside assembler by Wire/Napalm
			
	SIF PLUGIN:	-Update to last PCSX2 src
	
	LOGGER: emulator will search for file DebugView.dll in plugins folder
		if not found it will use default nsx2 logger	
		 


13 March 2003
CHANGES v0.07

	GUI:	-Fix Crash Bug at Exit
	        -Add LogFile Functions ( ShadowPrince )
	        -Fix the path absolute & Code clean in main_gtk.c ( ShadowPrince )
	        -Add ClearOutput option in menu ( Pofis )
	        -Add F7 Pause - F8 Run ( Pofis )
	        -Add Key handle to GS plugin
	        -Fix long name bug ( ShadowPrince )


	
	CPU:	-Fix bug in DIV opcode ( Divide by zero )
  	        -Add new type 128 bits for Parallel Op.
	        -Add more MMI opcodes
	        -Add more COP1 opcodes
	        -Change FPR1 register 128b to 32b
	        -Fix bug in Emu Init COP2 register
	        -Add more COP2/VU1 opcodes
	        -Add VU1 micromode 
	        -StupidBug in COP2-DestField & VITOF0/VITOF4


	DMA:	-Add DMA Transfer to VIF1
	        -Add DMA Transfer TO/FROM SPR
	        -Fix a bug in DMA_##_TRANSFER : add Stall mode ( works as Normal Transfert )
	        -Fix a bug in DMA_GS_Transfer_Normal_Mode() for the SPR Memory


	BIOS:	-Write SetSyscall
	        -Add SetRPCVersion
	        -Add Threads ( very buggy )
	        -Rewrite Semaphores


	LOADER: -Rewrite Elf Loader	

	
	TIMER:  -Add Timers

	
	GIF:	-Add Detection of GIF Registers ( not fully )	

	VIF: 	-Add Detection of VIF0/VIF1 Registers ( not fully )
	        -Add VIF Command


	MEMORY:	-Add SPR Memory
	        -Change the main Read/Write function ( now if a addr is unknow -> mapped to main memory )


	OTHERS:	-Add a little Fix
	        -Update the PAD handle PAD_RPCCMD_SET_MMODE




06 February 2003
CHANGES v0.06
	Overview:
	Demos running with GStaris 0.6 :
		1987, 1fx, 3stars, bytheway, cubemastah, demo2d,
		fire, jasper1, new_printf, plasma_tunnel, printf, 
		ps2tut_01, ps2tut_02a, ps2tut_02b, ps2tut_02c,
		stench,and others...

	

	GUI:	-add DebugWindow ( Not fully completed )
	
	CPU:	-Remove the PrefetchInterpreter Version 
	        -Fix & add missing r5900 Opcodes
	        -Fix bug in IsNot32bitIntegerOverflow()
	        -Fix bug in opcodes Tables
	        -Basic COP2 (vu) implementation 

	DMA: 	-Rewrite all DMA transfert.
		-Partial Implementation of "ChainedTransfertMode"
	
	BIOS: 	-Partial Emulation of "Semaphore", 
	        -Partial Emulation of DMA Handler  & Interrupt Handler

	IOP:	-Use the SifPlugin Plugin ( made by F|RES and Florin ( my mistake , typo Error )


	TIMERS: -Partial Emulation of Timers

	PLUGINS:-has own folder : plugins

	INPUT:	-Use of Input Pluggin.
	        -Hack of Analogic Joystick ( bind to UP/Down Button ) for turnip.elf
	
	GS:	-F8 key to make SnapShot
	
	ELF: 	-Rewrite some parts
		
		
	OTHERS: -Split files in several parts 


02 January 2003
CHANGES v0.05
	GUI:
	I use now the Gimp Tool Kit ( GTK ) for the GUI.
	For Win32 users, you need the GTK+ 2.0.0 runtime libraries (3.1 MB).
	You can download it at this URL : http://www.bloodshed.net/dev/packages/gtk.html
	You can use the GS pluggins ( GSsoftdx and GStaris )

	Other:
	I use Dev-C++ for the developpement.
	If someone want I keep a SDL version, tell me ( or if someone want to continue the SDL version )



27 November 2002
CHANGES v0.04:
	GUI:	-Stupid Bug in GUI AddText
	        -Speed Up the GUI drawing
	        -New GUI Feature : Style ( change by F4 ):  swtich Default - Debug - FullScreen ( In the Window... for the moment )
	        -New GUI Feature : Execute ONE opcode - key F5
	
	CPU:	-Rewrite all COP1 ( FPU ) code
	        -Some Fix in CPU Core
	        -Speed Up the Interpreter Core.
		-Now all opcode are prefetched before execution
		-It can make time to open the file but the execution is faster.

	OTHERS:	-Remove the Bios File. 
		-I don't use it for the emulation. Maybe in the future...

14 October 2002
CHANGES v0.03:
	-Internal Plugin GS 0.4 by the PCSX2 team
	-some FPU opcodes
	-some opcodes
	-Stupid Bug in SLT
	-Stupid Bug in fopen ( ) ( bad read of elf file )
	-first release with a mini GUI : It's a mini GUI with partial user interaction. 
		F1 : Pause the Emu
		F2 : Resume the Emu
		F3 : Display Debug Info
	-Replace the INIAPI by INIPARSER
	
	
	

9 September 2002
CHANGES v0.02:
        -Implementation Memory Acces 
	-Some FPU functions implemented.
	-|__>1 new demo works : ps2tut_01.elf
	-Rename Ps2_config.ini to nsx2.ini
	-Clean code for better lisibility
	-Add comments to code
	-New Makefile
	-Add a new file : HOW_IT_WORKS.txt which explain how works this emu


	
		
	
NOTES :
	I use only interpreter.
	All the configuration can be done in the nsx2.ini file.
	
	
	I CURRENTLY NEED HELP IN CODING THIS EMU.
	IF YOU CAN HELP ME , CONTACT ME.	
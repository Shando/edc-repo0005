WSCamp Ver0.21

Wonder Swan Color Emulator

WHAT'S NEW
----------

Ver0.21(Oct 13 2002) 
    Added internal EEPROM control.(thanks wai)
    It copes with the  1Mbit 2Mbit SRAM cartridge.
    The initial value of the VBlank timer control is changed.


KEYBOARD AND JOYPAD SETTING
---------------------------

It can be set up by rewriting 'WSCamp.ini'.

[KEYBOARD]       Keyboard setting

        Horizontal mode
HYUp             Y1 key
HYRight          Y2 key
HYDown           Y3 key
HYLeft           Y4 key
HXUp             X1 key
HXRight          X2 key
HXDown           X3 key
HXLeft           X4 key
HOption          Option button (don't care)
HStart           Start button
HAButton         A button
HBButton         B button

        Vertical mode
VYLeft           Y1 key
VYUp             Y2 key
VYRight          Y3 key
VYDown           Y4 key
VXLeft           X1 key
VXUp             X2 key
VXRight          X3 key
VXDown           X4 key
VOption          Option button (don't care)
VStart           Start button
VAButton         A button
VBButton         B button

        The key word which can be used for the setting.
                 0~9
                 A~Z
                 BS
                 RETURN
                 SHIFT
                 CONTROL
                 SPACE
                 LEFT
                 RIGHT
                 UP
                 DOWN
                 -
                 ^
                 \
                 @
                 [
                 ;
                 :
                 ]
                 .
                 /

[JOYPAD]        Joypad setting

        Horizontal mode
HYUp             Y1 key
HYRight          Y2 key
HYDown           Y3 key
HYLeft           Y4 key
HXUp             X1 key
HXRight          X2 key
HXDown           X3 key
HXLeft           X4 key
HOption          Option button (don't care)
HStart           Start button
HAButton         A button
HBButton         B button

        Vertical mode
VYLeft           Y1 key
VYUp             Y2 key
VYRight          Y3 key
VYDown           Y4 key
VXLeft           X1 key
VXUp             X2 key
VXRight          X3 key
VXDown           X4 key
VOption          Option button (don't care)
VStart           Start button
VAButton         A button
VBButton         B button

        The key word which can be used for the setting.
                 1~11
                 LEFT
                 RIGHT
                 UP
                 DOWN

Fanction key setting
    [F1] toggle of the horizontal mode and the vertical mode.


DISCLAIMERS
-----------

Use this software as a soft development support tool.
Author is not responsible for anything bad that happens. You use it at your own risk!

The NEC CPU emulator code is taken from the MAME project, and terms of their use
are covered under the MAME license. (http://www.mame.net)
Dox and Bryan McPhail is the author of the NEC CPU core.(mish@mame.net)

Tech info is taken from the Cygne project.


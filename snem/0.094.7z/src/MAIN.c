//1b15a
#include <stdio.h>
#include <stdlib.h>
#include "snes.h"

int romloaded=0,exitsnem=0;
int bit16;
int lorom;
int vidout;
int sblankchk=0;
int soundupdate=0;
int subscreenon=1,bg1on=1,bg2on=1,bg3on=1;
static int speed_count=0;
static void soundcheck()
{
        soundupdate=1;
}

static void incspeedcount()
{
        speed_count++;
//        soundupdate=1;
}

int fpsc,frames;
static void fpscount()
{
        fpsc=frames;
        frames=0;
}

int spcemu,palf,bit16;

void dumpregs();
int main(int argc, char *argv[])
{
        int lastf4=0;
        char filename[1024]="";
        int fps;
//        atexit(dumpregs);
        bit16=0;
        allegro_init();
        install_keyboard();
        install_timer();
        install_mouse();
        if (argc<2)
        {
//                romloaded=0;
                set_gfx_mode(GFX_AUTODETECT,400,300,0,0);
                file_select_ex("Please choose a ROM image",filename,"SMC",1024,400,300);
                loadsmc(filename);
                if (alert(NULL,"Emulate SPC?",NULL,"Yes","No",'Y','N')==1) spcemu=1;
                else                                                       spcemu=0;
                if (alert(NULL,"Graphics mode?",NULL,"8-bit","16-bit",'8','1')==1) bit16=0;
                else                                                               bit16=1;

//                if (alert(NULL,"Video standard?",NULL,"PAL","NTSC",'P','N')==1) palf=1;
//                else                                                            palf=0;
        }
        else
        {
                set_gfx_mode(GFX_AUTODETECT,400,300,0,0);
                loadsmc(argv[1]);
//                romloaded=1;
                if (alert(NULL,"Emulate SPC?",NULL,"Yes","No",'Y','N')==1) spcemu=1;
                else                                                       spcemu=0;
                if (alert(NULL,"Graphics mode?",NULL,"8-bit","16-bit",'8','1')==1) bit16=0;
                else                                                               bit16=1;
//                if (alert(NULL,"Video standard?",NULL,"PAL","NTSC",'P','N')==1) palf=1;
//                else                                                            palf=0;
        }
        if (palf) fps=50;
        else      fps=60;
        makeopcodetable();
        if (!lorom) makehiromtable();
        else        makeloromtable();
        reset65816();
        resetspc();
        initppu();
//        spcemu=1;
        if (spcemu) initsound();
        install_int_ex(fpscount,BPS_TO_TIMER(1));
        if (spcemu) install_int_ex(soundcheck,BPS_TO_TIMER(500));
//        clear_to_color(screen,makecol(0,0,0));
//        if (!romloaded) entergui();
//        while (!exitsnem)
//        {
        speed_count=0;
        if (palf) fps=50;
        else      fps=60;
        install_int_ex(incspeedcount,BPS_TO_TIMER(fps));
        while (!key[KEY_ESC])
        {
//                if (romloaded)
//                {
                        while (speed_count>0)
                        {
                                poll_keyboard();
                                if (palf) mainloop(312);
                                else      mainloop(262);
                                speed_count--;
                                vbl=0;
                        }
                        renderscreen();
                        frames++;
                if (soundupdate && spcemu)
                {
                        soundupdate=0;
                        updatesound();
                }
                rest(0);
//                }
                if (key[KEY_F1])
                {
                        dumpchar();
                        speed_count=0;
                }
                if (key[KEY_F2])
                {
                        rest(400);
//                        while (key[KEY_F2]) rest(0); //yield_timeslice();
                        subscreenon^=1;
                }
                if (key[KEY_1])
                {
                        rest(400);
//                        while (key[KEY_1]) rest(0); //yield_timeslice();
                        bg1on^=1;
                }
                if (key[KEY_2])
                {
                        rest(400);
//                        while (key[KEY_2]) rest(0); //yield_timeslice();
                        bg2on^=1;
                }
                if (key[KEY_3])
                {
                        rest(400);
//                        while (key[KEY_3]) rest(0); //yield_timeslice();
                        bg3on^=1;
                }
                if (key[KEY_F4] && !lastf4)
                {
                        remove_int(incspeedcount);
                        install_int_ex(incspeedcount,BPS_TO_TIMER(5));
                }
                if (!key[KEY_F4] && lastf4)
                {
                        remove_int(incspeedcount);
                        install_int_ex(incspeedcount,BPS_TO_TIMER(fps));
                }
                if (key[KEY_F5])
                {
                        rest(400);
//                        while (key[KEY_F5]) rest(0); //yield_timeslice();
                        sblankchk^=1;
                }
                lastf4=key[KEY_F4];
        }
//        remove_int(incspeedcount);
//        entergui();
//        }
//        vidout=1;
//        renderscreen();
//        dumpregs();
//        dumpspcregs();
//        dumpppuregs();
//        dumpio();
//        dumpvram();
//        dumpsound();
//        dumpsamp();
        return 0;
}

END_OF_MAIN();

[ PSXeven v0.19 (04/28/05) -- ReadmeOrDIE ]           

>> DISCLAIMER/LEGAL <<

This software is freeware and may be used freely, distributed as-is, 
but without any guarantees or warranties whatsoever. It is 
not the author's responsibility if the program eats your harddrive,
steals your girlfriend, kills your cat, stabs you with a knife or
screws up your PC. So dont you go crawling to your momma that 
somebody broke your wookie. If you do not agree to this conditions 
then delete this program asap.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  

Sony Playstation is registered trademark of Sony. 

>> WHAT THE FUCK IS IT? <<

Its a SONY Playstation emulator, basically it allows you to run SONY PS 
games on a pc with WIN9X/WINMe.. etc. If you dont know what a playstation
is then you've probably been living on Pluto. :P 

>> HOW TO USE <<

1. Unzip the provided zip file to any directory you like.
2. Put a psx bios dump inside the "PSXeven\bios" directory.
3. Load a psx cd on your drive.
4. Click on "Run CD".

Whether the game plays, program crashes or starts humping your fingers
is another story altogether.

>> CUSTOMIZATION <<

The emulator is provided with default GPU/SPU/CDR/PAD plugins,
which will run as long as the plugin requirements are met. The default
plugins are as follows:
	
	GPU - P.E.O.pS GPU Plugin (Pete Bernert)
	SPU - P.E.O.pS SPU Plugin (Pete Bernert)
	CDR - CdrXeven 		  (mine :P)
	PAD - Sapu's DI Keys 	  (Sapu)

You can configure the default plugins by going to "Config" -> "Graphics", " Config" 
-> "Sound" and so on. You can also do the same by right clicking on the client 
window and going to the "Quick Configure" menu. 

If you are up to it you can change the default spu/gpu/cdr/pad plugins by going to
"Config" -> "Advanced" and using the "Plugin Manager" tab. Course you need to get
additional plugins from websites like WWW.EMUFANATICS.COM or WWW.NGEMU.COM. 
A WORD OF WARNING: IT ONLY SUPPORTS NEWER PSEMUPRO PLUGINS, old versions without 
some specific export functions will crash your PC.

Additionally you can go to "Config" -> "Advanced" and use the "PSXeven Options" tab.
Not much options right now, you can leave them as they are or if your up to it you 
can experiment with some (they're not that many :P). A "Memcard Manager" is also
added for convenience.

>> SOME MENU FUNCTIONS <<

1. Load CD - what do you think? :p
2. Load ISO - okay just to clear things up, "ISO"'s should be binary images and not
   iso9660 encoded, otherwise everything will probably blow up.
3. Compress/Decompress ISO File - well if you use psx cd images a lot, and you have  
   a relatively fast computer, it's recommended to compress the binary images using
   this tool. Will save a lot of space, in most BUT NOT ALL cases.
4. Force Change Disk - during times when the games asks you to change disk you can use 
   this menu to do a cd2cd, cd2iso, iso2iso, iso2cd disk change. Note, newer cdr 
   plugins will still do the cd2cd disk change automatically.
5. Other menus and stuff are self-explanatory. :P

>> HOTKEY FUNCTIONS <<

   F1  - Save state, ("PSXeven\states") needs to exist.
   F2  - Select savestate slot. (1-5)
   F3  - Load state from current slot.
   F8  - Create snapshot, ("PSXeven\snap") directory needs to exist.
   ESC - Pause/Continue current game.

>> REQUIREMENTS <<

1. A PC :P Minimum PC Requirements: NOT DEFINED, you need a relatively good one.
2. A Psx bios dump, from your console.
3. A Human brain, sufficiently functioning for all of your tinkering needs. j/k :P

>> BUGS/OUTSTANDING ISSUES <<

1. A LOT of games are unplayable or unbootable.
2. XA and MDECs are not yet up to speed.
3. Speed is not optimized for low end pcs.
4. Some bugs in GUI - dont do a lot of weird stuff.. it'l blow up :p
5. Im hungry.

>> COMPATIBILITY <<

Err dunno, i know Tekken 3 is running.. heh.

>> FAQ - Frequently Asked Questions <<

1. What is a wookie? - i have no freaking idea.
2. My games dont play, what's wrong? - Either the game is unsupported or 
   the emu is not configured correctly. Try tinkering with other plugins 
   and make sure you have a psx bios.
3. Where do i get a psx bios? - dont ask from me, dump one. You may only
   use a Copyrighted playstation bios if you are legally entitled to.
4. Who the fuck are you? - scroll down.

>> THANKS << 
 
   linuzappz: 		for valuable information/tools and help
   PsYcHoJaK: 		for getting me started in emu programming 
   Pete Bernert: 	for letting me use his gpu/spu plugins
   expert: 		for help/hints 
   Keith: 		for my site and for being a great guy.
   liquid: 		for a bunch of stuff :p

   Okay, list will be too long if i go on individually so thanks 
   to these guys for their help as well: 
  
   Shiori, DarkWatcher, Lord Kane, Exophase, Betamax, ShadowLady, 
   Samor, CKemu, Evil Squall, mike9010, SaPu, Raziel, 501XX, BaD_BURN.. 
   and to all people who helped.

   Greets To: 
   Gk1986, kairi00, Asfaloth, Asz, carnage179, Neojag, Nezzar, 
   Fou-lu, Efrainman, Snake785, Zephon, GoTrunks, pyrokenx, 
   YoD,wierd, Cless,i4get,Azimer, lu_zero, _Demo_, Martin, 
   ShadowFlare, dixon, Bobbi, Death Metal, ebola, Takmadeus, 
   moomoomoo, prafull, cooliscool, jegHegy, jadam, fluffy, spajdr,
   Skye, Shunt, Scart_T
   
   People in #emufanatics, #ngemu, #fimp, #ckemu, #batard 
   BATARDS and maggots :p and to you all. Dont kill me if i 
   missed to greet or thank you okay? :p
	
   Dedicated to my girlfriend NoTe. She throws sidewinders to 
   my head but i love her.. hehe.

>> WEBPAGE ADDRESS << 
   
   HomePage: 		http://batard.psxfanatics.com
   P.E.Op.S Page: 	http://sourceforge.net/project/peops
   Forums:		http://www.emufanatics.com/forums

>> WHO THE FUCK ARE YOU? <<
   
   Nick: 		Xeven 
   Name:   		F??c???s
   Age:    		25
   Sex: 		Male
   Country: 		Philippines
   Current location: 	MN
   Education:		BSEE
   Occupation:		Cooks sand to make chips
   Contact:		zenra12@yahoo.com

   
   
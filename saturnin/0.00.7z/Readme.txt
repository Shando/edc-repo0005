                                                                                
  ########     ####    ###############   ### ########## #####  ###############  ### 
##########    ######   ###############   ### ########## ###### ###############  ### 
#####    #   #######     #####   ####   #### ####  ########### ### #### ########### 
#########   ########     #####   ####   ######### ################ #### ########### 
##########  ### ####     ####   #####   ### ########## ###########################  
#    ##### ##########    ####   #####  #### #########  ### ####################### #
######### ###########   #####   ##########  #### ######### ###### #### ###  ###### #
######## ####    ####   ####     ########  ##### #########  ##### #### ###   ##### #
                                                                       Ben-J 2003  #
                                                                                   #
                                                                                   #
                                                                                   #
########  #####   ##########      #######   #####   #### ##### #####  ###### ###### 

Saturnin v0.00
==============

First, a little note for a better understanding : Saturnin was the name of a little duck who was the hero of kiddie TV show on french TV in the late sixties. I think it'll explain a lot of things :)
And no, I wasn't born at this time.

What it's made of :
-------------------
- Visual C++ 6.0
- OpenGL for display
- Lex/Flex for Saturn binary file disassembly

What it can do now :
--------------------
Well ... not much :) 
- it shows the bios screen, allows navigation through menus, and date/hour/language setting (no cursor in the menu, as I haven't added sprite support yet)
- it can disassemble a Saturn binary file
- and it can show the system ID of a Saturn cd (only d:\ now, sorry) 

What it can't do :
------------------
Everything else ! (apart the laundry)(I'm just joking)


Its growth :
------------
Master SH2 : 100%
Slave SH2 : 0%
SMPC : 60%
Sound : 0%
VDP1 : 0%
VDP2 : 15%
SCU : 40%
DSP : 0%
CD : 5%
DMA : 0%
Interrupts : 100%


What it needs to run :
------------------------
Be sure to place the saturn bios in the same directory than Saturnin, and to rename it 'bios.bin'.
Commands are :
- arrow keys
- A => S
- B => D
- C => F
- X => X
- Y => C
- Z => V
- Start => Return


Its godfathers :
----------------
- Ben-J, webmaster of Consollection, who created the website and is hosting it. He's often feeding it.
- Fabien Autrel, the Satourne coder, who healed its malformations and fractures, where many others would have terminated its life :)


Thanks to :
-----------------
- TyRaNiD
- the Segadev list
- the Dynarec list
- everyone supporting this project
- and of course Ben-J and Fabien again !


If you want to contact me (or the duck), write here :
saturnin@consollection.com

Don't forget the website !
saturnin.consollection.com

See you soon for some brand new adventures !

Runik
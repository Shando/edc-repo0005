Jackal v0.009
-------------

How Jackal runs
---------------
Jackal uses a pop-up menu system.Just run the emulator and click the right mouse button on 
the window of the emulator.Then, if you want,for example,to open a bios choose Load Bios,
load the bios file and then go to Cpu->Run.The same thing for psx-exe files.Choose Load Exe
and then go to Cpu->Run.

What Jackal currently emulates
------------------------------

-the bios very well
-dynarec cpu core
-no GTE at all
-GPU in direct Draw
-partial but not available cd-rom support
-partial dma and interrupts

Known bugs
----------
-fps counter a little bit crazy
-bad emulation of dma and interrupts (that's why most games don't run)
-seems that big files can't be correctly loaded into memory yet
-some lighting problems in GPU
-many, many bugs........

Info
----
Jackal is a psx emulator by Expert (expertcd@yahoo.com) and Floating Point.
Expert is from Greece ...... The first of this kind of programmers from that land!
You will find the webpage of Jackal in the emualliance web page (www.emualliance.com).
The direct link to the emulator's web site is not available yet.
Any downloads of the emulator from other pages are not allowed.

Greets
------
Greets go to.....
Mario Rodrigez, author of Atlaant
Twin, he knows what for...
Doomed, for his great site (lot of info)
Nagra, for his great site also
antiloop, for his source which he gave us to study
and last but not least...
bitmaster,bero,TseA,Nintenda,Novaflare,AkumaX

(readme.txt edited by AkumaX)
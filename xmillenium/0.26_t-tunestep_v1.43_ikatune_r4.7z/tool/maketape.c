/*
	Xmillennium T_TUNE
	�e�[�v�t�@�C���̍쐬
*/
#include <stdio.h>

char dummydata[256] = { 0 };

main()
{
	FILE *fp;
	unsigned long freq,min,length;
	char fname[128];

	printf("Sampling rate (Hz)?");
	scanf("%ld",&freq);
	printf("Size (minits) ?");
	scanf("%ld",&min);

	length = min*60*freq/8;
	sprintf(fname,"C%d.tap",min);
	printf("Sampling rate %ld:Size %lx(%ld min.):filename '%s'\n",freq,length,min,fname);

	fp=fopen(fname,"wb");
	if(fp==NULL) return;
	fwrite(&freq,1,4,fp);
	while(length >=256)
	{
		fwrite(&dummydata,1,256,fp);
		length -=256;
	}
		fwrite(&dummydata,1,length,fp);
	fclose(fp);
}
#################################################################################
  #######    ####  #######    ########   #####      ######  ######       ####### 
 ######### ######  #################### ###### ###################  #############
 #################    #######################  ###################  ######## ####
 ###### ###### ###   #### ####     ##### ###   ####### # ######### #### #########
# ##### ##########   ###   ##       #######    ### ############### ###  ###  ### 
#  ###############  ###    ###       ## ###   ### ######## ###  ######  ###      
### ######     ###  ###    ######  ###   #######  ##  ###   ##  #####   ######   
 ###### #      ##   #         ########     ####   #    ##   #    ###    ######   
 # #           #                ###                                              
##################################################################################
Satourne - http://www.satourne.consollection.com/
A Sega Saturn / Sega Titan Video by Fabien Autrel

### Satourne version 1.0 plugin ###

After several months of coding here is the result of my work. The emulator has been
rewritten from scratch to adopt a plugin system. I've made this choice to open the
developpement to anyone who is interested in some part of the saturn hardware.
Keep in mind that I'm not a professional coder, hence don't expect this program to be
totaly bug-free.

## 1. How to use ##

You must put the plugins in their corresponding directory. After the first start of the
emu you must choose and eventually configure the plugins for each component.
Upon the first start you must also set the bios paths (satunr bios and stv bios) in the
options (menu options-> other options).

# machine mode #
You can select the machine emulated (saturn or ST-V) through this menu. In saturn mode
you can load a saturn binary to test your own saturn programs.

# the options #

You can activate the emulation of a 1Mb cartridge or 4Mb cartridge. With the standard
plugins it seems that no game using a RAM cartridge work.

You can modify the minimum number of cycles executed in one call by the SH2 plugin.
By increasing this value the emulation should be faster but less compatible, by decreasing
it the emulation should be slower but more compatible. The speed gain may vary depending on
the emulation technique used by the plugin.

You can alos modify the machine frequency to speed up emulation. Depending on the game
emulated it can affect the game behaviour.

## 2.Plugin developpement ##

You should find along with this emulator the plugin specifications. There is a header for
each component. I designed the plugin system to encapsulate the emulation of each saturn chip.
This may sounds unusual compared to other emulators but it can allow the design of plugins
using various emulation techniques for the same component.
If you think I should modify the plugin interfaces please let me know your thoughts  about
the subject.


For any question (except explanations about finding the bioses) use this email:
satourne@consollection.com.

P.S. : We are looking for people who can
- built a compatibility list for Sega Saturn games and Sega Titan Video games
- make screenshots of games
- develop plugin
- etc.
volunteer ? mail us at ben.j@consollection.com

Fabien
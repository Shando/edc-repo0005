#################################################################################
  #######    ####  #######    ########   #####      ######  ######       ####### 
 ######### ######  #################### ###### ###################  #############
 #################    #######################  ###################  ######## ####
 ###### ###### ###   #### ####     ##### ###   ####### # ######### #### #########
# ##### ##########   ###   ##       #######    ### ############### ###  ###  ### 
#  ###############  ###    ###       ## ###   ### ######## ###  ######  ###      
### ######     ###  ###    ######  ###   #######  ##  ###   ##  #####   ######   
 ###### #      ##   #         ########     ####   #    ##   #    ###    ######   
 # #           #                ###                                              
##################################################################################
Satourne - http://www.satourne.consollection.com/
A Sega Saturn / Sega Titan Video by Fabien Autrel


### Satourne version 1.0.1 plugin ###
What'news :
[] Now you can use the msvcr70.dll, which is included in the Satourne Archive
[] CD block ISO plugin version 1.0.1
   -removed ASPI detection code (forgotten during wild port)
[] SCSP plugin version 1.0.1
   -added timers support
   -fixed a bug in Reset() function 
   -I'm really sorry Bart, I forgot to mention the fact that I use your very good
    68000 emulator, now fixed!
[] SCU no DSP plugin version 1.0.1
   -fixed a bug in DMA indirect mode:
    this fixes die hard (now showing polygons), some backgrounds in decathlete
    and gouraud shading bugs in nights and burning rangers (gouraud shading tables
    are now correctly filed)
[] SMPC Dinput plugin version v1.0 : To select a peripheral, please use the arrow key on your keyboard
[] VDP opengl plugin version 1.0.1
   -Corrected a bug in color RAM address offset calculation, still incorrect in some cases
   -Corrected a bug in VDP2 cell mode (was causing a black zone on the border of planes)
   -priority function works better, still far from being perfect...
   -added an option to force sprite priority to 6, this makes kof97 and metalslug playable
    (and perheaps other non tested games), just try it if you don't see sprites.



### Satourne version 1.0 plugin ###

After several months of coding here is the result of my work. The emulator has been
rewritten from scratch to adopt a plugin system. I've made this choice to open the
developpement to anyone who is interested in some part of the saturn hardware.
Keep in mind that I'm not a professional coder, hence don't expect this program to be
totaly bug-free.

## 1. How to use ##

You must put the plugins in their corresponding directory. After the first start of the
emu you must choose and eventually configure the plugins for each component.
Upon the first start you must also set the bios paths (satunr bios and stv bios) in the
options (menu options-> other options).

# machine mode #
You can select the machine emulated (saturn or ST-V) through this menu. In saturn mode
you can load a saturn binary to test your own saturn programs.

# the options #

You can activate the emulation of a 1Mb cartridge or 4Mb cartridge. With the standard
plugins it seems that no game using a RAM cartridge work.

You can modify the minimum number of cycles executed in one call by the SH2 plugin.
By increasing this value the emulation should be faster but less compatible, by decreasing
it the emulation should be slower but more compatible. The speed gain may vary depending on
the emulation technique used by the plugin.

You can alos modify the machine frequency to speed up emulation. Depending on the game
emulated it can affect the game behaviour.

## 2.Plugin developpement ##

You should find along with this emulator the plugin specifications. There is a header for
each component. I designed the plugin system to encapsulate the emulation of each saturn chip.
This may sounds unusual compared to other emulators but it can allow the design of plugins
using various emulation techniques for the same component.
If you think I should modify the plugin interfaces please let me know your thoughts  about
the subject.


For any question (except explanations about finding the bioses) use this email:
satourne@consollection.com.

P.S. : We are looking for people who can
- built a compatibility list for Sega Saturn games and Sega Titan Video games
- make screenshots of games
- develop plugin
- etc.
volunteer ? mail us at ben.j@consollection.com

Fabien
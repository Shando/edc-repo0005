SNESGT Ver 0.230 beta 7
Copyright (c)GIGO,Hii 2001-2011


--------------------
 System requirement
--------------------
 * Windows 2000/XP/Vista/7


--------------------
 Command line option
--------------------
 * -f Start up in fullscreen mode


--------------------
 Archive file
--------------------
 * Archive file is supported with 'Common Archivers Library' DLLs.

   Common Archivers Library
   http://www.csdinc.co.jp/archiver/index-e.html


--------------------
 Plugin support
--------------------
 * SNESGT supports VirtuaNES2 filter plugin and Kega Fusion render plugin.
   Put these plugins into 'plugin' directory. 

--------------------
  Contact
-----------
 url : http://gigo.retrogames.com/



		Dreamemu
	                 Version 0.03
                  Copyright (C) Lord Cheese 2000, 2001
                      http://dreamemu.emulation64.com

Dreamemu is an emulator for the Sega Dreamcast console
This version (0.03) was released on 3rd August 2001

++++++++++++++++++
Table of contents
++++++++++++++++++

1.  Disclaimer & Copyright
2.  What's New
3.  System Requirments
4.  Where To Get Required Software
5.  Using Dreamemu
6.  Known Issues
7. Contact & Feedback
8. History
9. Thanks & Greets

++++++++++++++++++++++++++
1. Disclaimer & Copyright
++++++++++++++++++++++++++

Dreamemu is strictly a non profit product. Dreamemu, or any part
therof, may not be sold commercially, for profit or otherwise.
It is not to be placed on media which contains illegal
Dreamcast GD-ROM/CD-ROM images. It is also not to be used in 
conjunction with illegal Dreamcast GD-ROM/CD-ROM images.

Sega, Dreamcast and the Dreamcast logo are either trademarks 
or registered trademarks of Sega Enterprises Ltd.

The author, Lord Cheese, is not responsible for any damages 
caused through the use of this software. You run this software
at your own risk, and the software is provided "AS IS" without 
a warrenty of any kind.

++++++++++++++
2. What's New
++++++++++++++

SH-4:
          Implemented FPU
          Fixed some sign problems
          Implemented basic timers (not done correctly yet)
          SCIF Faking
PowerVR:
          Support for 320x240 mode
Maple Bus (Control Interface):
          Implemented controllers (not perfect, but working)
GD-ROM:
         Implemented ISO9660 filesystem support (ISO Image support only)
Other:        
         Basic Plugin system (Controller Plugin only)
         Fixed INI file problem
         Added some new loading and gui options
Debugger:
        The program counter can now be set independantly by the user

++++++++++++++++++++++++
3. System Requirements
++++++++++++++++++++++++

Minimum System Requirment:
Dreamemu should run on any system that conforms to the following:

- x86 Processor (e.g. Intel/AMD CPUs)
- Win32 Operating System: Windows 95/98/98SE/ME/2000/NT or  compatible
- 16MB RAM or higher
- DirectX 8.0a or higher
- VGA or compatible video card

Recommended System Requirment:

- Pentium II/III/IV/Celeron class processor running at 350Mhz or higher
  OR AMD K6-3/Athlon/Duron running at 350MHz or higher
- 64MB RAM or higher

++++++++++++++++++++++++++++++++++
4. Where To Get Required Software
++++++++++++++++++++++++++++++++++

1. DirectX can be downloaded from http://www.microsoft.com/directx
2. A Win32 operating system can be bought in most computer stores.
   or you can order it online at http://www.microsoft.com
3. Dreamcast demos and freeware games can be downloaded at 
   http://www.julesdcdev.com (may be off-line). Also check out
   http://dreamcomp.emulation64.com, http://dcdev.allusion.net,
   http://www.dcemulation.com, http://www.boob.co.uk, among other sites.
4. IP.BINs and 1ST_READ.BINs/Bootfiles are the executable code 
   the Dreamcast processes. These will be contained in the software
   you download from these sites
5. ISO images of freeware software may be downloaded off these sites
    and others. To make your own, download CDRWIN from www.goldenhawk.com
    or get any other program that allows you to make ISO9660 images
6. Dreamcast emulator plugins, which should be provided with this package.
    For information on plugins, you should see their relevant readme files
7. A dreamcast BIOS which must be dumped yourself from your own dreamcast

++++++++++++++++
5. Using Dreamemu
++++++++++++++++

Firstly, set your desktop colour depth to 16bit. Dreamemu still does not support 32bit colour depth
accross all dreamcast modes. 
Next, run dreamemu and ignore any error messages about missing bios or plugins.
Then, configure your directorys using Settings->Directorys. Select your BIOS and the 
relevant plugins. Configure plugins (if you can do so) and restart dreamemu.
Now you are ready to use dreamemu.

Load an IP.BIN and/or bootfile and press start emulation.
If CD/GD filesystem support is required, you must also load an ISO image
of the files needed. Support for cd filesystem will be greatly improved in
future versions.

Note: Presently, you only need a BIOS to make sure the BIOS font displays properly.
It is not essential to run any software titles (however, text will not display if the program
uses the BIOS font). However, if you do not have a BIOS present, Dreamemu may crash 
unexpectedly.

Two executables are provided, dreamemu.exe and dreamemu_dbgr.exe. The latter
contains a debugger which is not documented in this document.

++++++++++++++
6. Known Issues
++++++++++++++

1. Sometimes, the emulator will crash after you exit it. Also, sometimes the program will remain
    in the task list (press Ctrl+Alt+Delete to access this and remove it if its there).
2. Dreamemu has crashed on Windows 2000 sometimes for me, although I can get Stars running. Some beta 
   testers have reported that it crashes on Windows 2000 and cant run anything at all!
3. Some beta testers have reported that it crashes on Win98 and Win98 SE. I have tested it on 
   Win98 it works fine for me.
4. RGB555 mode is implemented in the same way as RGB565 for the moment so the wrong colours will possibly show in this mode
5. If a software title requires cd-rom/gd-rom filesystem support, you must load both the ISO9660 image
    and the IP.BIN/Bootfiles for the software. The need for this will be removed soon (i.e., the IP.BIN and bootfiles
    will be loaded directly from the ISO image)
6. With DCPhoenix, the menu does not display long enough to make a selection. To run the game, once
    you see the menu appearing, just hammer the down key if you want the No Sound version.

+++++++++++++++++++++++
7. Contact & Feedback
+++++++++++++++++++++++

If you find any bugs in this program, or have any other useful 
feedback, please inform me, either by e-mail or IRC.

Queries such as "Where can i download ISOs?" will be ignored, 
and repeated questions of this nature will be forwarded to Sega 
Enterprises Ltd, who will punish you accordingly.

Also, please DO NOT e-mail me questions like:
"Do commercial games work" or
"How come XXX game dosn't work" or
"How do I get XXX game to work" or
"How do I make an ISO run with Dreamemu" etc.
These are EXTREMELY ANNOYING and are the main cause of why I
don't regularly reply to e-mails.

AND...Do not send me pictures of bugs or of "games that work" that 
are really doctored screenshots. I know what my emulator is capable
of, what it is not capable of and know roughly what sort of results it 
gives. I code the thing remember?!?

E-mail: dreamemu@emulation64.com
WWW: http://dreamemu.emulation64.com

IRC: #Dreamemu

Using IRC:
Go to http://www.mirc.com and download mIRC. Read the instructions,
and then logon to any EFnet server. Dreamemu's IRC channel name is,
surprise, surprise, #Dreamemu. To join type '/join #Dreamemu'
without the quotes and press Enter. If you can't get into #Dreamemu,
message me (lrdcheese) to give your feedback. To do this, type 
'/msg lrdcheese WHATEVER_YOU_WANT_TO_SAY' where 
WHATEVER_YOU_WANT_TO_SAY is whatever you want to say :)

++++++++++++
8. History
++++++++++++

Dreamemu v0.02
- released on:
- download: http://dreamemu.emulation64.com

Dreamemu v0.01
- released on:
- download: http://dreamemu.emulation64.com

++++++++++++++++++++
9. Thanks & Greets
++++++++++++++++++++

See Aboutbox

++++
EOF
Readme for Dreamemu Controller Plugin
version 0.03

******************************************
DIRECTX 8.0a NEEDED!!!
(although you may get away with 8.0)
*******************************************
controls:
Player 1:
Up: H
Down: N
Left: B
Right: M
A: X
B: C
X: S
Y: D
Left Trigger:   A
Right Trigger: F
Start V

Player 2:
Up: Up Arrow
Down: Down Arrow
Left: Left Arrow
Right: Right Arrow
A: J
B: K
X:U 
Y: I
Left Trigger: Y
Right Trigger: O
Start: L
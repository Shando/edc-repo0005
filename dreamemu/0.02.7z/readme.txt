			=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                                        Dreamemu  v0.02
	                        Copyright (C) Lord Cheese 2000, 2001
			=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

*************************
*TOC
*************************
1. Disclaimer & Copyright
2. What's New
3. How To Use
4. Known Bugs
5. Contact & Feedback

**************************
*1. Disclaimer & Copyright
**************************

Dreamemu is strictly a non profit product. Dreamemu, or any part therof, may not be sold
commercially, for profit or otherwise. It is not to be placed on media which contains illegal
Dreamcast GD-ROM/CD-ROM images. It is also not to be used in conjunction with illegal Dreamcast
GD-ROM/CD-ROM images.

Sega, Dreamcast and the Dreamcast logo are either trademarks or registered trademarks
of Sega Enterprises Ltd.

**************************
*3. What's New
**************************

SH-4 CPU:
	 Rewrote CPU Interpreter Core: Increased speed and accuracy
Graphics: 
	 2D Framebuffer: RGB565 mode implemented, graphics drawing speed increased, corrected screen update rate (still not accurate)
Debugger:
	 Disassembly: The amount of disassembly to process can now be controlled by the user.
		      The whole memory area does not need to be disassembled, although this is possible
 		      too. (Note: not all regions can be disasm'ed yet...have to rewrite the debugger so I didnt bother adding these in yet)
Emulator:
 	 Command Line: -lx command line option added
 	 Header Information: Got rid of the error message and correct device information is now shown
         Support for scrambled boot files added

IMPORTANT NOTE: Unlike the last release, in which you needed 32bit colour to run, in this release
	        you MUST set your desktop colour to 16bit. Setting it to 32bit wont crash Dreamemu,
		it will just show the wrong colours. Support for the different desktop colour depths
		will be added shortly.

New Software working: Stars Demo
                      640x80 example
		      argb8888 example (not showing correctly now)

There could be more...I havent tried much...please inform me if there is! 

**************************
*4.How To Use
**************************

Dreamcast demos and freeware demos can be downloaded at http://www.julesdcdev.com
The software that I have tested will be uploaded to the downloads section on the site.

General Use:
Unzip the zipfile to a directory, e.g. c:\dreamemu.
After reading through this text file, execute the Dreamemu.exe file.
Go to the "File" menu and select "Load IP.BIN".
In the dialog box that appears, select the desired IP.BIN and press 'Open'.
Errors are tracked in the status bar, the debug console, or through message boxes.
If the image was loaded succesfully, "Image loaded" should appear on the status bar.
Go to the "Emulation" menu and click "Start".
If no errors occur, Dreamemu will start emulating the file and the progress is shown on the 
status bar.
To stop emulation, click the Emulation->Stop menu item.

Debug Console:
A simple console to control dreamemu with. Some commands can only be executed through the debug
console, so it is worthwhile to look at its features and how to use it. 

How to use:
Type in the command in the text field and press 'Accept Command' (pressing enter won't work)
To exit Dreamemu quickly, just press the 'Exit' button
Dreamemu Console Commands:
debugger - launches the Dreamemu debugger (same as using Debug->Debugger)
help - displays a list of the present commands (prehaps more than here)
show breakpoint - shows a list of present breakpoints (debug console only)

console prefixes:
'>'       - this precedes a command that has been entered
'!'       - this denotes a successful command or process
'*'       - this is associated with an error. An error will cause Dreamemu to run 
            unpridictably or not at all. If an error occurs, it is recommened to 
	    restart Dreamemu and solve the error
'@'       - this denotes a warning. A warning is not as critical as an error, but may 
            lead to unpredictable results/crashes
no prefix - this usualy denotes a process, e.g. 'creating direct draw object...'. Processes
            end with three dots

Warning list:
'inappropriate colour depth warning' - this means that the colour depth you have selected in Windows 
                                       may not be sufficent for some of the Dreamcast's graphics modes.
                                       To solve, set the required colour depth as indicated my the 
                                       message box
'direct draw surface lost'           - indicates that Dreamemu has lost the current Direct Draw 
                                       surface. You must let Dreamemu to try and solve this error itself
'invalid image header warning'       - the IP.BIN you loaded is not a correct IP.BIN and may not work.
                                       Please note that even if you do not see this error, your IP.BIN 
                                       may be corrupted
'boot file not found'                - this indicates that the boot file specified in the IP.BIN 
                                       (commonly 1ST_READ.BIN) cannot be located. This means you will 
                                       only see the SEGA boot logo, and after that, you will see 
                                       'Breakpoint at 0x00000000' in the debug console, indictaing an
                                       invalid jump address caused by no 1ST_READ.BIN being present. 
                                       To solve, make sure you have the relevant boot file in the 
                                       directory you have the IP.BIN in.
Build Information label:
There is a label in the about dialog box telling you some information about the Dreamemu 
binary that you are holding:

Release Build/Debug Build
Private/Public Build
Version

Guide to Dreamemu's ini file settings:

[Settings]
Defaultdir: Selects the default directory for images. The directory in string form is used.
BootROM:    Selects the directory in which your BIOS image can be found (Note: not working)
AdvancePCOnUnhandled: Specifies if the CPU should continue after an unhandled instruction
WindowSizeWidth: The 'X' size of the video display area 
WindowSizeHeight: The 'Y' size of the video display area 
AutoScrollDebugOutput: Specifies if the debug output window should scroll down automatically after each message (slower)
ShowStatusbar: Specifies if the Statusbar should be shown (not working)
Scrambled: Specifies whether boot files should be taken as scrambled as default

[Default]
Alttitle: Specifies the default title
Comment: Specfies the default comment

Image Settings:
(The name of the image is specified in brakets)
Alttitle: An alternative name for the image. Default:  the title specified in the IP.BIN
Comment:  This is the comment that will be used to describe rom images if they are not
          described in a section of their own. Default: comment in [default] section.
Scrambled: Specifies if the boot file is scrambled

**************************
*5. Known Bugs
**************************

1. There was a crash on exit error, which it appears that I have fixed, but if it does crash on exit
   for you, I would like to hear from you.
2. If no 1ST_READ.BIN is loaded, 'Breakpoint at 0x00000000' will be displayed in the debug console,
   and emulation will stop. See the section on warnings above for more information.
3. Dreamemu has crashed on Windows 2000 sometimes for me, although I can get Stars running. Some beta 
   testers have reported that it crashes on Windows 2000 and cant run anything at all!
4. Some beta testers have reported that it crashes on Win98 and Win98 SE I have tested it on 
   Win98 it works fine for me.
5. RGB555 mode is implemented in the same way as RGB565 for the moment so the wrong colours will possibly show in this mode

**************************
6. Contact & Feedback
**************************

If you find any bugs in this program, or have any other useful feedback, please inform me, either 
by e-mail or IRC.

Queries such as "Where can i download ISOs?" will be ignored, and repeated questions of this 
nature will be forwarded to Sega Enterprises Ltd. 

e-mail: dreamemu@emulation64.com
WWW: http://dreamemu.emulation64.com

IRC: #Dreamemu

     Go to http://www.mirc.com and download mIRC. Read the instructions, and then logon to any EFnet server. Dreamemu's 
     IRC channel name is, surprise, surprise, #Dreamemu. To join type '/join #Dreamemu' without the      quotes and press Enter.
     If you can't get into #Dreamemu, message me (lrdcheese) to give your feedback. To do this, type 
     '/msg lrdcheese WHATEVER_YOU_WANT_TO_SAY' where WHATEVER_YOU_WANT_TO_SAY is whatever you want to say :)

EOF
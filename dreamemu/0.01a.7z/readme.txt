			=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                                        Dreamemu V 0.01a
	                        Copyright (C) Lord Cheese 2000
			=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

*************************
*TOC
*************************
1. Disclaimer & Copyright
2. What's New
3. How To Use
4. Known Bugs
5. Contact & Feedback

**************************
*1. Disclaimer & Copyright
**************************

Dreamemu is strictly a non profit product. Dreamemu, or any part therof, may not be sold
commercially, for profit or otherwise. It is not to be placed on media which contains illegal
Dreamcast GD-ROM/CD-ROM images. It is also not to be used in conjunction with illegal Dreamcast
GD-ROM/CD-ROM images.

Sega, Dreamcast and the Dreamcast logo are either trademarks or registered trademarks
of Sega Enterprises Ltd.

**************************
*3. What's New
**************************

Pretty much everthing since its a new release! :)

Almost full CPU emulation (approx. 30 opcodes need to be added)
FPU emulation started
Most PowerVR registers identifed and emulated
2D Graphics Output from VRAM using Direct Draw
Detailed Memory Map drawn up
Disassembler complete apart from FPU opcodes
Register debugger - contains some SH-4 Registers and PowerVR registers
Debug Console - basic debug console showing errors etc.
Translate instuction function from Hex to Mnemonic (some errors)
IP.BIN display and editor
Tiny Ini file

Because I wanted to release this week, somethings that I should
have implemented are not present (they are not major)
1. Some of the image information is not complete (only the information 
   on the far left is done)
2. You cannot switch resoulutions/screen sizes easily
3. Add 16/24 bit colour support
4. Reset Emulation does not work properly
5. Disasm/Memory/Registers displays arn't complete or laid out 
   in the best possible way.
6. Emulation is very slow.
7. Boot file descrambling support
8. SH-4 FPU/Serial interface/MMU etc.

There are others, and there are lots of things I have to improve/add
but expect some of these things in the next release, coming soon (I hope)!
Send your feedback to me please!

**************************
*4.How To Use
**************************

General Use:
Unzip the zipfile to a directory, e.g. c:\dreamemu.
After reading through this text file, execute the Dreamemu.exe file.
Go to the "File" menu and select "Load IP.BIN".
In the dialog box that appears, select the desired IP.BIN and press 'Open'.
Errors are tracked in the status bar, the debug console, or through message boxes.
If the image was loaded succesfully, "Image loaded" should appear on the status bar.
Go to the "Emulation" menu and click "Start".
If no errors occur, Dreamemu will start emulating the file and the progress is shown on the 
status bar.
To stop emulation, click the Emulation->Stop menu item.

Debug Console:
A simple console to control dreamemu with. Some commands can only be executed through the debug
console, so it is worthwhile to look at its features and how to use it. 

How to use:
Type in the command in the text field and press 'Accept Command' (pressing enter won't work)
To exit Dreamemu quickly, just press the 'Exit' button
Dreamemu Console Commands:
debugger - launches the Dreamemu debugger (same as using Debug->Debugger)
help - displays a list of the present commands (prehaps more than here)
show breakpoint - shows a list of present breakpoints (debug console only)

console prefixes:
'>'       - this precedes a command that has been entered
'!'       - this denotes a successful command or process
'*'       - this is associated with an error. An error will cause Dreamemu to run 
            unpridictably or not at all. If an error occurs, it is recommened to 
	    restart Dreamemu and solve the error
'@'       - this denotes a warning. A warning is not as critical as an error, but may 
            lead to unpredictable results/crashes
no prefix - this usualy denotes a process, e.g. 'creating direct draw object...'. Processes
            end with three dots

Warning list:
'inappropriate colour depth warning' - this means that the colour depth you have selected in Windows 
                                       may not be sufficent for some of the Dreamcast's graphics modes.
                                       To solve, set the required colour depth as indicated my the 
                                       message box
'direct draw surface lost'           - indicates that Dreamemu has lost the current Direct Draw 
                                       surface. You must let Dreamemu to try and solve this error itself
'invalid image header warning'       - the IP.BIN you loaded is not a correct IP.BIN and may not work.
                                       Please note that even if you do not see this error, your IP.BIN 
                                       may be corrupted
'boot file not found'                - this indicates that the boot file specified in the IP.BIN 
                                       (commonly 1ST_READ.BIN) cannot be located. This means you will 
                                       only see the SEGA boot logo, and after that, you will see 
                                       'Breakpoint at 0x00000000' in the debug console, indictaing an
                                       invalid jump address caused by no 1ST_READ.BIN being present. 
                                       To solve, make sure you have the relevant boot file in the 
                                       directory you have the IP.BIN in.
Build Information label:
There is a label in the about dialog box telling you some information about the Dreamemu 
binary that you are holding:

The string is divided as follows:
Build Type - Version - Build Number
For example:
Release - 0.01a - 543

This would mean that you are holding a release build, of version 0.01a, build number 543.

Guide to Dreamemu's ini file settings:
There should be no capital letters used unless otherwise stated (didn't bother to 
convert to upper/lower case). Places where caps can be used are in comments and alternative titles.

[settings]
defaultdir: Selects the default directory for rom images. The directory in string form is used.
            Default: c:\

[default]
comment: Specfies the default comment

Image Settings:
(The name of the image is specified in brakets)
alttitle: An alternative name for the image. Default:  the title specified in the IP.BIN
comment:  This is the comment that will be used to describe rom images if they are not
          described in a section of their own. Default: comment in [default] section.

**************************
*5. Known Bugs
**************************

1. There was a crash on exit error, which it appears that I have fixed, but if it does crash on exit
   for you, I would like to hear from you.
2. If no 1ST_READ.BIN is loaded, 'Breakpoint at 0x00000000' will be displayed in the debug console,
   and emulation will stop. See the section on warnings above for more information.

**************************
6. Contact & Feedback
**************************

If you find any bugs in this program, or have any other useful feedback, please inform me, either 
by e-mail or IRC.

Queries such as "Where can i download ISOs?" will be ignored, and repeated questions of this 
nature will be forwarded to Sega Enterprises Ltd. 

e-mail: dreamemu@emulation64.com
WWW: http://dreamemu.emulation64.com

IRC: Go to http://www.mirc.com and download mIRC. Read the instructions, and then logon to any EFnet server. Dreamemu's 
     IRC channel name is, surprise, surprise, #Dreamemu. To join type '/join #Dreamemu' without the      quotes and press Enter.
     If you can't get into #Dreamemu, message me (lrdcheese) to give your feedback. To do this, type 
     '/msg lrdcheese WHATEVER_YOU_WANT_TO_SAY' where WHATEVER_YOU_WANT_TO_SAY is what you want to say :)

EOF
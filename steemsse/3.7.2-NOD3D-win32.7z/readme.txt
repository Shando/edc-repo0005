This build of Steem SSE doesn't require DirectX 9.
Please copy other files from regular build.
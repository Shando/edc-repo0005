#include "stdafx.h"
#include "resource.h"
#include "SystemInfo.h"
#include "../Core/CPU.h"
#include "../Core/System.h"


SystemInfo *systemInfo;


SystemInfo::SystemInfo(HINSTANCE _hInstance, HWND _hParent) : Dialog((LPCSTR)IDD_SYSTEM,_hInstance,_hParent)
{

}


SystemInfo::~SystemInfo()
{

}


void SystemInfo::Update()
{

}


BOOL SystemInfo::DlgProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) 
	{
	case WM_INITDIALOG:
		{

		}
		return TRUE;

	case WM_COMMAND:
		return TRUE;

	case WM_CLOSE:
		Show(false);
		return TRUE;
	}
	return FALSE;
}


#include "stdafx.h"

#include "IniFile.h"

namespace W32Util
{
	IniFile::IniFile()
	{
	}
	IniFile::~IniFile()
	{
	}
	void IniFile::SetFile(const TCHAR *_filename)
	{
		if (_filename)
		{
			char path_buffer[_MAX_PATH], drive[_MAX_DRIVE] ,dir[_MAX_DIR];
			char fname[_MAX_FNAME],ext[_MAX_EXT];

			GetModuleFileName(NULL,path_buffer,sizeof(path_buffer));
			_splitpath( path_buffer, drive, dir, fname, ext );
			_makepath( filename, drive, dir, _filename, ".ini");
		}
	}
	void IniFile::SetSection(const TCHAR *_section)
	{
		_tcscpy(section,_section);
	}
	int  IniFile::ReadInt    (const TCHAR *key, int def)
	{
		return GetPrivateProfileInt(section, key, def, filename);
	}
	void IniFile::WriteInt   (const TCHAR *key, int value)
	{
		char temp[256];
		WritePrivateProfileString(section, key, itoa(value,temp,10), filename);	
	}
	bool IniFile::ReadBool   (const TCHAR *key, bool def)
	{
		return ReadInt(key,def?1:0) == 0 ? false : true;
	}
	void IniFile::WriteBool  (const TCHAR *key, bool value)
	{
		WriteInt(key,value?1:0);
	}
	void IniFile::ReadString (const TCHAR *key, const TCHAR *def, TCHAR *out, int size)
	{
		GetPrivateProfileString(section, key, def, out, size, filename);	
	}
	void IniFile::WriteString(const TCHAR *key, const TCHAR *value)
	{
		WritePrivateProfileString(section, key, value, filename);	
	}
	
	void IniFile::ReadStringList(const TCHAR *key, std::vector<std::string> &list)
	{
		int count = ReadInt(key);
		for (int i=0; i<count; i++)
		{
			char temp[256], temp2[256]; 
			sprintf(temp,"%s%i",key,i);
			ReadString(temp,"",temp2,256);
			list.push_back(std::string(temp2));
		}
	}
	void IniFile::WriteStringList(const TCHAR *key, std::vector<std::string> &list)
	{
		WriteInt(key,(int)list.size());
		int i=0;
		for (std::vector<std::string>::iterator iter = list.begin(); iter!=list.end(); iter++)
		{
			char temp[256];
			sprintf(temp,"%s%i",key,i);
			WriteString(temp,iter->c_str());
			i++;
		}
	}

	void LoadWindowPos(const TCHAR * key, HWND wnd)
	{

	}
	void SaveWindowPos(const TCHAR * key, HWND wnd)
	{

	}

}
#pragma once

#include <vector>
#include <string>

namespace W32Util
{
	class IniFile
	{
		TCHAR filename[512];
		TCHAR section[256];
	public:
		IniFile();
		~IniFile();
		
		void SetFile(const TCHAR *fname);
		void SetSection(const TCHAR *section);

		int  ReadInt    (const TCHAR *key, int def = 0);
		void WriteInt   (const TCHAR *key, int value);
		bool ReadBool   (const TCHAR *key, bool def = false);
		void WriteBool  (const TCHAR *key, bool value);
		void ReadString (const TCHAR *key, const TCHAR *def, TCHAR *out, int size = 255);
		void WriteString(const TCHAR *key, const TCHAR *value);
		void ReadStringList (const TCHAR *key, std::vector<std::string> &list);
		void WriteStringList(const TCHAR *key, std::vector<std::string> &list);
		void LoadWindowPos  (const TCHAR *key, HWND wnd);
		void SaveWindowPos  (const TCHAR *key, HWND wnd);
	};
}
#include "stdafx.h"
#include "misc.h"
#include "../imgdecoder.h"

namespace W32Util
{
	/** @author Rui Godinho Lopes <ruiglopes@yahoo.com>
	*/
	void PreMultiplyRGBChannels(HBITMAP bmp, LPBYTE pBitmapBits)
	{
		BITMAP bmpInfo;
		::GetObject(bmp, sizeof(BITMAP), &bmpInfo);
		// pre-multiply rgb channels with alpha channel
		for (int y=0; y<bmpInfo.bmHeight; ++y)
		{
			BYTE *pPixel= pBitmapBits + bmpInfo.bmWidth * 4 * y;

			for (int x=0; x<bmpInfo.bmWidth ; ++x)
			{
				pPixel[0]= pPixel[0]*pPixel[3]/255;
				pPixel[1]= pPixel[1]*pPixel[3]/255;
				pPixel[2]= pPixel[2]*pPixel[3]/255;
				pPixel+= 4;
			}
		}
	}

#ifndef _M_X64

	LayeredWindow::LayeredWindow(HWND _wnd) : wnd(_wnd)
	{
		m_pImgDecoder=0;
		m_pImg=0;
		m_bmpDialog=0;
	}
	LayeredWindow::~LayeredWindow()
	{
	}

	void LayeredWindow::Update(HBITMAP bmp, BYTE SourceConstantAlpha/*= 255*/)
	{
		DWORD style = GetWindowLong(wnd, GWL_STYLE);
		SetWindowLong(wnd, GWL_EXSTYLE, style | WS_EX_LAYERED);
		// make sure the window has the WS_EX_LAYERED style
		//wnd.ModifyStyleEx(0, WS_EX_LAYERED);
		// ok... into the per-pixel-alpha bendling....
		// Create/setup the DC's
		HDC dcScreen = ::GetDC(NULL);
		HDC dcMemory = CreateCompatibleDC(dcScreen);
		HBITMAP oldBitmap = (HBITMAP)SelectObject(dcMemory, bmp);
		// get the bitmap dimensions
		SIZE szWindow;
		BITMAP bmpInfo;
		::GetObject(bmp, sizeof(BITMAP), &bmpInfo);

		szWindow.cx = bmpInfo.bmWidth;
		szWindow.cy = bmpInfo.bmHeight;
		
		// get the window rectangule (we are only interested in the top left position)
		RECT rectDlg;
		GetWindowRect(wnd, &rectDlg);
		// calculate the new window position/size based on the bitmap size
		POINT ptWindowScreenPosition = {rectDlg.left,rectDlg.top};
		// Perform the alpha blend
		// setup the blend function
		BLENDFUNCTION blendPixelFunction= { AC_SRC_OVER, 0, SourceConstantAlpha, AC_SRC_ALPHA };
		POINT ptSrc={0,0}; // start point of the copy from dcMemory to dcScreen
		// perform the alpha blend
		BOOL bRet= ::UpdateLayeredWindow(wnd, dcScreen, &ptWindowScreenPosition, &szWindow, dcMemory,
			&ptSrc, 0, &blendPixelFunction, ULW_ALPHA);
		if (!bRet)
		{
			MessageBox(0,"FALIURE",0,0);
		}
		SelectObject(dcMemory, oldBitmap); // clean up
		ReleaseDC(NULL, dcScreen);
		ReleaseDC(NULL, dcMemory);
	}


	void LayeredWindow::Unload()
	{
		if (m_pImgDecoder)
		{
			DWORD style = GetWindowLong(wnd, GWL_STYLE);
			SetWindowLong(wnd, GWL_EXSTYLE, style & ~WS_EX_LAYERED);
			DeleteObject(m_bmpDialog);
			::ImgDeleteDIBSection(m_pImg);
			::ImgDeleteDecoder(m_pImgDecoder);
		}
		m_pImg=0;
		m_bmpDialog=0;
		m_pImgDecoder=0;
	}


	void LayeredWindow::LoadBackground(LPCTSTR pFileName)
	{
		if (m_pImgDecoder)
			return;
		HBITMAP hBitmap;
		LPBYTE pBitmapBits;
		LPVOID pImg = NULL;

		::ImgNewDecoder(&m_pImgDecoder);

		// first try to load with paintlib....
		if (0 == ::ImgNewDIBFromFile(m_pImgDecoder, pFileName, &pImg))
		{
			::ImgGetHandle(pImg, &hBitmap, (LPVOID *)&pBitmapBits);

			// get the bitmap info
			BITMAP bmpInfo;
			::GetObject(hBitmap, sizeof(BITMAP), &bmpInfo);

			if (bmpInfo.bmBitsPixel != 32)
			{
				::ImgDeleteDIBSection(pImg);
				::MessageBox(0,"ERROR: Skin bitmap not 32-bit with alpha channel",0,0);
				return;
			}
		}
		else // ops... paitlib fail to load file... maybe is an PSP file?
		{
			::MessageBox(0,"ERROR: Unrecognized skin bitmap",0,0);
			return;
		}

		m_pImg = pImg;
		m_bmpDialog = hBitmap;
		// before using the UpdateLayeredWindow we have to 
		// pre-multiply the RGB channels with the alpha channel
		PreMultiplyRGBChannels(m_bmpDialog, pBitmapBits);
		// now update the dummy dialog....
		Update(m_bmpDialog, 255);
	}
#endif
	//don't call
	void testops()
	{
#if 0
		__asm 
		{ 
			test eax,0x40000003
			test ecx,0x40000003
			test ebx,0x40000003
			test edx,0x40000003
		}
#endif
	}
	//shamelessly taken from http://www.catch22.org.uk/tuts/tips.asp
	void CenterWindow(HWND hwnd)
	{
		HWND hwndParent;
		RECT rect, rectP;
		int width, height;      
		int screenwidth, screenheight;
		int x, y;

		//make the window relative to its parent
		hwndParent = GetParent(hwnd);
		if (!hwndParent)
			return;

		GetWindowRect(hwnd, &rect);
		GetWindowRect(hwndParent, &rectP);
        
		width  = rect.right  - rect.left;
		height = rect.bottom - rect.top;

		x = ((rectP.right-rectP.left) -  width) / 2 + rectP.left;
		y = ((rectP.bottom-rectP.top) - height) / 2 + rectP.top;

		screenwidth  = GetSystemMetrics(SM_CXSCREEN);
		screenheight = GetSystemMetrics(SM_CYSCREEN);
    
		//make sure that the dialog box never moves outside of
		//the screen
		if(x < 0) x = 0;
		if(y < 0) y = 0;
		if(x + width  > screenwidth)  x = screenwidth  - width;
		if(y + height > screenheight) y = screenheight - height;

		MoveWindow(hwnd, x, y, width, height, FALSE);
	}

	HBITMAP CreateBitmapFromARGB(HWND someHwnd, DWORD *image, int w, int h)
	{
		BITMAPINFO *bitmap_header;
		static char bitmapbuffer[sizeof(BITMAPINFO)+16];
		memset(bitmapbuffer,0,sizeof(BITMAPINFO)+16);
		bitmap_header=(BITMAPINFO *)bitmapbuffer;
		bitmap_header->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
		bitmap_header->bmiHeader.biPlanes = 1;
		bitmap_header->bmiHeader.biBitCount = 32;
		bitmap_header->bmiHeader.biCompression = BI_RGB;
		bitmap_header->bmiHeader.biWidth = w;
		bitmap_header->bmiHeader.biHeight = -h;

		((unsigned long *)bitmap_header->bmiColors)[0] = 0x00FF0000;
		((unsigned long *)bitmap_header->bmiColors)[1] = 0x0000FF00;
		((unsigned long *)bitmap_header->bmiColors)[2] = 0x000000FF;

		HDC dc = GetDC(someHwnd);
		HBITMAP bitmap = CreateDIBitmap(dc,&bitmap_header->bmiHeader,CBM_INIT,image,bitmap_header,DIB_RGB_COLORS);
		ReleaseDC(someHwnd,dc);
		return bitmap;
	}	
 
	void NiceSizeFormat(size_t size, char *out)
	{
		char *sizes[] = {"B","KB","MB","GB","TB","PB","EB"};
		int s = 0;
		int frac = 0;
		while (size>=1024)
		{
			s++;
			frac = (int)size & 1023;
			size /= 1024;
		}
		float f = (float)size + ((float)frac / 1024.0f);
		if (s==0)
			sprintf(out,"%d B",size);
		else
			sprintf(out,"%3.1f %s",f,sizes[s]);
	}
	BOOL CopyTextToClipboard(HWND hwnd, TCHAR *text)
	{
		OpenClipboard(hwnd);
		EmptyClipboard();
		HANDLE hglbCopy = GlobalAlloc(GMEM_MOVEABLE, (strlen(text) + 1) * sizeof(TCHAR)); 
		if (hglbCopy == NULL) 
		{ 
			CloseClipboard(); 
			return FALSE; 
		} 

		// Lock the handle and copy the text to the buffer. 

		TCHAR *lptstrCopy = (TCHAR *)GlobalLock(hglbCopy); 
		strcpy(lptstrCopy, text); 
		lptstrCopy[strlen(text)] = (TCHAR) 0;    // null character 
		GlobalUnlock(hglbCopy); 
		SetClipboardData(CF_TEXT,hglbCopy);
		CloseClipboard();
		return TRUE;
	}

}
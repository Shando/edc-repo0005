#pragma once

namespace W32Util
{
	void CenterWindow(HWND hwnd);
	HBITMAP CreateBitmapFromARGB(HWND someHwnd, DWORD *image, int w, int h);
	void NiceSizeFormat(size_t size, char *out);
	BOOL CopyTextToClipboard(HWND hwnd, TCHAR *text);
#ifndef _M_X64
	class LayeredWindow
	{
		HWND wnd;
		LPVOID m_pImg;
		HBITMAP m_bmpDialog;
		LPVOID m_pImgDecoder;
		void Update(HBITMAP bmp, BYTE SourceConstantAlpha);

	public:
		LayeredWindow(HWND _wnd);
		~LayeredWindow();
		void LoadBackground(LPCTSTR pFileName);
		void Unload();
	};
#endif
}
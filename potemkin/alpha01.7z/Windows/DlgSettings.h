#pragma once

void dlgSettings_Run(HINSTANCE _hInstance, HWND _hParent, int page);
void dlgConfWiz_Run(HINSTANCE _hInstance, HWND _hParent);


#pragma once

#include "Debugger/Debugger_Disam.h"
#include "Debugger/Debugger_MemoryDlg.h"
#include "Debugger/Debugger_DynaViewDlg.h"

extern CDisasm *disasmWindow[MAX_CPUCOUNT];
extern CMemoryDlg *memoryWindow[MAX_CPUCOUNT];
extern CDynaViewDlg *dynaWindow[MAX_CPUCOUNT];

extern HMENU g_hPopupMenus;
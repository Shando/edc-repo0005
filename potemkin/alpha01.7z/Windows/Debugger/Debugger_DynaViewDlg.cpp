/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <windowsx.h>
#include "..\resource.h"
#include <commctrl.h>

#include "../../Core/Debugger/SymbolMap.h"
#include "Debugger_DynaViewDlg.h"
#include "../main.h"
//TEMPORARY
#include "../../Core/MIPS/MIPS.h"
#include "../../Core/MIPS/MIPSCompiler.h"
#include "../../Core/MIPS/MIPSBlockCache.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////
// I M P L E M E N T A T I O N //////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////
// I M P L E M E N T A T I O N //////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

// __________________________________________________________________________________________________
// constructor 
//
CDynaViewDlg::CDynaViewDlg(HINSTANCE _hInstance, HWND _hParent, CPU *_cpu) : Dialog((LPCSTR)IDD_DYNAVIEW, _hInstance,_hParent)
{
	//
	// --- build dialog ---
	//
	debint = 0;
	cpu = _cpu;
	TCHAR temp[256];
	sprintf(temp,"Dynarec Viewer - %s",cpu->GetName());
	SetWindowText(m_hDlg,temp);
	ShowWindow(m_hDlg,SW_HIDE);
	//CtrlMemView *ptr = CtrlMemView::getFrom(GetDlgItem(m_hDlg,IDC_MEMVIEW));

//	debint = new ARMDebugInterface(cpu);
	//ptr->setDebugger(debint);

	//Button_SetCheck(GetDlgItem(m_hDlg,IDC_RAM), TRUE);
	//Button_SetCheck(GetDlgItem(m_hDlg,IDC_MODESYMBOLS), TRUE);

//	GetWindowRect(GetDlgItem(m_hDlg,IDC_SYMBOLS),&slRect);
	m_hListView = GetDlgItem(m_hDlg, IDC_BLOCKLIST);
	ListView_SetExtendedListViewStyleEx(m_hListView,0,
		LVS_EX_GRIDLINES|LVS_EX_TRACKSELECT|LVS_EX_LABELTIP);


	LVCOLUMN lvc;
    lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM; 
	lvc.iSubItem = 0;
	lvc.pszText = "Num.";
	lvc.cx = 30;
	lvc.fmt = LVCFMT_RIGHT;
	ListView_InsertColumn(m_hListView, 0, &lvc);
	lvc.iSubItem = 1;
	lvc.pszText = "Function";
	lvc.cx = 120;
	lvc.fmt = LVCFMT_LEFT;
	ListView_InsertColumn(m_hListView, 1, &lvc);
	lvc.cx = 70;
	lvc.iSubItem = 2;
	lvc.pszText = "Address";
	ListView_InsertColumn(m_hListView, 2, &lvc);
	lvc.cx = 40;
	lvc.iSubItem = 3;
	lvc.fmt = LVCFMT_RIGHT;
	lvc.pszText = "MIPS";
	ListView_InsertColumn(m_hListView, 3, &lvc);
	lvc.cx = 40;
	lvc.iSubItem = 4;
	lvc.pszText = "x86";
	ListView_InsertColumn(m_hListView, 4, &lvc);
	lvc.cx = 40;
	lvc.iSubItem = 5;
	lvc.pszText = "Ratio";
	ListView_InsertColumn(m_hListView, 5, &lvc);
	lvc.cx = 60;
	lvc.iSubItem = 6;
	lvc.pszText = "Hits";
	ListView_InsertColumn(m_hListView, 6, &lvc);
	Update();
	
	ListView_SetExtendedListViewStyle(m_hListView,LVS_EX_FULLROWSELECT);
	Size();
}


CDynaViewDlg::~CDynaViewDlg(void)
{
	delete debint;
}

void CDynaViewDlg::Update(void)
{
	if (m_hDlg != NULL)
	{
		int sel = ListView_GetSelectionMark(m_hListView);
		int topIndex = ListView_GetTopIndex(m_hListView);
		ListView_DeleteAllItems(m_hListView);
		LVITEM lvi;
		ZeroMemory(&lvi, sizeof(LVITEM));
		lvi.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM;/// | LVIF_STATE
		lvi.lParam = 0;

		int numBlocks = MIPSComp::GetNumBlocks();
		for (int i=0; i<numBlocks; i++)
		{
			u32 addr = MIPSComp::GetBlockAddr(i);
			int hits = MIPSComp::GetNumHits(i); //TODO
			int symbol = Debugger_GetSymbolNum(addr, ST_FUNCTION);
			const char *name = "?";
			if (symbol != -1)
				name = Debugger_GetSymbolName(symbol);

			int size = MIPSComp::GetBlockSize(i),
				compSize = MIPSComp::GetBlockCompiledSize(i);
			char temp[256];
			sprintf(temp, "%i", i);
			lvi.pszText = temp;
			lvi.iItem = i;
			int idx = (int)SendMessage(m_hListView, LVM_INSERTITEM, 0, (LPARAM)(const LV_ITEM *)(&lvi));
			sprintf(temp, "%s", name);
			ListView_SetItemText(m_hListView,idx,1,temp);
			sprintf(temp, "%08x", addr);
			ListView_SetItemText(m_hListView,idx,2,temp);
			sprintf(temp, "%d", size);
			ListView_SetItemText(m_hListView,idx,3,temp);
			sprintf(temp, "%d", compSize);
			ListView_SetItemText(m_hListView,idx,4,temp);
			sprintf(temp, "%f", (float)compSize/(float)size);
			ListView_SetItemText(m_hListView,idx,5,temp);
			sprintf(temp, "%d", hits);
			ListView_SetItemText(m_hListView,idx,6,temp);
		//	UpdateItem(idx);
		}
		if (sel!=-1)
			ListView_SetSelectionMark(m_hListView,sel);
		else
			ListView_SetSelectionMark(m_hListView,0);
//		ListView_SetTopIndex(m_hListView, topIndex);

	}	
}

void CDynaViewDlg::NotifyMapLoaded()
{
	if (m_hDlg)
	{
	}
	Update(); 
}


BOOL CDynaViewDlg::DlgProc(UINT message, WPARAM wParam, LPARAM lParam)
{

	switch(message)
	{
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case IDC_UPDATE:
				Update();
				break;
			}
		}
		break;
	case WM_NOTIFY:
		{
			NMITEMACTIVATE *nm = (NMITEMACTIVATE *)lParam;
			if (nm->hdr.idFrom == IDC_BLOCKLIST)
			{
				switch (nm->hdr.code)
				{
				case LVN_COLUMNCLICK:
					//sort here
					break;
				case LVN_ITEMCHANGED:
				case LVN_ITEMACTIVATE:
				case LVN_MARQUEEBEGIN:
				case NM_CLICK:
					{
						Display(ListView_GetSelectionMark(m_hListView));
					//dontFillList =true;
					//Update();
					//dontFillList =false;
					}
					break;
				case NM_DBLCLK:
					{
						int sel = ListView_GetSelectionMark(m_hListView);
						u32 addr = MIPSComp::GetBlockAddr(sel);
						for (int i=0; i<numCPUs; i++)
							if (disasmWindow[i])
								disasmWindow[i]->Goto(addr);
					}
					break;
				case NM_RCLICK:
					{
						POINT pt;
						GetCursorPos(&pt);
						//TrackPopupMenuEx(GetSubMenu(g_hPopupMenus,1),TPM_RIGHTBUTTON,pt.x,pt.y,m_hDlg,0);
					}

					break;
				}
			}
		}
		break;
	case WM_USER+1:
		NotifyMapLoaded();
		break;
	case WM_INITDIALOG:
		{
			return TRUE;
		}
		break;
	case WM_SIZE:
		Size();
		break;
		
	case WM_CLOSE:
		Show(false);
		break;
	}
		
	return FALSE;
}

void CDynaViewDlg::Display(int blockNum)
{
static char temp[32768];
	if (blockNum != -1)
	{
		MIPSComp::DisassembleBlock(blockNum, temp);
		SetWindowText(GetDlgItem(m_hDlg,IDC_EMULATEDASM),temp);
		MIPSComp::DisassembleCompiledBlock(blockNum, temp);
		SetWindowText(GetDlgItem(m_hDlg,IDC_NATIVEASM),temp);
	}
	else
	{
		LOG(CPU,"Block %i not found",blockNum);
	}

}


void CDynaViewDlg::Goto(u32 addr)
{
	static int lastCount = -1;
	int numBlocks = MIPSComp::GetNumBlocks();
	if (numBlocks != lastCount)
	{
		Update();
		lastCount = numBlocks;
	}
	Show(true);
	int blockNum = MIPSComp::GetBlockNumFromAddr(addr);
	Display(blockNum);
	ListView_SetSelectionMark(m_hListView, blockNum);
	ListView_SetItemState(m_hListView,blockNum,LVIS_SELECTED,LVIS_SELECTED);
	ListView_EnsureVisible(m_hListView,blockNum,FALSE);
//	CtrlMemView *mv = CtrlMemView::getFrom(GetDlgItem(CDynaViewDlg::m_hDlg,IDC_MEMVIEW));
//	mv->gotoAddr(addr & ~3);
}


void CDynaViewDlg::Size()
{
	/*
	RECT rc;
	GetClientRect(m_hDlg,&rc);
	int dw=rc.right-rc.left;
	int dh=rc.bottom-rc.top;
	HWND memView = GetDlgItem(m_hDlg, IDC_MEMVIEW);
	HWND symList = GetDlgItem(m_hDlg, IDC_SYMBOLS);
	int wf = slRect.right-slRect.left;
	int w = dw-3-wf;
	int top = 48;
	MoveWindow(symList,0,top,wf,dh-top,TRUE);
	MoveWindow(memView,wf+4,top,w,dh-top,TRUE)*/
}

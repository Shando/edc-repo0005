/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <windowsx.h>
#include <commctrl.h>

#include "../resource.h"

#include "../../Core/MemMap.h"

#include "Debugger_MemSearchDlg.h"
#include "CtrlMemView.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////
// I M P L E M E N T A T I O N //////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

CMemSearchDlg *memsearchdlg;

/////////////////////////////////////////////////////////////////////////////////////////////////////
// I M P L E M E N T A T I O N //////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

// __________________________________________________________________________________________________
// constructor 
//
CMemSearchDlg::CMemSearchDlg(HINSTANCE _hInstance, HWND _hParent) : Dialog((LPCSTR)IDD_MEMSEARCH,_hInstance,_hParent)
{
	Size();
	ShowWindow(m_hDlg,SW_HIDE);

	m_hListView = GetDlgItem(m_hDlg , IDC_SEARCHRESULTS);

	LVCOLUMN lvc;
	lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM; 
	lvc.iSubItem = 0;
	lvc.pszText = "Address";
	lvc.cx = 70;
	lvc.fmt = LVCFMT_LEFT;
	ListView_InsertColumn(m_hListView, 0, &lvc);
	lvc.cx = 200;
	lvc.iSubItem = 1;
	lvc.pszText = "Symbol";
	ListView_InsertColumn(m_hListView, 1, &lvc);
	ListView_SetExtendedListViewStyle(m_hListView,LVS_EX_FULLROWSELECT);

	SetWindowText(GetDlgItem(m_hDlg ,IDC_SEARCHRANGESTART),"02000000");
	SetWindowText(GetDlgItem(m_hDlg ,IDC_SEARCHRANGEEND),"023fffff");

	//GetWindowRect(GetDlgItem(m_hDlg,IDC_SYMBOLS),&slRect);
	//Size();
}

CMemSearchDlg::~CMemSearchDlg()
{

}

void 
CMemSearchDlg::Update(void)
{
	/*
	HWND m_hDlg = m_pWinDialog->GetDialogHandle();
	HWND list = GetDlgItem(m_hDlg,IDC_SYMBOLS);
	Debugger_FillSymbolListBox(list,ST_DATA);	
	*/
}

BOOL  
CMemSearchDlg::DlgProc(UINT message, WPARAM wParam, LPARAM lParam)
{

	switch(message)
	{
	case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
			case IDC_SEARCH: 
				{
					char temp[256];
					u32 value,start,end;
					GetWindowText(GetDlgItem(m_hDlg,IDC_SEARCHFOR),temp,255);
					sscanf(temp,"%08x",&value);
					GetWindowText(GetDlgItem(m_hDlg,IDC_SEARCHRANGESTART),temp,255);
					sscanf(temp,"%08x",&start);
					GetWindowText(GetDlgItem(m_hDlg,IDC_SEARCHRANGEEND),temp,255);
					sscanf(temp,"%08x",&end);
					sprintf(temp,"%08x %08x %08x",value,start,end);
					//MessageBox(m_hDlg,temp,"sfd",0);
					for (u32 addr = start; addr<=end; addr+=4)
					{
						if (ReadMem32Unchecked(addr) == value)
						{
							char temp[256];
							sprintf(temp,"%08x",addr);
							LVITEM lvi;
							lvi.mask = LVIF_TEXT /* | LVIF_STATE*/; 
							memset(&lvi,0,sizeof(lvi));
							lvi.pszText = temp;
							
							int idx =(int)SendMessage(m_hListView, LVM_INSERTITEM, 0, (LPARAM)(const LV_ITEM *)(&lvi));
							ListView_SetItemText(m_hListView,idx,1,temp);
//							ListView_SetItemText(m_hListView,idx,2,iso.name);
							//add to list
						}
					}
				}
				break;
			case IDCANCEL:
				Show(false);
				break;
			}
		}
		break;
	case WM_INITDIALOG:
		{
			return TRUE;
		}
		break;
	case WM_SIZE:
		Size();
		break;
		
	case WM_CLOSE:
		Show(false);
		break;
	}
		
	return FALSE;
}


void CMemSearchDlg::Size()
{
	RECT rc;
	GetClientRect(m_hDlg,&rc);
	int dw=rc.right-rc.left;
	int dh=rc.bottom-rc.top;

	HWND list = GetDlgItem(m_hDlg, IDC_SEARCHRESULTS);
	int left = 192;
	MoveWindow(list,left,0,dw-left,dh,TRUE);
	/*
	RECT rc;
	HWND m_hDlg = m_pWinDialog->GetDialogHandle();
	GetClientRect(m_hDlg,&rc);
	int dw=rc.right-rc.left;
	int dh=rc.bottom-rc.top;
	HWND memView = GetDlgItem(m_hDlg, IDC_MEMVIEW);
	HWND symList = GetDlgItem(m_hDlg, IDC_SYMBOLS);
	int wf = slRect.right-slRect.left;
	int w = dw-3-wf;
	int top = 48;
	MoveWindow(symList,0,top,wf,dh-top,TRUE);
	MoveWindow(memView,wf+4,top,w,dh-top,TRUE);
*/
}
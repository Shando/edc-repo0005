/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "../W32Util/DialogManager.h"

#include "../../Core/MemMap.h"
#include "../../Core/CPU.h"
#include "../../Core/System.h" 

#include "DebugInterface.h"

class CDynaViewDlg : public Dialog
{
private:
	CPU *cpu;

	BOOL DlgProc(UINT message, WPARAM wParam, LPARAM lParam);
	DebugInterface *debint;		
	HWND m_hListView;
public:
	int index; //helper 

	// constructor
	CDynaViewDlg(HINSTANCE _hInstance, HWND _hParent, CPU *_cpu);
	
	// destructor
	~CDynaViewDlg(void);
	
	void Goto(u32 addr);
	void Display(int blockNum);
	void Update(void);	
	void NotifyMapLoaded();

	void Size(void);
};



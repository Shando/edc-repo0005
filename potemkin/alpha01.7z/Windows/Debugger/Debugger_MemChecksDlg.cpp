/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <windowsx.h>
#include "..\resource.h"
#include <commctrl.h>

//#include "../PowerPC/PowerPC.h"

#include "../../Core/Debugger/Breakpoints.h"
#include "Debugger_MemChecksDlg.h"
#include "../../Core/Debugger/SymbolMap.h"
#include "../Main.h"
#include "CtrlMemView.h"

#ifdef THEMES
#include "../XPTheme.h"
#endif

/////////////////////////////////////////////////////////////////////////////////////////////////////
// I M P L E M E N T A T I O N //////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

bool dontFillList = false;
CMemChecksDlg *memcheckdlg;
/////////////////////////////////////////////////////////////////////////////////////////////////////
// I M P L E M E N T A T I O N //////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

// __________________________________________________________________________________________________
// constructor 
//

CMemChecksDlg::CMemChecksDlg(HINSTANCE _hInstance, HWND _hParent) : Dialog((LPCSTR)IDD_MEMCHECKS,_hInstance,_hParent)
{
	// --- build dialog ---
	//

#ifdef THEMES
	if (WTL::CTheme::IsThemingSupported())
		EnableThemeDialogTexture(m_hDlg,ETDT_ENABLETAB);
#endif
	ShowWindow(m_hDlg,FALSE);

	m_hListView = GetDlgItem(m_hDlg, IDC_MEMCHECKS);
	LVCOLUMN lvc;
    lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM; 
	lvc.iSubItem = 0;
	lvc.pszText = "Range";
	lvc.cx = 120;
	lvc.fmt = LVCFMT_LEFT;
	ListView_InsertColumn(m_hListView, 0, &lvc);
	lvc.cx = 100;
	lvc.iSubItem = 1;
	lvc.pszText = "Symbol";
	ListView_InsertColumn(m_hListView, 1, &lvc);
	lvc.cx = 40;
	lvc.iSubItem = 2;
	lvc.pszText = "Conditions";
	ListView_InsertColumn(m_hListView, 2, &lvc);
	lvc.cx = 40;
	lvc.iSubItem = 3;
	lvc.pszText = "Action";
	ListView_InsertColumn(m_hListView, 3, &lvc);
	lvc.cx = 50;
	lvc.iSubItem = 4;
	lvc.pszText = "Hits";
	ListView_InsertColumn(m_hListView, 4, &lvc);
	Update();

	ListView_SetExtendedListViewStyle(m_hListView,LVS_EX_FULLROWSELECT);
	
	FillList();
}

// __________________________________________________________________________________________________
// destructor 
//
CMemChecksDlg::~CMemChecksDlg(void)
{

}


// __________________________________________________________________________________________________
// FillList 
//
void 
CMemChecksDlg::FillList(void)
{
	if (dontFillList) return;
	int sel = ListView_GetSelectionMark(m_hListView);
	ListView_DeleteAllItems(m_hListView);
	LVITEM lvi;
	ZeroMemory(&lvi, sizeof(LVITEM));
	lvi.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM/* | LVIF_STATE*/; 
	lvi.lParam = 0;
	
	for (unsigned int i=0; i<CBreakPoints::MemChecks.size(); i++)
	{
		lvi.pszText = "x";
		lvi.iItem = i;
	    LRESULT idx = SendMessage(m_hListView, LVM_INSERTITEM, 0, (LPARAM)(const LV_ITEM *)(&lvi));
		UpdateItem(idx);
	}
	ListView_SetSelectionMark(m_hListView,sel);
}

static bool inUpdate = false;
// __________________________________________________________________________________________________
// Update 
//
void 
CMemChecksDlg::Update(void)
{
	if (inUpdate)
		return;
	inUpdate=true;

	int selection = ListView_GetSelectionMark(m_hListView);
	BOOL sel = selection != -1;
	BOOL ee = FALSE;
	if (sel)
	{
		MemCheck &mc = CBreakPoints::MemChecks[selection];

		//fill in items
		Button_SetCheck(GetDlgItem(m_hDlg,IDC_ONWRITE),mc.bOnWrite);
		Button_SetCheck(GetDlgItem(m_hDlg,IDC_ONREAD), mc.bOnRead);
		Button_SetCheck(GetDlgItem(m_hDlg,IDC_ACTIONLOG),mc.bLog);
		Button_SetCheck(GetDlgItem(m_hDlg,IDC_RANGEENDENABLE),mc.bRange);
		Button_SetCheck(GetDlgItem(m_hDlg,IDC_ACTIONBREAK), mc.bBreak);
		char temp[256];
		sprintf(temp,"%08x",mc.iStartAddress);
		SetWindowText(GetDlgItem(m_hDlg,IDC_RANGESTART),temp);
		sprintf(temp,"%08x",mc.iEndAddress);
		SetWindowText(GetDlgItem(m_hDlg,IDC_RANGEEND),temp);

		if (mc.bRange)
			ee=TRUE;
	}

	EnableWindow(GetDlgItem(m_hDlg,IDC_MEMCHECKDELETE),sel);
	EnableWindow(GetDlgItem(m_hDlg,IDC_RANGESTART),sel);
	EnableWindow(GetDlgItem(m_hDlg,IDC_RANGEENDENABLE),sel);
	EnableWindow(GetDlgItem(m_hDlg,IDC_RANGEEND),ee);
	EnableWindow(GetDlgItem(m_hDlg,IDC_ONWRITE),sel);
	EnableWindow(GetDlgItem(m_hDlg,IDC_ONREAD),sel);
	EnableWindow(GetDlgItem(m_hDlg,IDC_ACTIONLOG),sel);
	EnableWindow(GetDlgItem(m_hDlg,IDC_ACTIONBREAK),sel);
	
	inUpdate=false;
	Size();
}

// __________________________________________________________________________________________________
// UpdateItem 
//
void 
CMemChecksDlg::UpdateItem(int idx)
{
	MemCheck &mc = CBreakPoints::MemChecks[idx];

	char temp[256];
	if (mc.bRange)
		sprintf(temp,"%08x-%08x",mc.iStartAddress,mc.iEndAddress);
	else
		sprintf(temp,"%08x",mc.iStartAddress);

	ListView_SetItemText(m_hListView,idx,0,temp);

	sprintf(temp,"%s",Debugger_GetSymbolName(Debugger_GetSymbolNum(mc.iStartAddress)));
	ListView_SetItemText(m_hListView,idx,1,temp);

	memset(temp,0,256);
	if (mc.bOnWrite) strcat(temp,"W");
	if (mc.bOnRead)  strcat(temp,"R");
	ListView_SetItemText(m_hListView,idx,2,temp);
	memset(temp,0,256);
	if (mc.bLog)     strcat(temp,"L");
	if (mc.bBreak)   strcat(temp,"B");
	ListView_SetItemText(m_hListView,idx,3,temp);
	sprintf(temp,"%i",mc.numHits);
	ListView_SetItemText(m_hListView,idx,4,temp);
}

// __________________________________________________________________________________________________
// RegistersDlgProc 
//
BOOL 
CMemChecksDlg::DlgProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:
		{
			return TRUE;
		}
		break;
	
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_RANGESTART:
		case IDC_RANGEEND:
			{
				switch (HIWORD(wParam))
				{
				case EN_CHANGE:
					{
						if (inUpdate) break;
						int sel = ListView_GetSelectionMark(m_hListView);
						if (sel!=-1)
						{
							MemCheck &mc = CBreakPoints::MemChecks[sel];

							char temp[256];
							GetWindowText(GetDlgItem(m_hDlg,IDC_RANGESTART),temp,255);
							sscanf(temp,"%08x",&mc.iStartAddress);
							if (mc.bRange)
							{
								char temp[256];
								GetWindowText(GetDlgItem(m_hDlg,IDC_RANGEEND),temp,255);
								sscanf(temp,"%08x",&mc.iEndAddress);
							}

							UpdateItem(sel);
						}
					}
					break;
				default:
					break;
				}
			}
			break;
		case IDC_MEMCHECKNEW:
			{
				MemCheck mc;
				mc.bRange=false;
				mc.bBreak=true;
				mc.bLog=true;
				mc.bOnRead=false;
				mc.bOnWrite=false;
				mc.iStartAddress=0xCC000000;
				mc.iEndAddress=0xCC000004;
				AddNewCheck(mc);

				break;
			}
		case ID_MEMCHECKS_DUPLICATE:
			{
				int sel = ListView_GetSelectionMark(m_hListView);
				if (sel!=-1)
				{
					MemCheck mc = CBreakPoints::MemChecks[sel];
					AddNewCheck(mc);
				}
			}
			break;
		case ID_MEMCHECKS_DELETE: //popup menu
		case IDC_MEMCHECKDELETE:
			{
				int sel = ListView_GetSelectionMark(m_hListView);
				if (sel!=-1)
					CBreakPoints::MemChecks.erase(CBreakPoints::MemChecks.begin() + sel);
				FillList();
				Update();
			}
			//pass through?
		case IDC_ONREAD:
		case IDC_ONWRITE:
		case IDC_ACTIONLOG:
		case IDC_ACTIONBREAK:
		case IDC_RANGEENDENABLE:
			{
				int sel = ListView_GetSelectionMark(m_hListView);
				if (sel!=-1)
				{
					MemCheck &mc = CBreakPoints::MemChecks[sel];
					mc.bOnWrite=(Button_GetCheck(GetDlgItem(m_hDlg,IDC_ONWRITE))>0?true:false);
					mc.bOnRead =(Button_GetCheck(GetDlgItem(m_hDlg,IDC_ONREAD))>0?true:false);
					mc.bLog    =(Button_GetCheck(GetDlgItem(m_hDlg,IDC_ACTIONLOG))>0?true:false);
					mc.bBreak  =(Button_GetCheck(GetDlgItem(m_hDlg,IDC_ACTIONBREAK))>0?true:false);
					mc.bRange  =(Button_GetCheck(GetDlgItem(m_hDlg,IDC_RANGEENDENABLE))>0?true:false);

					EnableWindow(GetDlgItem(m_hDlg,IDC_RANGEEND),mc.bRange);
					UpdateItem(sel);
				}
			}
			break;
		default:
			break;
		}
		break;
	case WM_NOTIFY:
		{
			NMITEMACTIVATE *nm = (NMITEMACTIVATE *)lParam;
			if (nm->hdr.idFrom==IDC_MEMCHECKS)
			{
				switch (nm->hdr.code)
				{
				case LVN_MARQUEEBEGIN:
				case NM_CLICK:
					dontFillList =true;
					Update();
					dontFillList =false;
					break;
				case NM_RCLICK:
					{
						POINT pt;
						GetCursorPos(&pt);
						TrackPopupMenuEx(GetSubMenu(g_hPopupMenus,1),TPM_RIGHTBUTTON,pt.x,pt.y,m_hDlg,0);
					}

					break;
				}
			}
		}
		break;
	case WM_CLOSE:
		Show(FALSE);
		break;
	case WM_SIZE:
		Size();
		break;
	default:
		break;
	}
		
	return FALSE;
}


void CMemChecksDlg::AddNewCheck(MemCheck &mc)
{
	CBreakPoints::MemChecks.push_back(mc);
	FillList();
	ListView_SetSelectionMark(m_hListView,CBreakPoints::MemChecks.size()-1);
}

void CMemChecksDlg::Size()
{
	RECT rc;
	GetClientRect(m_hDlg,&rc);
	int dw=rc.right-rc.left;
	int dh=rc.bottom-rc.top;

	HWND list = GetDlgItem(m_hDlg, IDC_MEMCHECKS);
	int left = 184;
	MoveWindow(list,left,0,dw-left,dh,TRUE);
}
#pragma once

//wrapper between disasm control and DolphinHLE debugger
#include "../../Core/CPU.h"

class ARMDebugInterface : public DebugInterface
{
	CPU *cpu;
public:
	ARMDebugInterface(CPU *_cpu){cpu=_cpu;} 
	virtual char *disasm(unsigned int address, unsigned int align);
	virtual int getInstructionSize(int instruction) {return cpu->GetInstructionSize();}
	virtual bool isAlive();
	virtual bool isBreakpoint(unsigned int address);
	virtual void setBreakpoint(unsigned int address);
	virtual void clearBreakpoint(unsigned int address);
	virtual void clearAllBreakpoints();
	virtual void toggleBreakpoint(unsigned int address);
	virtual unsigned int readMemory(unsigned int address);
	virtual unsigned int getPC();
	virtual void setPC(unsigned int address);
	virtual void step() {}
	virtual void runToBreakpoint();
	virtual int getColor(unsigned int address);
	virtual char *getDescription(unsigned int address);
};
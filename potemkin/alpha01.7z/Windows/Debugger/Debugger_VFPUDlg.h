/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once
#include "../W32Util/DialogManager.h"

#include "../../Core/MemMap.h"
#include "../../Core/CPU.h"
#include "../../Core/System.h" 

#include "DebugInterface.h"

class CVFPUDlg : public Dialog
{
private:
	CPU *cpu;
	HFONT font;
	int mode;
	BOOL DlgProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	int index; //helper 

	// constructor
	CVFPUDlg(HINSTANCE _hInstance, HWND _hParent);
	
	// destructor
	~CVFPUDlg(void);
	
	void Goto(u32 addr);
	void Update(void);	

	void Size(void);
};


extern CVFPUDlg *vfpudlg;

/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "../W32Util/DialogManager.h"
#include "../../Core/Debugger/Breakpoints.h"

class CMemChecksDlg : public Dialog
{
private:
	HWND             m_hListView;
		
	void EnableStuff();

	BOOL DlgProc(UINT message, WPARAM wParam, LPARAM lParam);
		
public:
	CMemChecksDlg(HINSTANCE _hInstance, HWND _hParent);
	~CMemChecksDlg();

	// show
	void Update(void);

	void UpdateItem(int n);
	void FillList(void);

	void AddNewCheck(MemCheck &mc);
	void Size();
};

extern CMemChecksDlg *memcheckdlg;
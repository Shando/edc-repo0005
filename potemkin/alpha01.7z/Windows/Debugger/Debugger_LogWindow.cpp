/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
	
#include "stdafx.h"
#include <windowsx.h>
#include "../W32Util/IniFile.h"
#include "../resource.h"
#include "Debugger_LogWindow.h"
#include "../../globals.h"
#include "../../Core/Core.h"

extern W32Util::IniFile iniFile;

#define USE_LOG_COUNTER 1

CDebugger_LogWindow *logwindow;

char logbuf[1024*1024*8];


void doLogUpdate()
{
	logwindow->Redraw();
}

CDebugger_LogWindow::CDebugger_LogWindow(HINSTANCE _hInstance, HWND _hParent)
	: Dialog((LPCSTR)IDD_LOG, _hInstance, _hParent)
{
	CDebugger_LogManager::Init();
	//Set default position
	SetWindowPos(m_hDlg, 0, 100, 600, 0, 0, SWP_NOSIZE);

	RECT rect;
	memset(&rect, 0, sizeof(RECT));

	ResizeListview();

	HWND box = GetDlgItem(m_hDlg,IDC_LOG);

	char temp[256];

	for (int i=0; i<CDebugger_LogManager::NUMBER_OF_LOGS; i++)
	{
		strncpy_s(temp,CDebugger_LogManager::m_Log[i]->m_szShortName,_TRUNCATE);
		strcat_s(temp," - ");
		strcat_s(temp,CDebugger_LogManager::m_Log[i]->m_szName);
		int idx = ComboBox_AddString(box,temp);
		ComboBox_SetItemData(box, idx, i);
	}	

	ComboBox_SetCurSel(box,0);
	CDebugger_LogManager::m_bDirty=true;
	UpdateDlg();
}



CDebugger_LogWindow::~CDebugger_LogWindow()
{
	CDebugger_LogManager::Shutdown();
}

// __________________________________________________________________________________________________
// ResizeListview
//
void 
CDebugger_LogWindow::ResizeListview(void)
{
	RECT rect, wnd_rect;
	GetClientRect(m_hDlg, &rect);

	wnd_rect.left = 0;
	wnd_rect.top  = 30;
	wnd_rect.right  = rect.right-rect.left;
	wnd_rect.bottom = rect.bottom-rect.top-26;

	HWND button = GetDlgItem(m_hDlg, IDC_SUBMIT);
	MoveWindow(button,wnd_rect.right-45,wnd_rect.bottom+3,45,22,true);

	HWND line = GetDlgItem(m_hDlg, IDC_CMDLINE);
	MoveWindow(line,wnd_rect.left,wnd_rect.bottom+3,wnd_rect.right-wnd_rect.left-48,22,true);

	HWND wnd = GetDlgItem(m_hDlg, IDC_LOGBOX);
	MoveWindow(wnd,wnd_rect.left,wnd_rect.top,wnd_rect.right-wnd_rect.left,wnd_rect.bottom-wnd_rect.top,true);

	//m_pWinListView->SetSize(wnd_rect);
}

void CDebugger_LogWindow::Redraw(void)
{
	if (!CDebugger_LogManager::m_bDirty)
		return;
	HWND logbox = GetDlgItem(m_hDlg, IDC_LOGBOX);
	//m_pWinListView->DeleteAllItems();
	SendMessage(logbox,WM_SETTEXT,0,(LPARAM)"");
	char *p = logbuf;
	*p=0;
	CDebugger_LogManager::GetContents(p,m_activeLog);
	
	SendMessage(logbox,WM_SETTEXT,FALSE,(LPARAM)logbuf);
	SendMessage(logbox,EM_SETSEL,10000000,10000000);
	SendMessage(logbox,EM_SCROLLCARET,0,0);
	CDebugger_LogManager::m_bDirty=false;
}

void CDebugger_LogWindow::UpdateDlg(void)
{
	int sel = ComboBox_GetCurSel(GetDlgItem(m_hDlg,IDC_LOG));
	m_activeLog = (int)ComboBox_GetItemData(GetDlgItem(m_hDlg,IDC_LOG),sel);

	if (m_activeLog == CDebugger_LogManager::MASTER_LOG)
	{
		Button_Enable(GetDlgItem(m_hDlg,IDC_LOGENABLE),	false);
		Button_Enable(GetDlgItem(m_hDlg,IDC_LOG_SHOW),	false);
		Button_Enable(GetDlgItem(m_hDlg,IDC_LOG_TO_FILE), false);
	}
	else
	{
		Button_Enable(GetDlgItem(m_hDlg,IDC_LOGENABLE),	true);
		Button_Enable(GetDlgItem(m_hDlg,IDC_LOG_SHOW),	true);
		Button_Enable(GetDlgItem(m_hDlg,IDC_LOG_TO_FILE), true);

		Button_SetCheck(GetDlgItem(m_hDlg,IDC_LOGENABLE), CDebugger_LogManager::m_Log[m_activeLog]->m_bEnable);
		Button_SetCheck(GetDlgItem(m_hDlg,IDC_LOG_SHOW), CDebugger_LogManager::m_Log[m_activeLog]->m_bShowInLog);
		Button_SetCheck(GetDlgItem(m_hDlg,IDC_LOG_TO_FILE),CDebugger_LogManager:: m_Log[m_activeLog]->m_bLogToFile);
	}
}


BOOL CDebugger_LogWindow::DlgProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
	case WM_INITDIALOG:
		{
			return TRUE;
		}
		break;

	case WM_COMMAND:
		{
			switch(LOWORD(wParam))
			{
			case IDC_LOG:
				switch (HIWORD(wParam)) 
				{ 
				case LBN_SELCHANGE: 
					{
						CDebugger_LogManager::m_bDirty=true;
						UpdateDlg();
						Redraw();
					}
					break;
				};
				break;

			case IDC_SUBMIT:
				{
					TCHAR temp[2048];
					HWND box = GetDlgItem(m_hDlg,IDC_CMDLINE); 
					GetWindowText(box,temp,2047);
					Core_CmdLine(temp);
					SetWindowText(box,"");
					Redraw();
				}
				break;

			case IDC_LOGENABLE:
				CDebugger_LogManager::m_Log[m_activeLog]->m_bEnable = (Button_GetCheck(GetDlgItem(m_hDlg,IDC_LOGENABLE))>0?true:false);
				break;

			case IDC_LOG_SHOW:
				CDebugger_LogManager::m_Log[m_activeLog]->m_bShowInLog = (Button_GetCheck(GetDlgItem(m_hDlg,IDC_LOG_SHOW))>0?true:false);
				break;

			case IDC_LOG_TO_FILE: 
				CDebugger_LogManager::m_Log[m_activeLog]->m_bLogToFile = (Button_GetCheck(GetDlgItem(m_hDlg,IDC_LOG_TO_FILE))>0?true:false);
				break;

			case IDC_UPDATELOG:
				Redraw();
				break;
			}
		}
		break;

	case WM_SIZE:
		{
			ResizeListview();
		}
		break;

	case WM_CLOSE:
		Show(false);
		break;
	}

	return FALSE;
}

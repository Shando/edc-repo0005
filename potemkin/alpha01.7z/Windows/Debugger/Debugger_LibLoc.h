#pragma once


int LoadSymbolsFromO(const char* filename, unsigned int base, unsigned int count);

// GClibloc.c V1.0 by Costis!
// (CONFIDENTIAL VERSION)

#include "stdafx.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "SimpleELF.h"
#include "../../Core/Memmap.h"
#include "../../Core/Debugger/SymbolMap.h"
#include "Debugger_LibLoc.h"


#define gELFTypeS(a) (a == ET_NONE ? "NONE" : \
					   a == ET_REL ? "RELOCATABLE" : \
					   a == ET_EXEC ? "EXECUTABLE" : \
					   a == ET_DYN ? "SHARED OBJECT" : \
					   a == ET_CORE ? "CORE" : \
					   a == ET_LOPROC ? "PROCESSOR SPECIFIC: LOPROC" : \
					   a == ET_HIPROC ? "PROCESSOR SPECIFIC: HIPROC" : "INVALID")

inline unsigned long bswap (unsigned long a)
{
	__asm
	{
		//mov eax, a
		//bswap eax
		//mov a, eax
	}
	return a;
}

void readSectionHeader (FILE *ifil, int section, ELF_Header ELF_H, Section_Header *ELF_SH)
{
		fseek (ifil, ELF_H.e_shoff + ELF_H.e_shentsize * section, SEEK_SET);
		fread (ELF_SH, sizeof (Section_Header),1,ifil);

		// Convert the GameCube (Big Endian) format to Little Endian 
		ELF_SH->name = bswap (ELF_SH->name);
		ELF_SH->type = bswap (ELF_SH->type);
		ELF_SH->flags = bswap (ELF_SH->flags);
		ELF_SH->addr = bswap (ELF_SH->addr);
		ELF_SH->offset = bswap (ELF_SH->offset);
		ELF_SH->size = bswap (ELF_SH->size);
		ELF_SH->link = bswap (ELF_SH->link);
		ELF_SH->info = bswap (ELF_SH->info);
		ELF_SH->addralign = bswap (ELF_SH->addralign);
		ELF_SH->entsize = bswap (ELF_SH->entsize);
}

void readProgramHeader (FILE *ifil, int psection, ELF_Header ELF_H, Program_Header *ELF_PH)
{
		fseek (ifil, ELF_H.e_phoff + ELF_H.e_phentsize * psection, SEEK_SET);
		fread (ELF_PH,  sizeof (Program_Header), 1, ifil);

		// Convert the GameCube (Big Endian) format to Little Endian
		ELF_PH->type = bswap (ELF_PH->type);
		ELF_PH->offset = bswap (ELF_PH->offset);
		ELF_PH->vaddr = bswap (ELF_PH->vaddr);
		ELF_PH->paddr = bswap (ELF_PH->paddr);
		ELF_PH->filesz = bswap (ELF_PH->filesz);
		ELF_PH->memsz = bswap (ELF_PH->memsz);
		ELF_PH->flags = bswap (ELF_PH->flags);
		ELF_PH->align = bswap (ELF_PH->align);
}

unsigned long locShStrTab (FILE *ifil, ELF_Header ELF_H)
{
	int i;
	Section_Header ELF_SH;
	char stID[10];

	for (i = 1; i < ELF_H.e_shnum; i++)
	{
		readSectionHeader (ifil, i, ELF_H, &ELF_SH);
		if (ELF_SH.type == SHT_STRTAB)
		{
			fseek (ifil, ELF_SH.offset + ELF_SH.name, SEEK_SET);
			fread (stID, 1, 10, ifil);
			if (strcmp (stID, ".shstrtab") == 0)
				return ELF_SH.offset;
		}
	}
	return 0;
}
	

unsigned long locStrTab (FILE *ifil, ELF_Header ELF_H)
{
	int i;
	Section_Header ELF_SH;
	unsigned long ShStrTab;
	char stID[10];

	// Locate the Section String Table first.
	for (i = 1; i < ELF_H.e_shnum; i++)
	{
		readSectionHeader (ifil, i, ELF_H, &ELF_SH);
		if (ELF_SH.type == SHT_STRTAB)
		{
			fseek (ifil, ELF_SH.offset + ELF_SH.name, SEEK_SET);
			fread (stID, 1, 10, ifil);
			if (strcmp (stID, ".shstrtab") == 0)
				break;
		}
	}
	
	if (i >= ELF_H.e_shnum)
		return 0; // No Section String Table was located.

	ShStrTab = ELF_SH.offset;

	// Locate the String Table using the Section String Table.
	for (i = 1; i < ELF_H.e_shnum; i++)
	{
		readSectionHeader (ifil, i, ELF_H, &ELF_SH);
		if (ELF_SH.type == SHT_STRTAB)
		{
			fseek (ifil, ShStrTab + ELF_SH.name, SEEK_SET);
			fread (stID, 1, 8, ifil);
			if (strcmp (stID, ".strtab") == 0)
				return ELF_SH.offset;
		}
	}

	return 0; // No String Table was located.
}

unsigned long locStrTabShStrTab (FILE *ifil, unsigned long ShStrTab, ELF_Header ELF_H)
{
	int i;
	Section_Header ELF_SH;
	char stID[8];

	for (i = 1; i < ELF_H.e_shnum; i++)
	{
		readSectionHeader (ifil, i, ELF_H, &ELF_SH);
		if (ELF_SH.type == SHT_STRTAB)
		{
			fseek (ifil, ShStrTab + ELF_SH.name, SEEK_SET);
			fread (stID, 1, 8, ifil);
			if (strcmp (stID, ".strtab") == 0)
				return ELF_SH.offset;
		}
	}
	return 0;
}

unsigned long locSection (FILE *ifil, unsigned long ShType, ELF_Header ELF_H)
{
	int i;
	Section_Header ELF_SH;

	for (i = 0; i < ELF_H.e_shnum; i++)
	{
		readSectionHeader (ifil, i, ELF_H, &ELF_SH);
		if (ELF_SH.type == ShType)
			return i;
	}
	return 0;
}

unsigned long locCode (unsigned char *bbuf, unsigned long fsize, unsigned char *abuf, unsigned long offset, unsigned long size)
{
	unsigned int i, j;

	i = 0;
	while (i < fsize)
	{
		u32 cw1 = *(unsigned long*)(abuf + offset);
		u32 cw2 = *(unsigned long*)(bbuf + i);
		if (cw1 == cw2 || (cw1==0))
		{
			// Code section possibly found.
			for (j = 4; j < size; j += 4)
			{
				cw1 = *(unsigned long*)(abuf + offset + j);
				cw2 = *(unsigned long*)(bbuf + i + j);
				if ((cw2 != cw1) && (cw1 != 0))
					break;
			}

			if (j >= size)
				return i; // The code section was found.
		}
		i += 4;
	}

	return 0;
}			


int LoadSymbolsFromO(const char* filename, unsigned int base, unsigned int count)
{
	unsigned int i, j;
	FILE *ifil;
	char astr[64];
	unsigned char *abuf, *bbuf;
	unsigned long ShStrTab, StrTab, SymTab;
	ELF_Header ELF_H;
	Section_Header ELF_SH;
	Symbol_Header ELF_SYM;
	Rela_Header ELF_RELA;
	
	int filesize;
	ifil = fopen (filename, "rb");
	fseek(ifil,0,SEEK_END);
	filesize = ftell(ifil);
	fseek(ifil,0,SEEK_SET);

	fread (&ELF_H, 1, sizeof (ELF_Header), ifil);
	/*
	ELF_H.e_type = (ELF_H.e_type >> 8) | (ELF_H.e_type << 8);
	ELF_H.e_machine = (ELF_H.e_machine >> 8) | (ELF_H.e_machine << 8);
	ELF_H.e_ehsize = (ELF_H.e_ehsize >> 8) | (ELF_H.e_ehsize << 8);
	ELF_H.e_phentsize = (ELF_H.e_phentsize >> 8) | (ELF_H.e_phentsize << 8);
	ELF_H.e_phnum = (ELF_H.e_phnum >> 8) | (ELF_H.e_phnum << 8);
	ELF_H.e_shentsize = (ELF_H.e_shentsize >> 8) | (ELF_H.e_shentsize << 8);
	ELF_H.e_shnum = (ELF_H.e_shnum >> 8) | (ELF_H.e_shnum << 8);
	ELF_H.e_shtrndx = (ELF_H.e_shtrndx >> 8) | (ELF_H.e_shtrndx << 8);
	*/
	/*
	__asm
	{
		mov eax, ELF_H.e_version
		bswap eax
		mov ELF_H.e_version, eax
		mov eax, ELF_H.e_entry
		bswap eax
		mov ELF_H.e_entry, eax
		mov eax, ELF_H.e_phoff
		bswap eax
		mov ELF_H.e_phoff, eax
		mov eax, ELF_H.e_shoff
		bswap eax
		mov ELF_H.e_shoff, eax
		mov eax, ELF_H.e_flags
		bswap eax
		mov ELF_H.e_flags, eax
	}*/

	_dbg_log4_(MASTER_LOG,"Identification ID: %c%c%c%c\n", ELF_H.ID[0], ELF_H.ID[1], ELF_H.ID[2], ELF_H.ID[3]);
	_dbg_log2_(MASTER_LOG,"ELF Type: %d (%s)\n", ELF_H.e_type, gELFTypeS (ELF_H.e_type));
	_dbg_log1_(MASTER_LOG,"ELF Machine: %d\n", ELF_H.e_machine);
	_dbg_log1_(MASTER_LOG,"ELF Version: %d\n", ELF_H.e_version);

	ShStrTab = locShStrTab (ifil, ELF_H);
	fseek (ifil, ShStrTab + 1, SEEK_SET);
	fread (astr, 1, 32, ifil);

	_dbg_log1_(MASTER_LOG,"num sections ? = %d",ELF_H.e_shnum);
	for (i = 0; i < ELF_H.e_shnum; i++)
	{
		readSectionHeader (ifil, i, ELF_H, &ELF_SH);
		if (ELF_SH.type != 0)
		{
			fseek (ifil, ShStrTab + ELF_SH.name, SEEK_SET);
			j = 0;
			while (1)
				if ((astr[j++] = fgetc (ifil)) == 0) break;
		}
	}

	

	StrTab = locStrTab (ifil, ELF_H);
	SymTab = locSection (ifil, SHT_SYMTAB, ELF_H);

	readSectionHeader (ifil, SymTab, ELF_H, &ELF_SH);
	for (i = 1; i < ELF_SH.size / 16; i++)
	{
		fseek (ifil, ELF_SH.offset + 16 * i, SEEK_SET);
		fread (&ELF_SYM, 1, sizeof (Symbol_Header), ifil);
		//ELF_SYM.name = bswap (ELF_SYM.name);
		//ELF_SYM.value = bswap (ELF_SYM.value);
		//ELF_SYM.size = bswap (ELF_SYM.size);
		//ELF_SYM.shndx = (ELF_SYM.shndx >> 8) | (ELF_SYM.shndx << 8);

		fseek (ifil, StrTab + ELF_SYM.name, SEEK_SET);
		j = 0;
		while (1)
			if ((astr[j++] = fgetc (ifil)) == 0) break;
	}	
	abuf = (unsigned char *)malloc (1024*1024);

/*
	for (int i=0; i<16; i++)
	{
		int progsection = locSection(ifil,i,ELF_H);
		readSectionHeader (ifil, progsection, ELF_H, &ELF_SH);
		if (ELF_SH.offset == 0x3b0)
		{
			_dbg_log_(MASTER_LOG,"woohoo");
		}
	}
*/
//	int progsection = 7; //locSection(ifil,SHT_RELA,ELF_H);
	//fread (abuf, filesize, 1, ifil);

	//printf ("\nRelocatable Addend Header Information:\n\n");
	readSectionHeader (ifil, locSection (ifil, 4, ELF_H), ELF_H, &ELF_SH);
	
	if (ELF_SH.entsize==0) //corrupt file?
	{
		_dbg_log1_(MASTER_LOG,"Huh? ELF_SH.entsize==0 in %s!",filename);
	}
	else
	{
		unsigned int num = ELF_SH.size / ELF_SH.entsize;

		_dbg_log1_(MASTER_LOG,"locating functions (%d)..",num);
		for (int i=0; i < (int)num; i++)
		{
			fseek (ifil, ELF_SH.offset + 12 * i, SEEK_SET);
			fread (&ELF_RELA, 1, sizeof (Rela_Header), ifil);
			//ELF_RELA.offset = bswap (ELF_RELA.offset);
			//ELF_RELA.info = bswap (ELF_RELA.info);
			//ELF_RELA.addend = bswap (ELF_RELA.addend);

			*(unsigned long*)(abuf + (ELF_RELA.offset & ~3)) = 0;
			if (ELF_SH.size == 0 || ELF_SH.entsize==0) //corrupt file?
			{
				_dbg_log1_(MASTER_LOG,"Huh? ELF_SH.entsize==0 in %s!",filename);
				return 0;
			}
		}

		bbuf = (unsigned char*)GetMemPointer(base);

		readSectionHeader (ifil, SymTab, ELF_H, &ELF_SH);
		for (int i = 1; i < ELF_SH.size / 16; i++)
		{
			fseek (ifil, ELF_SH.offset + 16 * i, SEEK_SET);
			fread (&ELF_SYM, 1, sizeof (Symbol_Header), ifil);
			//ELF_SYM.name = bswap (ELF_SYM.name);
			//ELF_SYM.value = bswap (ELF_SYM.value);
			//ELF_SYM.size = bswap (ELF_SYM.size);
			//ELF_SYM.shndx = (ELF_SYM.shndx >> 8) | (ELF_SYM.shndx << 8);
			_dbg_log4_(MASTER_LOG,"%08x %08x %08x %04x",ELF_SYM.name,ELF_SYM.value,ELF_SYM.size,ELF_SYM.shndx);
			//if (ELF_SYM.shndx == 1)
			int headerIDX = ELF_SYM.shndx;
			Section_Header hdr;
			readSectionHeader (ifil, headerIDX, ELF_H, &hdr);
			fseek (ifil, hdr.offset, SEEK_SET);
			fread (abuf, 1, hdr.size, ifil);
			{
				fseek (ifil, StrTab + ELF_SYM.name, SEEK_SET);
				j = 0;

				while (1)
					if ((astr[j++] = fgetc (ifil)) == 0) 
						break;

				if (ELF_SYM.size>=8 && astr[0]!='@')
				{
					_dbg_log1_(MASTER_LOG,"locating %s..",astr);
					u32 offset = locCode (bbuf, count, abuf, ELF_SYM.value, ELF_SYM.size);
					if (offset != 0 && ELF_SYM.size>12)
					{
						_dbg_log2_(MASTER_LOG,"%s: 0x%X\n", astr, offset);
						Debugger_AddSymbol(astr,offset+base,ELF_SYM.size,ST_FUNCTION);
					}
				}
			}
		}	
	}
	free (abuf);
	fclose (ifil);
	//CDisasm::UpdateDialog();
	return 0;
}
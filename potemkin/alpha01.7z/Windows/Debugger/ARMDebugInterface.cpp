#include "stdafx.h"

#include "../../Core/Debugger/Breakpoints.h"
#include "../../Core/Debugger/SymbolMap.h"
#include "DebugInterface.h"

#include "ARMDebugInterface.h"
//#include "..\HW\MemMap.h"
#include "../../Globals.h"
#include "../../Core/HW.h"	
#include "../../Core/MemMap.h"	

#include "../../Core/ARM/ARMTables.h"	
#include "../../Core/MIPS/MIPSTables.h"	

char *ARMDebugInterface::disasm(unsigned int address, unsigned int align) 
{
	CPU *x = currentCPU;
	currentCPU = cpu;
	
	static char mojs[256]; 
	switch(cpu->GetType())
	{
	case CPUTYPE_ARM7:
	case CPUTYPE_ARM9:
		if (align==4)
			ARMDisAsm(cpu->memMap.ReadMem32Unchecked(address),address,mojs);
		else
			THUMBDisAsm(cpu->memMap.ReadMem16Unchecked(address),address,mojs);
		break;
	case CPUTYPE_MIPSR4K:
		MIPSDisAsm(cpu->memMap.ReadMem32Unchecked(address),address,mojs);
		break;
	}
	currentCPU = x;
	return mojs;
}
unsigned int ARMDebugInterface::readMemory(unsigned int address)
{
	return cpu->memMap.ReadMem32Unchecked(address);
}

bool ARMDebugInterface::isAlive()
{
	return HW_IsInited();
}

bool ARMDebugInterface::isBreakpoint(unsigned int address) 
{
	return CBreakPoints::IsAddressBreakPoint(address);
}

void ARMDebugInterface::setBreakpoint(unsigned int address)
{
	CBreakPoints::AddBreakPoint(address);
}
void ARMDebugInterface::clearBreakpoint(unsigned int address)
{
	CBreakPoints::RemoveBreakPoint(address);
}
void ARMDebugInterface::clearAllBreakpoints() {}
void ARMDebugInterface::toggleBreakpoint(unsigned int address)
{
	CBreakPoints::IsAddressBreakPoint(address)?CBreakPoints::RemoveBreakPoint(address):CBreakPoints::AddBreakPoint(address);
}


int ARMDebugInterface::getColor(unsigned int address)
{
	int colors[6] = {0xe0FFFF,0xFFe0e0,0xe8e8FF,0xFFe0FF,0xe0FFe0,0xFFFFe0};
	int n=Debugger_GetSymbolNum(address);
	if (n==-1) return 0xFFFFFF;
	return colors[n%6];
}
char *ARMDebugInterface::getDescription(unsigned int address) 
{
	return Debugger_GetDescription(address);
}

unsigned int ARMDebugInterface::getPC() 
{
	return cpu->GetPC();
}

void ARMDebugInterface::setPC(unsigned int address) 
{
	cpu->SetPC(address); 	
}

void ARMDebugInterface::runToBreakpoint() 
{
	
}

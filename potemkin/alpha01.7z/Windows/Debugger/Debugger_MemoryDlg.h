/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once
#include "../W32Util/DialogManager.h"

#include "../../Core/MemMap.h"
#include "../../Core/CPU.h"
#include "../../Core/System.h" 

#include "DebugInterface.h"

class CMemoryDlg : public Dialog
{
private:
	CPU *cpu;
	static RECT slRect;

	BOOL DlgProc(UINT message, WPARAM wParam, LPARAM lParam);
	DebugInterface *debint;		
public:
	int index; //helper 

	// constructor
	CMemoryDlg(HINSTANCE _hInstance, HWND _hParent, CPU *_cpu);
	
	// destructor
	~CMemoryDlg(void);
	
	void Goto(u32 addr);
	void Update(void);	
	void NotifyMapLoaded();

	void Size(void);
};



#pragma	once


namespace GameList
{
	void Create(HWND parent, HINSTANCE hInstance);
	void Destroy();
	void Update(bool dontAsk=false);
	void Doubleclick();
	HWND GetHWND();
	COLORREF GetBannerBGColor();
	void SetBannerBGColor(COLORREF col);
	void GetSelectedGCMPath(TCHAR *buffer, int size);
	DWORD HandleWMNotify(HWND hwnd, WPARAM wParam, LPARAM lParam);
}

 
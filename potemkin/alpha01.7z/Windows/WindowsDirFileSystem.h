#pragma once

#include "../Core/FileSystems/FileSystem.h"


class WindowsDirFileSystem : public IFileSystem
{
	struct OpenFileEntry
	{
		HANDLE hFile;
	};
	typedef std::map<u32,OpenFileEntry> EntryMap;
	EntryMap entries;
	std::string basePath;
	IHandleAllocator *hAlloc;

	std::string GetWin32Path(std::string localpath);

public:
	WindowsDirFileSystem(IHandleAllocator *_hAlloc, std::string _basePath);
	std::vector<FileInfo> GetDirListing(std::string path);
	u32      OpenFile(std::string filename, FileAccess access);
	void     CloseFile(u32 handle);
	size_t   ReadFile(u32 handle, u8 *pointer, s64 size);
	size_t   WriteFile(u32 handle, const u8 *pointer, s64 size);
	size_t   SeekFile(u32 handle, s32 position, FileMove type);
	FileInfo GetFileInfo(std::string filename);
	bool     OwnsHandle(u32 handle);
};
 
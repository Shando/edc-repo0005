#include "stdafx.h"

#include "WindowsDirFileSystem.h"

WindowsDirFileSystem::WindowsDirFileSystem(IHandleAllocator *_hAlloc, std::string _basePath) : basePath(_basePath)
{
	hAlloc = _hAlloc;
}

std::string WindowsDirFileSystem::GetWin32Path(std::string localpath)
{
	//Convert slashes
	if (localpath[0] == '/')
		localpath.erase(0,1);
	for (unsigned int i=0; i<localpath.size(); i++)
	{
		if (localpath[i] == '/')
			localpath[i] = '\\';
	}

	return basePath + localpath;
}


u32 WindowsDirFileSystem::OpenFile(std::string filename, FileAccess access)
{
	std::string fullName = GetWin32Path(filename);
	LOG(HLE,"Actually opening %s",fullName.c_str());

	OpenFileEntry entry;

	// Convert parameters to Windows permissions and access
	DWORD desired = 0;
	DWORD sharemode = 0;
	DWORD openmode = 0;
	if (access & FILEACCESS_READ)
	{
		desired   |= GENERIC_READ;
		sharemode |= FILE_SHARE_READ;
	}
	if (access & FILEACCESS_WRITE)
	{
		desired   |= GENERIC_WRITE;
		sharemode |= FILE_SHARE_WRITE;
	}
	if (access & FILEACCESS_CREATE)
	{
		openmode = OPEN_ALWAYS;
	}
	else
		openmode = OPEN_EXISTING;

	//Let's do it!
	entry.hFile = CreateFile(fullName.c_str(), desired, sharemode, 0, openmode, 0, 0);
	
	if (entry.hFile == INVALID_HANDLE_VALUE)
	{
		LOG(HLE,"WindowsDirFileSystem::OpenFile: FAILED, %i", GetLastError());
		//wwwwaaaaahh!!
		return 0;
	}
	else
	{
		u32 newHandle = hAlloc->GetNewHandle();
		entries[newHandle] = entry;

		return newHandle;
	}
}

void WindowsDirFileSystem::CloseFile(u32 handle)
{
	EntryMap::iterator iter = entries.find(handle);
	if (iter != entries.end())
	{
		hAlloc->FreeHandle(handle);
		CloseHandle((*iter).second.hFile);
		entries.erase(iter);
	}
	else
	{
		//This shouldn't happen...
		LOG(HLE,"Hey, what are you doing? Closing non-open files?");
	}
}

bool WindowsDirFileSystem::OwnsHandle(u32 handle)
{
	EntryMap::iterator iter = entries.find(handle);
	return (iter != entries.end());
}

size_t WindowsDirFileSystem::ReadFile(u32 handle, u8 *pointer, s64 size)
{
	EntryMap::iterator iter = entries.find(handle);
	if (iter != entries.end())
	{
		DWORD bytesRead;
		::ReadFile((*iter).second.hFile, (LPVOID)pointer, (DWORD)size, &bytesRead, 0);
		return bytesRead;
	}
	else
	{
		//This shouldn't happen...
		LOG(HLE,"Hey, what are you doing? Reading non-open files?");
		return 0;
	}
}

size_t WindowsDirFileSystem::WriteFile(u32 handle, const u8 *pointer, s64 size) 
{
	EntryMap::iterator iter = entries.find(handle);
	if (iter != entries.end())
	{
		DWORD bytesRead;
		::WriteFile((*iter).second.hFile, (LPVOID)pointer, (DWORD)size, &bytesRead, 0);
		return bytesRead;
	}
	else
	{
		//This shouldn't happen...
		LOG(HLE,"Hey, what are you doing? Reading non-open files?");
		return 0;
	}
}

size_t WindowsDirFileSystem::SeekFile(u32 handle, s32 position, FileMove type) 
{
	EntryMap::iterator iter = entries.find(handle);
	if (iter != entries.end())
	{
		DWORD moveMethod = 0;
		switch (type)
		{
		case FILEMOVE_BEGIN: moveMethod = FILE_BEGIN; break;
		case FILEMOVE_CURRENT: moveMethod = FILE_CURRENT; break;
		case FILEMOVE_END: moveMethod = FILE_END; break;
		}
		DWORD newPos = SetFilePointer((*iter).second.hFile, (LONG)position, 0, moveMethod);
		return (size_t)newPos;
	}
	else
	{
		//This shouldn't happen...
		LOG(HLE,"Hey, what are you doing? Seeking in non-open files?");
		return 0;
	}
}

FileInfo WindowsDirFileSystem::GetFileInfo(std::string filename) 
{
	FileInfo x; 
	x.size=0; 

	std::string fullName = GetWin32Path(filename);

	WIN32_FILE_ATTRIBUTE_DATA data;
	GetFileAttributesEx(fullName.c_str(), GetFileExInfoStandard, &data);

	x.size = data.nFileSizeLow | ((u64)data.nFileSizeHigh<<32);

	return x;
}

std::vector<FileInfo> WindowsDirFileSystem::GetDirListing(std::string path)
{
	std::vector<FileInfo> myVector;
	WIN32_FIND_DATA findData;
	HANDLE hFind;

	std::string w32path = GetWin32Path(path) + "\\*.*";

	hFind = FindFirstFile(w32path.c_str(), &findData);

	if (hFind == INVALID_HANDLE_VALUE)
	{
		return myVector; //the empty list
	}

	while (true)
	{
		FileInfo entry;

		if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			entry.type = FILETYPE_DIRECTORY;
		else
			entry.type = FILETYPE_NORMAL;

		entry.size = findData.nFileSizeLow | ((u64)findData.nFileSizeHigh<<32);
		entry.name = findData.cFileName;
		
		myVector.push_back(entry);

		int retval = FindNextFile(hFind, &findData);
		if (!retval)
			break;
	}

	return myVector;
}


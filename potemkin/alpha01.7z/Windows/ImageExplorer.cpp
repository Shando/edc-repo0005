#include "stdafx.h"
#include <commctrl.h>
#include "ImageExplorer.h"
#include "resource.h"


ImageExplorer *imageExplorer;

ImageExplorer::ImageExplorer(HINSTANCE _hInstance, HWND _hParent) : Dialog((LPCTSTR)IDD_FILESYSTEMBROWSER,_hInstance,_hParent)
{
	
}

ImageExplorer::~ImageExplorer()
{

}


BOOL ImageExplorer::DlgProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) {
	case WM_INITDIALOG:
		{
			HWND tree = GetDlgItem(this->m_hDlg,IDC_DIRTREE);
			SetWindowLong(tree,GWL_STYLE,GetWindowLong(tree,GWL_STYLE)|TVS_FULLROWSELECT|TVS_HASLINES|TVS_HASBUTTONS|TVS_NOHSCROLL|TVS_SHOWSELALWAYS);

			TVINSERTSTRUCT it;
			
			ZeroMemory(&it,sizeof(it));
			it.hInsertAfter=TVI_ROOT;
			it.hParent=0;
			it.item.cChildren=0;
			it.item.iImage=0;
			it.item.pszText="ROOT";
			it.item.mask = TVIF_TEXT;
			SendMessage(tree,TVM_INSERTITEM,0,(LPARAM)&it);
		}
		return TRUE;
	case WM_COMMAND:
		return TRUE;
	case WM_CLOSE:
		Show(false);
		return TRUE;
	}
	return FALSE;
}


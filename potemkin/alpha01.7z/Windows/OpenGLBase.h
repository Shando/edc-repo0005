#pragma once


bool GL_Init(HWND window);
void GL_Shutdown();
void GL_BeginFrame();
void GL_EndFrame();

#pragma once

#include "W32Util/DialogManager.h"

class SystemInfo : public Dialog
{
protected:
	BOOL DlgProc(UINT message, WPARAM wParam, LPARAM lParam);

public:
	SystemInfo(HINSTANCE _hInstance, HWND _hParent);
	~SystemInfo();

	void Update();
};

extern SystemInfo *systemInfo;

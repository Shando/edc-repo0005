#pragma	   once

#include "../Globals.h"

#include "W32Util/DialogManager.h"	


class ImageExplorer : public Dialog
{
protected:
	BOOL DlgProc(UINT message, WPARAM wParam, LPARAM lParam);

public:
	ImageExplorer(HINSTANCE _hInstance, HWND _hParent);
	~ImageExplorer();
};

extern ImageExplorer *imageExplorer;

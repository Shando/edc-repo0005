#include "stdafx.h"
#include <windowsx.h>
#include <commctrl.h>
#include <string>
#include "../Globals.h"
#include "GameList.h"
#include "../Core/Core.h"
#include "../Core/DS/NitroROM.h"
#include "../Core/EmuThread.h"
#include "WndMainWindow.h"
#include "DlgSettings.h"
//#include "W32Util/MappedFile.h"	
#include "resource.h"
#include "W32Util/misc.h"
#include "W32Util/IniFile.h"
//#include "DlgProperties.h"


enum
{
	GAMELIST_BANNER = 0,
	GAMELIST_TITLE,
	GAMELIST_TYPE,
	GAMELIST_COMPANY,
	GAMELIST_NOTES,
	GAMELIST_GENRE,
	GAMELIST_SIZE,
	GAMELIST_ID,
	GAMELIST_NUMCOLS
};

extern HMENU g_hPopupMenus;

namespace GameList
{
	HWND m_hParent; 
	HINSTANCE hInstance;
	HWND m_hListView;
	HIMAGELIST imageList;
	
	std::string path;

	struct GameListEntry
	{
		char title[256];
		char type[256];
		char company[256];
		char notes[256];
		char genre[256];
		int size;
		int bitmapindex;
		char id[5];
		char path[MAX_PATH];
	};
	std::vector<GameListEntry> glist;
	static int sortDir[GAMELIST_NUMCOLS] = {1,1,1,1,1,1,1};
	int icmp(int i1, int i2)
	{
		if (i1<i2) return -1;
		else if (i2<i1) return 1;
		else return 0;
	}

	int CALLBACK ListViewCompareProc(LPARAM lParam1, LPARAM lParam2, LPARAM	lParamSort)
	{
		int m = sortDir[lParamSort];
		switch(lParamSort) {
		case GAMELIST_TITLE:     return m*strcmpi(glist[lParam1].title, glist[lParam2].title);
		case GAMELIST_GENRE:     return m*strcmpi(glist[lParam1].genre, glist[lParam2].genre);
		case GAMELIST_TYPE:      return m*strcmpi(glist[lParam1].type, glist[lParam2].type);
		case GAMELIST_COMPANY:   return m*strcmpi(glist[lParam1].company, glist[lParam2].company);
		case GAMELIST_NOTES:     return m*strcmpi(glist[lParam1].notes, glist[lParam2].notes);
		case GAMELIST_ID:        return m*strcmpi(glist[lParam1].id, glist[lParam2].id);
		case GAMELIST_SIZE:      return m*icmp(glist[lParam1].size, glist[lParam2].size);
		default:
			return 0;
		}
	}

	void Create(HWND _hParent, HINSTANCE _hInstance)
	{
		imageList = 0;
		m_hParent = _hParent;
		hInstance = _hInstance;
		m_hListView = CreateWindowEx(
			WS_EX_CLIENTEDGE,WC_LISTVIEW,"",WS_CHILD | LVS_REPORT | WS_VISIBLE | LVS_SINGLESEL,	
			0,0,400,400,_hParent,NULL,_hInstance,NULL);
		ListView_SetExtendedListViewStyle(m_hListView,
			LVS_EX_FULLROWSELECT|LVS_EX_HEADERDRAGDROP); //|LVS_EX_GRIDLINES);
		
		//create columns
		struct {int sub,str,w,fmt;} columns[GAMELIST_NUMCOLS] = 
		{
			{GAMELIST_BANNER,  IDS_GAMELISTBANNER, 37, 0},
			{GAMELIST_TITLE,   IDS_GAMELISTTITLE,  200,0},
			{GAMELIST_TYPE,    IDS_GAMELISTTYPE,   50,0},
			{GAMELIST_COMPANY, IDS_GAMELISTCOMPANY,80, 0},
			{GAMELIST_NOTES,   IDS_GAMELISTNOTES,  130,0},
			{GAMELIST_GENRE,   IDS_GAMELISTGENRE,  100,0},
			{GAMELIST_SIZE,    IDS_GAMELISTSIZE,   58, LVCFMT_RIGHT},
			{GAMELIST_ID,      IDS_GAMELISTID,     50, 0},
		};
		for (int i=0; i<GAMELIST_NUMCOLS; i++)
		{
			LVCOLUMN lvc;
			ZeroMemory(&lvc,sizeof(LVCOLUMN));
			TCHAR temp[256];
			lvc.mask = LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM | LVCF_FMT;  
			lvc.iSubItem = columns[i].sub;
			lvc.fmt = columns[i].fmt;
			lvc.cx = columns[i].w;
			LoadString(hInstance,columns[i].str, temp, 256);
			lvc.pszText = temp;
			ListView_InsertColumn(m_hListView, i, &lvc);
		}
	}

	void Destroy()
	{
		if (imageList!=0)
		{
			ListView_SetImageList(m_hListView,0,LVSIL_SMALL);
			ImageList_Destroy(imageList);
		}
		DestroyWindow(m_hListView);
	}

	void Update(bool dontAsk)
	{
		glist.clear();

		int sel = ListView_GetSelectionMark(m_hListView);
		ListView_DeleteAllItems(m_hListView);

		if (imageList!=0)
		{
			ListView_SetImageList(m_hListView,0,LVSIL_SMALL);
			ImageList_Destroy(imageList);
		}

		imageList=ImageList_Create(32, 32, ILC_COLOR32, 16, 32);
		ListView_SetImageList(m_hListView,imageList,LVSIL_SMALL);		

		bool foundAny=false;
		W32Util::IniFile gameConfigs;
		gameConfigs.SetFile("games");

		
		GameListEntry gle;
		memset(&gle,0,sizeof(GameListEntry));
		_tcscpy(gle.title,_T(" Boot GP32 Empty"));
		_tcscpy(gle.path,"[GP32]");
		glist.push_back(gle);
		_tcscpy(gle.title," Boot GBA Empty");
		_tcscpy(gle.path,"[GBA]");
		glist.push_back(gle);
		_tcscpy(gle.title," Boot DS Empty");
		_tcscpy(gle.path,"[DS]");
		glist.push_back(gle);

		int numGames = 3;
		const char *formats[5] = {"\\*.gba","\\*.bin","\\*.nds","\\*.nef","\\*.ptru"};
		for (int f=0; f<5; f++)
		{
			for (unsigned int i=0; i<g_Config.gcmPaths.size(); i++)
			{
				WIN32_FIND_DATA findData;
				HANDLE FindFirst = FindFirstFile((g_Config.gcmPaths[i] + formats[f]).c_str(), &findData);
				if (FindFirst == INVALID_HANDLE_VALUE)
				{	//no games found here..
					continue;
				}
				else
				{
					bool keepLooping = true;
					char temp[1024];
					while (keepLooping)
					{
						sprintf(temp,"%s\\%s",g_Config.gcmPaths[i].c_str(),findData.cFileName);	
						GameListEntry gle;
						HBITMAP memBM=0;

						if (f==2)
						{
							NDSTool_OpenROM(temp);
							u32 icon[32*32];
							NDSTool_ExtractIcon(icon);
							NDSTool_CloseROM();
							memBM = W32Util::CreateBitmapFromARGB(m_hListView, (DWORD*)icon, NDS_ICON_WIDTH, NDS_ICON_HEIGHT);
							gle.bitmapindex = ImageList_Add(imageList,memBM,0);
						}
//						else
//							memBM = LoadBitmap(hInstance,(LPCSTR)IDB_NOBANNERFOUND);
						if (memBM)
							DeleteObject(memBM);
						/*
						CISOTools ISOHandler(temp);

						u32 BannerImage[CISOTools::DVD_BANNER_WIDTH * CISOTools::DVD_BANNER_HEIGHT];
						char szGameName[256];
						char szCompany[256];


						strcpy(gle.id, ISOHandler.GetGameId());
						strcpy(gle.company, szCompany);
						gameConfigs.SetSection(ISOHandler.GetGameId());
						gameConfigs.ReadString("Genre","-",gle.genre,256);
						gameConfigs.ReadString("Notes","-",gle.notes,256);
						gameConfigs.ReadString("Name",szGameName,gle.title,256);
						gle.size = ISOHandler.GetISOSize();
						*/


						strcpy(gle.type,formats[f]+3);
						strcpy(gle.title,findData.cFileName);
						strcpy(gle.id,"");
						strcpy(gle.notes,"");
						strcpy(gle.genre,"");
						strcpy(gle.company,"unknown");
						strcpy(gle.path, temp);
						HANDLE hFile = CreateFile(gle.path, GENERIC_READ, 0, NULL,
							OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
						if (hFile != INVALID_HANDLE_VALUE)
							gle.size=GetFileSize(hFile,0);
						else
							gle.size=0;
						CloseHandle(hFile);
						glist.push_back(gle);
						keepLooping = FindNextFile(FindFirst, &findData) ? true : false;
						numGames++;
					}
				}
			}
		}


		LVITEM lvi;
		ZeroMemory(&lvi, sizeof(LVITEM));
		for (int i=0; i<numGames; i++)
		{
			GameListEntry &gle = glist[i];
			lvi.iItem   = i;
			lvi.mask = LVIF_TEXT | LVIF_IMAGE | LVIF_PARAM;
			lvi.pszText = "";
			lvi.iImage  = gle.bitmapindex;
			lvi.lParam  = i;
			int idx = ListView_InsertItem(m_hListView, (LPARAM)(const LV_ITEM *)(&lvi));
			ListView_SetItemText(m_hListView,idx,GAMELIST_ID, gle.id);
			ListView_SetItemText(m_hListView,idx,GAMELIST_TITLE, gle.title);
			ListView_SetItemText(m_hListView,idx,GAMELIST_COMPANY, gle.company);
			ListView_SetItemText(m_hListView,idx,GAMELIST_NOTES,gle.notes);
			ListView_SetItemText(m_hListView,idx,GAMELIST_GENRE,gle.genre);
			ListView_SetItemText(m_hListView,idx,GAMELIST_TYPE,gle.type);
			char temp[25];
			W32Util::NiceSizeFormat(gle.size,temp);
			ListView_SetItemText(m_hListView,idx,GAMELIST_SIZE,temp);
		}

		ListView_SetSelectionMark(m_hListView,sel);
		ListView_SortItems(m_hListView,	ListViewCompareProc,GAMELIST_TITLE);

		/*
		if (!numGames && !dontAsk)
		{
			TCHAR text[512];
			LoadString(hInstance,IDS_ERRORNOGCMFOUND,text,512);
			if (IDYES == MessageBox(MainWindow::GetHWND(),text,"Dolphin Error",MB_YESNO|MB_ICONQUESTION))
			{
				dlgSettings_Run(MainWindow::GetHInstance(),MainWindow::GetHWND(),1);
			}
		}*/
	}


	inline COLORREF blend50(COLORREF c1, COLORREF c2)
	{
		return ((c1&0xFEFEFE)>>1) + ((c2&0xFEFEFE)>>1) + 0x010101;
	}



	int GetCurrentItem()
	{
		int numSel = ListView_GetSelectedCount(m_hListView);
		if (numSel == 1)
		{
			int n = ListView_GetNextItem(m_hListView,-1,LVNI_SELECTED);
			if (n == -1) 
				return -1;

			LVITEM it;
			it.iItem = n;
			it.iSubItem=0;
			it.mask = LVIF_PARAM;
			ListView_GetItem(m_hListView,&it);
			return it.lParam;
		}
		else
			return -1;
	}

	DWORD HandleWMNotify(HWND hwnd, WPARAM wParam, LPARAM lParam)
	{
		NMHDR *hdr = (NMHDR*)lParam;
		NMLVDISPINFO *pLvdi = (NMLVDISPINFO *)lParam;
		NMLISTVIEW *nmlv = (NMLISTVIEW*)lParam;

		switch(hdr->code) {
		case LVN_COLUMNCLICK:
			{
				int si = nmlv->iSubItem;
				if (si==GAMELIST_BANNER) si=GAMELIST_TITLE;
				ListView_SortItems(hdr->hwndFrom,
					ListViewCompareProc,
					(LPARAM)(si));
				sortDir[si] *= -1;
				break;
			}
		case LVN_ITEMACTIVATE:
			{
				LPNMITEMACTIVATE hdr = (LPNMITEMACTIVATE)lParam;
				if (hdr->hdr.hwndFrom != m_hListView) return 0;
				
			}
			break;
		case NM_CUSTOMDRAW:
			{
				int result = CDRF_DODEFAULT;

				NMLVCUSTOMDRAW* pLVCD = reinterpret_cast<NMLVCUSTOMDRAW*>(hdr);
				switch (pLVCD->nmcd.dwDrawStage) 
				{
				case CDDS_PREPAINT:
					result = CDRF_NOTIFYITEMDRAW;
					break;
				case CDDS_ITEMPREPAINT:
					result = CDRF_NOTIFYSUBITEMDRAW;
					break;
				case (CDDS_ITEMPREPAINT | CDDS_SUBITEM):
					pLVCD->clrTextBk = (pLVCD->nmcd.dwItemSpec&1) ? blend50(GetSysColor(COLOR_3DLIGHT),GetSysColor(COLOR_WINDOW)) : GetSysColor(COLOR_WINDOW);
					switch (pLVCD->iSubItem) {
					//case 1: pLVCD->clrText = 0xAAAAAA; break;
					case GAMELIST_TITLE: pLVCD->clrText = 0xFF0000; break;
					case GAMELIST_COMPANY: pLVCD->clrText = 0x007030; break;
					default:pLVCD->clrText = 0x000000; break;
					}
				
				//case CDDS_ITEMPOSTPAINT:
				//	{
				//		RECT rc = pLVCD->rcText;
				//		HDC dc = pLVCD->nmcd.hdc;
				//		TextOut(dc,rc.left,rc.top,"hello",strlen("hello"));
				//	}
					break;
				}
				return result;
			}
			break;
		//case NM_
		case NM_RCLICK:
			{
				LPNMITEMACTIVATE hdr = (LPNMITEMACTIVATE)lParam;
				if (hdr->hdr.hwndFrom != m_hListView) return 0;
				POINT pt;
				GetCursorPos(&pt);
				int idx=GetCurrentItem();
				if (idx!=-1)
				{
					switch (TrackPopupMenuEx(GetSubMenu(g_hPopupMenus,4),TPM_RIGHTBUTTON|TPM_RETURNCMD,pt.x,pt.y,hwnd,0))
					{
					case ID_GAMELIST_PLAY:
						Doubleclick();
						break;
					case ID_GAMELIST_PROPERTIES:
						//DlgProperties_Run(glist[idx].path,glist[idx].title,hInstance,hwnd);
						/*
						{
							SHELLEXECUTEINFO sei = { sizeof(sei) };
							sei.fMask = SEE_MASK_FLAG_DDEWAIT;
							sei.lpVerb = TEXT("properties");
							sei.lpFile = glist[idx].path;
							ShellExecuteEx(&sei);
						}*/
						break;
					case ID_GAMELIST_OPENWITH:
						{
							SHELLEXECUTEINFO sei = { sizeof(sei) };
							sei.fMask = SEE_MASK_FLAG_DDEWAIT;
							sei.lpVerb = TEXT("openas");
							sei.lpFile = glist[idx].path;
							ShellExecuteEx(&sei);
						}
						break;
					}
				}
			}
			break;
		case NM_DBLCLK:
		case NM_RETURN:
			Doubleclick();
			break;
		}
		return 0;
	}
	void Doubleclick()
	{
		int idx = GetCurrentItem();
		if (idx!=-1 && !g_State.bEmuThreadStarted)
		{
			char path[1024],title[256];
			strcpy(path,glist[idx].path);
			strcpy(title,glist[idx].title);
			g_State.bEmuThreadStarted=true;
			MainWindow::SetPlaying(title);
			MainWindow::Update();
			//g_Config.Boot_GCM = true;
			//CCore::Start(path,0,BOOT_ISO);
			//Core_Init(MODE_GBA,path);
			EmuThread_Start(path);
		}
	}

	void GetSelectedGCMPath(TCHAR *buffer, int size)
	{
		int idx = GetCurrentItem();
		if (idx != -1)
		{
			strncpy(buffer,glist[idx].path,size);
		}
		else
			strcpy(buffer,"");
	}

	HWND GetHWND()
	{
		return m_hListView;
	}
}
/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <windowsx.h>
#include "resource.h"
#include "../Globals.h"
#include "DlgSettings.h"
#include "W32Util/PropertySheet.h"
#include "W32Util/ShellUtil.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////
// I M P L E M E N T A T I O N //////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

// __________________________________________________________________________________________________
// GeneralDlgProc 
//



struct TabGeneral : public W32Util::Tab 
{
	COLORREF bgcolor;

	void Init(HWND hDlg)
	{
		TCHAR temp[256];
		sprintf(temp,TEXT("%06x"),g_Config.bannerBGColor);
		SetWindowText(GetDlgItem(hDlg,IDC_BANNERBG),temp);

		Button_SetCheck(GetDlgItem(hDlg,IDC_AUTOLOADLAST), g_Config.bAutoLoadLast);
		Button_SetCheck(GetDlgItem(hDlg,IDC_AUTORUN), g_Config.bAutoRun);

		//add bioses to list
		WIN32_FIND_DATA find;
		HANDLE search = FindFirstFile("bios/*.*",&find);
		if (search != INVALID_HANDLE_VALUE)
		{
			HRESULT hr;
			do 
			{
				if (strcmp(find.cFileName,".")!=0 && strcmp(find.cFileName,"..")!=0)
					ListBox_AddString(GetDlgItem(hDlg,IDC_BIOSLIST),find.cFileName);

				hr = FindNextFile(search,&find);
			} while(hr);
			FindClose(search);
		}
	}

	void Command(HWND hDlg,WPARAM wParam)
	{
		switch (LOWORD(wParam))
		{
		case IDC_CHOOSEBANNERBG:
			{
				CHOOSECOLOR col;
				static COLORREF custcols[16];
				ZeroMemory(&col,sizeof(CHOOSECOLOR));
				col.lStructSize = sizeof(CHOOSECOLOR);
				col.hwndOwner = hDlg;
				TCHAR temp[256];
				GetWindowText(GetDlgItem(hDlg,IDC_BANNERBG),temp,256);
				sscanf(temp,TEXT("%06x"),&col.rgbResult);
				col.lpCustColors = custcols;
				col.Flags = CC_RGBINIT | CC_ANYCOLOR | CC_FULLOPEN;
				
				if (ChooseColor(&col))
				{
					char temp[256];
					sprintf(temp,"%06x",col.rgbResult);
					SetWindowText(GetDlgItem(hDlg,IDC_BANNERBG),temp);
					break;
				}
			}
			break;
			//other buttons here..
		}
	}
	void Apply(HWND hDlg)
	{
		char temp[256];
		GetWindowText(GetDlgItem(hDlg,IDC_BANNERBG),temp,256);
		sscanf(temp,"%06x",&g_Config.bannerBGColor);
		g_Config.bAutoLoadLast = Button_GetCheck(GetDlgItem(hDlg,IDC_AUTOLOADLAST)) != 0 ? true : false;
		g_Config.bAutoRun = Button_GetCheck(GetDlgItem(hDlg,IDC_AUTORUN)) != 0 ? true : false;

//		GetWindowText(GetDlgItem(hDlg,IDC_DVDHLEPATH),g_Config.DVDHLEPath,256);
	}
};



struct TabPaths : public W32Util::Tab
{
	void Init(HWND hDlg)
	{
		for (unsigned int i=0; i<g_Config.gcmPaths.size(); i++)
		{
			ListBox_AddString(GetDlgItem(hDlg,IDC_GCMPATHS), g_Config.gcmPaths[i].c_str());
		}
//		Button_SetCheck(GetDlgItem(hDlg,IDC_DISABLEGCMCHECK), g_Config.bDontAskForGCMPaths);
	}
	void Command(HWND hDlg,WPARAM wParam)
	{
		switch (LOWORD(wParam))
		{	
		case IDC_ADDGCMPATH:
			{
				std::string path = W32Util::BrowseForFolder(hDlg,"Set GCM Path:");
				if (path.size())
					ListBox_AddString(GetDlgItem(hDlg,IDC_GCMPATHS), path.c_str());
			}
			break;
		case IDC_REMOVEGCMPATH:
			ListBox_DeleteString(GetDlgItem(hDlg,IDC_GCMPATHS),ListBox_GetCurSel(GetDlgItem(hDlg,IDC_GCMPATHS)));
			break;
			//other buttons here..
		}
	}

	void Apply(HWND hDlg)
	{
		g_Config.gcmPaths.clear();
		for (int i=0; i<ListBox_GetCount(GetDlgItem(hDlg,IDC_GCMPATHS)); i++)
		{
			char temp[1024];
			ListBox_GetText(GetDlgItem(hDlg,IDC_GCMPATHS),i,temp);
			g_Config.gcmPaths.push_back(std::string(temp));
		}
//		g_Config.bDontAskForGCMPaths = Button_GetCheck(GetDlgItem(hDlg,IDC_DISABLEGCMCHECK)) != 0 ? true : false;
	}
};


// __________________________________________________________________________________________________
// constructor 
//
void dlgSettings_Run(HINSTANCE _hInstance, HWND _hParent, int page)
{
	W32Util::PropSheet sheet;
	sheet.Add(new TabGeneral,      (LPCTSTR)IDD_SETTINGSGENERAL, (LPCTSTR)IDS_DLGSETTINGSGENERAL);
	sheet.Add(new TabPaths,        (LPCTSTR)IDD_SETTINGSPATHS,   (LPCTSTR)IDS_DLGSETTINGSGCMPATHS);
//	sheet.Add(new TabPluginSelect, (LPCTSTR)IDD_SETTINGSPLUGINS, (LPCTSTR)IDS_DLGSETTINGSPLUGINS);
	sheet.Show(_hInstance, _hParent, TEXT("DaSh"),page);
}


void dlgConfWiz_Run(HINSTANCE _hInstance, HWND _hParent)
{
	W32Util::PropSheet sheet;
//	sheet.SetWaterMark((LPCTSTR)IDB_WIZBANNER);
	sheet.SetIcon(LoadIcon(_hInstance, (LPCTSTR)IDI_DASH));
	sheet.Add(new W32Util::WizFirstPage(IDC_CFGWIZFIRSTPAGETITLE), (LPCTSTR)IDD_WIZARDPAGE1, 0);
	sheet.Add(new TabPaths,              (LPCTSTR)IDD_SETTINGSPATHS, (LPCTSTR)IDS_CFGWIZTITLE1, (LPCTSTR)IDS_CFGWIZSUBTITLE1);
//	sheet.Add(new TabPluginSelect,            (LPCTSTR)IDD_SETTINGSPLUGINS, (LPCTSTR)IDS_CFGWIZTITLE2, (LPCTSTR)IDS_CFGWIZSUBTITLE2);
	sheet.Add(new W32Util::WizLastPage(IDC_CFGWIZLASTPAGETITLE),  (LPCTSTR)IDD_WIZARDPAGELAST, 0);
	sheet.Show(_hInstance,_hParent,"DaSh Configuration Wizard",0,0,true);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"


#include "Commctrl.h"

//#include "Core.h"
#include "Windows/resource.h"

#include "Windows/WndMainWindow.h"
#include "Windows/Debugger/Debugger_LogWindow.h"
#include "Windows/Debugger/Debugger_MemoryDlg.h"
#include "Windows/Debugger/Debugger_MemChecksDlg.h"
#include "Windows/Debugger/Debugger_MemSearchDlg.h"
#include "Windows/Debugger/Debugger_DynaViewDlg.h"
#include "Windows/Debugger/Debugger_VFPUDlg.h"

#include "Windows/W32Util/DialogManager.h"
#include "Windows/DlgSettings.h"
#include "Windows/ImageExplorer.h"

#include "Windows/Debugger/CtrlDisAsmView.h"
#include "Windows/Debugger/CtrlMemView.h"
#include "Windows/Debugger/CtrlRegisterList.h"

#include "Windows/WindowsHost.h"

#include "Windows/main.h"

//#include <intrin.h>
//#include "zlib.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////
// G L O B A L S ////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

HINSTANCE global_hInstance;

CDisasm *disasmWindow[MAX_CPUCOUNT];
CMemoryDlg *memoryWindow[MAX_CPUCOUNT];
CDynaViewDlg *dynaWindow[MAX_CPUCOUNT];

/////////////////////////////////////////////////////////////////////////////////////////////////////
// I M P L E M E N T A T I O N //////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#include <math.h>

#pragma pack(1)
typedef struct
{
	unsigned long num;
	unsigned long GPR[32];
	unsigned long CR;
	unsigned long LR;
	unsigned long CTR;
	unsigned long XER;
	double FPR[32];
	unsigned long SRR0;
	unsigned long SRR1;
	unsigned long GQR[8];
	double PSF[32];
} GC_Context;



void Dump2Text(void)
{
	FILE* pOut = fopen("e:\\dump.txt", "wt");
	FILE* pFile = fopen("e:\\dump.bin", "rb");
	if (pFile)
	{
		for (int i=0; i<1000; i++)
		{
			GC_Context tmpContent, content;
			fread(&tmpContent, 1, sizeof(tmpContent), pFile);

			u8* p1 = (u8*)&tmpContent;
			u8* p2 = (u8*)&content;
			for (int j=0; j<sizeof(tmpContent); j++)
			{
				p2[j] = p1[j^3];
			}

			fprintf(pOut, "0x%08x:    PC: 0x%08x\n", content.num, content.SRR0);

			for (int j=0; j<32;j++)
			{
				fprintf(pOut, "GPR[%02i]	0x%08x\n", j, content.GPR[j]);
			}
		}
		fclose(pOut);
		fclose(pFile);
	}

	exit(1);
}




bool CheckForCPUExtensions()
{
/*	int i;
	int id[4];
	__cpuid(id, 1);
	i=id[3];
	hasMMX  = ((i&0x0800000)!=0);
	hasSSE  = ((i&0x2000000)!=0);
	hasSSE2 = ((i&0x4000000)!=0);

	if (!hasMMX)
	{
		if (IDNO == MessageBox(0,"WARNING: Your CPU does not appear to support MMX. \nDaSh will not work and will probably crash.\n\nContinue anyway?","Compatibility Warning",MB_YESNO|MB_ICONERROR))
		{
			return false;
		}
	}
	if (!hasSSE)
	{
		if (IDNO == MessageBox(0,"WARNING: Your CPU does not appear to support SSE.\nDaSh hasn't been fully tested without it and may not work.\n\nContinue anyway?","Compatibility Warning",MB_YESNO|MB_ICONERROR))
		{
			return false;
		}
	}
*/
	return true;
}


// __________________________________________________________________________________________________
// WinMain
// Note that there is NO core code in here anymore
//
int WINAPI WinMain(HINSTANCE _hInstance, HINSTANCE hPrevInstance, LPSTR szCmdLine, int iCmdShow)
{	
//	Dump2Text();
	// Check for available CPU extensions
	if (!CheckForCPUExtensions())
	{
		return -1;
	}
/*
	FILE *f = fopen("bios/bios.bin","rb");

	char *mojs = new char[1024*1024*2];
	char *out = new char[1024*1024*2];
	fread(mojs,1024*1024*2,1,f);
	fclose(f);
	int olen;
	compress((Bytef*)out,(uLongf*)&olen,(Bytef*)mojs,1024*1024*2);

	f = fopen("bios/fakebios.bin","wb");
	fwrite(out,olen,1,f);
	fclose(f);
	return 0;
*/
	char *token = szCmdLine;
	char fileToLoad[256] = "";
	
	token = strtok(szCmdLine," ");

	g_Config.Load();

	while (token)
	{
		if (strcmp(token,"-s"))
		{
			//start as server
		}
		else if (strcmp(token,"-c"))
		{
			//start as client
		}
		else if (strcmp(token,"-run"))
		{
			//run immediately
		}
		else if (strcmp(token,"-left"))
		{
			//left layout
		}
		else if (strcmp(token,"-right"))
		{
			//right layout
		}
		else if (strcmp(token,"-fb"))
		{
			//enable framebuffer
		}
		else
		{
			//load a dol
		}

		token=strtok(NULL," ");
	}

	//Windows, API init stuff
	MSG msg;
	global_hInstance = _hInstance;

	INITCOMMONCONTROLSEX comm;
	comm.dwSize = sizeof(comm);
	comm.dwICC = ICC_BAR_CLASSES | ICC_LISTVIEW_CLASSES | ICC_TAB_CLASSES;
	InitCommonControlsEx(&comm);

	if (g_Config.bFirstRun)
	{
		dlgConfWiz_Run(_hInstance, 0);
	}
	
	MainWindow::Init(_hInstance);
	host = new WindowsHost(MainWindow::GetDisplayHWND());

	HACCEL hAccelTable = LoadAccelerators(_hInstance, (LPCTSTR)IDR_ACCELS);
	g_hPopupMenus=LoadMenu(_hInstance,(LPCSTR)IDR_POPUPMENUS);

	MainWindow::Show(_hInstance, iCmdShow);

	HWND hwndMain = MainWindow::GetHWND();
	HMENU menu = GetMenu(hwndMain);
	HMENU systemsMenu = GetSubMenu(menu, 0);

	RemoveMenu(systemsMenu, 0, MF_BYPOSITION);
	
	for (int i=0; i<4; i++)
	{
		AppendMenu(systemsMenu, MF_STRING, 0x10000+i, "PSP");
	}

	//initialize custom controls
	CtrlDisAsmView::init();
	CtrlMemView::init();
	CtrlRegisterList::init();


	//DialogManager::AddDlg(arm7dis      = new CDisasm(_hInstance, hwndMain, &arm7));
	//DialogManager::AddDlg(arm9dis      = new CDisasm(_hInstance, hwndMain, &arm9));
	//DialogManager::AddDlg(memoryWindow[0]    = new CMemoryDlg(_hInstance, hwndMain, &arm9));
	//DialogManager::AddDlg(memoryWindow[1]    = new CMemoryDlg(_hInstance, hwndMain, &arm7));
	DialogManager::AddDlg(memcheckdlg  = new CMemChecksDlg(_hInstance, hwndMain));
	DialogManager::AddDlg(memsearchdlg = new CMemSearchDlg(_hInstance, hwndMain));
	DialogManager::AddDlg(logwindow    = new CDebugger_LogWindow(_hInstance, hwndMain));
	DialogManager::AddDlg(imageExplorer = new ImageExplorer(_hInstance,hwndMain));
	DialogManager::AddDlg(vfpudlg = new CVFPUDlg(_hInstance,hwndMain));

	//imageExplorer->Show(true);
#ifdef LOGGING
	logwindow->Show(true);	
#endif

	MainWindow::Update();
	MainWindow::UpdateMenus();

	if (strlen(fileToLoad))	
	{
		// TODO: load the thing
	}

	//so.. we're at the message pump of the GUI thread
	while (GetMessage(&msg, NULL, 0, 0))  //while no quit
	{
		//DSound_UpdateSound();

		//hack to make it possible to get to main window from floating windows with Esc
		if (msg.hwnd != hwndMain && msg.message==WM_KEYDOWN && msg.wParam==VK_ESCAPE)
			BringWindowToTop(hwndMain);

		//Translate accelerators and dialog messages...
		if (!TranslateAccelerator(hwndMain, hAccelTable, &msg)) 
		{
			if (!DialogManager::IsDialogMessage(&msg))
			{
				//and finally translate and dispatch
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
	}

	DialogManager::DestroyAll();
	g_Config.Save();
	delete host;
	return 0;
}
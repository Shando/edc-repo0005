#include "stdafx.h"

#include "../System.h"
#include "../MemMap.h"
#include "../Misc.h"
#include "../Host.h"

#include "PSPSystem.h"
#include "PSPMixer.h"

#include "HLE/sceAudio.h"

int PSPMixer::Mix(short *stereoout, int numSamples)
{
	return PSPHLE::__AudioMix(stereoout, numSamples);
}

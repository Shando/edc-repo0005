#include "stdafx.h"

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glext.h>

#include "ge_constants.h"
#include "PSPGfxState.h"

GPUgstate gstate;



//When you have changed state outside the psp gfx core,
//or saved the context and has reloaded it, call this function.
void ApplyState()
{

}

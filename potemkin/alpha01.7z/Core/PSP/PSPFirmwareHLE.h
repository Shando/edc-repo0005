#pragma once

#include "../../Globals.h"

#define STACKTOP 0x09F00000
#define STACKSIZE 0x10000

namespace PSPHLE
{
	typedef void (* HLEFunc)();

	struct HLEFunction 
	{
		u32 ID;
		HLEFunc func;
		const char *name;
		int numParameters; //not used
	};

	struct HLEModule
	{
		const char *name;
		int numFunctions;
		const HLEFunction *funcTable;
	};

#define HLEDECL __cdecl

#define FID(s) (s^0x1337babe)

#define PARAM(n) currentMIPS->r[4+n]
#define RETURN(n) currentMIPS->r[2]=n;

	const char *GetFuncName(const char *module, u32 nib);
	const char *GetFuncName(int module, int func);
	const char *GetModuleName(int moduleindex);
	const HLEFunction *GetFunc(const char *module, u32 nib);
	int GetFuncIndex(int moduleIndex, u32 nib);
	int GetModuleIndex(const char *modulename);

	void Init();
	void WriteSyscall(const char *module, u32 nib, u32 address);
	void CallSyscall(u32 op);

	// Need to be able to save entire kernel state
	int GetStateSize();
	void SaveState(u8 *ptr);
	void LoadState(const u8 *ptr);
}

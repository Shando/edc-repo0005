#pragma once

#include "../../Globals.h"

#include "../System.h"
#include "../MemMap.h"


void Load_PBP(const TCHAR *filename);

void Load_PSP_ISO(const TCHAR *filename);
void Load_PSP_ELF(const TCHAR *filename);
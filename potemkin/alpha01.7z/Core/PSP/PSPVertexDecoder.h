#pragma once
#include "../../Globals.h"



struct DecodedVertex
{
	float pos[3];    //in case of morph, preblend during decode
	float normal[3]; //in case of morph, preblend during decode
	float uv[2];      //scaled by uscale, vscale, if there
	float color[4]; //unlit
	float weights[8];
};




//Right now 
//  - only contains computed information
//  - does decoding in nasty branchfilled loops
//Future 
//  - will compile into lighting fast specialized x86 
//
//We want 100% perf on 1Ghz even in vertex complex games!
//
//We should do a caching mechanism for these - compiling into x86
//each time will destroy instruction cache
class VertexDecoder 
{

	u32 fmt;
	bool throughmode;
	int biggest;

	int weightoff;
	int tcoff;
	int coloff;
	int nrmoff;
	int posoff;
	int size;
	int oneSize;

	int tc;
	int col;
	int nrm;
	int pos;
	int weighttype;
	int idx;
	int morphcount;
	int nweights;

public:
	VertexDecoder() {}
	~VertexDecoder() {}
	void SetVertexType(u32 fmt);
	void DecodeVerts(DecodedVertex *decoded, const void *verts, const void *inds, int prim, int count) const;
};

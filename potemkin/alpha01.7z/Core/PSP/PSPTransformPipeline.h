#pragma once

#include "../System.h"
#include "../MemMap.h"
#include "../Host.h"


void TransformAndDrawPrim(void *verts, void *inds, int prim, int count);

struct Color4
{
	float r,g,b,a;
	Color4() { }
	Color4(float _r, float _g, float _b, float _a=1.0f)
	{
		r=_r; g=_g; b=_b; a=_a;
	}
	Color4(float in[4]) {r=in[0];g=in[1];b=in[2];a=in[3];}

	float &operator [](int i) {return *(&r + i);}
	const float &operator [](int i) const {return *(&r + i);}

	Color4 operator *(float f) const
	{
		return Color4(f*r,f*g,f*b,f*a);
	}
	Color4 operator *(const Color4 &c) const
	{
		return Color4(r*c.r,g*c.g,b*c.b,a*c.a);
	}
	void operator *=(const Color4 &c)
	{
		r*=c.r,g*=c.g,b*=c.b,a*=c.a;
	}
	Color4 operator +(const Color4 &c) const
	{
		return Color4(r+c.r,g+c.g,b+c.b,a+c.a);
	}
	void operator +=(const Color4 &c)
	{
		r+=c.r,g+=c.g,b+=c.b,a+=c.a;
	}
	void GetFromRGB(u32 col)
	{
		r = ((col>>16)&0xff)/255.0f;
		g = ((col>>8)&0xff)/255.0f;
		b = ((col>>0)&0xff)/255.0f;
	}
	void GetFromA(u32 col)
	{
		a = (col&0xff)/255.0f;
	}
};


extern float worldMatrix[12];
extern float viewMatrix[12];
extern float projMatrix[16];
extern float tgenMatrix[12];
extern float boneMatrix[8*12];

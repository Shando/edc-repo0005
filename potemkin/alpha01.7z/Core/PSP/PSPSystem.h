#pragma once

#include "../System.h"
#include "../MemMap.h"
#include "../FileSystems/MetaFileSystem.h"

extern System PSPSystem;

extern MemRegionInfo PSPregions[];

extern const int numPSPRegions;
extern MetaFileSystem pspFileSystem;

void PSP_Init();
void PSP_Shutdown();
void PSP_HWAdvance(int cycles);
void PSP_SWI();

// In the future - Put these in PC memory space and rock :)
inline u32 PSP_GetMemoryBase() { return 0x08000000;}
inline u32 PSP_GetMemoryEnd()  { return 0x0A000000;}

inline u32 PSP_GetKernelMemoryBase() { return 0x08000000;}
inline u32 PSP_GetKernelMemoryEnd()  { return 0x08800000;}

inline u32 PSP_GetUserMemoryBase() { return 0x08800000;}
inline u32 PSP_GetUserMemoryEnd()  { return 0x0A000000;}

inline u32 PSP_GetDefaultLoadAddress() { return 0x08880000;}
//inline u32 PSP_GetDefaultLoadAddress() { return 0x0898dab0;}
inline u32 PSP_GetVidMemBase() { return 0x04000000;}
#include "stdafx.h"

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glext.h>

#include "PSPDisplay.h"
#include "PSPGfxState.h"

#include "../Graphics/G2D.h"
#include "../Host.h"
#include "../MemMap.h"
#include "ge_constants.h"

#define xres 480
#define yres 272


//////////////////////////////////////////////////////////////////////////
// STATE BEGIN
static GLuint backbufTex;

extern u32 *pspframebuf;
u16 realFB[512*272];
int pspframebufmode;
static int numFrames;
// STATE END
//////////////////////////////////////////////////////////////////////////

void PSPDisplay_Init()
{
/*
	LOG(G3D, "ProjMtxNum: %02x", (u32*)&gstate.projmtxnum - (u32*)&gstate.nop);
	LOG(G3D, "Lx0: %02x", (u32*)&gstate.lpos[0] - (u32*)&gstate.nop);
	LOG(G3D, "Lac0: %02x", (u32*)&gstate.lcolor[0] - (u32*)&gstate.nop);
	LOG(G3D, "Diffuse: %02x", (u32*)&gstate.materialdiffuse - (u32*)&gstate.nop);
	LOG(G3D, "TexMapMode: %02x", (u32*)&gstate.texmapmode - (u32*)&gstate.nop);*/



	glPolygonMode (GL_FRONT_AND_BACK, GL_FILL);
	
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glShadeModel(GL_SMOOTH);

	glEnable(GL_TEXTURE_2D);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	

	//glMatrixMode(GL_PROJECTION);
	//glOrtho(0.0f,480,272,0.0f,-1.0f,1.0f);		// Create Ortho 640x480 View (0,0 At Top Left)
	//glMatrixMode(GL_MODELVIEW);						// Select The Modelview Matrix
	//glLoadIdentity();								// Reset The Modelview Matrix

	glGenTextures(1,&backbufTex);

	//initialize lights
	for (int i=0; i<4; i++)
	{
		float ones[4]={1,1,1,1};
		float zeros[4]={0,0,0,1};
		glLightfv(i,GL_DIFFUSE,ones);
		glLightfv(i,GL_AMBIENT,zeros);
		glLightfv(i,GL_SPECULAR,ones);
		glDisable(GL_LIGHT0+i);
	}

	//initialize backbuffer textures
	for (int i=0; i<2; i++)
	{
		glBindTexture(GL_TEXTURE_2D,backbufTex);
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);
		glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,512,512,0, GL_RGBA,GL_UNSIGNED_SHORT_1_5_5_5_REV,0);
	}
	glDisable(GL_TEXTURE_2D);
	//gluBuild2DMipmaps(GL_TEXTURE_2D,GL_RGB5_A1,256,128,GL_RPSP,GL_UNSIGNED_BYTE,g2dCores[0].GetPointer());
	//(GL_TEXTURE_2D,0,3,128,128,0,GL_BGR_EXT,GL_UNSIGNED_BYTE,g2dCores[0].GetPointer());

	for (int i=0; i<3; i++)
	{
		PSPDisplay_Draw();
	}
}

void PSPDisplay_Draw()
{
	LOG(G3D, "============= PSPDisplay_Draw() (2d blit) =============");
	static int i=0;
	i++;
	if ((i&15))
	{
		//return;
	}


	//return;
	host->BeginFrame();

	glClearColor(0,0,0,0);
	glClear(GL_DEPTH_BUFFER_BIT);

	glColor4f(1,1,1,1);

	glEnable(GL_TEXTURE_2D);

	float u1 = 480/512.0f;
	float v1 = 272/512.0f;

	u32 *src = (u32*)pspframebuf;
	u32 *dst = (u32*)realFB;
	for (int y=0; y<272; y++)
	{
		for (int x=0; x<240; x++)
		{
			int r = src[x] & 0x1F001F;
			int g = src[x] & 0x3E003E0;
			int b = src[x] & 0x7E007E00;
			dst[x] = (r<<11) | (g<<1) | (b>>9);
		}
		src+=256;
		dst+=240;
	}
	glBindTexture(GL_TEXTURE_2D,backbufTex);
	//glPixelStoref(GL_PACK_ROW_LENGTH,512);
	glTexSubImage2D(GL_TEXTURE_2D,0,0,0,480,272, GL_RGBA, GL_UNSIGNED_SHORT_5_5_5_1, realFB);

	glBegin(GL_TRIANGLE_FAN);
	glTexCoord2f(0,0);
	glVertex3f(0,0,0);
	glTexCoord2f(u1,0);
	glVertex3f(480,0,0);
	glTexCoord2f(u1,v1);
	glVertex3f(480,272,0);
	glTexCoord2f(0,v1);
	glVertex3f(0,272,0);
	glEnd();

	glDisable(GL_TEXTURE_2D);
	host->EndFrame();

	numFrames++;
}

void PSPDisplay_Shutdown()
{
	glDeleteTextures(1,&backbufTex);
}

#include "stdafx.h"

#include "../System.h"
#include "../MemMap.h"
#include "../Misc.h"



#include "../MIPS/MIPS.h"
#include "../MIPS/MIPSCompiler.h"

#include "PSPSystem.h"
#include "PSPDisplay.h"
#include "PSPMixer.h"
#include "PSPFirmwareHLE.h"
#include "HLE/sceKernel.h"
#include "HLE/sceKernelMemory.h"
#include "HLE/sceAudio.h"

//#include "PSPIO.h"

System PSPSystem = 
{
	"PSP",
	"Sony",
	"*.pbp;*.elf;*.iso;*.cso;",
	1, //one cpu
	1, //one display
	1, //one controller, max
	0x08900000, // ???????????
	{CPUTYPE_MIPSR4K},
	{222000000}, //222mhz
	PSP_HWAdvance,
	PSP_SWI
};

MetaFileSystem pspFileSystem;


void MEMDECL PSPVramWrite8(u32 address, u8 value)
{
	//MessageBox(0,"oh yea8",0,0);
}

void MEMDECL PSPVramWrite16(u32 address, u16 value)
{
	//MessageBox(0,"oh yea16",0,0);

}

void MEMDECL PSPVramWrite32(u32 address, u32 value)
{
//	MessageBox(0,"oh yea32",0,0);

}


MemRegionInfo PSPregions[] =
{
	//{"HLE Hack Memory", CPU_0,       MRTYPE_MEMORY, 0x00000000,0x00001000,0}, //4k of hacks :P
	{"Scratchpad", CPU_0, MRTYPE_MEMORY, 0x00010000, 0x00014000, 0},
	{"Kernel Memory", CPU_0,       MRTYPE_MEMORY, 0x08000000,0x08400000,0}, //guess
	{"User   Memory", CPU_0,       MRTYPE_MEMORY, 0x08800000,0x0A000000,0}, //guess
	{"User   Memory Uncached", CPU_0, MRTYPE_MIRROR, 0x48800000,0x4A000000,0}, //guess
	{"User   Memory Kernel", CPU_0,   MRTYPE_MIRROR, 0x88800000,0x8A000000,0}, //guess
	//	{"Memory Uncached", CPU_0,       MRTYPE_MIRROR, 0x48900000,0x4A000000,0}, //guess
	{"EDRam",       CPU_0,       MRTYPE_MEMORY, 0x0A000000,0x0A100000,0}, //guess
	{"Frame Buffer ",CPU_0,       MRTYPE_MEMORY, 0x04000000,0x04800000,0,0,0,0},//PSPVramWrite8,PSPVramWrite16,PSPVramWrite32}, //guess
	{"Frame Buffer Uncached",CPU_0,       MRTYPE_MIRROR, 0x44000000,0x44800000,0,0,0,0},//PSPVramWrite8,PSPVramWrite16,PSPVramWrite32}, //guess
//	{"MExt",       MRTYPE_MIRROR, 0x02400000,0x02800000,0},
};

const int numPSPRegions = sizeof(PSPregions)/sizeof(MemRegionInfo);

u32 *pspframebuf;
u32 *pspmainram;

void PSP_Init()
{
	MIPSComp::Init();
	currentSystem = &PSPSystem;
	cpus[0] = &mipsr4k;
	currentCPU = &mipsr4k;
	numCPUs=1;
	MemMap_Init(PSPregions,numPSPRegions,1,0);
	mipsr4k.Reset();
	mipsr4k.SetPC(0x0);
	mipsr4k.SetPC(0x0);

	pspframebuf = (u32*)mipsr4k.memMap.GetMemPointer(0x04000000);
	pspmainram  = (u32*)mipsr4k.memMap.GetMemPointer(PSP_GetMemoryBase());

	//Add an exitthread
	//PSPHLE::WriteSyscall("ThreadManForUser",0x532A522E,0x00000010);
	//PSPIO_SelfTest();
	//PSPIO_Init();
	 
	PSPDisplay_Init();
	host->InitSound(new PSPMixer);
}

void PSP_Shutdown()
{
	host->ShutdownSound();
	PSPHLE::__KernelShutdown();
	MemMap_Shutdown();
	PSPDisplay_Shutdown();
}

static int curTimer=0;
void PSP_HWAdvance(int cycles)
{
	curTimer-=cycles;
	if (curTimer<0) 
	{
		//PSPDisplay_Draw();

		curTimer+=2000000;
	}
}

void PSP_SWI()
{
	LOG(INTC,"SWI");
//	currentARM->SWI();
}

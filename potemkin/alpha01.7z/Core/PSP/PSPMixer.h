#pragma once

#include "../System.h"
#include "../MemMap.h"
#include "../Host.h"


class PSPMixer : public Mixer
{
public:
	int Mix(short *stereoout, int numSamples);
};


#pragma once
#include "../../Globals.h"


void PSPSetTexture();
#pragma once

#include "../../Globals.h"


#include "PSPTransformPipeline.h"

struct GPUgstate
{
	union
	{
		u32 cmdmem[256];
		struct
		{
			int nop;
			u32 vaddr,
				iaddr,
				pad00,
				prim,
				bezier,
				spline,
				boundBox,
				jump,
				bjump,
				call,
				ret,
				end,
				pad01,
				signal,
				finish,
				base,
				pad02,
				vertType,
				offsetAddr,
				origin,
				region1,
				region2,
				lightingEnable,
				lightEnable[4],
				clipEnable,
				cullfaceEnable,
				textureMapEnable,
				fogEnable,
				ditherEnable,
				alphaBlendEnable,
				alphaTestEnable,
				zTestEnable,
				stencilTestEnable,
				antiAliasEnable,
				patchCullEnable,
				colorTestEnable,
				logicOpEnable,
				pad03,
				boneMatrixNumber,
				boneMatrixData,
				morphwgt[8], //dont use
				pad04[0x39-0x33],

				worldmtxnum,//0x3A
				worldmtxdata, //0x3B
				viewmtxnum,   //0x3C
				viewmtxdata,
				projmtxnum,
				projmtxdata,
				texmtxnum,
				texmtxdata,

				viewportx1,
				viewporty1,
				viewportz1,
				viewportx2,
				viewporty2,
				viewportz2,
				texscaleu,
				texscalev,
				texoffsetu,
				texoffsetv,
				offsetx,
				offsety,
				pad111[2],
				shademode,
				reversenormals,
				pad222,
				materialupdate,
				materialemissive,
				materialambient,
				pad333[2],
				materialdiffuse,
				materialspecular,
				materialalpha,
				materialspecularcoef,
				ambientcolor,
				ambientalpha,
				colormodel,
				ltype[4],
				lpos[12],
				ldir[12],
				latt[12],
				lconv[4],
				lcutoff[4],
				lcolor[12],
				cullmode,
				fbptr,
				fbwidth,
				zbptr,
				zbwidth,
				texaddr[8],
				texbufwidth[8],
				clutaddr,
				clutaddrupper,
				transfersrc,
				transfersrcw,
				transferdst,
				transferdstw,
				padxxx[2],
				texsize[8],
				texmapmode,
				texshade,
				texmode,
				texformat,
				loadclut,
				clutformat,
				texfilter,
				texwrap,
				padxxxxx,
				texfunc,
				texenvcolor,
				texflush,
				texsync,
				fog1,
				fog2,
				fogcolor,
				texlodslope,
				padxxxxxx,
				framebufpixformat,
				clearmode
				;

			u32 pad05[0x63-0x40];

		};
	};
	u32 vertexAddr;
	u32 indexAddr;

	bool textureChanged;

	float uScale,vScale;
	float uOff,vOff;
	float lightpos[4][3];
	float lightdir[4][3];
	float lightatt[4][3];
	Color4 lightColor[3][4]; //ADS 
	float morphWeights[8];
	
	u16 paletteMem[256*2];
};


void ApplyState();


extern GPUgstate gstate;

#include "stdafx.h"

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glext.h>

#include "../MemMap.h"
#include "ge_constants.h"
#include "PSPDisplay.h"
#include "PSPGfxState.h"
#include "PSPTexture.h"


struct TexCacheEntry
{
	u32 addr;
	u32 hash;
	u32 frameCounter;
	u32 numMips;
	int dim;
	GLuint texture;
};

typedef std::map<u32, TexCacheEntry> TexCache;

u8 *tempArea;

u32 curTextureWidth;
u32 curTextureHeight;

TexCache cache;


u32 PaletteLoad(int index)
{
	int pf = gstate.clutformat&3;
	int shift = (gstate.clutformat>>2)&31;
	int mask = (gstate.clutformat>>8)&255;
	int start = ((gstate.clutformat>>16)&31)*16;

	if (pf<3)
	{
		//16-bit
		u16 *p = (u16*)gstate.paletteMem;
		u16 col = p[((start+index)>>shift) & mask];
		int r,g,b,a;
		switch (pf)
		{
		case 0:
			r = (col&0x1f)*8;
			g = ((col>>5)&0x3f)*4;
			b = ((col>>11)&0x1f)*8;
			a = 255;
			break;
		case 1:
			r = (col&0x1f)*8;
			g = ((col>>5)&0x1f)*8;
			b = ((col>>10)&0x1f)*8;
			a = (col>>15)*255;
			break;
		case 2:
			r = (col&0xf)*16;
			g = ((col>>4)&0xf)*16;
			b = ((col>>8)&0xf)*16;
			a = ((col>>12)&0xF)*16;
			break;
		}
		return (r) | (g<<8) | (b<<16) | (a<<24);
	}
	else
	{
		u32 *p = (u32*)gstate.paletteMem;
		u32 col = p[((start+index)>>shift) & mask];
		return _byteswap_ulong(col);
	}
}


// This is STUPID, I HATE OPENGL
// This should not have to be done per texture!
void UpdateSamplingParams()
{
	int minFilt = gstate.texfilter & 0x7;
	int magFilt = (gstate.texfilter>>8)&1;
	minFilt &= 1; //no mipmaps yet

	int sClamp = gstate.texwrap & 1;
	int tClamp = (gstate.texwrap>>8) & 1;
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, sClamp ? GL_CLAMP_TO_EDGE : GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, tClamp ? GL_CLAMP_TO_EDGE : GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilt ? GL_LINEAR : GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilt ? GL_LINEAR : GL_NEAREST);
}


void PSPSetTexture()
{
	if (!tempArea)
		tempArea = new u8[512*512*4]; // maximum texture size

	u32 texaddr = (gstate.texaddr[0] & 0xFFFFF0) | ((gstate.texbufwidth[0]<<8) & 0xFF000000);
	texaddr &= 0xFFFFFFF;
	LOG(G3D,"Texture at %08x",texaddr);
	u8 *texptr = GetMemPointer(texaddr);

	TexCache::iterator iter = cache.find(texaddr);
	if (iter != cache.end())
	{
		//Validate the texture here (width, height etc)
		TexCacheEntry &entry = iter->second;

		int dim = gstate.texsize[0] & 0xF0F;
		
		if (dim == entry.dim && entry.hash == *(u32*)texptr)
		{
			//got one!
			glBindTexture(GL_TEXTURE_2D, entry.texture);
			UpdateSamplingParams();
			LOG(G3D,"Texture Found in Cache, applying");
			return; //Done!
		}
		else
		{
			//Damnit, got overwritten.
			//if (dim != entry.dim)
			//{
			//	glDeleteTextures(1, &entry.texture);
			//}
			cache.erase(iter);
			//Fall through
			LOG(G3D,"Texture overwritten, redecoding...");
		}
	}
	else
	{
		LOG(G3D,"No texture in cache, decoding...");
	}

	//we have to decode it

	TexCacheEntry entry;

	entry.addr = texaddr;
	entry.hash = *(u32*)texptr;
	glGenTextures(1, &entry.texture);
	glBindTexture(GL_TEXTURE_2D,entry.texture);
			
	int bufw = gstate.texbufwidth[0] & 0x3ff;
	
	entry.dim = gstate.texsize[0] & 0xF0F;

	int w = 1 << (gstate.texsize[0] & 0xf);
	int h = 1 << ((gstate.texsize[0]>>8) & 0xf);

	curTextureHeight=h;
	curTextureWidth=w;
	int format = gstate.texformat & 0xF;

	LOG(G3D,"Texture Width %04x Height %04x Bufw %d Fmt %d", w, h, bufw, format);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	switch (format)
	{

	case GE_TFMT_4444:
	case GE_TFMT_5551:
	case GE_TFMT_5650:
		{
			u16 *dst = (u16*)tempArea;
			u16 *src = (u16*)texptr;
			if (gstate.texmode & 1) //Swizzled!
			{
				for (int y=0; y<h/8; y++)
				{
					for (int x=0; x<w/8; x++)
					{
						for (int yy=0; yy<8; yy++)
						{
							for (int xx=0; xx<8; xx++)
							{
								dst[(y*8+yy)*w + x*8 + xx] = 
									src[(y*(bufw/8)+x)*8 + (yy*8+xx)];
							}
						}
					}
				}
			}
			else
			{
				for (int y=0; y<h; y++)
				{
					memcpy(dst+y*w,src+bufw*y,2*bufw);
				}
			}
			int fmt = GL_UNSIGNED_SHORT_5_6_5_REV;
			switch (format)
			{
			case GE_TFMT_4444: fmt = GL_UNSIGNED_SHORT_4_4_4_4_REV; break;
			case GE_TFMT_5551: fmt = GL_UNSIGNED_SHORT_1_5_5_5_REV; break;
			}

			//worky?
			glTexImage2D(GL_TEXTURE_2D,0,4, w, h, 0, GL_RGBA, fmt, (GLvoid*)tempArea);
			break;
		}
		
	case GE_TFMT_CLUT4:
		{
			u32 *dst = (u32*)tempArea;
			u8 *src = (u8*)texptr;
			if (gstate.texmode & 1) //Swizzled!
			{
				for (int y=0; y<h/8; y++)
				{
					for (int x=0; x<w/32; x++)
					{
						for (int yy=0; yy<8; yy++)
						{
							for (int xx=0; xx<32; xx++)
							{
								int idx = src[(y*bufw*4+x*16*8) + (yy*16+xx/2)];
								if (xx&1) idx>>=4; else idx&=0xF;
								dst[(y*8+yy)*w + x*32 + xx] = PaletteLoad(idx);
							}
						}
					}
				}
			}
			else
			{
				for (int y=0; y<h; y++)
				{
					for (int x=0; x<w; x++)
					{
						int idx = *src;
						if (x&1) idx >>= 4; else idx &= 0xF;
						dst[x] = PaletteLoad(idx);
						if (x&1)
							src++;
					}
					src -= w/2;
					src += bufw/2;
					dst += w; 
				}
			}
			int fmt = GL_UNSIGNED_INT_8_8_8_8;;
			glTexImage2D(GL_TEXTURE_2D,0,4, w, h, 0, GL_RGBA, fmt, (GLvoid*)tempArea);
			break;
		}


	case GE_TFMT_CLUT8:
		{
			u32 *dst = (u32*)tempArea;
			u8 *src = (u8*)texptr;
			if (gstate.texmode & 1) //Swizzled!
			{
				for (int y=0; y<h/8; y++)
				{
					for (int x=0; x<w/16; x++)
					{
						for (int yy=0; yy<8; yy++)
						{
							for (int xx=0; xx<16; xx++)
							{
								int idx = src[(y*bufw*8+x*16*8) + (yy*16+xx)];
								dst[(y*8+yy)*w + x*16 + xx] = PaletteLoad(idx);
							}
						}
					}
				}
			}
			else
			{
				for (int y=0; y<h; y++)
				{
					for (int x=0; x<w; x++)
					{
						int idx = src[x];
						dst[x] = PaletteLoad(idx);
					}
					src += bufw;
					dst += w; 
				}
			}
			int fmt = GL_UNSIGNED_INT_8_8_8_8;;
			glTexImage2D(GL_TEXTURE_2D,0,4, w, h, 0, GL_RGBA, fmt, (GLvoid*)tempArea);
			break;
		}



	case GE_TFMT_8888:
		{
			u32 *dst = (u32*)tempArea;
			u32 *src = (u32*)texptr;
			if (gstate.texmode & 1) //Swizzled!
			{
				for (int y=0; y<h/8; y++)
				{
					for (int x=0; x<w/4; x++)
					{
						for (int yy=0; yy<8; yy++)
						{
							for (int xx=0; xx<4; xx++)
							{
								dst[(y*8+yy)*w + x*4*8 + xx] = 
									src[(y*(bufw/4)+x)*4 + (yy*8+xx)];
							}
						}
					}
				}
			}
			else
			{
				for (int y=0; y<h; y++)
				{
					memcpy(dst+y*w,src+bufw*y,4*bufw);

				}
			}
			int fmt = GL_UNSIGNED_INT_8_8_8_8;;
			glTexImage2D(GL_TEXTURE_2D,0,4, w, h, 0, GL_RGBA, fmt, (GLvoid*)tempArea);
			break;
		}

	default:
		LOG(G3D, "Unknown Texture Format %i, not setting texture",format);
		MessageBox(0,"ANOTHER tex format??",0,0);
		return;
	}

	UpdateSamplingParams();

	cache[texaddr] = entry;
}




#pragma once


namespace PSPHLE
{
	void sceNetInit();	
	void sceNetTerm();
}
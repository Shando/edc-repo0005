#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceRtc.h"

namespace PSPHLE
{

	void HLEDECL sceRtcGetCurrentTick()
	{
		RETURN(GetTickCount());
	}
}
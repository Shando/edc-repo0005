#pragma once


namespace PSPHLE
{
	void __IoInit();
	void __IoShutdown();

	void HLEDECL sceIoRead();   //(int fd, void *data, int size); 
	void HLEDECL sceIoWrite();  //(int fd, void *data, int size); 
	void HLEDECL sceIoLseek();  //(int fd, int offset, int whence); 
	void HLEDECL sceIoClose();  //(int fd); 
	void HLEDECL sceIoOpen();   //(const char* file, int mode); 
	void HLEDECL sceIoRemove(); //(const char *file); 
	void HLEDECL sceIoMkdir();  //(const char *dir, int mode); 
	void HLEDECL sceIoRmdir();  //(const char *dir); 
	void HLEDECL sceIoDevctl(); //(const char *name int cmd, void *arg, size_t arglen, void *buf, size_t *buflen); 
	void HLEDECL sceIoRename(); //(const char *oldname, const char *newname); 
	void HLEDECL sceIoAssign();
	void HLEDECL sceIoDopen();
	void HLEDECL sceIoDread();
	void HLEDECL sceIoDclose();
	void HLEDECL sceIoGetstat();
	void HLEDECL sceIoChdir();
	void HLEDECL sceIoPollAsync();
	void HLEDECL sceIoChangeAsyncPriority();
	void HLEDECL sceIoCloseAsync();
	void HLEDECL sceIoLseekAsync();
	void HLEDECL sceIoOpenAsync();
	void HLEDECL sceIoReadAsync();
	void HLEDECL sceIoWaitAsync();
	void HLEDECL sceIoWaitAsyncCB();
	void HLEDECL sceIoGetAsyncStat();
}


#pragma once

#define SCE_GE_LIST_COMPLETED		0
#define SCE_GE_LIST_QUEUED			1
#define SCE_GE_LIST_DRAWING			2
#define SCE_GE_LIST_STALLING		3
#define SCE_GE_LIST_PAUSED			4


namespace PSPHLE
{
	void HLEDECL sceGeEdramGetAddr();
	void HLEDECL sceGeEdramGetSize();
	void HLEDECL sceGeListEnQueue();
	void HLEDECL sceGeListEnQueueHead();
	void HLEDECL sceGeListUpdateStallAddr();
	void HLEDECL sceGeListSync();
	void HLEDECL sceGeDrawSync();
	void HLEDECL sceGeBreak();
	void HLEDECL sceGeContinue();
	void HLEDECL sceGeSetCallback();
	void HLEDECL sceGeUnsetCallback();
}
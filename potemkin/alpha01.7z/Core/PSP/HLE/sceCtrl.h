#pragma once

namespace PSPHLE
{
	void sceCtrlInit();
	void sceCtrlSetSamplingMode();
	void sceCtrlReadBufferPositive();
}


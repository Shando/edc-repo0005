#pragma once

namespace PSPHLE
{
	void HLEDECL scePowerGetBatteryLifePercent();
	void HLEDECL scePowerIsPowerOnline();
	void HLEDECL scePowerIsBatteryExist();
	void HLEDECL scePowerIsBatteryCharging();
	void HLEDECL scePowerGetBatteryChargingStatus();
	void HLEDECL scePowerIsLowBattery();
	void HLEDECL scePowerRegisterCallback();

	void HLEDECL sceKernelPowerLock();
	void HLEDECL sceKernelPowerUnlock();
	void HLEDECL sceKernelPowerTick();

}


#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceKernel.h"
#include "sceKernelThread.h"
#include "sceKernelEventFlag.h"

#include <queue>


namespace PSPHLE
{
	class EventFlag : public KernelObject
	{
	public:
		const char *GetName() {return name;}
		const char *GetTypeName() {return "EventFlag";}
		void GetQuickInfo(char *ptr, int size)
		{
			sprintf_s(ptr, size, "init=%08x cur=%08x numwait=%i",
				initPattern,
				currentPattern,
				numWaitThreads);
		}
		SceSize 	size;
		char 		name[KERNELOBJECT_MAX_NAME_LENGTH+1];
		SceUInt 	attr;
		SceUInt 	initPattern;
		SceUInt 	currentPattern;
		int 		numWaitThreads;
	};


	/** Event flag creation attributes */
	enum PspEventFlagAttributes
	{
		/** Allow the event flag to be waited upon by multiple threads */
		PSP_EVENT_WAITMULTIPLE = 0x200
	};

	/** Event flag wait types */
	enum PspEventFlagWaitTypes
	{
		/** Wait for all bits in the pattern to be set */
		PSP_EVENT_WAITAND = 0,
		/** Wait for one or more bits in the pattern to be set */
		PSP_EVENT_WAITOR  = 1,
		/** Clear the wait pattern when it matches */
		PSP_EVENT_WAITCLEAR = 0x20
	};

	//SceUID sceKernelCreateEventFlag(const char *name, int attr, int bits, SceKernelEventFlagOptParam *opt);
	void HLEDECL sceKernelCreateEventFlag()
	{
		const char *name = (const char *)GetMemPointer(PARAM(0));

		EventFlag *e = new EventFlag;
		SceUID id = kernelObjects.Create(e);

		e->size = sizeof(EventFlag);
		strncpy_s(e->name, 32, name, _TRUNCATE);
		e->attr = PARAM(1);
		e->initPattern = PARAM(2);
		e->currentPattern = e->initPattern;
		e->numWaitThreads = 0;

		LOG(HLE,"%i=sceKernelCreateEventFlag(\"%s\", %08x, %08x, %08x)", id, e->name, e->attr, e->currentPattern, PARAM(3));
		RETURN(id);
	}

	//int sceKernelClearEventFlag(SceUID evid, u32 bits);
	void HLEDECL sceKernelClearEventFlag()
	{
		SceUID id = PARAM(0);
		u32 bits = PARAM(1);

		u32 error;
		EventFlag *e = kernelObjects.Get<EventFlag>(id, error);
		if (e)
		{
			e->currentPattern &= ~bits;
			RETURN(0);
		}
		else
		{
			RETURN(error);
		}
		LOG(HLE,"sceKernelClearEventFlag(%i, %08x)", id, bits);
		RETURN(0);
	}

	//int sceKernelDeleteEventFlag(int evid);
	void HLEDECL sceKernelDeleteEventFlag()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"sceKernelDeleteEventFlag(%i)", id);
		RETURN(kernelObjects.Destroy<EventFlag>(id));
	}

	//int sceKernelSetEventFlag(SceUID evid, u32 bits);
	void HLEDECL sceKernelSetEventFlag()
	{
		SceUID id = PARAM(0);
		u32 bits = PARAM(1);
		u32 error;
		EventFlag *e = kernelObjects.Get<EventFlag>(id, error);
		if (e)
		{
			e->currentPattern |= bits;
			RETURN(0);
		}
		else
		{
			RETURN(error);
		}
	}

	//int sceKernelWaitEventFlag(SceUID evid, u32 bits, u32 wait, u32 *outBits, SceUInt *timeout);
	void HLEDECL sceKernelWaitEventFlag()
	{
		SceUID id = PARAM(0);
		u32 bits = PARAM(1);
		u32 wait = PARAM(2);
		u32 outBitsPtr = PARAM(3);
		u32 timeoutPtr = PARAM(4);

		LOG(HLE,"UNIMPL: sceKernelWaitEventFlag(%i, %08x, %i, %08x, %08x)", id, bits, wait, outBitsPtr, timeoutPtr);
		__KernelWaitCurThread(WAITTYPE_EVENTFLAG, id);
	}

	//int sceKernelWaitEventFlagCB(SceUID evid, u32 bits, u32 wait, u32 *outBits, SceUInt *timeout);
	void HLEDECL sceKernelWaitEventFlagCB()
	{
		SceUID id = PARAM(0);
		u32 bits = PARAM(1);
		u32 wait = PARAM(2);
		u32 outBitsPtr = PARAM(3);
		u32 timeoutPtr = PARAM(4);

		LOG(HLE,"UNIMPL: sceKernelWaitEventFlagCB(%i, %08x, %i, %08x, %08x)", id, bits, wait, outBitsPtr, timeoutPtr);
		RETURN(0);
	}

	//int sceKernelPollEventFlag(int evid, u32 bits, u32 wait, u32 *outBits);
	void HLEDECL sceKernelPollEventFlag()
	{
		SceUID id = PARAM(0);
		u32 bits = PARAM(1);
		u32 wait = PARAM(2);
		u32 outBitsPtr = PARAM(3);

		LOG(HLE,"UNIMPL: sceKernelPollEventFlag(%i, %08x, %i, %08x)", id, bits, wait, outBitsPtr);
		RETURN(0);
	}

	//int sceKernelReferEventFlagStatus(SceUID event, SceKernelEventFlagInfo *status);
	void HLEDECL sceKernelReferEventFlagStatus()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"UNIMPL: sceKernelReferEventFlagStatus()");
		RETURN(0);
	}

	//odd one out - never seen
	void HLEDECL sceKernelCancelEventFlag()
	{
		LOG(HLE,"UNIMPL: sceKernelCancelEventFlag()");
		RETURN(0);
	}
}


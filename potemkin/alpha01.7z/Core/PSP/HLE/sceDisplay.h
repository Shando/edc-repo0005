#pragma once


namespace PSPHLE
{
	void sceDisplayIsVblank();
	void sceDisplaySetMode();
	void sceDisplaySetFramebuf();
	void sceDisplayGetFramebuf();
	void sceDisplayWaitVblankStart();
	void sceDisplayWaitVblank();
	void sceDisplayWaitVblankStartCB();
	void sceDisplayGetVcount();
	void sceDisplayGetFramePerSec();
}
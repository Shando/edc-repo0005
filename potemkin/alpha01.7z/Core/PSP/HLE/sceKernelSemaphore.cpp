#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceKernel.h"
#include "sceKernelThread.h"
#include "sceKernelSemaphore.h"

namespace PSPHLE
{
	/** Current state of a semaphore.
	* @see sceKernelReferSemaStatus.
	*/

	struct NativeSemaphore
	{
		/** Size of the ::SceKernelSemaInfo structure. */
		SceSize 	size;
		/** NUL-terminated name of the semaphore. */
		char 		name[32];
		/** Attributes. */
		SceUInt 	attr;
		/** The initial count the semaphore was created with. */
		int 		initCount;
		/** The current count. */
		int 		currentCount;
		/** The maximum count. */
		int 		maxCount;
		/** The number of threads waiting on the semaphore. */
		int 		numWaitThreads;
	};


	struct Semaphore : public KernelObject 
	{
		const char *GetName() {return ns.name;}
		const char *GetTypeName() {return "Semaphore";}
		NativeSemaphore ns;
		std::vector<SceUID> waitingThreads;
	};

	void HLEDECL sceKernelCancelSema()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"UNIMPL: sceKernelCancelSema()");
		RETURN(0);
	}

	//SceUID sceKernelCreateSema(const char *name, SceUInt attr, int initVal, int maxVal, SceKernelSemaOptParam *option);
	void HLEDECL sceKernelCreateSema()
	{
		const char *name = (const char *)GetMemPointer(PARAM(0));

		Semaphore *s = new Semaphore;
		SceUID id = kernelObjects.Create(s);

		strncpy_s(s->ns.name, 32, name, _TRUNCATE);
		s->ns.attr = PARAM(1);
		s->ns.initCount = PARAM(2);
		s->ns.currentCount = s->ns.initCount;
		s->ns.maxCount = PARAM(3);

		LOG(HLE,"%i=sceKernelCreateSema(%s, %08x, %i, %i, %08x)", id, s->ns.name, s->ns.attr, s->ns.initCount, s->ns.maxCount, PARAM(4));

		RETURN(id);
	}

	//int sceKernelDeleteSema(SceUID semaid);
	void HLEDECL sceKernelDeleteSema()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"sceKernelDeleteSema(%i)", id);
		RETURN(kernelObjects.Destroy<Semaphore>(id));
	}

	void HLEDECL sceKernelReferSemaStatus()
	{
		SceUID id = PARAM(0);
		u32 error;
		Semaphore *s = kernelObjects.Get<Semaphore>(id, error);
		if (s)
		{
			LOG(HLE,"sceKernelReferSemaStatus(%i, %08x)", id, PARAM(1));
			NativeSemaphore *outptr = (NativeSemaphore*)GetMemPointer(PARAM(1));
			int szToCopy = outptr->size - 4;
			memcpy((char*)outptr + 4, (char*)s + 4, szToCopy);
			RETURN(0);
		}
		else
		{
			LOG(HLE,"Error %08x", error);
			RETURN(error);
		}
	}
	
	//int sceKernelSignalSema(SceUID semaid, int signal);
	void HLEDECL sceKernelSignalSema()
	{
		//TODO: check that this thing really works :)
		SceUID id = PARAM(0);
		u32 signal = PARAM(1);
		u32 error;
		Semaphore *s = kernelObjects.Get<Semaphore>(id, error);
		if (s)
		{
			int oldval = s->ns.currentCount;
			s->ns.currentCount += signal;
			LOG(HLE,"sceKernelSignalSema(%i, %i) (old: %i, new: %i)", id, signal, oldval, s->ns.currentCount);
			
			bool wokeThreads = false;
retry:
			//TODO: check for threads to wake up - wake them
			std::vector<SceUID>::iterator iter;
			for (iter = s->waitingThreads.begin(); iter!=s->waitingThreads.end(); s++)
			{
				SceUID id = *iter;
				int wVal = (int)__KernelGetWaitValue(id, error);
				if (wVal <= s->ns.currentCount)
				{
					__KernelWakeThread(id, 0);
					s->ns.currentCount -= wVal;
					wokeThreads = true;
					s->waitingThreads.erase(iter);
					goto retry;
				}
				else
				{
					break;
				}
			}
			//pop the thread that were released from waiting

			if (wokeThreads)
				__KernelReSchedule();

			RETURN(0);
		}
		else
		{
			LOG(HLE, "sceKernelSignalSema : Trying to signal invalid semaphore %i", id);
			RETURN(error);
		}
	}

	//int sceKernelWaitSema(SceUID semaid, int signal, SceUInt *timeout);
	void HLEDECL sceKernelWaitSema()
	{
		SceUID id = PARAM(0);
		int signal = PARAM(1);
		u32 timeoutPtr = PARAM(2);
		int timeout = PARAM(3);

		LOG(HLE,"sceKernelWaitSema(%i, %i, %i)", id, signal, timeout);
		
		u32 error;
		Semaphore *s = kernelObjects.Get<Semaphore>(id, error);
		if (s)
		{
			if (s->ns.currentCount >= signal) //TODO fix
			{
				s->ns.currentCount -= signal;
			}
			else
			{
				s->waitingThreads.push_back(__KernelGetCurThread());
				__KernelWaitCurThread(WAITTYPE_SEMA, id, signal);
				return;
			}
			RETURN(0);
		}
		else
		{
			RETURN(error);
		}
	} 

	//Should be same as WaitSema but without the wait
	void HLEDECL sceKernelPollSema()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"UNIMPL: sceKernelPollSema()");
		RETURN(0);
	}


	//int sceKernelWaitSemaCB(SceUID semaid, int signal, SceUInt *timeout);
	void HLEDECL sceKernelWaitSemaCB()
	{
		SceUID id = PARAM(0);
		int signal = PARAM(1);
		int timeout = PARAM(2);
		LOG(HLE,"sceKernelWaitSemaCB(%i, %i, %i)", id, signal, timeout);
		u32 error;
		Semaphore *s = kernelObjects.Get<Semaphore>(id, error);
		if (s)
		{
			LOG(HLE,"CurrentCount: %i, Signal: %i", s->ns.currentCount, signal);
			if (s->ns.currentCount >= signal) //TODO fix
			{
				LOG(HLE,"Subtracting");
				s->ns.currentCount -= signal;
			}
			else
			{
				s->waitingThreads.push_back(__KernelGetCurThread());
				__KernelWaitCurThread(WAITTYPE_SEMA, id, signal, true);
				return;
			}
			LOG(HLE,"After: CurrentCount: %i, Signal: %i", s->ns.currentCount, signal);
			RETURN(0);
		}
		else
		{
			LOG(HLE,"sceKernelWaitSemaCB - Bad semaphore");
			RETURN(error);
		}
	}
}


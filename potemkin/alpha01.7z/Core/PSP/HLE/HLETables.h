#pragma once

#include "../../../Globals.h"

namespace PSPHLE
{
	extern const int numModules;
	extern const HLEModule modules[];
}

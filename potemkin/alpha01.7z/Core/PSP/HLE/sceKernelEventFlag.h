#pragma once

namespace PSPHLE
{
	void HLEDECL sceKernelCreateEventFlag();
	void HLEDECL sceKernelClearEventFlag();
	void HLEDECL sceKernelDeleteEventFlag();
	void HLEDECL sceKernelSetEventFlag();
	void HLEDECL sceKernelWaitEventFlag();
	void HLEDECL sceKernelWaitEventFlagCB();
	void HLEDECL sceKernelPollEventFlag();
	void HLEDECL sceKernelCancelEventFlag();
	void HLEDECL sceKernelReferEventFlagStatus();
}


#include "stdafx.h"
#include "../../MIPS/MIPS.h"
#include "../PSPFirmwareHLE.h"
#include "../PSPDisplay.h"
#include "sceGe.h"

namespace PSPHLE
{


	//////////////////////////////////////////////////////////////////////////
	// State
	u32 umdStatus = 0;


	//////////////////////////////////////////////////////////////////////////




	enum UmdDriveStat
	{
		/** Wait for disc to be inserted */
		UMD_WAITFORDISC = 2,
		/** Wait for the UMD to be initialised so it can be accessed from the mapped drive */
		UMD_WAITFORINIT		= 0x20
	};

	//int sceUmdCheckMedium(int a);
	void sceUmdCheckMedium()
	{
		LOG(HLE,"1=sceUmdCheckMedium(?)");
		//ignore PARAM(0)
		RETURN(1); //non-zero: disc in drive
	}
	
	void sceUmdGetDiscInfo()
	{
		LOG(HLE,"sceUmdGetDiscInfo(?)");
		RETURN(0);
	}

	/** 
	* Activates the UMD drive
	* 
	* @param unit - The unit to initialise (probably). Should be set to 1.
	* @param drive - A prefix string for the fs device to mount the UMD on (e.g. "disc0:")
	* @return < 0 on error
	*
	* @par Example:
	* @code
	* // Wait for disc and mount to filesystem
	* int i;
	* i = sceUmdCheckMedium(0);
	* if(i == 0)
	* {
	*    sceUmdWaitDriveStat(UMD_WAITFORDISC);
	* }
	* sceUmdActivate(1, "disc0:"); // Mount UMD to disc0: file system
	* sceUmdWaitDriveStat(UMD_WAITFORINIT);
	* // Now you can access the UMD using standard sceIo functions
	* @endcode


	1.PATH replace

	target API are
	scrLoadModule
	sceIoOpen
	sceIoOpenAsync
	sceIoDopen
	sceIoChdir
	sceIoGetstat
	sceIoSync
	sceIoChstat
	sceIoDevctl

	2.UMD EMULATION

	sceUmdCheckMedium�Falways return 1
	sceUmdActivate :the emulated UMD status set 0x22
	sceUmdDeactivate :the emulated UMD status set 0x0A
	sceUmdGetDriveStat:return the emulated UMD status.
	sceUmdWaitDriveStat,sceUmdWaitDriveStatWithTimer,sceUmdWaitDriveStatCB:return;
	sceUmdRegisterUMDCallBack:no register.When the emulated UMD status changes,CALLBACK is called directly.

	3.LoadModule fix

	sceKernelLoadModuleByID
	scrLoadModule
	*
	*/


	void sceUmdActivate()
	{
		u32 retVal  = 1;
		LOG(HLE,"%i=sceUmdActivate(%08x)",retVal,PARAM(0));
		RETURN(retVal);
	}
	void sceUmdDeactivate()
	{
		LOG(HLE,"sceUmdDeactivate(?)");
		RETURN(0);
	}

	void sceUmdRegisterUMDCallBack()
	{
		LOG(HLE,"0=sceUmdRegisterUMDCallback(id=%i)",PARAM(0));
		RETURN(0);
	}

	void sceUmdGetDriveStat()
	{
		u32 retVal = 50;
		LOG(HLE,"%i=sceUmdGetDriveStat()",retVal);
		RETURN(retVal);
	}

	/** 
	* Wait for a drive to reach a certain state
	*
	* @param stat - The drive stat to wait for.
	* @return < 0 on error
	*
	*/
	void sceUmdWaitDriveStat()
	{
		LOG(HLE,"0=sceUmdWaitDriveStat()");
		//__KernelWaitCurThread(WAITTYPE_UMD, 0);
		RETURN(0);
	}

	void sceUmdWaitDriveStatWithTimer()
	{
		LOG(HLE,"0=sceUmdWaitDriveStatWithTimer()");
		//__KernelWaitCurThread(WAITTYPE_UMD, 0);
		RETURN(0);
	}

	void sceUmdWaitDriveStatCB()
	{
		LOG(HLE,"0=sceUmdWaitDriveStatCB()");
		//__KernelWaitCurThread(WAITTYPE_UMD, 0);
		RETURN(0);
	}

	/** 
	* Register a callback for the UMD drive.
	* @note Callback is of type UmdCallback
	*
	* @param cbid - A callback ID created from sceKernelCreateCallback
	* @return < 0 on error
	* @par Example:
	* @code
	* cbid = sceKernelCreateCallback("UMD Callback", umd_callback);
	* sceUmdRegisterUMDCallback(cbid);
	* @endcode
	*/

}
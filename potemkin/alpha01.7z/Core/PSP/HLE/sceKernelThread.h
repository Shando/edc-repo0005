#pragma once

#include "sceKernelModule.h"
#include "../PSPFirmwareHLE.h"
namespace PSPHLE
{
	void HLEDECL sceKernelChangeThreadPriority();
	void HLEDECL sceKernelCreateThread();
	void HLEDECL sceKernelDelayThread();
	void HLEDECL sceKernelDelayThreadCB();
	void HLEDECL sceKernelDeleteThread();
	void HLEDECL sceKernelExitDeleteThread();
	void HLEDECL sceKernelExitThread();
	void HLEDECL _sceKernelExitThread();
	void HLEDECL sceKernelGetThreadId();
	void HLEDECL sceKernelStartThread();
	void HLEDECL sceKernelWaitThreadEnd();
	void HLEDECL sceKernelReferThreadStatus();
	void HLEDECL sceKernelChangeCurrentThreadAttr();
	void HLEDECL sceKernelRotateThreadReadyQueue();
	void HLEDECL sceKernelCheckThreadStack();
	void HLEDECL sceKernelSuspendThread();
	void HLEDECL sceKernelResumeThread();
	void HLEDECL sceKernelWakeupThread();
	void HLEDECL sceKernelTerminateDeleteThread();

	void __KernelThreadingInit();
	void __KernelThreadingShutdown();
	
	void __KernelScheduleWakeup(int usFromNow, int threadnumber);
	SceUID __KernelGetCurThread();

	enum WaitType //probably not the real values
	{
		WAITTYPE_NONE = 0,
		WAITTYPE_SLEEP = 1,
		WAITTYPE_DELAY = 2,
		WAITTYPE_SEMA  = 3,
		WAITTYPE_EVENTFLAG = 4,
		WAITTYPE_MBX = 5,
		WAITTYPE_VPL = 6,
		WAITTYPE_FPL = 7,
		WAITTYPE_THREADEND = 9,
		WAITTYPE_AUDIOCHANNEL = 10, // this is fake, should be replaced with 8 eventflags
		WAITTYPE_UMD = 11           // this is fake, should be replaced with 1 eventflag
	};


	bool __KernelTrigger(WaitType type, int id);
	u32 __KernelGetWaitValue(SceUID threadID, u32 &error);
	void __KernelWakeThread(SceUID threadID, u32 returnStatus);
	void __KernelWaitCurThread(WaitType type, SceUID id, u32 value=0, bool processCallbacks = false);
	void __KernelReSchedule();

	SceUID __KernelGetCurThread();
	void __KernelSetupRootThread(SceUID moduleId, int args, const char *argp, int prio, int stacksize, int attr); //represents the real PSP elf loader, run before execution
	void HLEDECL _sceKernelReturnFromThread();

}


#pragma once

#include "sceKernel.h"
#include "../PSPFirmwareHLE.h"
namespace PSPHLE
{
	u32 __KernelGetModuleGP(SceUID module);
	void HLEDECL sceKernelLoadModule();
	void HLEDECL sceKernelStartModule();
	void HLEDECL sceKernelStopModule();
	void HLEDECL sceKernelUnloadModule();
	void HLEDECL sceKernelGetModuleIdByAddress();
	void HLEDECL sceKernelGetModuleId();
	void HLEDECL sceKernelLoadExec();
}


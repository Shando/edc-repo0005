#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../PSPSystem.h"
#include "../../MIPS/MIPS.h"

#include "sceKernel.h"
#include "sceKernelThread.h"
#include "sceKernelMemory.h"


namespace PSPHLE
{
	//////////////////////////////////////////////////////////////////////////
	// STATE BEGIN
	BlockAllocator userMemory;
	BlockAllocator kernelMemory;
	// STATE END
	//////////////////////////////////////////////////////////////////////////

	//FPL - Fixed Length Dynamic Memory Pool - every item has the same length
	struct FPL : KernelObject
	{
		const char *GetName() {return name;}
		const char *GetTypeName() {return "FPL";}
		char name[KERNELOBJECT_MAX_NAME_LENGTH+1];
		SceUID mpid;
		u32 attr;
		int blocksize;
		int numBlocks;
		int numFreeBlocks;
		int numWaitThreads;
		bool *freeBlocks;
		u32 address;
	};

	struct SceKernelVplInfo
	{
		SceSize size;
		char name[KERNELOBJECT_MAX_NAME_LENGTH+1];
		SceUInt attr;
		int poolSize;
		int freeSize;
		int numWaitThreads;

	};

	struct VPL : KernelObject
	{
		const char *GetName() {return nv.name;}
		const char *GetTypeName() {return "VPL";}
		SceKernelVplInfo nv;
		int size;
		bool *freeBlocks;
		BlockAllocator alloc;
	};

	void __KernelMemoryInit()
	{
		kernelMemory.Init(PSP_GetKernelMemoryBase(), PSP_GetKernelMemoryEnd()-PSP_GetKernelMemoryBase());
		userMemory.Init(PSP_GetUserMemoryBase(), PSP_GetUserMemoryEnd()-PSP_GetUserMemoryBase());
		LOG(HLE, "Kernel and user memory pools initialized");
	}
	void __KernelMemoryShutdown()
	{
		LOG(HLE,"Shutting down user memory pool: ");
		userMemory.ListBlocks();
		userMemory.Shutdown();
		LOG(HLE,"Shutting down \"kernel\" memory pool: ");
		kernelMemory.ListBlocks();
		kernelMemory.Shutdown();
	}

	//sceKernelCreateFpl(const char *name, SceUID mpid, SceUint attr, SceSize blocksize, int numBlocks, optparam)
	void sceKernelCreateFpl()
	{
		const char *name = (const char *)GetMemPointer(PARAM(0));

		FPL *fpl = new FPL;
		SceUID id = kernelObjects.Create(fpl);
		strncpy_s(fpl->name, 32, name, _TRUNCATE);
		fpl->mpid = PARAM(1); //partition
		fpl->attr = PARAM(2);
		fpl->blocksize = PARAM(3);
		fpl->numBlocks = PARAM(4);
		fpl->numWaitThreads = 0;
		fpl->freeBlocks = new bool[fpl->numBlocks];
		
		int totalSize = fpl->blocksize * fpl->numBlocks;
		fpl->address = userMemory.Alloc(totalSize, false, "FPL");

		memset(fpl->freeBlocks, 0, fpl->numBlocks * sizeof(bool));
		LOG(HLE,"sceKernelCreateFpl(\"%s\", partition=%i, attr=%i, bsize=%i, nb=%i)", 
			name, fpl->mpid, fpl->attr, fpl->blocksize, fpl->numBlocks);

		RETURN(id);
	}

	void sceKernelDeleteFpl()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"sceKernelDeleteFpl(%i)", id);
		RETURN(kernelObjects.Destroy<FPL>(id));
	}


	void sceKernelAllocateFpl()
	{
		SceUID id = PARAM(0);
		u32 error;
		FPL *fpl = kernelObjects.Get<FPL>(id, error);
		if (fpl)
		{
			u32 *blockPtrPtr = (u32 *)GetMemPointer(PARAM(1));
			int timeOut = PARAM(2);
			LOG(HLE,"sceKernelAllocateFpl(%i, %08x, %i)", id, blockPtrPtr, timeOut);
			*blockPtrPtr = fpl->address;
			RETURN(0);
		}
		else
		{
			RETURN(error);
		}
	}
	void sceKernelAllocateFplCB()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"UNIMPL: sceKernelAllocateFplCB(%i)", id);
		u32 error;
		FPL *fpl = kernelObjects.Get<FPL>(id, error);
		if (fpl)
		{
			RETURN(0);
		}
		else
		{
			RETURN(error);
		}
	}
	void sceKernelTryAllocateFpl()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"BAD sceKernelTryAllocateFpl(%i)", id);
		u32 error;
		FPL *fpl = kernelObjects.Get<FPL>(id, error);
		if (fpl)
		{
			u32 *blockPtrPtr = (u32 *)GetMemPointer(PARAM(1));
			LOG(HLE,"sceKernelTryAllocateFpl(%i, %08x)", id, blockPtrPtr);
			*blockPtrPtr = fpl->address;
			RETURN(0);
		}
		else
		{
			RETURN(error);
		}
	}
	void sceKernelFreeFpl()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"UNIMPL: sceKernelFreeFpl(%i)", id);
		u32 error;
		FPL *fpl = kernelObjects.Get<FPL>(id, error);
		if (fpl)
		{
			RETURN(0);
		}
		else
		{
			RETURN(error);
		}
	}
	void sceKernelCancelFpl()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"UNIMPL: sceKernelCancelFpl(%i)", id);
		u32 error;
		FPL *fpl = kernelObjects.Get<FPL>(id, error);
		if (fpl)
		{
			RETURN(0);
		}
		else
		{
			RETURN(error);
		}
	}
	void sceKernelReferFplStatus()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"UNIMPL: sceKernelReferFplStatus(%i)", id);
		u32 error;
		FPL *fpl = kernelObjects.Get<FPL>(id, error);
		if (fpl)
		{
			RETURN(0);
		}
		else
		{
			RETURN(error);
		}
	}



	//////////////////////////////////////////////////////////////////////////
	// ALLOCATIONS
	//////////////////////////////////////////////////////////////////////////
	//00:49:12 <TyRaNiD> ector, well the partitions are 1 = kernel, 2 = user, 3 = me, 4 = kernel mirror :)


	class PartitionMemoryBlock : public KernelObject
	{
	public:
		const char *GetName() {return name;}
		const char *GetTypeName() {return "MemoryPart";}
		void GetQuickInfo(char *ptr, int size)
		{
			int sz = alloc->GetBlockSizeFromAddress(address);
			sprintf_s(ptr, size, "MemPart: %08x - %08x  size: %08x", address, address+sz, sz);
		}
		PartitionMemoryBlock(BlockAllocator *_alloc, u32 size, bool fromEnd)
		{
			alloc = _alloc;
			address = alloc->Alloc(size, fromEnd);
			alloc->ListBlocks();
		}
		~PartitionMemoryBlock()
		{
			alloc->Free(address);
		}
		bool IsValid() {return address != (u32)-1;}
		BlockAllocator *alloc;
		u32 address;
		char name[32];
	};


	void sceKernelMaxFreeMemSize() 
	{
		u32 retVal = userMemory.GetLargestFreeBlockSize()-0x1000;
		LOG(HLE,"%08x (dec %i)=sceKernelMaxFreeMemSize",retVal,retVal);
		RETURN(retVal);
	}
	void sceKernelTotalFreeMemSize()
	{
		u32 retVal = userMemory.GetLargestFreeBlockSize()-0x1000;
		LOG(HLE,"%08x (dec %i)=sceKernelTotalFreeMemSize",retVal,retVal);
		RETURN(retVal);
	}

	void sceKernelAllocPartitionMemory()
	{
		int partid = PARAM(0);
		const char *name = (const char*)GetMemPointer(PARAM(1));
		int type = PARAM(2);
		u32 size = PARAM(3);
		int addr = PARAM(4); //only if type == addr

		PartitionMemoryBlock *block = new PartitionMemoryBlock(&userMemory, size, type==1);
		if (!block->IsValid())
		{
			LOG(HLE, "ARGH! sceKernelAllocPartMem failed");
			RETURN(-1);
		}
		SceUID id = kernelObjects.Create(block);
		strncpy_s(block->name, 32, name, _TRUNCATE);

		LOG(HLE,"%i = sceKernelAllocPartMem(partition = %i, %s, type= %i, size= %i, addr= %08x)",
			id, partid,name,type,size,addr);
		if (type == 2)
			LOG(HLE, "ARGH! sceKernelAllocPartMem wants a specific address");

		RETURN(id); //for now
	}

	void sceKernelFreePartitionMemory()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"sceKernelFreePartitionMemory(%d)",id);

		RETURN(kernelObjects.Destroy<PartitionMemoryBlock>(id));
	}

	void sceKernelGetBlockHeadAddr()
	{
		SceUID id = PARAM(0);

		u32 error;
		PartitionMemoryBlock *block = kernelObjects.Get<PartitionMemoryBlock>(id, error);
		if (block)
		{
			LOG(HLE,"%08x = sceKernelGetBlockHeadAddr(%i)", block->address, id);
			RETURN(block->address);
		}
		else
		{
			LOG(HLE,"sceKernelGetBlockHeadAddr failed(%i)", id);
			RETURN(error);
		}
	}


	void sceKernelMemory_Unknown1()
	{
		LOG(HLE,"WARNING sceKernelMemory_Unknown1(%08x, %08x, %08x, %08x)", PARAM(0),PARAM(1),PARAM(2),PARAM(3));
		RETURN(0);
	}
	void sceKernelMemory_Unknown2()
	{
		//pretty sure this only takes one arg
		LOG(HLE,"WARNING sceKernelMemory_Unknown2(%08x)", PARAM(0));
		RETURN(0);
	}
	void sceKernelMemory_Unknown3()
	{
		LOG(HLE,"WARNING sceKernelMemory_Unknown3(%08x, %08x, %08x, %08x)", PARAM(0),PARAM(1),PARAM(2),PARAM(3));
		RETURN(0);
	}



	void sceKernelCreateVpl()
	{
		const char *name = (const char *)GetMemPointer(PARAM(0));
		VPL *vpl = new VPL;
		SceUID id = kernelObjects.Create(vpl);

		strncpy_s(vpl->nv.name, 32, name, _TRUNCATE);
		//vpl->nv.mpid = PARAM(1); //seems to be the standard memory partition (user, kernel etc)
		vpl->nv.attr = PARAM(2);
		vpl->size = PARAM(3);
		vpl->nv.poolSize = vpl->size;
		vpl->nv.size = sizeof(vpl->nv);
		vpl->nv.numWaitThreads = 0;
		vpl->nv.freeSize = vpl->nv.poolSize;
		
		u32 address = userMemory.Alloc(vpl->size, false, "VPL");
		vpl->alloc.Init(address, vpl->size);

		LOG(HLE,"sceKernelCreateVpl(\"%s\", block=%i, attr=%i, size=%i)", 
			name, PARAM(1), vpl->nv.attr, vpl->size);

		RETURN(id);
	}
	void sceKernelDeleteVpl()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"UNIMPL: sceKernelDeleteVpl(%i)", id);
		kernelObjects.Destroy<VPL>(id);
		RETURN(0);
	}
	void sceKernelAllocateVpl()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"sceKernelAllocateVpl()");
		u32 error;
		VPL *vpl = kernelObjects.Get<VPL>(id, error);
		if (vpl)
		{
			u32 size = PARAM(1);
			u32 *blockPtrPtr = (u32 *)GetMemPointer(PARAM(2));
			int timeOut = PARAM(2);
			LOG(HLE,"sceKernelAllocateVpl(vpl=%i, size=%i, ptrout= %08x , timeout=%i)", id, size, PARAM(2), timeOut);
			u32 addr = vpl->alloc.Alloc(size);
			if (addr != (u32)-1)
			{
				*blockPtrPtr = addr;
				RETURN(0);
			}
			else
			{
				LOG(HLE, "FAILURE");
				RETURN(-1);
			}
		}
		else
		{
			RETURN(error);
		}
		RETURN(0);
	}
	void sceKernelAllocateVplCB()
	{
		SceUID id = PARAM(0);
		u32 error;
		VPL *vpl = kernelObjects.Get<VPL>(id, error);
		if (vpl)
		{
			u32 size = PARAM(1);
			u32 *blockPtrPtr = (u32 *)GetMemPointer(PARAM(2));
			int timeOut = PARAM(2);
			LOG(HLE,"sceKernelAllocateVplCB(vpl=%i, size=%i, ptrout= %08x , timeout=%i)", id, size, PARAM(2), timeOut);
			u32 addr = vpl->alloc.Alloc(size);
			if (addr != (u32)-1)
			{
				*blockPtrPtr = addr;
				RETURN(0);
			}
			else
			{
				LOG(HLE, "FAILURE");
				RETURN(-1);
			}
		}
		else
		{
			RETURN(error);
		}
		RETURN(0);
	}
	void sceKernelTryAllocateVpl()
	{
		SceUID id = PARAM(0);
		u32 error;
		VPL *vpl = kernelObjects.Get<VPL>(id, error);
		if (vpl)
		{
			u32 size = PARAM(1);
			u32 *blockPtrPtr = (u32 *)GetMemPointer(PARAM(2));
			int timeOut = PARAM(2);
			LOG(HLE,"sceKernelAllocateVplCB(vpl=%i, size=%i, ptrout= %08x , timeout=%i)", id, size, PARAM(2), timeOut);
			u32 addr = vpl->alloc.Alloc(size);
			if (addr != (u32)-1)
			{
				*blockPtrPtr = addr;
				RETURN(0);
			}
			else
			{
				LOG(HLE, "FAILURE");
				RETURN(-1);
			}
		}
		else
		{
			RETURN(error);
		}
		RETURN(0);
	}
	void sceKernelFreeVpl()
	{
		LOG(HLE,"UNIMPL: sceKernelFreeVpl()");
		RETURN(0);
	}
	void sceKernelCancelVpl()
	{
		LOG(HLE,"UNIMPL: sceKernelCancelVpl()");
		RETURN(0);
	}
	void sceKernelReferVplStatus()
	{
		SceUID id = PARAM(0);
		u32 error;
		VPL *v = kernelObjects.Get<VPL>(id, error);
		if (v)
		{
			LOG(HLE,"sceKernelReferVplStatus(%i, %08x)", id, PARAM(1));
			SceKernelVplInfo *info = (SceKernelVplInfo*)GetMemPointer(PARAM(1));
			v->nv.freeSize = v->alloc.GetTotalFreeBytes();
			*info = v->nv;
		}
		else
		{
			LOG(HLE,"Error %08x", error);
			RETURN(error);
		}
		RETURN(0);
	}



}


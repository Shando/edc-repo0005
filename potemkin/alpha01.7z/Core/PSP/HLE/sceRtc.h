#pragma once

namespace PSPHLE 
{
	void HLEDECL sceRtcGetCurrentTick();
}
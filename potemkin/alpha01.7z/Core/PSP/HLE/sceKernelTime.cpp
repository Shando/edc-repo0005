#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceKernel.h"
#include "sceKernelTime.h"

namespace PSPHLE
{


	//////////////////////////////////////////////////////////////////////////
	// TIMER
	//////////////////////////////////////////////////////////////////////////

	struct VTimer : public KernelObject
	{
		const char *GetName() {return name;}
		const char *GetTypeName() {return "VTimer";}

		SceSize 	size;
		char 		name[KERNELOBJECT_MAX_NAME_LENGTH+1];
		u64 startTime;
		bool running;
		u32 handler;
		u64 handlerTime;
		u32 argument;
	};

	void HLEDECL sceKernelCreateVTimer()
	{
		LOG(HLE,"sceKernelCreateVTimer");
		const char *name = (const char*)GetMemPointer(PARAM(0));
	
		VTimer *vt = new VTimer();
		SceUID id = kernelObjects.Create(vt);
		strncpy_s(vt->name, name, _TRUNCATE);
		vt->running = true;
		vt->startTime = 0; //TODO fix
		RETURN(id); //TODO: return timer ID
	}
	void HLEDECL sceKernelStartVTimer()
	{
		LOG(HLE,"sceKernelStartVTimer");
		int timerID = PARAM(0);

		RETURN(0); //ok; 1=alreadyrunning
	}
	void HLEDECL sceKernelSetVTimerHandler()
	{
		LOG(HLE,"sceKernelSetVTimerHandler");

	}
	void HLEDECL _sceKernelReturnFromTimerHandler()
	{
		
	}
	//////////////////////////////////////////////////////////////////////////
	// Other clock stuff
	//////////////////////////////////////////////////////////////////////////

	struct SceKernelSysClock
	{
		u32 hi;
		u32 lo;
	};

	void HLEDECL sceKernelGetSystemTimeLow()
	{
		//TODO: unhack!
		static int t=0;
		t+=1000;
		LOG(HLE,"%i=sceKernelGetSystemTimeLow()",t);
		RETURN(t);
	}

	void HLEDECL sceKernelGetSystemTimeWide()
	{
		//TODO: unhack!
		static int t=0;
		t+=1000;
		LOG(HLE,"%i=sceKernelGetSystemTimeWide()",t);
		RETURN(t);
	}
	void HLEDECL sceKernelUSec2SysClock()
	{
		u32 microseconds = PARAM(0);
		SceKernelSysClock *clock = (SceKernelSysClock*)GetMemPointer(PARAM(1));
		clock->lo = microseconds; //TODO: fix
		LOG(HLE,"sceKernelUSec2SysClock(%i, %08x )",PARAM(0), PARAM(1));
		RETURN(0);
	}
	void HLEDECL sceKernelLibcClock()
	{
		u32 retVal = clock()*1000;
		LOG(HLE,"%i = sceKernelLibcClock",retVal);
		RETURN(retVal); // TODO: fix
	}
	void HLEDECL sceKernelLibcTime()
	{
		u32 retVal = (u32)time((time_t*)GetMemPointer(PARAM(0)));
		LOG(HLE,"%i = sceKernelLibcTime()",retVal);
		RETURN(retVal);
	}
	void HLEDECL sceKernelLibcGettimeofday()
	{
		union {
			__int64 ns100; /*time since 1 Jan 1601 in 100ns units */
			FILETIME ft;
		} now;

		struct timeval
		{
			u32 tv_sec;
			u32 tv_usec;
		};

		timeval *tv = (timeval*)GetMemPointer(PARAM(0));
		LOG(HLE,"sceKernelLibcGettimeofday()");

		GetSystemTimeAsFileTime (&now.ft);
		tv->tv_usec = (long) ((now.ns100 / 10LL) % 1000000LL);
		tv->tv_sec = (long) ((now.ns100 - 116444736000000000LL) / 10000000LL);
		RETURN(0);
	}
	void sceRtcGetCurrentClockLocalTime()
	{
		LOG(HLE,"0=sceRtcGetCurrentClockLocalTime()");
		RETURN(0);
	}
	void sceRtcGetTick()
	{
		LOG(HLE,"0=sceRtcGetTick()");
		RETURN(0);
	}

	void sceRtcGetTickResolution()
	{
		LOG(HLE,"100=sceRtcGetTickResolution()");
		RETURN(100);
	}
}


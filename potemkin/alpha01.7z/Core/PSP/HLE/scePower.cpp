#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "scePower.h"

namespace PSPHLE
{
	void HLEDECL scePowerGetBatteryLifePercent()
	{
		LOG(HLE, "scePowerGetBatteryLifePercent");
		RETURN(100);
	}
	void HLEDECL scePowerIsPowerOnline()
	{
		LOG(HLE, "scePowerIsPowerOnline");
		RETURN( 1);
	}
	void HLEDECL scePowerIsBatteryExist()
	{
		LOG(HLE, "scePowerIsBatteryExist");
		RETURN( 1);
	}
	void HLEDECL scePowerIsBatteryCharging()
	{
		LOG(HLE, "scePowerIsBatteryCharging");
		RETURN( 0);
	}
	void HLEDECL scePowerGetBatteryChargingStatus()
	{
		LOG(HLE, "scePowerGetBatteryChargingStatus");
		RETURN( 0);
	}
	void HLEDECL scePowerIsLowBattery()
	{
		LOG(HLE, "scePowerIsLowBattery");
		RETURN( 0);
	}

	void HLEDECL scePowerRegisterCallback()
	{
		LOG(HLE,"0=scePowerRegisterCallback() UNIMPL");
		RETURN (0);
	}
	void HLEDECL sceKernelPowerLock()
	{
		LOG(HLE,"sceKernelPowerLock()");
		RETURN (0);
	}
	void HLEDECL sceKernelPowerUnlock()
	{
		LOG(HLE,"sceKernelPowerUnlock()");
		RETURN (0);
	}
	void HLEDECL sceKernelPowerTick()
	{
		LOG(HLE,"sceKernelPowerTick()");
		RETURN (0);
	}

}


#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceKernel.h"
#include "sceKernelThread.h"

namespace PSPHLE
{
	void __KernelInterruptInit()
	{

	}
	void __KernelInterruptShutdown()
	{

	}



	void __SetupInterruptContext()
	{
		//Assume current thread context is saved
	}

	void __TriggerInterrupt(int intno)
	{
		
	}
}


#include "stdafx.h"
#include "../PSPFirmwareHLE.h"

#include "HLETables.h"

#include "sceCtrl.h"
#include "sceDisplay.h"
#include "sceHttp.h"
#include "sceAtrac.h"
#include "sceIo.h"
#include "scePower.h"
#include "sceNet.h"
#include "sceGe.h"
#include "sceRtc.h"
#include "sceSas.h"
#include "sceUmd.h"
#include "sceKernel.h"
#include "sceKernelEventFlag.h"
#include "sceKernelCallback.h"
#include "sceKernelMemory.h"
#include "sceKernelModule.h"
#include "sceKernelSemaphore.h"
#include "sceKernelThread.h"
#include "sceKernelTime.h"
#include "sceAudio.h"
#include "sceUtility.h"
#include "Misc.h"


namespace PSPHLE
{
// kill the API names in release builds
#ifndef FINAL
#define N(s) s
#else
#define N(s) 0
#endif

	//\*\*\ found\:\ {[a-zA-Z]*}\ {0x[a-zA-Z0-9]*}\ \*\*
	//{FID(\2),0,N("\1")},

	//Metal Gear Acid modules:
	//kjfs
	//sound
	//zlibdec
#define NID_THREADRETURN 0xc0debabe
	const HLEFunction FakeSysCalls[] =
	{
		{FID(NID_THREADRETURN), _sceKernelReturnFromThread, N("_sceKernelReturnFromThread")},
	};



	const HLEFunction sceCtrl[] = 
	{
		{FID(0x6a2774f3), sceCtrlInit,          N("sceCtrlInit")}, //(int unknown), init with 0
		{FID(0x1f4011e6), sceCtrlSetSamplingMode, N("sceCtrlSetSamplingMode")}, //(int on);
		{FID(0x1f803938), sceCtrlReadBufferPositive,          N("sceCtrlReadBufferPositive")}, //(ctrl_data_t* paddata, int unknown) // unknown should be 1
		{FID(0x6A2774F3), 0, N("sceCtrlSetSamplingCycle")}, //?
		{FID(0x6A2774F3),sceCtrlInit,N("sceCtrlSetSamplingCycle")},
		{FID(0x02BAAD91),0,N("sceCtrlGetSamplingCycle")},
		{FID(0xDA6B76A1),0,N("sceCtrlGetSamplingMode")},
		{FID(0x3A622550),sceCtrlReadBufferPositive,N("sceCtrlPeekBufferPositive")},
		{FID(0xC152080A),0,N("sceCtrlPeekBufferNegative")},
		{FID(0x60B81F86),0,N("sceCtrlReadBufferNegative")},
		{FID(0xB1D0E5CD),0,N("sceCtrlPeekLatch")},
		{FID(0x0B588501),0,N("sceCtrlReadLatch")},
		{FID(0x348D99D4),0,N("sceCtrl_348D99D4")},
		{FID(0xAF5960F3),0,N("sceCtrl_AF5960F3")},
		{FID(0xA68FD260),0,N("sceCtrl_A68FD260")},
		{FID(0x6841BE1A),0,N("sceCtrl_6841BE1A")},
		{FID(0xa7144800),0,N("sceCtrl_a7144800")},
		{FID(0x687660fa),0,N("sceCtrl_687660fa")},
	};	

	const HLEFunction sceDisplay[] = 
	{
		{FID(0x0E20F177),sceDisplaySetMode,          N("sceDisplaySetMode")},
		{FID(0x289D82FE),sceDisplaySetFramebuf,      N("sceDisplaySetFramebuf")},
		{FID(0x36CDFADE),sceDisplayWaitVblank,       N("sceDisplayWaitVblank")},
		{FID(0x984C27E7),sceDisplayWaitVblankStart,  N("sceDisplayWaitVblankStart")},
		{FID(0x46F186C3),sceDisplayWaitVblankStartCB,N("sceDisplayWaitVblankStartCB")},
		{FID(0x8EB9EC49),sceDisplayWaitVblankStartCB,N("sceDisplayWaitVblankCB")},

		{FID(0xdba6c4c4),sceDisplayGetFramePerSec,N("sceDisplayGetFramePerSec")},
		{FID(0x773dd3a3),0,N("sceDisplayGetCurrentHcount")},
		{FID(0x210eab3a),0,N("sceDisplayGetAccumulatedHcount")},
		{FID(0x9C6EAAD7),sceDisplayGetVcount,N("sceDisplayGetVcount")},
		{FID(0x984C27E7),0,N("sceDisplayWaitVblankStart")},
		{FID(0xDEA197D4),0,N("sceDisplayGetMode")},
		{FID(0x7ED59BC4),0,N("sceDisplaySetHoldMode")},
		{FID(0xA544C486),0,N("sceDisplaySetResumeMode")},
		{FID(0x289D82FE),0,N("sceDisplaySetFrameBuf")},
		{FID(0xEEDA2E54),sceDisplayGetFramebuf,N("sceDisplayGetFrameBuf")},
		{FID(0xB4F378FA),0,N("sceDisplayIsForeground")},
		{FID(0x31C4BAA8),0,N("sceDisplayGetBrightness")},
		{FID(0x4D4E10EC),sceDisplayIsVblank,N("sceDisplayIsVblank")},
	};	

	const HLEFunction scePsmf[] =
	{
		{FID(0x0ba514e5),0,N("scePsmf_0x0ba514e5")},
		{FID(0x1e6d9013),0,N("scePsmf_0x1e6d9013")},
		{FID(0x68d42328),0,N("scePsmf_0x68d42328")},
		{FID(0xa83f7113),0,N("scePsmf_0xa83f7113")},
		{FID(0xc22c8327),0,N("scePsmf_0xc22c8327")},
		{FID(0xeaed89cd),0,N("scePsmf_0xeaed89cd")},
		{FID(0x4bc9bde0),0,N("scePsmf_0x4bc9bde0")},
		{FID(0x5b70fcc1),0,N("scePsmf_0x5b70fcc1")},
		{FID(0x76d3aeba),0,N("scePsmf_0x76d3aeba")},
		{FID(0x9553cc91),0,N("scePsmf_0x9553cc91")},
		{FID(0xbd8ae0d8),0,N("scePsmf_0xbd8ae0d8")},
		{FID(0xc7db3a5b),0,N("scePsmf_0xc7db3a5b")},
	};

	const HLEFunction scePsmfPlayer[] =
	{
		{FID(0x1078c008),0,N("scePsmfPlayer_0x1078c008")},
		{FID(0x1e57a8e7),0,N("scePsmfPlayer_0x1e57a8e7")},
		{FID(0x235d8787),0,N("scePsmfPlayer_0x235d8787")},
		{FID(0x2beb1569),0,N("scePsmfPlayer_0x2beb1569")},
		{FID(0x3d6d25a9),0,N("scePsmfPlayer_0x3d6d25a9")},
		{FID(0x3ea82a4b),0,N("scePsmfPlayer_0x3ea82a4b")},
		{FID(0x3ed62233),0,N("scePsmfPlayer_0x3ed62233")},
		{FID(0x46f61f8b),0,N("scePsmfPlayer_0x46f61f8b")},
		{FID(0x68f07175),0,N("scePsmfPlayer_0x68f07175")},
		{FID(0x75f03fa2),0,N("scePsmfPlayer_0x75f03fa2")},
		{FID(0x85461eff),0,N("scePsmfPlayer_0x85461eff")},
		{FID(0x8a9ebdcd),0,N("scePsmfPlayer_0x8a9ebdcd")},
		{FID(0x95a84ee5),0,N("scePsmfPlayer_0x95a84ee5")},
		{FID(0x9b71a274),0,N("scePsmfPlayer_0x9b71a274")},
		{FID(0x9ff2b2e7),0,N("scePsmfPlayer_0x9ff2b2e7")},
		{FID(0xa0b8ca55),0,N("scePsmfPlayer_0xa0b8ca55")},
		{FID(0xa3d81169),0,N("scePsmfPlayer_0xa3d81169")},
		{FID(0xb8d10c56),0,N("scePsmfPlayer_0xb8d10c56")},
		{FID(0xb9848a74),0,N("scePsmfPlayer_0xb9848a74")},
		{FID(0xdf089680),0,N("scePsmfPlayer_0xdf089680")},
		{FID(0xe792cd94),0,N("scePsmfPlayer_0xe792cd94")},
		{FID(0xf3efaa91),0,N("scePsmfPlayer_0xf3efaa91")},
		{FID(0xf8ef08a6),0,N("scePsmfPlayer_0xf8ef08a6")},
	};
				
	const HLEFunction Kernel_Library[] = 
	{
		{FID(0x092968F4),sceKernelCpuSuspendIntr,N("sceKernelCpuSuspendIntr")},
		{FID(0x5F10D406),sceKernelCpuResumeIntr, N("sceKernelCpuResumeIntr")}, //int oldstat
		{FID(0x3b84732d),sceKernelCpuResumeIntrWithSync, N("sceKernelCpuResumeIntrWithSync")},
		{FID(0x47a0b729),0, N("sceKernelIsCpuIntrSuspended")}, //flags
		{FID(0xb55249d2),sceKernelIsCpuIntrEnable, N("sceKernelIsCpuIntrEnable")}, 
	};

	const HLEFunction ThreadManForUser[] = 
	{
		{FID(0x55C20A00),sceKernelCreateEventFlag, N("sceKernelCreateEventFlag")},
		{FID(0x812346E4),sceKernelClearEventFlag,  N("sceKernelClearEventFlag")},
		{FID(0xEF9E4C70),sceKernelDeleteEventFlag, N("sceKernelDeleteEventFlag")},
		{FID(0x1fb15a32),sceKernelSetEventFlag,    N("sceKernelSetEventFlag")},
		{FID(0x402FCF22),sceKernelWaitEventFlag,   N("sceKernelWaitEventFlag")},
		{FID(0x328C546A),sceKernelWaitEventFlagCB, N("sceKernelWaitEventFlagCB")},
		{FID(0x30FD48F0),sceKernelPollEventFlag,   N("sceKernelPollEventFlag")},
		{FID(0xCD203292),sceKernelCancelEventFlag, N("sceKernelCancelEventFlag")},
		{FID(0xA66B0120),sceKernelReferEventFlagStatus,N("sceKernelReferEventFlagStatus")},

		{FID(0x8FFDF9A2),sceKernelCancelSema,    N("sceKernelCancelSema")},
		{FID(0xD6DA4BA1),sceKernelCreateSema,    N("sceKernelCreateSema")}, //(const char *s, int flg, int val, int max, const void *p); 
		{FID(0x28b6489c),sceKernelDeleteSema,    N("sceKernelDeleteSema")}, //(int id)	
		{FID(0x58b1f937),sceKernelPollSema,      N("sceKernelPollSema")}, //(int id, int count); 
		{FID(0xBC6FEBC5),sceKernelReferSemaStatus,N("sceKernelReferSemaStatus")},
		{FID(0x3F53E640),sceKernelSignalSema,    N("sceKernelSignalSema")},
		{FID(0x4E3A1105),sceKernelWaitSema,      N("sceKernelWaitSema")},
		{FID(0x6d212bac),sceKernelWaitSemaCB,     N("sceKernelWaitSemaCB")},

		{FID(0x7e65b999),0,N("sceKernelCancelAlarm")},

		{FID(0xFCCFAD26),0,N("sceKernelCancelWakeupThread")},
		{FID(0xea748e31),sceKernelChangeCurrentThreadAttr,N("sceKernelChangeCurrentThreadAttr")},
		{FID(0x71bc9871),sceKernelChangeThreadPriority,N("sceKernelChangeThreadPriority")},
		{FID(0x446D8DE6),sceKernelCreateThread,N("sceKernelCreateThread")},
		{FID(0x9fa03cd3),sceKernelDeleteThread,N("sceKernelDeleteThread")},
		{FID(0xBD123D9E),0,N("sceKernelDelaySysClockThread")},
		{FID(0x1181E963),0,N("sceKernelDelaySysClockThreadCB")},
		{FID(0xceadeb47),sceKernelDelayThread,N("sceKernelDelayThread")},
		{FID(0x68da9e36),sceKernelDelayThreadCB,N("sceKernelDelayThreadCB")},
		{FID(0xaa73c935),sceKernelExitThread,N("sceKernelExitThread")},
		{FID(0x809ce29b),sceKernelExitDeleteThread,N("sceKernelExitDeleteThread")},
		{FID(0x94aa61ee),0,N("sceKernelGetThreadCurrentPriority")},
		{FID(0x293b45b8),sceKernelGetThreadId,N("sceKernelGetThreadId")},
		{FID(0x3B183E26),0,N("sceKernelGetThreadExitStatus")},
		{FID(0x52089CA1),0,N("sceKernelGetThreadStackFreeSize")},
		{FID(0xFFC36A14),0,N("sceKernelReferThreadRunStatus")},
		{FID(0x17c1684e),sceKernelReferThreadStatus,N("sceKernelReferThreadStatus")},
		{FID(0x2C34E053),0,N("sceKernelReleaseWaitThread")},
		{FID(0x75156e8f),sceKernelResumeThread,N("sceKernelResumeThread")},
		{FID(0x27e22ec2),0,N("sceKernelResumeDispatchThread")},
		{FID(0x912354a7),sceKernelRotateThreadReadyQueue,N("sceKernelRotateThreadReadyQueue")},
		{FID(0x9ACE131E),sceKernelSleepThread,N("sceKernelSleepThread")},
		{FID(0x82826f70),sceKernelSleepThreadCB,N("sceKernelSleepThreadCB")},
		{FID(0xF475845D),sceKernelStartThread,N("sceKernelStartThread")},
		{FID(0x9944f31f),sceKernelSuspendThread,N("sceKernelSuspendThread")},
		{FID(0x3ad58b8c),0,N("sceKernelSuspendDispatchThread")},
		{FID(0x616403ba),0,N("sceKernelTerminateThread")},
		{FID(0x383f7bcc),sceKernelTerminateDeleteThread,N("sceKernelTerminateDeleteThread")},
		{FID(0x840E8133),0,N("sceKernelWaitThreadEndCB")},


		{FID(0x94416130),0,N("sceKernelGetThreadmanIdList")},
		{FID(0x57CF62DD),0,N("sceKernelGetThreadmanIdType")},

		{FID(0xD2D615EF),0,N("sceKernelCancelVTimerHandler")},
		{FID(0x20fff560),sceKernelCreateVTimer,N("sceKernelCreateVTimer")},
		{FID(0x328F9E52),0,N("sceKernelDeleteVTimer")},
		{FID(0xB3A59970),0,N("sceKernelGetVTimerBase")},
		{FID(0xB7C18B77),0,N("sceKernelGetVTimerBaseWide")},
		{FID(0x034A921F),0,N("sceKernelGetVTimerTime")},
		{FID(0xC0B3FFD2),0,N("sceKernelGetVTimerTimeWide")},
		{FID(0x5F32BEAA),0,N("sceKernelReferVTimerStatus")},
		{FID(0x542AD630),0,N("sceKernelSetVTimerTime")},
		{FID(0xFB6425C3),0,N("sceKernelSetVTimerTimeWide")},
		{FID(0xd8b299ae),sceKernelSetVTimerHandler,N("sceKernelSetVTimerHandler")},
		{FID(0x53B00E9A),0,N("sceKernelSetVTimerHandlerWide")},
		{FID(0xc68d9437),sceKernelStartVTimer,N("sceKernelStartVTimer")},

		{FID(0xd13bde95),sceKernelCheckThreadStack,N("sceKernelCheckThreadStack")},
		{FID(0x349d6d6c),sceKernelCheckCallback,N("sceKernelCheckCallback")},
		{FID(0xE81CAF8F),sceKernelCreateCallback,N("sceKernelCreateCallback")},

		{FID(0x82BC5777),sceKernelGetSystemTimeWide,N("sceKernelGetSystemTimeWide")},
		{FID(0xdb738f35),0,N("sceKernelGetSystemTime")},
		{FID(0x369ed59d),sceKernelGetSystemTimeLow,N("sceKernelGetSystemTimeLow")},

		{FID(0xDAA3F564),0,N("sceKernelReferAlarmStatus")},
		{FID(0x8218B4DD),0,N("sceKernelReferGlobalProfiler")},
		{FID(0x627E6F3A),0,N("sceKernelReferSystemStatus")},
		{FID(0x64D4540E),0,N("sceKernelReferThreadProfiler")},

		{FID(0x6652b8ca),0,N("sceKernelSetAlarm")},
		{FID(0xD0AEEE87),0,N("sceKernelStopVTimer")},
		{FID(0xba6b92e2),0,N("sceKernelSysClock2USec")},
		{FID(0x110DEC9A),0,N("sceKernelUSec2SysClock")},
		{FID(0xC8CD158C),0,N("sceKernelUSec2SysClockWide")},
		{FID(0xE1619D7C),0,N("sceKernelSysClock2USecWide")},
		{FID(0xB2C25152),0,N("sceKernelSetSysClockAlarm")},

		//sceKernelThreadBlockSwitchThread 0x278c0df5

		{FID(0x110dec9a),sceKernelUSec2SysClock,N("sceKernelUSec2SysClock")},
		{FID(0x278C0DF5),sceKernelWaitThreadEnd,N("sceKernelWaitThreadEnd")},
		{FID(0xd59ead2f),sceKernelWakeupThread,N("sceKernelWakeupThread")}, //AI Go, audio?

		{FID(0x0C106E53),0,N("sceKernelRegisterThreadEventHandler")},
		{FID(0x72F3C145),0,N("sceKernelReleaseThreadEventHandler")},
		{FID(0x369EEB6B),0,N("sceKernelReferThreadEventHandlerStatus")},

		{FID(0xEDBA5844),sceKernelDeleteCallback,N("sceKernelDeleteCallback")},
		{FID(0xC11BA8C4),sceKernelNotifyCallback,N("sceKernelNotifyCallback")},
		{FID(0xBA4051D6),0,N("sceKernelCancelCallback")},
		{FID(0x2A3D44FF),0,N("sceKernelGetCallbackCount")},
		{FID(0x349D6D6C),0,N("sceKernelCheckCallback")},
		{FID(0x730ED8BC),0,N("sceKernelReferCallbackStatus")},

		{FID(0x8125221D),0,N("sceKernelCreateMbx")},
		{FID(0x86255ADA),0,N("sceKernelDeleteMbx")},
		{FID(0xE9B3061E),0,N("sceKernelSendMbx")},
		{FID(0x18260574),0,N("sceKernelReceiveMbx")},
		{FID(0xF3986382),0,N("sceKernelReceiveMbxCB")},
		{FID(0x0D81716A),0,N("sceKernelPollMbx")},
		{FID(0x87D4DD36),0,N("sceKernelCancelReceiveMbx")},
		{FID(0xA8E8C846),0,N("sceKernelReferMbxStatus")},

		{FID(0x7C0DC2A0),0,N("sceKernelCreateMsgPipe")},
		{FID(0xF0B7DA1C),0,N("sceKernelDeleteMsgPipe")},
		{FID(0x876DBFAD),0,N("sceKernelSendMsgPipe")},
		{FID(0x7C41F2C2),0,N("sceKernelSendMsgPipeCB")},
		{FID(0x884C9F90),0,N("sceKernelTrySendMsgPipe")},
		{FID(0x74829B76),0,N("sceKernelReceiveMsgPipe")},
		{FID(0xFBFA697D),0,N("sceKernelReceiveMsgPipeCB")},
		{FID(0xDF52098F),0,N("sceKernelTryReceiveMsgPipe")},
		{FID(0x349B864D),0,N("sceKernelCancelMsgPipe")},
		{FID(0x33BE4024),0,N("sceKernelReferMsgPipeStatus")},

		{FID(0x56C039B5),sceKernelCreateVpl,N("sceKernelCreateVpl")},
		{FID(0x89B3D48C),sceKernelDeleteVpl,N("sceKernelDeleteVpl")},
		{FID(0xBED27435),sceKernelAllocateVpl,N("sceKernelAllocateVpl")},
		{FID(0xEC0A693F),sceKernelAllocateVplCB,N("sceKernelAllocateVplCB")},
		{FID(0xAF36D708),sceKernelTryAllocateVpl,N("sceKernelTryAllocateVpl")},
		{FID(0xB736E9FF),sceKernelFreeVpl,N("sceKernelFreeVpl")},
		{FID(0x1D371B8A),sceKernelCancelVpl,N("sceKernelCancelVpl")},
		{FID(0x39810265),sceKernelReferVplStatus,N("sceKernelReferVplStatus")},

		{FID(0xC07BB470),sceKernelCreateFpl,N("sceKernelCreateFpl")},
		{FID(0xED1410E0),sceKernelDeleteFpl,N("sceKernelDeleteFpl")},
		{FID(0xD979E9BF),sceKernelAllocateFpl,N("sceKernelAllocateFpl")},
		{FID(0xE7282CB6),sceKernelAllocateFplCB,N("sceKernelAllocateFplCB")},
		{FID(0x623AE665),sceKernelTryAllocateFpl,N("sceKernelTryAllocateFpl")},
		{FID(0xF6414A71),sceKernelFreeFpl,N("sceKernelFreeFpl")},
		{FID(0xA8AA591F),sceKernelCancelFpl,N("sceKernelCancelFpl")},
		{FID(0xD8199E4C),sceKernelReferFplStatus,N("sceKernelReferFplStatus")},

		{FID(0x0E927AED), _sceKernelReturnFromTimerHandler, N("_sceKernelReturnFromTimerHandler")},
		{FID(0x532A522E), _sceKernelExitThread,N("_sceKernelExitThread")},
		{FID(0x6E9EA350), _sceKernelReturnFromCallback,N("_sceKernelReturnFromCallback")},
		{FID(0xf8170fbe),0,N("sceKernelThreadMan_f8170fbe")},
		{FID(0x5bf4dd27),0,N("sceKernelThreadMan_5bf4dd27")}, //f(ptr, 1)
		{FID(0x6b30100f),0,N("sceKernelThreadMan_6b30100f")}, //f(ptr)
		{FID(0xb7d098c6),0,N("sceKernelThreadMan_b7d098c6")}, //x=f("GlobalHeaps Main Lock",0,0,0)
	};

	const HLEFunction IoFileMgrForUser[] =
	{
		{FID(0xb29ddf9c),sceIoDopen, N("sceIoDopen")},
		{FID(0xe3eb004c),sceIoDread, N("sceIoDread")},
		{FID(0xeb092469),sceIoDclose,N("sceIoDclose")},
		{FID(0xe95a012b),0,N("sceIoIoctlAsync")},
		{FID(0x63632449),0,N("sceIoIoctl")},
		{FID(0xace946e8),sceIoGetstat,N("sceIoGetstat")},
		{FID(0xb8a740f4),0,N("sceIoChstat")},
		{FID(0x55f4717d),sceIoChdir,N("sceIoChdir")},
		{FID(0x08bd7374),0,N("sceIoGetDevType")},
		{FID(0xB2A628C1),sceIoAssign,N("sceIoAssign")},
		{FID(0xe8bc6571),0,N("sceIoCancel")},
		{FID(0xb293727f),sceIoChangeAsyncPriority,N("sceIoChangeAsyncPriority")},
		{FID(0x810C4BC3),sceIoClose, N("sceIoClose")},  //(int fd); 
		{FID(0xff5940b6),sceIoCloseAsync,N("sceIoCloseAsync")},
		{FID(0x54F5FB11),sceIoDevctl,N("sceIoDevctl")}, //(const char *name int cmd, void *arg, size_t arglen, void *buf, size_t *buflen); 
		{FID(0xcb05f8d6),sceIoGetAsyncStat,N("sceIoGetAsyncStat")},
		{FID(0x27EB27B8),sceIoLseek, N("sceIoLseek")},  //(int fd, int offset, int whence); 
		{FID(0x68963324),0,N("sceIoLseek32")},
		{FID(0x1b385d8f),0,N("sceIoLseek32Async")},
		{FID(0x71b19e77),sceIoLseekAsync,N("sceIoLseekAsync")},
		{FID(0x109F50BC),sceIoOpen,  N("sceIoOpen")},   //(const char* file, int mode); 
		{FID(0x89AA9906),sceIoOpenAsync,N("sceIoOpenAsync")},
		{FID(0x06A70004),0,N("sceIoMkdir")},  //(const char *dir, int mode); 
		{FID(0x3251ea56),sceIoPollAsync,N("sceIoPollAsync")},
		{FID(0x6A638D83),sceIoRead,  N("sceIoRead")},   //(int fd, void *data, int size); 
		{FID(0xa0b5a7c2),sceIoReadAsync,N("sceIoReadAsync")},
		{FID(0xF27A9C51),0,N("sceIoRemove")}, //(const char *file); 
		{FID(0x779103A0),0,N("sceIoRename")}, //(const char *oldname, const char *newname); 
		{FID(0x1117C65F),0,N("sceIoRmdir")},  //(const char *dir); 
		{FID(0xA12A0514),0,N("sceIoSetAsyncCallback")},
		{FID(0xab96437f),0,N("sceIoSync")},
		{FID(0x6d08a871),0,N("sceIoUnassign")},
		{FID(0x42EC03AC),sceIoWrite, N("sceIoWrite")},  //(int fd, void *data, int size); 
		{FID(0x0facab19),0,N("sceIoWriteAsync")},
		{FID(0x35dbd746),sceIoWaitAsyncCB,N("sceIoWaitAsyncCB")},
		{FID(0xe23eec33),sceIoWaitAsync,N("sceIoWaitAsync")},
	};


	const HLEFunction UtilsForUser[] = 
	{
		{FID(0x91E4F6A7),sceKernelLibcClock,N("sceKernelLibcClock")},
		{FID(0x27CC57F0),sceKernelLibcTime, N("sceKernelLibcTime")},
		{FID(0x71EC4271),sceKernelLibcGettimeofday, N("sceKernelLibcGettimeofday")},
		{FID(0xBFA98062),0,N("sceKernelDcacheInvalidateRange")},
		{FID(0xC8186A58),0,N("sceKernelUtilsMd5Digest")},
		{FID(0x9E5C5086),0,N("sceKernelUtilsMd5BlockInit")},
		{FID(0x61E1E525),0,N("sceKernelUtilsMd5BlockUpdate")},
		{FID(0xB8D24E78),0,N("sceKernelUtilsMd5BlockResult")},
		{FID(0x840259F1),0,N("sceKernelUtilsSha1Digest")},
		{FID(0xF8FCD5BA),0,N("sceKernelUtilsSha1BlockInit")},
		{FID(0x346F6DA8),0,N("sceKernelUtilsSha1BlockUpdate")},
		{FID(0x585F1C09),0,N("sceKernelUtilsSha1BlockResult")},
		{FID(0xE860E75E),0,N("sceKernelUtilsMt19937Init")},
		{FID(0x06FB8A63),0,N("sceKernelUtilsMt19937UInt")},
		{FID(0x37FB5C42),sceKernelGetGPI,N("sceKernelGetGPI")},
		{FID(0x6AD345D7),sceKernelSetGPO,N("sceKernelSetGPO")},
		{FID(0x79D1C3FA),0,N("sceKernelDcacheWritebackAll")},
		{FID(0xB435DEC5),0,N("sceKernelDcacheWritebackInvalidateAll")},
		{FID(0x3EE30821),0,N("sceKernelDcacheWritebackRange")},
		{FID(0x34B9FA9E),0,N("sceKernelDcacheWritebackInvalidateRange")},
		{FID(0x80001C4C),0,N("sceKernelDcacheProbe")},
		{FID(0x16641D70),0,N("sceKernelDcacheReadTag")},
		{FID(0x4FD31C9D),0,N("sceKernelIcacheProbe")},
		{FID(0xFB05FAD0),0,N("sceKernelIcacheReadTag")},
		{FID(0x920f104a),0,N("sceKernelIcacheInvalidateAll")}
	};				   
					   
	const HLEFunction sceGe_user[] = 
	{				   
		{FID(0xE47E40E4),sceGeEdramGetAddr,       N("sceGeEdramGetAddr")},
		{FID(0xAB49E76A),sceGeListEnQueue,        N("sceGeListEnQueue")},
		{FID(0x1C0D95A6),sceGeListEnQueueHead,    N("sceGeListEnQueueHead")},
		{FID(0xE0D68148),sceGeListUpdateStallAddr,N("sceGeListUpdateStallAddr")},
		{FID(0x03444EB4),sceGeListSync,           N("sceGeListSync")},
		{FID(0xB287BD61),sceGeDrawSync,           N("sceGeDrawSync")},
		{FID(0xB448EC0D),sceGeBreak,              N("sceGeBreak")},
		{FID(0x4C06E472),sceGeContinue,           N("sceGeContinue")},
		{FID(0xA4FC06A4),sceGeSetCallback,        N("sceGeSetCallback")},
		{FID(0x05DB22CE),sceGeUnsetCallback,      N("sceGeUnsetCallback")},
		{FID(0x1F6752AD),sceGeEdramGetSize,       N("sceGeEdramGetSize")},
		{FID(0xB77905EA),0,N("sceGeEdramSetAddrTranslation")},
		{FID(0xDC93CFEF),0,N("sceGeGetCmd")},
		{FID(0x57C8945B),0,N("sceGeGetMtx")},
		{FID(0x438A385A),0,N("sceGeSaveContext")},
		{FID(0x0BF608FB),0,N("sceGeRestoreContext")},
		{FID(0x5FB86AB0),0,N("sceGeListDeQueue")},
	};				   

	const HLEFunction ModuleMgrForUser[] = 
	{
		{FID(0x977DE386),sceKernelLoadModule,N("sceKernelLoadModule")},
		{FID(0xb7f46618),0,N("sceKernelLoadModuleByID")},
		{FID(0x50F0C1EC),sceKernelStartModule,N("sceKernelStartModule")},
		{FID(0xD675EBB8),sceKernelExitGame,N("sceKernelSelfStopUnloadModule")}, //HACK
		{FID(0xd1ff982a),sceKernelStopModule,N("sceKernelStopModule")},
		{FID(0x2e0911aa),sceKernelUnloadModule,N("sceKernelUnloadModule")},
		{FID(0x710F61B5),0,N("sceKernelLoadModuleMs")},
		{FID(0xF9275D98),0,N("sceKernelLoadModuleBufferUsbWlan")}, ///???
		{FID(0xCC1D3699),0,N("sceKernelStopUnloadSelfModule")},
		{FID(0x748CBED9),0,N("sceKernelQueryModuleInfo")},
		{FID(0xd8b73127),sceKernelGetModuleIdByAddress, N("sceKernelGetModuleIdByAddress")},
		{FID(0xf0a26395),sceKernelGetModuleId, N("sceKernelGetModuleId")},
		{FID(0x8f2df740),0,N("sceKernel_ModuleMgr_8f2df740")},
	};	

	const HLEFunction StdioForUser[] = 
	{
		{FID(0x172D316E),sceKernelStdin,N("sceKernelStdin")},
		{FID(0xA6BAB2E9),sceKernelStdout,N("sceKernelStdout")},
		{FID(0xF78BA90A),sceKernelStderr,N("sceKernelStderr")},
	};					   
	
	
	const HLEFunction SysMemUserForUser[] = 
	{
		{FID(0xA291F107),sceKernelMaxFreeMemSize,  N("sceKernelMaxFreeMemSize")},
		{FID(0xF919F628),sceKernelTotalFreeMemSize,N("sceKernelTotalFreeMemSize")},
		{FID(0x3FC9AE6A),sceKernelDevkitVersion,   N("sceKernelDevkitVersion")},	
		{FID(0x237DBD4F),sceKernelAllocPartitionMemory,N("sceKernelAllocPartitionMemory")},  //(int size) ?
		{FID(0xB6D61D02),sceKernelFreePartitionMemory,N("sceKernelFreePartitionMemory")},   //(void *ptr) ?
		{FID(0x9D9A5BA1),sceKernelGetBlockHeadAddr,N("sceKernelGetBlockHeadAddr")},      //(void *ptr) ?
		{FID(0x13a5abef),sceKernelMemory_Unknown1,N("sceKernelMemory_Unknown1 0x13a5abef")},
		{FID(0x7591c7db),sceKernelMemory_Unknown2,N("sceKernelMemory_Unknown2 0x7591c7db")},
		{FID(0xf77d77cb),sceKernelMemory_Unknown3,N("sceKernelMemory_Unknown3 0xf77d77cb")},
	};					   

	const HLEFunction sceAtrac3plus[] = 
	{
		{FID(0x7db31251),sceAtracAddStreamData,N("sceAtracAddStreamData")},
		{FID(0x6a8c3cd5),sceAtracDecodeData,N("sceAtracDecodeData")},
		{FID(0xd5c28cc0),sceAtracEndEntry,N("sceAtracEndEntry")},
		{FID(0x780f88d1),sceAtracGetAtracID,N("sceAtracGetAtracID")},
		{FID(0xca3ca3d2),sceAtracGetBufferInfoForReseting,N("sceAtracGetBufferInfoForReseting")},
		{FID(0xa554a158),sceAtracGetBitrate,N("sceAtracGetBitrate")},
		{FID(0x31668baa),sceAtracGetChannel,N("sceAtracGetChannel")},
		{FID(0xfaa4f89b),sceAtracGetLoopStatus,N("sceAtracGetLoopStatus")},
		{FID(0xe88f759b),sceAtracGetInternalErrorInfo,N("sceAtracGetInternalErrorInfo")},
		{FID(0xd6a5f2f7),sceAtracGetMaxSample,N("sceAtracGetMaxSample")},
		{FID(0xe23e3a35),sceAtracGetNextDecodePosition,N("sceAtracGetNextDecodePosition")},
		{FID(0x36faabfb),sceAtracGetNextSample,N("sceAtracGetNextSample")},
		{FID(0x9ae849a7),sceAtracGetRemainFrame,N("sceAtracGetRemainFrame")},
		{FID(0x83e85ea0),sceAtracGetSecondBufferInfo,N("sceAtracGetSecondBufferInfo")},
		{FID(0xa2bba8be),sceAtracGetSoundSample,N("sceAtracGetSoundSample")},
		{FID(0x5d268707),sceAtracGetStreamDataInfo,N("sceAtracGetStreamDataInfo")},
		{FID(0x61eb33f5),sceAtracReleaseAtracID,N("sceAtracReleaseAtracID")},
		{FID(0x644e5607),sceAtracResetPlayPosition,N("sceAtracResetPlayPosition")},
		{FID(0x3f6e26b5),sceAtracSetHalfwayBuffer,N("sceAtracSetHalfwayBuffer")},
		{FID(0x83bf7afd),sceAtracSetSecondBuffer,N("sceAtracSetSecondBuffer")},
		{FID(0x0E2A73AB),sceAtracSetData,N("sceAtracSetData")}, //?
		{FID(0x7a20e7af),sceAtracSetDataAndGetID,N("sceAtracSetDataAndGetID")},
		{FID(0x0eb8dc38),sceAtracSetHalfwayBufferAndGetID,N("sceAtracSetHalfwayBufferAndGetID")},
		{FID(0xd1f59fdb),sceAtracStartEntry,N("sceAtracStartEntry")},
		{FID(0x868120b5),sceAtracSetLoopNum,N("sceAtracSetLoopNum")},
		{FID(0x132f1eca),0,N("sceAtrac3_0x132f1eca")},
		{FID(0xeca32a99),0,N("sceAtrac3_0xeca32a99")},
		{FID(0x0fae370e),0,N("sceAtrac3_0x0fae370e")},
	};

	/*
	*	0x62411801 sceSircsInit
	0x19155a2f sceSircsEnd
	0x71eef62d sceSircsSend
	 */
	const HLEFunction sceHttp[] =
	{
		{FID(0xd70d4847),0,N("sceHttpGetProxy")},
		{FID(0x4cc7d78f),0,N("sceHttpGetStatusCode")},
		{FID(0xedeeb999),0,N("sceHttpReadData")},
		{FID(0xa6800c34),0,N("sceHttpInitCache")},
		{FID(0xab1abe07),0,N("sceHttpInit")},
		{FID(0xd1c8945e),0,N("sceHttpEnd")},
		{FID(0x78b54c09),0,N("sceHttpEndCache")},
		{FID(0xbb70706f),0,N("sceHttpSendRequest")},
		{FID(0xa5512e01),0,N("sceHttpDeleteRequest")},
		{FID(0x15540184),0,N("sceHttpDeleteHeader")},
		{FID(0x5152773b),0,N("sceHttpDeleteConnection")},
		{FID(0x8acd1f73),0,N("sceHttpSetConnectTimeOut")},
		{FID(0x9988172d),0,N("sceHttpSetSendTimeOut")},
		{FID(0xf0f46c62),0,N("sceHttpSetProxy")},
		{FID(0x0dafa58f),0,N("sceHttpEnableCookie")},
		{FID(0x78a0d3ec),0,N("sceHttpEnableKeepAlive")},
		{FID(0x59e6d16f),0,N("sceHttpEnableCache")},
		{FID(0x0b12abfb),0,N("sceHttpDisableCookie")},
		{FID(0xc7ef2559),0,N("sceHttpDisableKeepAlive")},
		{FID(0xccbd167a),0,N("sceHttpDisableCache")},
		{FID(0xe4d21302),0,N("sceHttpsInit")},
		{FID(0xf9d8eb63),0,N("sceHttpsEnd")},
		{FID(0x47347b50),0,N("sceHttpCreateRequest")},
		{FID(0x8eefd953),0,N("sceHttpCreateConnection")},
		{FID(0xd081ec8f),0,N("sceHttpGetNetworkErrno")},
		{FID(0x3eaba285),0,N("sceHttpAddExtraHeader")},
		{FID(0xc10b6bd9),0,N("sceHttpAbortRequest")},
		{FID(0xfcf8c055),0,N("sceHttpDeleteTemplate")},
		{FID(0xf49934f6),0,N("sceHttpSetMallocFunction")},
		{FID(0x47940436),0,N("sceHttpSetResolveTimeOut")},
		{FID(0x2a6c3296),0,N("sceHttpSetAuthInfoCB")},
		{FID(0xd081ec8f),0,N("sceHttpGetNetworkErrno")},
		{FID(0x0809c831),0,N("sceHttpEnableRedirect")},
		{FID(0x9fc5f10d),0,N("sceHttpEnableAuth")},
		{FID(0x1a0ebb69),0,N("sceHttpDisableRedirect")},
		{FID(0xae948fee),0,N("sceHttpDisableAuth")},
		{FID(0xccbd167a),0,N("sceHttpDisableCache")},
		{FID(0xd081ec8f),0,N("sceHttpGetNetworkErrno")},
		{FID(0x76d1363b),0,N("sceHttp_76d1363b")},
		{FID(0x87797bdd),0,N("sceHttp_87797bdd")},
		{FID(0xf1657b22),0,N("sceHttp_f1657b22")},
	};				

	const HLEFunction sceMpeg[] =
	{
		//sceMpegAvcDecodeYCbCr
		//sceMpegAvcCsc
		//sceMpegAvcQueryYCbCr
		//sceMpegAvcInitYCbCr
		//sceMpegGetAvcAu
		{FID(0xe1ce83a7),0,N("sceMpegGetAtracAu")},
		{FID(0xfe246728),0,N("sceMpegGetAvcAu")},
		{FID(0xd8c5f121),0,N("sceMpegCreate")},
		{FID(0xf8dcb679),0,N("sceMpegQueryAtracEsSize")},
		{FID(0xc132e22f),0,N("sceMpegQueryMemSize")},
		{FID(0x21ff80e4),0,N("sceMpegQueryStreamOffset")},
		{FID(0x611e9e11),0,N("sceMpegQueryStreamSize")},
		{FID(0x42560f23),0,N("sceMpegRegistStream")},
		{FID(0x591a4aa2),0,N("sceMpegUnRegistStream")},
		{FID(0x707b7629),0,N("sceMpegFlushAllStream")},
		{FID(0xa780cf7e),0,N("sceMpegMallocAvcEsBuf")},
		{FID(0xceb870b1),0,N("sceMpegFreeAvcEsBuf")},
		{FID(0x167afd9e),0,N("sceMpegInitAu")},
		{FID(0x682a619b),0,N("sceMpegInit")},
		{FID(0x800c44df),0,N("sceMpegAtracDecode")},
		{FID(0x740fccd1),0,N("sceMpegAvcDecodeStop")},
		{FID(0x0e3c2e9d),0,N("sceMpegAvcDecode")},
		{FID(0xd7a29f46),0,N("sceMpegRingbufferQueryMemSize")},
		{FID(0x37295ed8),0,N("sceMpegRingbufferConstruct")},
		{FID(0x13407f13),0,N("sceMpegRingbufferDestruct")},
		{FID(0xb240a59e),0,N("sceMpegRingbufferPut")},
		{FID(0xb5f6dc87),0,N("sceMpegRingbufferAvailableSize")},
		{FID(0x606a4649),0,N("sceMpegDelete")},
		{FID(0x874624d6),0,N("sceMpegFinish")},
		{FID(0x4571cc64),0,N("sceMpeg_4571cc64")},
	};

	const HLEFunction sceRtc[] = 
	{
		{FID(0xC41C2853),sceRtcGetTickResolution,N("sceRtcGetTickResolution")},
		{FID(0x3f7ad767),sceRtcGetCurrentTick,N("sceRtcGetCurrentTick")},	
		{FID(0x029CA3B3),0,N("sceRtc_029CA3B3")},
		{FID(0x4cfa57b0),0,N("sceRtcGetCurrentClock")},
		{FID(0xE7C27D1B),sceRtcGetCurrentClockLocalTime,N("sceRtcGetCurrentClockLocalTime")},
		{FID(0x34885E0D),0,N("sceRtcConvertUtcToLocalTime")},
		{FID(0x779242A2),0,N("sceRtcConvertLocalTimeToUTC")},
		{FID(0x42307A17),0,N("sceRtcIsLeapYear")},
		{FID(0x05ef322c),0,N("sceRtcGetDaysInMonth")},
		{FID(0x57726bc1),0,N("sceRtcGetDayOfWeek")},
		{FID(0x4B1B5E82),0,N("sceRtcCheckValid")},
		{FID(0x3a807cc8),0,N("sceRtcSetTime_t")},
		{FID(0x27c4594c),0,N("sceRtcGetTime_t")},
		{FID(0xF006F264),0,N("sceRtcSetDosTime")},
		{FID(0x36075567),0,N("sceRtcGetDosTime")},
		{FID(0x7ACE4C04),0,N("sceRtcSetWin32FileTime")},
		{FID(0xCF561893),0,N("sceRtcGetWin32FileTime")},
		{FID(0x7ED29E40),0,N("sceRtcSetTick")},
		{FID(0x6FF40ACC),sceRtcGetTick,N("sceRtcGetTick")},
		{FID(0x9ED0AE87),0,N("sceRtcCompareTick")},
		{FID(0x44F45E05),0,N("sceRtcTickAddTicks")},
		{FID(0x26D25A5D),0,N("sceRtcTickAddMicroseconds")},
		{FID(0xF2A4AFE5),0,N("sceRtcTickAddSeconds")},
		{FID(0xE6605BCA),0,N("sceRtcTickAddMinutes")},
		{FID(0x26D7A24A),0,N("sceRtcTickAddHours")},
		{FID(0xE51B4B7A),0,N("sceRtcTickAddDays")},
		{FID(0xCF3A2CA8),0,N("sceRtcTickAddWeeks")},
		{FID(0xDBF74F1B),0,N("sceRtcTickAddMonths")},
		{FID(0x42842C77),0,N("sceRtcTickAddYears")},
		{FID(0xC663B3B9),0,N("sceRtcFormatRFC2822")},
		{FID(0x7DE6711B),0,N("sceRtcFormatRFC2822LocalTime")},
		{FID(0x0498FB3C),0,N("sceRtcFormatRFC3339")},
		{FID(0x27F98543),0,N("sceRtcFormatRFC3339LocalTime")},
		{FID(0xDFBC5F16),0,N("sceRtcParseDateTime")},
		{FID(0x28E1E988),0,N("sceRtcParseRFC3339")},
	};
						   //890129c in tyshooter looks bogus
	const HLEFunction sceSuspendForUser[] =
	{
		{FID(0xEADB1BD7),sceKernelPowerLock,N("sceKernelPowerLock")}, //(int param) set param to 0
		{FID(0x3AEE7261),sceKernelPowerUnlock,N("sceKernelPowerUnlock")},//(int param) set param to 0
		{FID(0x090ccb3f),sceKernelPowerTick,N("sceKernelPowerTick")},
		{FID(0xa14f40b2),0,N("sceSuspendForUser_a14f40b2")},
		{FID(0xa569e425),0,N("sceSuspendForUser_a569e425")},
		{FID(0x3e0271d3),0,N("sceSuependForUser_3e0271d3")}, //when "acquiring mem pool" (fired up)
	};

	const HLEFunction sceUmdUser[] = 
	{
		{FID(0xC6183D47),sceUmdActivate,N("sceUmdActivate")},
		{FID(0x6B4A146C),sceUmdGetDriveStat,N("sceUmdGetDriveStat")},
		{FID(0x46EBB729),sceUmdCheckMedium,N("sceUmdCheckMedium")},
		{FID(0xE83742BA),sceUmdDeactivate,N("sceUmdDeactivate")},
		{FID(0x8EF08FCE),sceUmdWaitDriveStat,N("sceUmdWaitDriveStat")},
		{FID(0x56202973),sceUmdWaitDriveStatWithTimer,N("sceUmdWaitDriveStatWithTimer")},
		{FID(0x4A9E5E29),sceUmdWaitDriveStatCB,N("sceUmdWaitDriveStatCB")},
		{FID(0x6B4A146C),sceUmdGetDriveStat,N("sceUmdGetDriveStat")},
		{FID(0x20628E6F),0,N("sceUmdGetErrorStat")},
		{FID(0x340B7686),sceUmdGetDiscInfo,N("sceUmdGetDiscInfo")},
		{FID(0xAEE7404D),sceUmdRegisterUMDCallBack,N("sceUmdRegisterUMDCallBack")},
		{FID(0xBD2BDE07),0,N("sceUmdUnRegisterUMDCallBack")},
		{FID(0x87533940),0,N("sceUmd_0x87533940")},
		{FID(0x6af9b50a),0,N("sceUmd_0x6af9b50a")},
	};
	const HLEFunction IoFileMgrForKernel[] =
	{
		{FID(0xa905b705),0,N("sceIoCloseAll")},
		{FID(0x411106BA),0,N("sceIoGetThreadCwd")},
		{FID(0xCB0A151F),0,N("sceIoChangeThreadCwd")},
		{FID(0x8E982A74),0,N("sceIoAddDrv")},
		{FID(0xC7F35804),0,N("sceIoDelDrv")},
		{FID(0x3C54E908),0,N("sceIoReopen")},
	};
	const HLEFunction StdioForKernel[] = 
	{
		{FID(0x98220F3E),0,N("sceKernelStdoutReopen")},
		{FID(0xFB5380C5),0,N("sceKernelStderrReopen")},
		{FID(0x2CCF071A),0,N("fdprintf")},
	};
	const HLEFunction LoadCoreForKernel[] = 
	{
		{FID(0xACE23476),0,N("sceKernelCheckPspConfig")},
		{FID(0x7BE1421C),0,N("sceKernelCheckExecFile")},
		{FID(0xBF983EF2),0,N("sceKernelProbeExecutableObject")},
		{FID(0x7068E6BA),0,N("sceKernelLoadExecutableObject")},
		{FID(0xB4D6FECC),0,N("sceKernelApplyElfRelSection")},
		{FID(0x54AB2675),0,N("LoadCoreForKernel_54AB2675")},
		{FID(0x2952F5AC),0,N("sceKernelDcacheWBinvAll")},
		{FID(0xD8779AC6),0,N("sceKernelIcacheClearAll")},
		{FID(0x99A695F0),0,N("sceKernelRegisterLibrary")},
		{FID(0x5873A31F),0,N("sceKernelRegisterLibraryForUser")},
		{FID(0x0B464512),0,N("sceKernelReleaseLibrary")},
		{FID(0x9BAF90F6),0,N("sceKernelCanReleaseLibrary")},
		{FID(0x0E760DBA),0,N("sceKernelLinkLibraryEntries")},
		{FID(0x0DE1F600),0,N("sceKernelLinkLibraryEntriesForUser")},
		{FID(0xDA1B09AA),0,N("sceKernelUnLinkLibraryEntries")},
		{FID(0xC99DD47A),0,N("sceKernelQueryLoadCoreCB")},
		{FID(0x616FCCCD),0,N("sceKernelSetBootCallbackLevel")},
		{FID(0xF32A2940),0,N("sceKernelModuleFromUID")},
		{FID(0xCD0F3BAC),0,N("sceKernelCreateModule")},
		{FID(0x6B2371C2),0,N("sceKernelDeleteModule")},
		{FID(0x7320D964),0,N("sceKernelModuleAssign")},
		{FID(0x44B292AB),0,N("sceKernelAllocModule")},
		{FID(0xBD61D4D5),0,N("sceKernelFreeModule")},
		{FID(0xAE7C6E76),0,N("sceKernelRegisterModule")},
		{FID(0x74CF001A),0,N("sceKernelReleaseModule")},
		{FID(0xCF8A41B1),sceKernelFindModuleByName,N("sceKernelFindModuleByName")},
		{FID(0xFB8AE27D),0,N("sceKernelFindModuleByAddress")},
		{FID(0xCCE4A157),0,N("sceKernelFindModuleByUID")},
		{FID(0x82CE54ED),0,N("sceKernelModuleCount")},
		{FID(0xC0584F0C),0,N("sceKernelGetModuleList")},
	};

	const HLEFunction LoadExecForUser[] =
	{
		{FID(0x5572A5F), sceKernelExitGame, N("sceKernelExitGame")}, //()
		{FID(0x4AC57943),sceKernelRegisterExitCallback,N("sceKernelRegisterExitCallback")}, 
		{FID(0xBD2F1094),sceKernelLoadExec,N("sceKernelLoadExec")},
		{FID(0x2AC9954B),0,N("sceKernelExitGameWithStatus")},
	};

	const HLEFunction scePower[] = 
	{
		{FID(0x04B7766E),scePowerRegisterCallback,N("scePowerRegisterCallback")},
		{FID(0x2B51FE2F),0,N("scePower_2B51FE2F")},
		{FID(0x442BFBAC),0,N("scePower_442BFBAC")},
		{FID(0xEFD3C963),0,N("scePowerTick")},
		{FID(0xEDC13FE5),0,N("scePowerGetIdleTimer")},
		{FID(0x7F30B3B1),0,N("scePowerIdleTimerEnable")},
		{FID(0x972CE941),0,N("scePowerIdleTimerDisable")},
		{FID(0x27F3292C),0,N("scePowerBatteryUpdateInfo")},
		{FID(0xE8E4E204),0,N("scePower_E8E4E204")},
		{FID(0xB999184C),0,N("scePower_B999184C")},
		{FID(0x87440F5E),scePowerIsPowerOnline,N("scePowerIsPowerOnline")},
		{FID(0x0AFD0D8B),scePowerIsBatteryExist,N("scePowerIsBatteryExist")},
		{FID(0x1E490401),scePowerIsBatteryCharging,N("scePowerIsBatteryCharging")},
		{FID(0xB4432BC8),scePowerGetBatteryChargingStatus,N("scePowerGetBatteryChargingStatus")},
		{FID(0xD3075926),scePowerIsLowBattery,N("scePowerIsLowBattery")},
		{FID(0x78A1A796),0,N("scePower_78A1A796")},
		{FID(0x94F5A53F),0,N("scePower_94F5A53F")},
		{FID(0xFD18A0FF),0,N("scePower_FD18A0FF")},
		{FID(0x2085D15D),scePowerGetBatteryLifePercent,N("scePowerGetBatteryLifePercent")},
		{FID(0x8EFB3FA2),0,N("scePowerGetBatteryLifeTime")},
		{FID(0x28E12023),0,N("scePowerGetBatteryTemp")},
		{FID(0x862AE1A6),0,N("scePowerGetBatteryElec")},
		{FID(0x483CE86B),0,N("scePowerGetBatteryVolt")},
		{FID(0x23436A4A),0,N("scePower_23436A4A")},
		{FID(0x0CD21B1F),0,N("scePower_0CD21B1F")},
		{FID(0x165CE085),0,N("scePower_165CE085")},
		{FID(0xD6D016EF),0,N("scePowerLock")},
		{FID(0xCA3D34C1),0,N("scePowerUnlock")},
		{FID(0xDB62C9CF),0,N("scePowerCancelRequest")},
		{FID(0x7FA406DD),0,N("scePowerIsRequest")},
		{FID(0x2B7C7CF4),0,N("scePowerRequestStandby")},
		{FID(0xAC32C9CC),0,N("scePowerRequestSuspend")},
		{FID(0x2875994B),0,N("scePower_2875994B")},
		//{FID(0x3951AF53),0,N("scePowerEncodeUBattery")},
		{FID(0x0074EF9B),0,N("scePowerGetResumeCount")},
		{FID(0x04B7766E),0,N("scePowerRegisterCallback")},
		{FID(0xDFA8BAF8),0,N("scePowerUnregisterCallback")},
		{FID(0xDB9D28DD),0,N("scePower_DB9D28DD")},
		{FID(0x843FBF43),0,N("scePowerSetCpuClockFrequency")},
		{FID(0xB8D7B3FB),0,N("scePowerSetBusClockFrequency")},
		{FID(0xFEE03A2F),0,N("scePowerGetCpuClockFrequency")},
		{FID(0x478FE6F5),0,N("scePowerGetBusClockFrequency")},
		{FID(0xFDB5BFE9),0,N("scePowerGetCpuClockFrequencyInt")},
		{FID(0xBD681969),0,N("scePowerGetBusClockFrequencyInt")},
		{FID(0xB1A52C83),0,N("scePowerGetCpuClockFrequencyFloat")},
		{FID(0x9BADB3EB),0,N("scePowerGetBusClockFrequencyFloat")},
		{FID(0x737486F2),0,N("scePowerSetClockFrequency")},
		{FID(0x34f9c463),0,N("scePower_34f9c463")},
		{FID(0xea382a27),0,N("scePower_ea382a27")},
	};
	
	
	const HLEFunction sceAudio[] = 
	{
		{FID(0x01562ba3), 0, N("sceAudio_01562ba3")},
		{FID(0x2d53f36e), 0, N("sceAudio_2d53f36e")},
		{FID(0x63f2889c), 0, N("sceAudio_63f2889c")},
		{FID(0x647cef33), 0, N("sceAudio_647cef33")},	
		{FID(0x210567F7), 0, N("sceAudioEnd")},
		{FID(0x38553111), 0, N("sceAudio_driver_38553111")},
		{FID(0x5C37C0AE), 0, N("sceAudio_driver_5C37C0AE")},
		{FID(0x80F1F7E0), 0, N("sceAudioInit")},
		{FID(0x927AC32B), 0, N("sceAudioSetVolumeOffset")},
		{FID(0xA2BEAA6C), 0, N("sceAudioSetFrequency")},
		{FID(0xA633048E), 0, N("sceAudio_driver_A633048E")},
		{FID(0xB011922F), 0, N("sceAudio_driver_B011922F")},
		{FID(0xB61595C0), 0, N("sceAudioLoopbackTest")},
		{FID(0xE0727056), 0, N("sceAudio_driver_E0727056")},
		{FID(0xE926D3FB), 0, N("sceAudio_driver_E926D3FB")},
		{FID(0x8c1009b2), 0, N("sceAudioOutput")}, 
		{FID(0x136CAF51), sceAudioOutputBlocking, N("sceAudioOutputBlocking")}, 
		{FID(0xE2D56B2D), 0, N("sceAudioOutputPanned")}, 
		{FID(0x13F592BC), sceAudioOutputPannedBlocking, N("sceAudioOutputPannedBlocking")}, //(long, long, long, void *)Output sound, blocking 
		{FID(0x5EC81C55), sceAudioChReserve, N("sceAudioChReserve")}, //(long, long samplecount, long)Initialize channel and allocate buffer  long, long samplecount, long);//init buffer? returns handle, minus if error
		{FID(0x6FC46853), sceAudioChRelease, N("sceAudioChRelease")}, //(long handle)Terminate channel and deallocate buffer //free buffer?
		{FID(0xE9D97901), sceAudioGetChannelRestLen, N("sceAudioGetChannelRestLen")}, 
		{FID(0xCB2E439E), 0, N("sceAudioSetChannelDataLen")}, //(long, long)
		{FID(0x95FD0C2D), 0, N("sceAudioChangeChannelConfig")}, 
		{FID(0xB7E1D8E7), 0, N("sceAudioChangeChannelVolume")}, 
		{FID(0x41efade7), 0, N("sceAudioOneshotOutput")},
		{FID(0x086e5895), 0, N("sceAudioInputBlocking")},	 
		{FID(0x6d4bec68), 0, N("sceAudioInput")},	 
		{FID(0xa708c6a6), 0, N("sceAudioGetInputLength")},
		{FID(0x87b2e651), 0, N("sceAudioWaitInputEnd")},
		{FID(0x7de61688), 0, N("sceAudioInputInit")},
		{FID(0xb011922f), 0, N("sceAudio_Unk 0xb011922f")},
	};


	const HLEFunction sceUtility[] = 
	{
		{FID(0x1579a159), 0, N("sceUtilityLoadNetModule")},
		{FID(0x34b78343), 0, N("sceUtilityGetSystemParamString")}, 
		{FID(0xf88155f6), 0, N("sceUtilityNetconfShutdownStart")}, 
		{FID(0x4db1e739), 0, N("sceUtilityNetconfInitStart")}, 
		{FID(0x91e70e35), 0, N("sceUtilityNetconfUpdate")},   
		{FID(0x6332aa39), 0, N("sceUtilityNetconfGetStatus")},        
		{FID(0x67af3428), 0, N("sceUtilityMsgDialogShutdownStart")},  
		{FID(0x2ad8e239), 0, N("sceUtilityMsgDialogInitStart")},      
		{FID(0x95fc253b), 0, N("sceUtilityMsgDialogUpdate")},         
		{FID(0x9a1c91d7), 0, N("sceUtilityMsgDialogGetStatus")},      
		{FID(0x9790b33c), sceUtilitySavedataShutdownStart, N("sceUtilitySavedataShutdownStart")},   
		{FID(0x50c4cd57), sceUtilitySavedataInitStart, N("sceUtilitySavedataInitStart")},       
		{FID(0xd4b95ffb), sceUtilitySavedataUpdate, N("sceUtilitySavedataUpdate")},          
		{FID(0x8874dbe0), sceUtilitySavedataGetStatus, N("sceUtilitySavedataGetStatus")},
		{FID(0x3dfaeba9), 0, N("sceUtilityOskShutdownStart")}, 
		{FID(0xf6269b82), 0, N("sceUtilityOskInitStart")}, 
		{FID(0x4b85c861), 0, N("sceUtilityOskUpdate")}, 
		{FID(0xf3f76017), 0, N("sceUtilityOskGetStatus")}, 
		{FID(0x41e30674), 0, N("sceUtilitySetSystemParamString")},
		{FID(0xA5DA2406), sceUtilityGetSystemParamInt, N("sceUtilityGetSystemParamInt")},
		{FID(0xc492f751), 0, N("sceUtility_c492f751")}, 
		{FID(0xefc6f80f), 0, N("sceUtility_efc6f80f")}, 
		{FID(0x7853182d), 0, N("sceUtility_7853182d")}, 
		{FID(0x946963f3), 0, N("sceUtility_946963f3")}, 
		{FID(0x2995d020), 0, N("sceUtility_2995d020")}, 
		{FID(0xb62a4061), 0, N("sceUtility_b62a4061")}, 
		{FID(0xed0fad38), 0, N("sceUtility_ed0fad38")}, 
		{FID(0x88bc7406), 0, N("sceUtility_88bc7406")}, 
		{FID(0x45c18506), 0, N("sceUtility_45c18506")}, 
		{FID(0x5eee6548), 0, N("sceUtility_5eee6548")}, 
		{FID(0x434d4b3a), 0, N("sceUtility_434d4b3a")}, 
		{FID(0x64d50c56), 0, N("sceUtility_64d50c56 (Gta)")}, 
		{FID(0x05afb9e4), 0, N("sceUtility_05afb9e4")}, 
		{FID(0x4928bd96), 0, N("sceUtility_4928bd96")}, 
		{FID(0xbda7d894), 0, N("sceUtility_bda7d894")}, 
		{FID(0xcdc3aa41), 0, N("sceUtility_cdc3aa41")}, 
		{FID(0xf5ce1134), 0, N("sceUtility_f5ce1134")}, 
		{FID(0xc629af26), 0, N("sceUtility_c629af26")}, 
	};

	const HLEFunction sceNet[] =
	{
		{FID(0x39AF39A6), sceNetInit, N("sceNetInit")},
		{FID(0x281928A9), sceNetTerm, N("sceNetTerm")},
		{FID(0x89360950), 0, N("sceNet_89360950")}, 
		{FID(0x0bf0a3ae), 0, N("sceNet_0bf0a3ae")}, 
		{FID(0xd27961c9), 0, N("sceNet_d27961c9")}, 
	};

	const HLEFunction sceNetAdhoc[] =
	{
		//SceNetAdhocctlNickname
		//sceNetAdhocMatchingInit
		//sceNetAdhocMatchingCreate
		//sceNetAdhocMatchingStart
		//sceNetAdhocMatchingCreate
		//sceNetAdhocctlAddHandler
		//sceNetAdhocctlDelHandler
		//sceNetAdhocctlDisconnect	
		//sceNetAdhocDialogConnect
		//sceNetAdhocPdpCreate
		//sceNetAdhocctlTerm
		{FID(0xE1D621D7), 0, N("sceNetAdhocInit")}, 
		{FID(0xA62C6F57), 0, N("sceNetAdhocTerm")}, 
		{FID(0x0AD043ED), 0, N("sceNetAdhocctlConnect")},
		{FID(0x6f92741b), 0, N("sceNetAdhoc_6f92741b")},
		{FID(0xabed3790), 0, N("sceNetAdhoc_abed3790")},
		{FID(0xdfe53e03), 0, N("sceNetAdhoc_dfe53e03")},
		{FID(0x7f27bb5e), 0, N("sceNetAdhoc_7f27bb5e")},
		{FID(0xc7c1fc57), 0, N("sceNetAdhoc_c7c1fc57")},
		{FID(0x157e6225), 0, N("sceNetAdhoc_157e6225")},
		{FID(0x4da4c788), 0, N("sceNetAdhoc_4da4c788")},
		{FID(0x877f6d66), 0, N("sceNetAdhoc_877f6d66")},
		{FID(0x8bea2b3e), 0, N("sceNetAdhoc_8bea2b3e")},
		{FID(0x9df81198), 0, N("sceNetAdhoc_9df81198")},
		{FID(0xe08bdac1), 0, N("sceNetAdhoc_e08bdac1")},
		{FID(0xfc6fc07b), 0, N("sceNetAdhoc_fc6fc07b")},
	};							

	const HLEFunction sceNetAdhocMatching[] = 
	{
		{FID(0x2a2a1e07), 0, N("sceNetAdhocMatching_2a2a1e07")},
		{FID(0x7945ecda), 0, N("sceNetAdhocMatching_7945ecda")},
		{FID(0xca5eda6f), 0, N("sceNetAdhocMatching_ca5eda6f")},
		{FID(0x93ef3843), 0, N("sceNetAdhocMatching_93ef3843")},
		{FID(0x32b156b3), 0, N("sceNetAdhocMatching_32b156b3")},
		{FID(0xf16eaf4f), 0, N("sceNetAdhocMatching_f16eaf4f")},
		{FID(0x5e3d4b79), 0, N("sceNetAdhocMatching_5e3d4b79")},
		{FID(0xea3c6108), 0, N("sceNetAdhocMatching_ea3c6108")},
	};

	const HLEFunction sceNetAdhocctl[] =
	{
		{FID(0x20B317A0), 0, N("sceNetAdhocctlAddHandler")},
		{FID(0x6402490B), 0, N("sceNetAdhocctlDelHandler")},
		{FID(0x34401D65), 0, N("sceNetAdhocctlDisconnect")},
		{FID(0xE26F226E), 0, N("sceNetAdhocctlInit")},
		{FID(0x9D689E13), 0, N("sceNetAdhocctlTerm")},
		{FID(0x0ad043ed), 0, N("sceNetAdhocctl_0ad043ed")},
		{FID(0x08fff7a0), 0, N("sceNetAdhocctl_08fff7a0")},
		{FID(0x75ecd386), 0, N("sceNetAdhocctl_75ecd386")},
		{FID(0x8916c003), 0, N("sceNetAdhocctl_8916c003")},
		{FID(0xded9d28e), 0, N("sceNetAdhocctl_ded9d28e")},
		{FID(0x81aee1be), 0, N("sceNetAdhocctl_81aee1be")},
	};

	const HLEFunction sceNetResolver[] =
	{
		{FID(0x224c5f44), 0, N("sceNetResolver_224c5f44")},
		{FID(0x244172af), 0, N("sceNetResolver_244172af")},
		{FID(0x94523e09), 0, N("sceNetResolver_94523e09")},
		{FID(0xf3370e61), 0, N("sceNetResolver_f3370e61")},
	};				   

	const HLEFunction KDebugForKernel[] = 
	{
		{FID(0xE7A3874D), 0, N("sceKernelRegisterAssertHandler")},
		{FID(0x2FF4E9F9), 0, N("sceKernelAssert")},
		{FID(0x9B868276), 0, N("sceKernelGetDebugPutchar")},
		{FID(0xE146606D), 0, N("sceKernelRegisterDebugPutchar")},
		{FID(0x7CEB2C09), sceKernelRegisterKprintfHandler, N("sceKernelRegisterKprintfHandler")},
		{FID(0x84F370BC), 0, N("Kprintf")},
		{FID(0x5CE9838B), 0, N("sceKernelDebugWrite")},
		{FID(0x66253C4E), 0, N("sceKernelRegisterDebugWrite")},
		{FID(0xDBB5597F), 0, N("sceKernelDebugRead")},
		{FID(0xE6554FDA), 0, N("sceKernelRegisterDebugRead")},
		{FID(0xB9C643C9), 0, N("sceKernelDebugEcho")},
		{FID(0x7D1C74F0), 0, N("sceKernelDebugEchoSet")},
		{FID(0x24C32559), 0, N("KDebugForKernel_24C32559")},
		{FID(0xD636B827), 0, N("sceKernelRemoveByDebugSection")},
		{FID(0x5282DD5E), 0, N("KDebugForKernel_5282DD5E")},
		{FID(0x9F8703E4), 0, N("KDebugForKernel_9F8703E4")},
		{FID(0x333DCEC7), 0, N("KDebugForKernel_333DCEC7")},
		{FID(0xE892D9A1), 0, N("KDebugForKernel_E892D9A1")},
		{FID(0xA126F497), 0, N("KDebugForKernel_A126F497")},
		{FID(0xB7251823), 0, N("sceKernelAcceptMbogoSig")},
	};

	const HLEFunction InterruptManager[] = 
	{
		{FID(0xCA04A2B9), sceKernelRegisterSubIntrHandler, N("sceKernelRegisterSubIntrHandler")},
		{FID(0xD61E6961), 0, N("sceKernelReleaseSubIntrHandler")},
		{FID(0xFB8E22EC), sceKernelEnableSubIntr, N("sceKernelEnableSubIntr")},
		{FID(0x8A389411), sceKernelDisableSubIntr, N("sceKernelDisableSubIntr")},
		{FID(0x5CB5A78B), 0, N("sceKernelSuspendSubIntr")},
		{FID(0x7860E0DC), 0, N("sceKernelResumeSubIntr")},
		{FID(0xFC4374B8), 0, N("sceKernelIsSubInterruptOccurred")},
		{FID(0xD2E8363F), 0, N("QueryIntrHandlerInfo")},
		{FID(0xEEE43F47), 0, N("sceKernelRegisterUserSpaceIntrStack")},
	};

#define SZ(a) sizeof(a)/sizeof(HLEFunction)

	const HLEFunction pspeDebug[] = 
	{
		{FID(0xDEADBEAF), 0, N("pspeDebugWrite")},
	};

	const HLEFunction ExceptionManagerForKernel[] = 
	{
		{FID(0x3FB264FC), 0, N("sceKernelRegisterExceptionHandler")},
		{FID(0x5A837AD4), 0, N("sceKernelRegisterPriorityExceptionHandler")},
		{FID(0x565C0B0E), sceKernelRegisterDefaultExceptionHandler, N("sceKernelRegisterDefaultExceptionHandler")},
		{FID(0x1AA6CFFA), 0, N("sceKernelReleaseExceptionHandler")},
		{FID(0xDF83875E), 0, N("sceKernelGetActiveDefaultExceptionHandler")},
		{FID(0x291FF031), 0, N("sceKernelReleaseDefaultExceptionHandler")},
		{FID(0x15ADC862), 0, N("sceKernelRegisterNmiHandler")},
		{FID(0xB15357C9), 0, N("sceKernelReleaseNmiHandler")},
	};

	const HLEFunction sceUsb[] = 
	{
		{FID(0xae5de6af), 0, N("sceUsbStart")},
		{FID(0xc2464fa0), 0, N("sceUsbStop")},
		{FID(0xc21645a4), 0, N("sceUsbGetState")},
		{FID(0x4e537366), 0, N("sceUsbGetDrvList")},
		{FID(0x112cc951), 0, N("sceUsbGetDrvState")},
		{FID(0x586db82c), 0, N("sceUsbActivate")},
		{FID(0xc572a9c8), 0, N("sceUsbDeactivate")},
		{FID(0x5be0e002), 0, N("sceUsbWaitState")},
		{FID(0x1c360735), 0, N("sceUsbWaitCancel")},
	};
	

	const HLEFunction sceLibFont[] = 
	{
		{FID(0x67f17ed7), 0, N("sceFontNewLib")},	
		{FID(0x574b6fbc), 0, N("sceFont?????????")},
		{FID(0x48293280), 0, N("sceFontSetResolution")},	
		{FID(0x27f6e642), 0, N("sceFont?????????")},
		{FID(0xbc75d85b), 0, N("sceFontGetFontList")},	
		{FID(0x099ef33c), 0, N("sceFontFindOptimumFont")},	
		{FID(0x681e61a7), 0, N("sceFontFindFont")},	
		{FID(0x2f67356a), 0, N("sceFontCalcMemorySize")},	
		{FID(0x5333322d), 0, N("sceFont?????????")},
		{FID(0xa834319d), 0, N("sceFontOpen")},	
		{FID(0x57fcb733), 0, N("sceFontOpenUserFile")},	
		{FID(0xbb8e7fe6), 0, N("sceFontOpenUserMemory")},	
		{FID(0x3aea8cb6), 0, N("sceFontClose")},	
		{FID(0x0da7535e), 0, N("sceFontGetFontInfo")},	
		{FID(0xdcc80c2f), 0, N("sceFontGetCharInfo")},	
		{FID(0x5c3e4a9e), 0, N("sceFontGetCharImageRect")},	
		{FID(0x980f4895), 0, N("sceFontGetCharGlyphImage")},	
		{FID(0xca1e6945), 0, N("sceFont?????????")},
		{FID(0x74b21701), 0, N("sceFontPixelToPointH")},	
		{FID(0xf8f0752e), 0, N("sceFontPixelToPointV")},	
		{FID(0x472694cd), 0, N("sceFontPointToPixelH")},	
		{FID(0x3c4b7e82), 0, N("sceFontPointToPixelV")},	
		{FID(0xee232411), 0, N("sceFont?????????")},
		{FID(0xaa3de7b5), 0, N("sceFont?????????")}, 	 
		{FID(0x48b06520), 0, N("sceFont?????????")},
		{FID(0x568be516), 0, N("sceFont?????????")},
		{FID(0x5dcf6858), 0, N("sceFont?????????")},

	};
	const HLEFunction sceWlanDrv[] =
	{
		{FID(0xd7763699), 0, N("sceWlanDrv_0xd7763699")},
		{FID(0x0c622081), 0, N("sceWlanDrv_0x0c622081")},
	};
	const HLEFunction sceNetApctl[] = 
	{
		{FID(0x24fe91a1), 0, N("sceNetApctl_24fe91a1")},
		{FID(0x5deac81b), 0, N("sceNetApctl_5deac81b")},
		{FID(0x8abadd51), 0, N("sceNetApctl_8abadd51")},
		{FID(0xe2f91f9b), 0, N("sceNetApctl_e2f91f9b")},
		{FID(0x5963991b), 0, N("sceNetApctl_5963991b")},
		{FID(0xb3edd0ec), 0, N("sceNetApctl_b3edd0ec")},
	};
	const HLEFunction sceUsbstor[] =
	{
		{FID(0x60066CFE), 0, N("sceUsbstorGetStatus")},
	};
	const HLEFunction sceUsbstorBoot[] =
	{
		{FID(0xE58818A8), 0, N("sceUsbstorBootSetCapacity")},
		{FID(0x594BBF95), 0, N("sceUsbstorBootSetLoadAddr")},
		{FID(0x6D865ECD), 0, N("sceUsbstorBootGetDataSize")},
		{FID(0xA1119F0D), 0, N("sceUsbstorBootSetStatus")},
		{FID(0x1F080078), 0, N("sceUsbstorBootRegisterNotify")},
		{FID(0xA55C9E16), 0, N("sceUsbstorBootUnregisterNotify")},
	};
	const HLEFunction sceDmac[] = 
	{
		{FID(0x617f3fe6), 0, N("sceDmacMemcpy")},
	};

	//OSD stuff? home button?
	const HLEFunction sceImpose[] =
	{
		{FID(0x36aa6e91), 0, N("sceImpose_36aa6e91")},
		{FID(0x381bd9e7), 0, N("sceImposeHomeButton")},
		{FID(0x24fd7bcf), 0, N("sceImpose_24fd7bcf")},
		{FID(0x8c943191), 0, N("sceImpose_8c943191")},
	};

	const HLEFunction sceNetInet[] = 
	{
		{FID(0x17943399), 0, N("sceNetInet_17943399")},
		{FID(0x2fe71fe7), 0, N("sceNetInet_2fe71fe7")},
		{FID(0x410b34aa), 0, N("sceNetInet_410b34aa")},
		{FID(0x5be8d595), 0, N("sceNetInet_5be8d595")},
		{FID(0x7aa671bc), 0, N("sceNetInet_7aa671bc")},
		{FID(0x8b7b220f), 0, N("sceNetInet_8b7b220f")},
		{FID(0x8d7284ea), 0, N("sceNetInet_8d7284ea")},
		{FID(0xb75d5b0a), 0, N("sceNetInet_b75d5b0a")},
		{FID(0xcda85c99), 0, N("sceNetInet_cda85c99")},
		{FID(0xfbabe411), 0, N("sceNetInet_fbabe411")},
		{FID(0x05038fc7), 0, N("sceNetInet_05038fc7")},
		{FID(0x1a33f9ae), 0, N("sceNetInet_1a33f9ae")},
		{FID(0x4cfe4e56), 0, N("sceNetInet_4cfe4e56")},
		{FID(0xb3888ad4), 0, N("sceNetInet_b3888ad4")},
		{FID(0xc91142e4), 0, N("sceNetInet_c91142e4")},
		{FID(0xd0792666), 0, N("sceNetInet_d0792666")},
		{FID(0xd10a1a7a), 0, N("sceNetInet_d10a1a7a")},
		{FID(0xdb094e1b), 0, N("sceNetInet_db094e1b")},
	};


	const HLEFunction sceSasCore[] =
	{
		//sceSsGetVoice
		//__sceSasGetEnvelopeHeight
		//sceWaveSetVoice
		//sceSsSMFSetPlayPanpot
		//sceSsSMFResetChannelMute
		//sceSsVoiceGetStatus
		//sceSsVoiceNoteOnByTone
		//sceWaveAudioGetRestSample
		//sceSsSMFGetPlayStatus
		//__sceSasRevVON
		//sceWaveSetLoopMode
		//sceSsSMFSetPlaySendPanpot
		//sceNetAdhocctlGetParameter
		//sceSsSMFBind
		//sceSsSMFResume
		//sceWaveGetVolume
		//sceSsVoiceSetPanpot
		//sceSsSMFSetPlayVelocity
		//sceWaveGetStat
		//sceNetAdhocDialogTerm
		//sceNetAdhocDialogConnect
		//sceSsSMFStop
		//sceWaveInit
		//sceSasSetVoice
		//__sceSasRevType
		//sceWaveGetRestByte
		//sceSsVoiceSetSendVelocity
		//sceSsVoiceSetVelocity

		//sceSasSetEffectParam
		//sceSsVoiceGetEndFlag
		//sceSsNoteOff
		///sceSsSMFGetPlayVelocity
		//sceSasSetSL
		//sceWaveAudioWrite
		//sceSsUnbindSoundData
		//sceWaveSetVolume
		//sceWaveStart
		//sceSasSetADSR
		//sceWaveAudioWriteBlocking
		//sceUmdWaitDriveStatsceWaveAudioSetSamplesceNetAdhocctlDisconnectsceSasGetEnvelope/
		//__sceSasRevParam
		//__sceSasSetADSR
		//__sceSasSetEffectType
		//__sceSasRevEVOL

		// REV is most likely Reverb
		{FID(0xa3589d81), _sceSasCore, N("__sceSasCore")},
		{FID(0x68a46b95), sceSasGetEndFlag, N("__sceSasGetEndFlag")},
		{FID(0x440ca7d8), sceSasSetVolume, N("__sceSasSetVolume")},
		{FID(0xad84d37f), sceSasSetPitch, N("__sceSasSetPitch")},
		{FID(0x99944089), sceSasSetVoice, N("__sceSasSetVoice")},
		{FID(0xb7660a23), 0, N("__sceSasSetNoise")},
		{FID(0x019b25eb), sceSasSetADSR, N("__sceSasSetADSR")},
		{FID(0x9ec3676a), 0, N("__sceSasSetADSRmode")},
		{FID(0x5f9529f6), 0, N("__sceSasSetSL")},
		{FID(0x74ae582a), 0, N("__sceSasGetEnvelopeHeight")},
		{FID(0xcbcd4f79), 0, N("__sceSasSetSimpleADSR")},
		{FID(0x42778a9f), sceSasInit, N("__sceSasInit")},
		{FID(0xa0cf2fa4), 0, N("__sceSasSetKeyOff")},
		{FID(0x76f01aca), 0, N("__sceSasSetKeyOn")},
		{FID(0xf983b186), 0, N("sceSasCore_f983b186")},
		{FID(0xd5a229c9), 0, N("__sceSasRevEVOL")},
		{FID(0x33d4ab37), 0, N("__sceSasRevType")},
		{FID(0x267a6dd2), 0, N("__sceSasRevParam")},
		{FID(0x2c8e6ab3), 0, N("__sceSasGetPauseFlag")},
		{FID(0x50a14dfc), 0, N("sceSasCore_50a14dfc")},
		{FID(0x787d04d5), 0, N("__sceSasSetPause")},
		{FID(0xa232cbe6), 0, N("sceSasCore_a232cbe6")},
		{FID(0xd5ebbbcd), 0, N("sceSasCore_d5ebbbcd")},
	};


	const HLEModule modules[] = 
	{
		{"FakeSysCalls", SZ(FakeSysCalls), FakeSysCalls},
		{"IoFileMgrForUser",SZ(IoFileMgrForUser),IoFileMgrForUser},
		{"ModuleMgrForUser",SZ(ModuleMgrForUser),ModuleMgrForUser},
		{"StdioForUser",SZ(StdioForUser),StdioForUser},
		{"SysMemUserForUser",SZ(SysMemUserForUser),SysMemUserForUser},
		{"ThreadManForUser",SZ(ThreadManForUser),ThreadManForUser},
		{"UtilsForUser",SZ(UtilsForUser),UtilsForUser},
		{"Kernel_Library",SZ(Kernel_Library),Kernel_Library},
		{"LoadExecForUser",SZ(LoadExecForUser),LoadExecForUser},
		{"KDebugForKernel",SZ(KDebugForKernel),KDebugForKernel},
		{"sceATRAC3plus_Library",SZ(sceAtrac3plus),sceAtrac3plus},
		{"sceUmdUser", SZ(sceUmdUser), sceUmdUser},
		{"sceUtility",SZ(sceUtility), sceUtility},
		{"ExceptionManagerForKernel", SZ(ExceptionManagerForKernel), ExceptionManagerForKernel},
		{"sceParseUri"},
		{"scePower",SZ(scePower),scePower},
		{"sceRtc",SZ(sceRtc),sceRtc},
		{"sceSasCore", SZ(sceSasCore),sceSasCore},
		{"sceSAScore"},
		{"sceUsbstor",SZ(sceUsbstor),sceUsbstor},
		{"sceUsbstorBoot",SZ(sceUsbstorBoot),sceUsbstorBoot},
		{"InterruptManager",SZ(InterruptManager),InterruptManager},
		{"sceUsb", SZ(sceUsb), sceUsb},
		{"scePsmf", SZ(scePsmf), scePsmf},
		{"scePsmfPlayer", SZ(scePsmfPlayer), scePsmfPlayer},
		{"sceDmac", SZ(sceDmac), sceDmac},
		{"SceBase64_Library"},
		{"sceCert_Loader"},
		{"SceFont_Library"},
		{"sceAtrac3plus",SZ(sceAtrac3plus),sceAtrac3plus},
		{"sceAudio",SZ(sceAudio),sceAudio},
		{"sceCtrl",SZ(sceCtrl),sceCtrl},            
		{"sceDisplay",SZ(sceDisplay),sceDisplay},
		{"sceGe_user",SZ(sceGe_user),sceGe_user},
		{"sceHttp",SZ(sceHttp),sceHttp},
		{"sceLibFont",SZ(sceLibFont),sceLibFont},
		{"sceMpeg",SZ(sceMpeg),sceMpeg},
		{"sceNet",SZ(sceNet),sceNet},
		{"sceNetAdhoc",SZ(sceNetAdhoc),sceNetAdhoc},
		{"sceNetAdhocctl",SZ(sceNetAdhocctl),sceNetAdhocctl},
		{"sceNetAdhocMatching",SZ(sceNetAdhocMatching),sceNetAdhocMatching},
		{"sceNetApctl",SZ(sceNetApctl),sceNetApctl},
		{"sceNetInet", SZ(sceNetInet),sceNetInet},
		{"sceNetResolver", SZ(sceNetResolver),sceNetResolver},
		{"sceMpeg"},
		{"sceNetInet"},
		{"sceNetResolver"},
		{"sceNetApctl"},
		{"sceOpenPSID"},
		{"sceParseHttp"},
		{"sceSsl"},
		{"sceSIRCS_IrDA_Driver"},
		{"sceSuspendForUser", SZ(sceSuspendForUser), sceSuspendForUser},
		{"sceRtc"},
		{"sceImpose",SZ(sceImpose),sceImpose}, //r: [UNK:36aa6e91] : 08b2cd68		//305: [MIPS32 R4K 00000000 ]: Loader: [UNK:24fd7bcf] : 08b2cd70
		{"sceWlanDrv",SZ(sceWlanDrv),sceWlanDrv},
		{"Pspnet_Scan"},
		{"Pspnet_Show_MacAddr"},
		{"pspeDebug", SZ(pspeDebug), pspeDebug},
		{"StdioForKernel", SZ(StdioForKernel), StdioForKernel},
		{"LoadCoreForKernel", SZ(LoadCoreForKernel), LoadCoreForKernel},
		{"IoFileMgrForKernel", SZ(IoFileMgrForKernel), IoFileMgrForKernel},

	};


	const int numModules = sizeof(modules)/sizeof(HLEModule);
}

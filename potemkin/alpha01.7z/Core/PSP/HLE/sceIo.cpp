#include "stdafx.h"
#include "../PSPSystem.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "../../EmuThread.h"
#include "../../FileSystems/FileSystem.h"
#include "../../FileSystems/MetaFileSystem.h"
#include "../../FileSystems/ISOFileSystem.h"
#include "../../../Windows/WindowsDirFileSystem.h"


#include "sceIo.h"
#include "sceKernel.h"
#include "sceKernelMemory.h"


/*
*
flash0: - fat access - system file volume
flash1: - fat access - configuration file volume
flashfat#: this too

lflash: - block access - entire flash
fatms: memstick
isofs: fat access - umd
ms0: - fat access - memcard
umd: - block access - umd
irda?: - (?=0..9) block access - infra-red port (doesnt support seeking, maybe send/recieve data from port tho)
mscm0: - block access - memstick cm??
umd00: block access - umd
umd01: block access - umd 
*/

#define O_RDONLY    0x0001
#define O_WRONLY    0x0002
#define O_RDWR      0x0003
#define O_NBLOCK    0x0010
#define O_APPEND    0x0100
#define O_CREAT     0x0200
#define O_TRUNC     0x0400
#define O_NOWAIT    0x8000


typedef s32 SceMode;
typedef s64 SceOff;
typedef s64 SceIores;


#define SCE_STM_FDIR 0x1000
#define SCE_STM_FREG 0x2000
#define SCE_STM_FLNK 0x4000
enum
{
	TYPE_DIR=0x10, 
	TYPE_FILE=0x20 
};

/* Date and time. */
typedef struct ScePspDateTime {
	unsigned short	year;
	unsigned short 	month;
	unsigned short 	day;
	unsigned short 	hour;
	unsigned short 	minute;
	unsigned short 	second;
	unsigned int 	microsecond;
} ScePspDateTime;

/** Structure to hold the status information about a file */
struct SceIoStat {
	SceMode 		st_mode;
	unsigned int 	st_attr;
	/** Size of the file in bytes. */
	SceOff 			st_size;
	/** Creation time. */
	ScePspDateTime 	st_ctime;
	/** Access time. */
	ScePspDateTime 	st_atime;
	/** Modification time. */
	ScePspDateTime 	st_mtime;
	/** Device-specific data. */
	unsigned int 	st_private[6];
};


struct SceIoDirEnt
{
	SceIoStat d_stat;
	char d_name[256];
	u32 d_private;
};

struct dirent { 
	u32 unk0; 
	u32 type; 
	u32 size; 
	u32 unk[19]; 
	char name[0x108]; 
};


namespace PSPHLE
{
	// STATE BEGIN
	char curFile[256];
	char curDir[256];
	// STATE END


	class FileNode : public KernelObject
	{
	public:
		~FileNode()
		{
			pspFileSystem.CloseFile(handle);
		}
		const char *GetName() {return fullpath.c_str();}
		const char *GetTypeName() {return "OpenFile";}
		void GetQuickInfo(char *ptr, int size)
		{
			_snprintf_s(ptr, size, _TRUNCATE, "Seekpos: %08x", (u32)pspFileSystem.GetSeekPos(handle));
		}
		std::string fullpath;
		u32 handle;
		u32 asyncResult;
	};


	void __IoInit()
	{
		LOG(HLE, "Starting up I/O...");

		char path_buffer[_MAX_PATH], drive[_MAX_DRIVE] ,dir[_MAX_DIR], file[_MAX_FNAME], ext[_MAX_EXT];
		char mypath[_MAX_PATH];

		GetModuleFileName(NULL,path_buffer,sizeof(path_buffer));
		_splitpath_s(path_buffer, drive, dir, file, ext );

		// Mount a couple of filesystems
		sprintf(mypath, "%s%sMemStick\\", drive, dir);
		WindowsDirFileSystem *memstick;
		memstick = new WindowsDirFileSystem(&pspFileSystem, mypath);

		pspFileSystem.Mount("ms0:",  memstick);
		pspFileSystem.Mount("fatms0:",  memstick);
		pspFileSystem.Mount("fatms:",   memstick);
		pspFileSystem.Mount("flash0:",  new EmptyFileSystem());
		pspFileSystem.Mount("flash1:",  new EmptyFileSystem());
	}	

	void __IoShutdown()
	{

	}

	void HLEDECL sceIoAssign()
	{
		const char *aliasname = (const char*)GetMemPointer(PARAM(0));
		const char *physname = (const char*)GetMemPointer(PARAM(1));
		const char *devname = (const char*)GetMemPointer(PARAM(2));
		u32 flag = PARAM(3);
		LOG(HLE,"sceIoAssign(%s, %s, %s, %08x, ...)",aliasname,physname,devname,flag);
		RETURN(0);
	}

	void sceKernelStdin()
	{
		LOG(HLE,"sceKernelStdin");
		RETURN(3);
	}
	void sceKernelStdout()
	{
		LOG(HLE,"sceKernelStdout");
		RETURN(1); // is this a good value?
	}

	void sceKernelStderr()
	{
		LOG(HLE,"sceKernelStderr");
		RETURN(2); // is this a good value?
	}

	void __IoGetStat(SceIoStat *stat, FileInfo &info)
	{
		memset(stat,0xfe,sizeof(SceIoStat));
		stat->st_size = (s64)info.size;

		int type, attr;
		if (info.type & FILETYPE_DIRECTORY)
			type = SCE_STM_FDIR, attr=TYPE_DIR;
		else
			type = SCE_STM_FREG, attr=TYPE_FILE;

		stat->st_mode = 0777 | type;
		stat->st_attr = attr;
		stat->st_size = info.size;
		stat->st_private[0] = info.startSector;
	}


	void sceIoGetstat()
	{
		const char *filename = (const char*)GetMemPointer(PARAM(0));
		u32 addr = PARAM(1);
		LOG(HLE,"sceIoGetstat(%s, %08x)",filename,addr);
		
		SceIoStat *stat = (SceIoStat*)GetMemPointer(addr);
		FileInfo info = pspFileSystem.GetFileInfo(filename);
		__IoGetStat(stat, info);

		RETURN(0);
	}

	void sceIoRead()   //(int fd, void *data, int size); 
	{
		SceUID id = PARAM(0);
		if (id == 3)
		{
			LOG(HLE,"sceIoRead STDIN");
			RETURN(0); //stdin	
			return;
		}

		u32 error;
		FileNode *f = kernelObjects.Get<FileNode>(id, error);
		if (f)
		{
			if (PARAM(1))
			{
				u8 *data = (u8*)GetMemPointer(PARAM(1));
				int size = PARAM(2);
				LOG(HLE,"sceIoRead(%d, %08x , %i)",id,PARAM(1),size);
				f->asyncResult = RETURN(pspFileSystem.ReadFile(f->handle, data, size)); 
			}
			else
			{
				LOG(HLE,"sceIoRead Reading into zero pointer");
				RETURN(-1);
			}
		}
		else
		{
			LOG(HLE,"sceIoRead ERROR: no file open");
		}
	}

	void sceIoWrite()  //(int fd, void *data, int size); 
	{
		SceUID id = PARAM(0);
		int size = PARAM(2);
		if (PARAM(0) == 2)
		{
			//stderr!
			char *str = (char*)GetMemPointer(PARAM(1));
			LOG(HLE,"stderr: %s", str);
			RETURN(size);
			return;
		}
		if (PARAM(0) == 1)
		{
			//stdout!
			char *str = (char*)GetMemPointer(PARAM(1));
			char temp = str[size];
			str[size]=0;
			LOG(HLE,"stdout: %s", str);
			str[size]=temp;
			RETURN(size);
			return;
		}
		u32 error;
		FileNode *f = kernelObjects.Get<FileNode>(id, error);
		if (f)
		{
			u8 *data = (u8*)GetMemPointer(PARAM(1));
			//LOG(HLE,"sceIoWrite(%d, %08x , %08x)",f,PARAM(1),size);
			f->asyncResult = RETURN(pspFileSystem.WriteFile(f->handle,data,size));
		}
		else
		{
			LOG(HLE,"sceIoWrite ERROR: no file open");
		}
	}

	void sceIoLseek() //(int fd, int offset, int whence); 
	{
		SceUID id = PARAM(0);
		u32 error;
		FileNode *f = kernelObjects.Get<FileNode>(id, error);
		if (f)
		{
			s64 offset = ((s64)PARAM(2)) | ((s64)(PARAM(3))<<32);
			int whence = PARAM(4);
			LOG(HLE,"sceIoLseek(%d,%08x,%i)",id,(int)offset,whence);
			
			FileMove seek=FILEMOVE_BEGIN;
			switch (whence)
			{
			case 0: break;
			case 1: seek=FILEMOVE_CURRENT;break;
			case 2: seek=FILEMOVE_END;break;
			}

			f->asyncResult = RETURN(pspFileSystem.SeekFile(f->handle, (s32)offset, seek));
		}
		else
		{
			LOG(HLE,"sceIoLseek ERROR: no file open");
		}
	}

	void sceIoOpen()   //(const char* file, int mode); 
	{
		const char *filename = (const char*)GetMemPointer(PARAM(0));
		int mode = PARAM(1);

		//memory stick filename
		int access=FILEACCESS_NONE;
		if (mode & O_RDONLY) access |= FILEACCESS_READ;
		if (mode & O_WRONLY) access |= FILEACCESS_WRITE;
		if (mode & O_APPEND) access |= FILEACCESS_APPEND;
		if (mode & O_CREAT)  access |= FILEACCESS_CREATE;

		u32 h = pspFileSystem.OpenFile(filename,(FileAccess)access);
		if (h == 0) 
		{
			LOG(HLE,"-1=sceIoOpen(%s, %08x) - file not found", filename, mode);
			RETURN(-1);
			return;
		}

		FileNode *f = new FileNode;
		SceUID id = kernelObjects.Create(f);
		f->handle = h;
		f->fullpath = filename;
		f->asyncResult = id;
		LOG(HLE,"%i=sceIoOpen(%s, %08x)",id,filename,mode);
		RETURN(id);
	}

	void sceIoClose()  //(int fd); 
	{
		SceUID f = PARAM(0);
		LOG(HLE,"sceIoClose(%d)",f);
		RETURN(kernelObjects.Destroy<FileNode>(f));
	}


	void sceIoRemove() //(const char *file); 
	{
		LOG(HLE,"sceIoRemove");		
	}
	void sceIoMkdir()  //(const char *dir, int mode); 
	{
		LOG(HLE,"sceIoMkdir");		

	}
	void sceIoRmdir()  //(const char *dir); 
	{
		LOG(HLE,"sceIoRmdir");		

	}
	void sceIoDevctl() //(const char *name, int cmd, void *arg, size_t arglen, void *buf, size_t *buflen); 
	{
		const char *name = (const char *)GetMemPointer(PARAM(0));
		int cmd = PARAM(1);
		u32 argAddr = PARAM(2);
		int argLen = PARAM(3);
		u32 bufPtr = PARAM(4);
		int bufLen = PARAM(5);
		int retVal = 0;
		LOG(HLE,"%i=sceIoDevctl(\"%s\", %08x, %08x, %i, %08x, %i)", 
			retVal, name, cmd,argAddr,argLen,bufPtr,bufLen);

		//089c6d1c weird branch
		/*
		089c6bdc ]: HLE: sceKernelCreateCallback(name= MemoryStick Detection ,entry= 089c7484 ) (z_un_089c6bc4)
		089c6c18 ]: HLE: sceIoDevctl("mscmhc0:", 02015804, 09ffb9c0, 4, 00000000, 0) (z_un_089c6bc4)
		089c6c40 ]: HLE: sceKernelCreateCallback(name= MemoryStick Assignment ,entry= 089c7534 ) (z_un_089c6bc4)
		089c6c78 ]: HLE: sceIoDevctl("fatms0:", 02415821, 09ffb9c4, 4, 00000000, 0) (z_un_089c6bc4)
		089c6cac ]: HLE: sceIoDevctl("mscmhc0:", 02025806, 00000000, 0, 09ffb9c8, 4) (z_un_089c6bc4)
		*/
		RETURN(retVal);
	}

	void sceIoRename() //(const char *oldname, const char *newname); 
	{
		LOG(HLE,"sceIoRename");		
		RETURN(0);
	}
	void sceIoChdir()
	{
		const char *dir = (const char*)GetMemPointer(PARAM(0));
		pspFileSystem.ChDir(dir);
		LOG(HLE,"sceIoChdir(%s)",dir);
		RETURN(1);
	}


	typedef u32 (*DeferredAction)(SceUID id, int param);
	DeferredAction defAction = 0;
	u32 defParam;

	void HLEDECL sceIoChangeAsyncPriority()
	{
		LOG(HLE,"UNIMPL sceIoChangeAsyncPriority(%d)",PARAM(0));
		RETURN(0);
	}

	u32 __IoClose(SceUID id, int param)
	{
		LOG(HLE,"Deferred IoClose(%d)",id);
		return kernelObjects.Destroy<FileNode>(id);
	}

	void HLEDECL sceIoCloseAsync()
	{
		LOG(HLE,"sceIoCloseAsync(%d)",PARAM(0));
		//sceIoClose();
		defAction = &__IoClose;
	}
	void HLEDECL sceIoLseekAsync()
	{
		LOG(HLE,"sceIoLseekAsync(%d)",PARAM(0));
		sceIoLseek();
		RETURN(0);
	}
	void HLEDECL sceIoOpenAsync()
	{
		LOG(HLE,"sceIoOpenAsync()");
		sceIoOpen();
	}	
	void HLEDECL sceIoReadAsync()
	{
		LOG(HLE,"sceIoReadAsync(%d)",PARAM(0));
		sceIoRead();
		RETURN(0);
	}

	void HLEDECL sceIoGetAsyncStat()
	{
		SceUID id = PARAM(0);
		u32 error;
		FileNode *f = kernelObjects.Get<FileNode>(id, error);
		if (f)
		{
			u64 *resPtr = (u64*)GetMemPointer(PARAM(2));
			*resPtr = f->asyncResult;
			LOG(HLE,"%i = sceIoGetAsyncStat(%i, %i, %08x) (HACK)", (u32)*resPtr, id, PARAM(1), PARAM(2));
			RETURN(0); //completed
		}
		else
		{
			LOG(HLE,"ERROR - sceIoGetAsyncStat with invalid id %i", id);
		}
	}


	void HLEDECL sceIoWaitAsync()
	{
		SceUID id = PARAM(0);
		u32 error;
		FileNode *f = kernelObjects.Get<FileNode>(id, error);
		if (f)
		{
			u64 *resPtr = (u64*)GetMemPointer(PARAM(1));
			*resPtr = f->asyncResult;
			if (defAction)
			{
				*resPtr = defAction(id, defParam);
				defAction = 0;
			}
			LOG(HLE,"%i = sceIoWaitAsync(%i, %08x) (HACK)", (u32)*resPtr, id, PARAM(1));
			RETURN(0); //completed
		}
		else
		{
			LOG(HLE,"ERROR - sceIoWaitAsync waiting for invalid id %i", id);
		}
	}

	void HLEDECL sceIoWaitAsyncCB()
	{
		SceUID id = PARAM(0);
		u32 error;
		FileNode *f = kernelObjects.Get<FileNode>(id, error);
		if (f)
		{
			u64 *resPtr = (u64*)GetMemPointer(PARAM(1));
			*resPtr = f->asyncResult;
			if (defAction)
			{
				*resPtr = defAction(id, defParam);
				defAction = 0;
			}
			LOG(HLE,"%i = sceIoWaitAsyncCB(%i, %08x) (HACK)", (u32)*resPtr, id, PARAM(1));
			RETURN(0); //completed
		}
		else
		{
			LOG(HLE,"ERROR - sceIoWaitAsyncCB waiting for invalid id %i", id);
		}
	}

	void HLEDECL sceIoPollAsync()
	{
		SceUID id = PARAM(0);
		u32 error;
		FileNode *f = kernelObjects.Get<FileNode>(id, error);
		if (f)
		{
			u64 *resPtr = (u64*)GetMemPointer(PARAM(1));
			*resPtr = f->asyncResult;
			if (defAction)
			{
				*resPtr = defAction(id, defParam);
				defAction = 0;
			}
			LOG(HLE,"%i = sceIoPollAsync(%i, %08x) (HACK)", (u32)*resPtr, id, PARAM(1));
			RETURN(0); //completed
		}
		else
		{
			LOG(HLE,"ERROR - sceIoPollAsync waiting for invalid id %i", id);
		}
	}

	class DirListing : public KernelObject
	{
	public:
		const char *GetName() {return name.c_str();}
		const char *GetTypeName() {return "DirListing";}
		std::string name;
		std::vector<FileInfo> listing;
		int index;
	};

	void sceIoDopen() //(const char *path); 
	{
		const char *path = (const char*)GetMemPointer(PARAM(0));
		LOG(HLE,"sceIoDopen(\"%s\")",path);

		DirListing *dir = new DirListing;
		SceUID id = kernelObjects.Create(dir);
		dir->listing = pspFileSystem.GetDirListing(path);
		dir->index = 0;
		dir->name = std::string(path);

		RETURN(id);
	}

	void sceIoDread()
	{

		SceUID id = PARAM(0);
		u32 error;
		DirListing *dir = kernelObjects.Get<DirListing>(id, error);
		if (dir)
		{
			if (dir->index == dir->listing.size())
			{
				RETURN(0);
				return;
			}

			FileInfo &info = dir->listing[dir->index];

			SceIoDirEnt *entry = (SceIoDirEnt*)GetMemPointer(PARAM(1));

			__IoGetStat(&entry->d_stat, info);

			strncpy_s(entry->d_name, info.name.c_str(), _TRUNCATE);
			entry->d_private = 0xC0DEBABE;
			LOG(HLE,"sceIoDread( %d %08x ) = %s",PARAM(0),PARAM(1), entry->d_name);

			dir->index++;
			RETURN(dir->listing.size()-dir->index+1);
		}
		else
		{
			LOG(HLE,"sceIoDread - invalid listing %i, error %08x", id, error);
		}
	}

	void sceIoDclose()
	{
		u32 id = PARAM(0);
		LOG(HLE,"sceIoDclose(%d)",id);
		RETURN(kernelObjects.Destroy<DirListing>(id));
	}
}

#pragma once

namespace PSPHLE
{
	void HLEDECL sceKernelLibcGettimeofday();
	void HLEDECL sceKernelLibcClock();
	void HLEDECL sceKernelLibcTime();
	void HLEDECL sceKernelUSec2SysClock();
	void HLEDECL sceKernelGetSystemTimeLow();
	void HLEDECL sceKernelGetSystemTimeWide();

	void HLEDECL sceKernelCreateVTimer();
	void HLEDECL sceKernelStartVTimer();
	void HLEDECL sceKernelSetVTimerHandler();

	void HLEDECL _sceKernelReturnFromTimerHandler();

	void HLEDECL sceRtcGetCurrentClockLocalTime();
	void HLEDECL sceRtcGetTickResolution();
	void HLEDECL sceRtcGetTick();

}



#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceCtrl.h"

namespace PSPHLE
{
	/* Index for the two analog directions */
#define CTRL_ANALOG_X   0
#define CTRL_ANALOG_Y   1

	/* Button bit masks */
#define CTRL_SQUARE     0x8000
#define CTRL_TRIANGLE   0x1000
#define CTRL_CIRCLE     0x2000
#define CTRL_CROSS      0x4000
#define CTRL_UP         0x0010
#define CTRL_DOWN       0x0040
#define CTRL_LEFT       0x0080
#define CTRL_RIGHT      0x0020
#define CTRL_START      0x0008
#define CTRL_SELECT     0x0001
#define CTRL_LTRIGGER   0x0100
#define CTRL_RTRIGGER   0x0200

	/* Returned control data */
	typedef struct _ctrl_data
	{
		u32 frame;
		u32 buttons;
		u8  analog[2];
		u8  unused[6];
	} ctrl_data_t;


	//////////////////////////////////////////////////////////////////////////
	// STATE BEGIN
	bool ctrlInited = false;
	bool analogEnabled = false;
	// STATE END
	//////////////////////////////////////////////////////////////////////////

	void sceCtrlInit()
	{
		ctrlInited = true;
		LOG(HLE,"sceCtrlInit");
	}

	void sceCtrlSetSamplingMode()
	{
		LOG(HLE,"sceCtrlSetSamplingMode");
		if (ctrlInited)
		{
			analogEnabled=true;
		}
	}

	void sceCtrlReadBufferPositive()
	{
		//LOG(HLE,"sceCtrlRead");
		
		if (ctrlInited)
		{
			static int frame = 0;
			_ctrl_data &data = *(_ctrl_data*)GetMemPointer(PARAM(0));
			data.frame=frame;
			data.buttons=0;
			if (GetAsyncKeyState(VK_SPACE))
				data.buttons|=CTRL_START;
			if (GetAsyncKeyState('V'))
				data.buttons|=CTRL_SELECT;
			if (GetAsyncKeyState('A'))
				data.buttons|=CTRL_SQUARE;
			if (GetAsyncKeyState('S'))
				data.buttons|=CTRL_TRIANGLE;
			if (GetAsyncKeyState('X'))
				data.buttons|=CTRL_CIRCLE;
			if (GetAsyncKeyState('Z'))
				data.buttons|=CTRL_CROSS;
			if (GetAsyncKeyState('Q'))
				data.buttons|=CTRL_LTRIGGER;
			if (GetAsyncKeyState('W'))
				data.buttons|=CTRL_RTRIGGER;
			if (GetAsyncKeyState(VK_UP))
				data.buttons|=CTRL_UP;
			if (GetAsyncKeyState(VK_DOWN))
				data.buttons|=CTRL_DOWN;
			if (GetAsyncKeyState(VK_LEFT))
				data.buttons|=CTRL_LEFT;
			if (GetAsyncKeyState(VK_RIGHT))
				data.buttons|=CTRL_RIGHT;
			data.analog[0]=128;data.analog[1]=128;
			frame++;
		}
	}
}


#include "stdafx.h"
#include "../../MIPS/MIPS.h"
#include "../PSPFirmwareHLE.h"
#include "../PSPDisplayListInterpreter.h"
#include "sceGe.h"

namespace PSPHLE
{


	int state;

	void HLEDECL sceGeEdramGetAddr()
	{
		u32 retVal = 0x04000000;
		LOG(HLE,"%08x = sceGeEdramGetAddr",retVal);
		RETURN(retVal);
	}
	void HLEDECL sceGeEdramGetSize()
	{
		u32 retVal = 0x00200000;
		LOG(HLE,"%08x = sceGeEdramGetSize()",retVal);
		RETURN(retVal);
	}
	void HLEDECL sceGeListEnQueue()
	{
		u32 listAddress = PARAM(0);
		u32 stallAddress = PARAM(1);
		u32 callbackId = PARAM(2);
		u32 optParamAddr = PARAM(3);

		u32 listID = PSPDisplay_EnqueueList(listAddress,stallAddress);
		if (listID)
			state = SCE_GE_LIST_STALLING;
		else
			state = SCE_GE_LIST_COMPLETED;
		LOG(HLE,"%i=sceGeListEnQueue(addr=%08x, stall=%08x, cbid=%08x, param=%08x)",listID,
			listAddress,stallAddress,callbackId,optParamAddr);
		LOG(HLE,"List enqueued.");
		//return display list ID
		RETURN(listID);
	}
	void HLEDECL sceGeListEnQueueHead()
	{
		u32 listAddress = PARAM(0);
		u32 stallAddress = PARAM(1);
		u32 callbackId = PARAM(2);
		u32 optParamAddr = PARAM(3);

		u32 listID = PSPDisplay_EnqueueList(listAddress,stallAddress);
		if (listID)
			state = SCE_GE_LIST_STALLING;
		else
			state = SCE_GE_LIST_COMPLETED;
		LOG(HLE,"%i=sceGeListEnQueueHead(addr=%08x, stall=%08x, cbid=%08x, param=%08x)",
			listID,	listAddress,stallAddress,callbackId,optParamAddr);
		LOG(HLE,"List enqueued.");
		//return display list ID
		RETURN(listID);
	}

	void HLEDECL sceGeListUpdateStallAddr()
	{
		u32 displayListID = PARAM(0);
		u32 stallAddress = PARAM(1);
		LOG(HLE,"sceGeListUpdateStallAddr(dlid=%i,stalladdr=%08x)",
			displayListID,stallAddress);

		PSPDisplay_UpdateStall(displayListID, stallAddress);
		LOG(HLE,"Stall address updated.");
	}

	void HLEDECL sceGeListSync()
	{
		u32 displayListID = PARAM(0);
		u32 mode = PARAM(1); //0 : wait for completion    1:check and return
		LOG(HLE,"sceGeListSync(dlid=%08x, mode=%08x)",
			displayListID,mode);
	}
	void HLEDECL sceGeDrawSync()
	{
		//wait/check entire drawing state
		u32 mode = PARAM(0); //0 : wait for completion    1:check and return
		LOG(HLE,"sceGeDrawSync(mode=%d)",mode);
		if (mode == 1)
		{
			RETURN(0);
		}
		else
		{
			RETURN(0);
		}
	}
	void HLEDECL sceGeBreak()
	{
		u32 mode = PARAM(0); //0 : current dlist 1: all drawing
		LOG(HLE,"sceGeBreak(mode=%d)",mode);
		
	}
	void HLEDECL sceGeContinue()
	{
		LOG(HLE,"sceGeContinue");
		// no arguments
	}
	void HLEDECL sceGeSetCallback()
	{
		u32 structAddr = PARAM(0);
		LOG(HLE,"sceGeSetCallback(struct=%08x)",
			structAddr);
	}
	void HLEDECL sceGeUnsetCallback()
	{
		u32 cbID = PARAM(0);
		LOG(HLE,"sceGeUnsetCallback(cbid=%08x)",
			cbID);
	}
}
#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"
#include "../../MIPS/MIPSAnalyst.h"
#include "../../ELF/ElfReader.h"

#include "../../FileSystems/FileSystem.h"
#include "../../FileSystems/MetaFileSystem.h"
#include "../../Util/BlockAllocator.h"
#include "../../Host.h"
#include "../PSPLoaders.h"
#include "../PSPSystem.h"

#include "sceKernel.h"
#include "sceKernelModule.h"
#include "sceKernelThread.h"
#include "sceKernelMemory.h"

namespace PSPHLE
{
/*
PRX blacklist
IoFileMgrForUser        iofilemgr.prx           firmware        ??              assumed
ModuleMgrForUser        modulemgr.prx           firmware        ??              assumed
StdioForUser            stdio.prx               firmware        ??              assumed
SysMemUserForUser       sysmem.prx              firmware        ??              assumed
ThreadManForUser        threadman.prx           firmware        ??              assumed
UtilsForUser            utils.prx               firmware        ??              assumed
sceCtrl                 ctrl.prx                firmware        ??              assumed
sceDisplay              display.prx             firmware        ??              assumed
sceGe_user              ge.prx                  firmware        ??              assumed
Kernel_Library         
LoadExecForUser         loadexec.prx            firmware                        assumed
sceSuspendForUser       
sceSasCore              sc_sascore.prx          umd             no              confirmed
sceAudio                audio.prx               firmware                        confirmed
sceNetAdhoc             pspnet_adhoc.prx        umd             no              confirmed
sceNetAdhocctl          pspnet_adhocctl.prx     umd             no              confirmed
sceNet                  pspnet.prx              umd             no              confirmed
sceWlanDrv              wlan.prx                firmware        ??              assumed
sceAtrac3plus           libatrac3plus.prx       umd             no              confirmed
sceUmdUser              umdman.prx              firmware        ??              not sure
sceUtility              utility.prx             firmware        ??              assumed
scePower                power.prx               firmware        ??              assumed
sceOpenPSID             openpsid.prx            firmware        ??              assumed
sceNetInet              pspnet_inet.prx         umd             no              confirmed
sceNetResolver          pspnet_resolver.prx     umd             no              confirmed
sceNetApctl             pspnet_apctl.prx        umd             no              confirmed
sceMpeg                 mpeg.prx                umd             no              confirmed
sceHttp                 libhttp_rfc.prx         umd             no              confirmed
sceParseHttp            libparse_http.prx       umd             no              confirmed
sceParseUri             libparse_uri.prx        umd             no              confirmed
sceSsl                  libssl.prx              umd             no              confirmed
sceRtc                  rtc.prx                 firmware        ??              assumed 
*/
	struct Module : public KernelObject
	{
		const char *GetName() {return name;}
		const char *GetTypeName() {return "Module";}
		void GetQuickInfo(char *ptr, int size)
		{
			sprintf_s(ptr, size, "name=%s gp=%08x entry=%08x",
				name,
				gp_value,
				entry_addr);
		}

		SceSize 		size;
		char 			nsegment;
		char 			reserved[3];
		int 			segmentaddr[4];
		int 			segmentsize[4];
		unsigned int 	entry_addr;
		unsigned int 	gp_value;
		unsigned int 	text_addr;
		unsigned int 	text_size;
		unsigned int 	data_size;
		unsigned int 	bss_size;
		/* The following is only available in the v1.5 firmware and above,
		but as sceKernelQueryModuleInfo is broken in v1.0 is doesn't matter ;) */
		unsigned short  attribute;
		unsigned char   version[2];
		char            name[28];
	};

	//////////////////////////////////////////////////////////////////////////
	// MODULES
	//////////////////////////////////////////////////////////////////////////
	struct StartModuleInfo
	{
		u32 size;
		u32 mpidtext;
		u32 mpiddata;
		u32 threadpriority;
		u32 threadattributes;
	};

	struct SceKernelLMOption {
		SceSize 		size;
		SceUID 			mpidtext;
		SceUID 			mpiddata;
		unsigned int 	flags;
		char 			position;
		char 			access;
		char 			creserved[2];
	};

	struct SceKernelSMOption {
		SceSize 		size;
		SceUID 			mpidstack;
		SceSize 		stacksize;
		int 			priority;
		unsigned int 	attribute;
	};

	//////////////////////////////////////////////////////////////////////////
	// STATE BEGIN
	int numModules;
	// STATE END
	//////////////////////////////////////////////////////////////////////////

	Module *__KernelLoadELFFromPtr(const u8 *ptr, u32 loadAddress, SceUID &id)
	{
		Module *m = new Module;
		SceUID uid = kernelObjects.Create(m);

		u32 hej = *((u32*)ptr);
		if (*(u32*)ptr != 0x464c457f)
		{
			DebugBreak();
		}
		// Open ELF reader
		ElfReader reader((void*)ptr);

		if (!reader.LoadInto(loadAddress))
		{
			DebugBreak();
		}

		struct libent
		{
			u32 exportName; //default 0
			u16 bcdVersion;
			u16 moduleAttributes;
			u8  exportEntrySize;
			u8  numVariables;
			u16 numFunctions;
			unsigned long __entrytableAddr;
		};

		SectionID entSection = reader.GetSectionByName(".lib.ent");
		SectionID textSection = reader.GetSectionByName(".text");

		u32 sceResidentAddr = 0;
		u32 moduleInfoAddr = 0;
		u32 textStart = reader.GetSectionAddr(textSection);
		u32 textSize = reader.GetSectionSize(textSection);

		SectionID sceResidentSection = reader.GetSectionByName(".rodata.sceResident");
		SectionID sceModuleInfoSection = reader.GetSectionByName(".rodata.sceModuleInfo");

		bool hasSymbols = false;
		bool dontadd = false;

		if (!host->AttemptLoadSymbolMap())
		{
			hasSymbols = reader.LoadSymbols();
			if (!hasSymbols)
			{
				host->ResetSymbolMap();
				MIPSAnalyst::ScanForFunctions(textStart, textStart+textSize);
			}
		}
		else
		{
			dontadd=true;
		}


		libent *lib = (libent *)(GetMemPointer(reader.GetSectionAddr(entSection)));
		//have fun
		//lib->l1+=0;
		sceResidentAddr = reader.GetSectionAddr(sceResidentSection);
		moduleInfoAddr = reader.GetSectionAddr(sceModuleInfoSection);

		struct PspResidentData 
		{
			unsigned long l1; // unknown 0xd632acdb
			unsigned long l2; // unknown 0xf01d73a7
			unsigned long startAddress; // address of _start
			unsigned long moduleInfoAddr; // address of sceModuleInfo struct
		};

		LOG(LOADER,"Resident data addr: %08x",  sceResidentAddr);

		PspResidentData *resdata = (PspResidentData *)GetMemPointer(sceResidentAddr);

		struct PspModuleInfo
		{
			// 0, 0, 1, 1 ?
			u16 moduleAttrs; //0x0000 User Mode, 0x1000 Kernel Mode
			u16 moduleVersion;
			// 28 bytes of module name, packed with 0's.
			char name[28];
			u32 gp;           // ptr to MIPS GOT data  (global offset table)
			u32 libent;       // ptr to .lib.ent section 
			u32 libentend;    // ptr to end of .lib.ent section 
			u32 libstub;      // ptr to .lib.stub section 
			u32 libstubend;   // ptr to end of .lib.stub section 
		};

		//return reader.GetEntryPoint();;
		PspModuleInfo *modinfo = (PspModuleInfo *)GetMemPointer(moduleInfoAddr);
		m->gp_value = modinfo->gp;
		strncpy_s(m->name, modinfo->name, _TRUNCATE);

		LOG(LOADER,"Module %s: %08x %08x %08x", modinfo->name, modinfo->gp, modinfo->libent,modinfo->libstub);

		struct PspLibStubEntry
		{
			// pointer to module name (will be in .rodata.sceResident section)
			unsigned long moduleNameSymbol;
			// mod version??
			unsigned short version;
			unsigned short val1;
			unsigned char val2; // 0x5
			unsigned char val3;
			// number of function symbols
			unsigned short numFuncs;
			// each symbol has an associated nid; nidData is a pointer
			// (in .rodata.sceNid section) to an array of longs, one
			// for each function, which identifies the function whose
			// address is to be inserted.
			//
			// The hash is the first 4 bytes of a SHA-1 hash of the function
			// name.  (Represented as a little-endian long, so the order
			// of the bytes is reversed.)
			unsigned long nidData;
			// the address of the function stubs where the function address jumps
			// should be filled in
			unsigned long firstSymAddr;
		};
		//sceDisplay at 5968-


		int numModules = (modinfo->libstubend - modinfo->libstub)/sizeof(PspLibStubEntry);

		LOG(LOADER,"Num Modules: %i",numModules);
		LOG(LOADER,"===================================================");

		PspLibStubEntry *entry = (PspLibStubEntry *)GetMemPointer(modinfo->libstub);

		int numSyms=0;
		for (int m=0; m<numModules; m++)
		{
			char *modulename = (char*)GetMemPointer(entry[m].moduleNameSymbol);
			u32 *nidDataPtr = (u32*)GetMemPointer(entry[m].nidData);
			u32 *stubs = (u32*)GetMemPointer(entry[m].firstSymAddr);

			LOG(LOADER,"Importing Module %s, stubs at %08x",modulename,entry[m].firstSymAddr);

			for (int i=0; i<entry[m].numFuncs; i++)
			{
				u32 addrToWriteSyscall = entry[m].firstSymAddr+i*8;
				LOG(LOADER,"%s : %08x",PSPHLE::GetFuncName(modulename, nidDataPtr[i]), addrToWriteSyscall);
				//write a syscall here
				PSPHLE::WriteSyscall(modulename, nidDataPtr[i], addrToWriteSyscall);
				if (!dontadd)
				{
					char temp[256];
					_snprintf_s(temp,255,"zz_%s", PSPHLE::GetFuncName(modulename, nidDataPtr[i]));
					host->AddSymbol(temp, addrToWriteSyscall, 4, ST_FUNCTION);
				}
				numSyms++;
			}
			LOG(LOADER,"-------------------------------------------------------------");
		}

		m->entry_addr = reader.GetEntryPoint();
		
		return m;
	}



	Module *__KernelLoadModule(u8 *fileptr, SceUID &id, SceKernelLMOption *options)
	{
		Module *m = __KernelLoadELFFromPtr(fileptr, PSP_GetDefaultLoadAddress(), id);

		return m;
	}

	void __KernelStartModule(Module *m, int args, const char *argp, SceKernelSMOption *options)
	{
		__KernelSetupRootThread(m->GetUID(), args, argp, options->priority, options->stacksize, options->attribute);

		//TODO: if current thread, put it in wait state, waiting for the new thread
	}


	u32 __KernelGetModuleGP(SceUID module)
	{
		u32 error;
		Module *m = kernelObjects.Get<Module>(module,error);
		if (m)
		{
			return m->gp_value;
		}
		else
		{
			return 0;
		}
	}

	void __KernelLoadExec(const char *filename, SceKernelLoadExecParam *param)
	{
		// Wipe kernel here, loadexec should reset the entire system
		__KernelInit();

		FileInfo info = pspFileSystem.GetFileInfo(filename);
		s64 size = (s64)info.size;
		if (!size)
		{
			return;
		}
		u32 handle = pspFileSystem.OpenFile(filename, FILEACCESS_READ);

		u8 *temp = new u8[(int)size];

		pspFileSystem.ReadFile(handle, temp, (size_t)size);

		SceUID moduleID;
		Module *m = __KernelLoadModule(temp, moduleID, 0);
		mipsr4k.pc = m->entry_addr;

		delete [] temp;

		pspFileSystem.CloseFile(handle);

		SceKernelSMOption option;
		option.size = sizeof(SceKernelSMOption);
		option.attribute = 0;
		option.mpidstack = 2;
		option.priority = 32;
		option.stacksize = 0x4000;

		__KernelStartModule(m, strlen(filename), filename, &option);
	}

	//TODO: second param
	void sceKernelLoadExec()
	{
		const char *name = (const char *)GetMemPointer(PARAM(0));
		SceKernelLoadExecParam *param = 0;
		if (PARAM(1))
		{
			param = (SceKernelLoadExecParam*)GetMemPointer(PARAM(1));
		}
		__KernelLoadExec(name, param);
	}

	void HLEDECL sceKernelLoadModule()
	{
		const char *name = (char *)GetMemPointer(PARAM(0));
		u32 flags = PARAM(1);
		if (PARAM(2))
		{
			SceKernelLMOption *lmoption= (SceKernelLMOption *)GetMemPointer(PARAM(2));

			//TODO: Check if module name is in "blacklist" (HLE:d list)
			//If it is, don't load it.
			//Else, actually do load it and resolve pointers!

			LOG(HLE,"%i=sceKernelLoadModule(name=%s,flag=%08x,(...))",
				numModules+1,name,flags,
				lmoption->size,lmoption->mpidtext,lmoption->mpiddata,lmoption->position);
		}
		else
		{
			LOG(HLE,"%i=sceKernelLoadModule(name=%s,flag=%08x,(...))", numModules+1, name, flags);
		}
		RETURN(++numModules);
	}

	void HLEDECL sceKernelStartModule()
	{
		int id = PARAM(0);
		int argsize = PARAM(1);
		u32 argptr = PARAM(2);
		u32 ptrReturn = PARAM(3);
		SceKernelSMOption *smoption = (SceKernelSMOption*)GetMemPointer(PARAM(4));
		LOG(HLE,"sceKernelStartModule(%d,asize=%08x,aptr=%08x,retptr=%08x,...)",
			id,argsize,argptr,ptrReturn);
	}

	void HLEDECL sceKernelStopModule()
	{
		LOG(HLE,"sceKernelStopModule");

	}

	void HLEDECL sceKernelUnloadModule()
	{
		LOG(HLE,"sceKernelUnloadModule");

	}

	void HLEDECL sceKernelGetModuleIdByAddress()
	{
		LOG(HLE,"sceKernelGetModuleIdByAddress(%08x)", PARAM(0));

	}
	void HLEDECL sceKernelGetModuleId()
	{
		LOG(HLE,"sceKernelGetModuleId");

	}


	void sceKernelFindModuleByName()
	{
		LOG(HLE,"sceKernelFindModuleByName()");
		RETURN(1);
	}

}


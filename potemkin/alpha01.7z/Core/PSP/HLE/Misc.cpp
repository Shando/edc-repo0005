#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "Misc.h"
#include "sceKernel.h"


namespace PSPHLE
{
	/** Enumeration for UMD stats */
	enum UmdDriveStat
	{
		/** Wait for disc to be inserted */
		UMD_WAITFORDISC = 2,
		/** Wait for the UMD to be initialised so it can be accessed from the mapped drive */
		UMD_WAITFORINIT = 0x20
	};
	/** UMD Callback function */
	typedef int (*UmdCallback)(int unknown, int event);



}
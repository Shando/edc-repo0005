#pragma once


namespace PSPHLE
{
	void sceUmdActivate();
	void sceUmdGetDriveStat();
	void sceUmdWaitDriveStat();
	void sceUmdWaitDriveStatWithTimer();
	void sceUmdWaitDriveStatCB();
	void sceUmdCheckMedium();
	void sceUmdDeactivate();
	void sceUmdGetDiscInfo();
	void sceUmdRegisterUMDCallBack();
}
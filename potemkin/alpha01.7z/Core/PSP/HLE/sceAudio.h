#pragma once

namespace PSPHLE
{

	void __AudioInit();
	void __AudioUpdate();
	void __AudioShutdown();
	int __AudioMix(short *outstereo, int numSamples);


	void sceAudioOutputBlocking();
	void sceAudioOutputPannedBlocking();
	void sceAudioChReserve();
	void sceAudioChRelease();
	void sceAudioGetChannelRestLen();
}


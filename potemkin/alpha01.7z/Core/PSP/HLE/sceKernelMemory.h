#pragma once

#include "../../Util/BlockAllocator.h"


//todo: "real" memory block allocator, 
// have elf loader grab its memory block first to avoid overwriting,
// etc


namespace PSPHLE
{
	extern BlockAllocator userMemory;
	extern BlockAllocator kernelMemory;

	void __KernelMemoryInit();
	void __KernelMemoryShutdown();

	void sceKernelMaxFreeMemSize();
	void sceKernelTotalFreeMemSize();
	void sceKernelGetBlockHeadAddr();

	void sceKernelAllocPartitionMemory();
	void sceKernelFreePartitionMemory();

	void sceKernelMemory_Unknown1();
	void sceKernelMemory_Unknown2();
	void sceKernelMemory_Unknown3();

	void sceKernelCreateVpl();
	void sceKernelDeleteVpl();
	void sceKernelAllocateVpl();
	void sceKernelAllocateVplCB();
	void sceKernelTryAllocateVpl();
	void sceKernelFreeVpl();
	void sceKernelCancelVpl();
	void sceKernelReferVplStatus();

	void sceKernelCreateFpl();
	void sceKernelDeleteFpl();
	void sceKernelAllocateFpl();
	void sceKernelAllocateFplCB();
	void sceKernelTryAllocateFpl();
	void sceKernelFreeFpl();
	void sceKernelCancelFpl();
	void sceKernelReferFplStatus();

}


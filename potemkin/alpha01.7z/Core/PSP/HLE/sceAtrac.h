#pragma once
namespace PSPHLE
{
	void HLEDECL sceAtracAddStreamData();
	void HLEDECL sceAtracDecodeData();
	void HLEDECL sceAtracEndEntry();
	void HLEDECL sceAtracGetAtracID();
	void HLEDECL sceAtracGetBufferInfoForReseting();
	void HLEDECL sceAtracGetBitrate();
	void HLEDECL sceAtracGetChannel();
	void HLEDECL sceAtracGetLoopStatus();
	void HLEDECL sceAtracGetInternalErrorInfo();
	void HLEDECL sceAtracGetMaxSample();
	void HLEDECL sceAtracGetNextDecodePosition();
	void HLEDECL sceAtracGetNextSample();
	void HLEDECL sceAtracGetRemainFrame();
	void HLEDECL sceAtracGetSecondBufferInfo();
	void HLEDECL sceAtracGetSoundSample();
	void HLEDECL sceAtracGetStreamDataInfo();
	void HLEDECL sceAtracReleaseAtracID();
	void HLEDECL sceAtracResetPlayPosition();
	void HLEDECL sceAtracSetHalfwayBuffer();
	void HLEDECL sceAtracSetSecondBuffer();
	void HLEDECL sceAtracSetData(); //?
	void HLEDECL sceAtracSetDataAndGetID();
	void HLEDECL sceAtracSetHalfwayBufferAndGetID();
	void HLEDECL sceAtracStartEntry();
	void HLEDECL sceAtracSetLoopNum();
}
#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceSas.h"
#include "sceKernel.h"

namespace PSPHLE
{
	void sceSasInit()
	{
		LOG(HLE,"0=sceSasInit()");
		RETURN(0);
	}

	void sceSasGetEndFlag()
	{
		LOG(HLE,"FFFFFFFF=sceSasGetEndFlag()");
		RETURN(0xFFFFFFFF);
	}

	void _sceSasCore()
	{
		LOG(HLE,"0=sceSasCore()");
		RETURN(0);
	}

	void sceSasSetVoice()
	{
		u32 core = PARAM(0);
		int num = PARAM(1);
		u32 vagAddr = PARAM(2);
		int size = PARAM(3);
		int loop = PARAM(4);
		LOG(HLE,"0=sceSasSetVoice(core=%08x, voicenum=%i, vag=%08x, size=%i, loop=%i)", 
			core, num, vagAddr, size, loop);

		//Real VAG header is 0x30 bytes behind the vagAddr

		RETURN(0);
	}

	void sceSasSetVolume()
	{
		u32 core = PARAM(0);
		int num = PARAM(1);
		int l = PARAM(2);
		int el = PARAM(3);
		int r = PARAM(4);
		int er = PARAM(5);
		LOG(HLE,"0=sceSasSetVolume(core=%08x, voicenum=%i, l=%i, r=%i, el=%i, er=%i", core, num, l, r, el, er);
		RETURN(0);
	}

	void sceSasSetPitch()
	{
		u32 core = PARAM(0);
		int num = PARAM(1);
		int pitch = PARAM(2);

		LOG(HLE,"0=sceSasSetPitch(core=%08x, voicenum=%i, pitch=%i)", core, num, pitch);
		RETURN(0);
	}

	void sceSasSetADSR()
	{
		u32 core = PARAM(0);
		int num = PARAM(1);
		int flag = PARAM(2);
		int a = PARAM(3);
		int d = PARAM(4);
		int s = PARAM(5);
		int r = PARAM(6); //??
		LOG(HLE,"0=sceSasSetADSR(core=%08x, voicenum=%i, flag=%i, a=%08x, d=%08x, s=%08x, r=%08x)", 
			core, num, flag, a,d,s,r);
		RETURN(0);
	}
}

	/*
	//VAG-Depack, hacked by bITmASTER@bigfoot.com
	//V0.1
	double f[5][2] = { { 0.0, 0.0 },
	{   60.0 / 64.0,  0.0 },
	{  115.0 / 64.0, -52.0 / 64.0 },
	{   98.0 / 64.0, -55.0 / 64.0 },
	{  122.0 / 64.0, -60.0 / 64.0 } };

	double samples[28];
	int predict_nr, shift_factor, flags;
	int i;
	int d, s;
	
	double s_1 = 0.0;
	double s_2 = 0.0;

	while( 1 ) 
	{
		predict_nr = fgetc( vag );
		shift_factor = predict_nr & 0xf;
		predict_nr >>= 4;
		flags = fgetc( vag );                           // flags
		if ( flags == 7 )
			break;              
		for ( i = 0; i < 28; i += 2 ) 
		{
			d = fgetc( vag );
			s = ( d & 0xf ) << 12;
			if ( s & 0x8000 )
				s |= 0xffff0000;
			samples[i] = (double) ( s >> shift_factor  );
			s = ( d & 0xf0 ) << 8;
			if ( s & 0x8000 )
				s |= 0xffff0000;
			samples[i+1] = (double) ( s >> shift_factor  );
		}
		for ( i = 0; i < 28; i++ ) {
			samples[i] = samples[i] + s_1 * f[predict_nr][0] + s_2 * f[predict_nr][1];
			s_2 = s_1;
			s_1 = samples[i];
			d = (int) ( samples[i] + 0.5 );
			fputc( d & 0xff, pcm );
			fputc( d >> 8, pcm );
		}
	}

 */


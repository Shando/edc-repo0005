#pragma once

//f0r smaller modules that don't deserve their own file

namespace PSPHLE
{

}
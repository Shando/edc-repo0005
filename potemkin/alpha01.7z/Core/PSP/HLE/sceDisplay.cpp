#include "stdafx.h"
#include "../../MIPS/MIPS.h"
#include "../PSPFirmwareHLE.h"
#include "../PSPDisplay.h"
#include "sceAudio.h"
#include "../../Host.h"
#include "sceDisplay.h"
#include "sceKernel.h"
#include "sceKernelThread.h"

extern u32 *pspframebuf;
extern int pspframebufmode;
static u32 topaddr;


namespace PSPHLE
{
	// STATE BEGIN
	u32 vCount = 0;
	u32 isVblank=0;
	// STATE END

	void sceDisplayIsVblank()
	{
		isVblank^=1;
		LOG(HLE,"%i=sceDisplayIsVblank()",isVblank);
		RETURN(isVblank);
	}
	void sceDisplaySetMode()
	{
		int unknown = PARAM(0);
		int xres = PARAM(1);
		int yres = PARAM(2);
		LOG(HLE,"sceDisplaySetMode(%d,%d,%d)",unknown,xres,yres);
		host->BeginFrame();

		glClearColor(0,0,0,0);
		glClear(GL_DEPTH_BUFFER_BIT);

		glColor4f(1,1,1,1);

		glEnable(GL_TEXTURE_2D);

		RETURN(0);
	}
	void sceDisplaySetFramebuf()
	{
		host->EndFrame();
		topaddr = PARAM(0);
		int linesize = PARAM(1);
		int pixelsize = PARAM(2);
		int mode = PARAM(3);
		pspframebufmode=mode;
		LOG(HLE,"sceDisplaySetFramebuf(topaddr=%08x,linesize=%d,pixelsize=%d,unknown=%d)",topaddr,linesize,pixelsize,mode);
		if (topaddr == 0)
		{
			LOG(HLE,"- screen off");
		}
		else
		{
			pspframebuf = (u32*)GetMemPointer((0x44000000)|(topaddr));
		}
		//PSPDisplay_Draw();
		host->BeginFrame();

		if (GetAsyncKeyState(VK_LSHIFT))
		{
			glPolygonMode (GL_FRONT_AND_BACK, GL_LINE);
		}
		else
		{
			glPolygonMode (GL_FRONT_AND_BACK, GL_FILL);
		}
		glClearColor(0,0,0,0);
		glClear(GL_DEPTH_BUFFER_BIT|GL_COLOR_BUFFER_BIT);

		glColor4f(1,1,1,1);

		glEnable(GL_TEXTURE_2D);
		RETURN(0);
	}

	void sceDisplayGetFramebuf()
	{
		LOG(HLE,"sceDisplayGetFramebuf");	
		RETURN(topaddr);
	}

	void sceDisplayWaitVblankStart()
	{
		LOG(HLE,"sceDisplayWaitVblankStart");
		host->UpdateSound();
		__AudioUpdate();
		vCount++;
		///MessageBox(0,"WTF",0,0);
		__KernelReSchedule();  //(Breaks pinball (!))
	//	Sleep(30);
		//PSPDisplay_Draw();
		//Sleep(10);
		RETURN(0);
	}

	void sceDisplayWaitVblank()
	{
		LOG(HLE,"sceDisplayWaitVblankStart");	
		sceDisplayWaitVblankStart();
	}
	void sceDisplayWaitVblankStartCB()
	{
		LOG(HLE,"sceDisplayWaitVblankStartCB");	
		sceDisplayWaitVblankStart();
	}
	void sceDisplayGetVcount()
	{
		vCount++;
		LOG(HLE,"%i=sceDisplayGetVcount()", vCount);	
		RETURN(vCount);
	}
	void sceDisplayGetFramePerSec()
	{
		LOG(HLE,"60=sceDisplayGetFramePerSec()");	
		RETURN(60);
	}

}
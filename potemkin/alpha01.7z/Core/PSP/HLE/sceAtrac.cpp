#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceKernel.h"
#include "sceUtility.h"

#include "../../EmuThread.h"



namespace PSPHLE
{
	void HLEDECL sceAtracAddStreamData()
	{
		LOG(HLE, "UNIMPL sceAtracAddStreamData(%i, %i)", PARAM(0), PARAM(1));
		RETURN(0);
	}
	void HLEDECL sceAtracDecodeData()
	{
		LOG(HLE, "UNIMPL sceAtracDecodeData(%i, ....)", PARAM(0));

		RETURN(0);
	}
	void HLEDECL sceAtracEndEntry()
	{
		LOG(HLE, "UNIMPL sceAtracEndEntry");
		RETURN(0);
	}
	void HLEDECL sceAtracGetAtracID()
	{
		LOG(HLE, "UNIMPL sceAtracGetAtracID");
		RETURN(0);
	}
	void HLEDECL sceAtracGetBufferInfoForReseting()
	{
		LOG(HLE, "UNIMPL sceAtracGetBufferInfoForReseting");
		RETURN(0);
	}
	void HLEDECL sceAtracGetBitrate()
	{
		LOG(HLE, "UNIMPL sceAtracGetBitrate");
		RETURN(0);
	}
	void HLEDECL sceAtracGetChannel()
	{
		LOG(HLE, "UNIMPL sceAtracGetChannel");
		RETURN(0);
	}
	void HLEDECL sceAtracGetLoopStatus()
	{
		LOG(HLE, "UNIMPL sceAtracGetLoopStatus");
		RETURN(0);
	}
	void HLEDECL sceAtracGetInternalErrorInfo()
	{
		LOG(HLE, "UNIMPL sceAtracGetInternalErrorInfo");
		RETURN(0);
	}
	void HLEDECL sceAtracGetMaxSample()
	{
		LOG(HLE, "UNIMPL sceAtracGetMaxSample");
		RETURN(0);
	}
	void HLEDECL sceAtracGetNextDecodePosition()
	{
		LOG(HLE, "UNIMPL sceAtracGetNextDecodePosition(%i, %08x)", PARAM(0), PARAM(1));
		u32 *outPos = (u32*)GetMemPointer(PARAM(1));
		*outPos = 1;
		RETURN(0);
	}
	void HLEDECL sceAtracGetNextSample()
	{
		LOG(HLE, "UNIMPL sceAtracGetNextSample");
		RETURN(0);
	}
	void HLEDECL sceAtracGetRemainFrame()
	{
		LOG(HLE, "sceAtracGetRemainFrame(%i, %08x)",PARAM(0),PARAM(1));
		u32 *outPos = (u32*)GetMemPointer(PARAM(1));
		*outPos = 12;
		RETURN(0);
	}
	void HLEDECL sceAtracGetSecondBufferInfo()
	{
		LOG(HLE, "sceAtracGetSecondBufferInfo(%i, %08x, %08x)",PARAM(0),PARAM(1),PARAM(2));
		u32 *outPos = (u32*)GetMemPointer(PARAM(1));
		u32 *outBytes = (u32*)GetMemPointer(PARAM(2));
		*outPos = 0;
		*outBytes = 0x10000;
		RETURN(0);
	}
	void HLEDECL sceAtracGetSoundSample()
	{
		LOG(HLE, "UNIMPL sceAtracGetSoundSample(%i, %08x, %08x, %08x)",PARAM(0),PARAM(1),PARAM(2),PARAM(3));
		u32 *outEndSample = (u32*)GetMemPointer(PARAM(1));
		u32 *outLoopStartSample = (u32*)GetMemPointer(PARAM(2));
		u32 *outLoopEndSample = (u32*)GetMemPointer(PARAM(2));
		*outEndSample = 0x10000;
		*outLoopStartSample = -1;
		*outLoopEndSample = -1;
		RETURN(0);
	}
	void HLEDECL sceAtracGetStreamDataInfo()
	{
		LOG(HLE, "UNIMPL sceAtracGetStreamDataInfo");
		RETURN(0);
	}
	void HLEDECL sceAtracReleaseAtracID()
	{
		LOG(HLE, "UNIMPL sceAtracReleaseAtracID");
		RETURN(0);
	}
	void HLEDECL sceAtracResetPlayPosition()
	{
		LOG(HLE, "UNIMPL sceAtracResetPlayPosition");
		RETURN(0);
	}
	void HLEDECL sceAtracSetHalfwayBuffer()
	{
		LOG(HLE, "UNIMPL sceAtracSetHalfwayBuffer");
		RETURN(0);
	}
	void HLEDECL sceAtracSetSecondBuffer()
	{
		LOG(HLE, "UNIMPL sceAtracSetSecondBuffer(%i, %08x, %i)", PARAM(0),PARAM(1),PARAM(2));
		RETURN(0);
	}
	void HLEDECL sceAtracSetData()
	{
		LOG(HLE, "UNIMPL sceAtracSetData");
		RETURN(0);
	} //?
	void HLEDECL sceAtracSetDataAndGetID()
	{
		LOG(HLE, "UNIMPL sceAtracSetDataAndGetID(%08x, %i)", PARAM(0), PARAM(1));
		RETURN(1);
	}
	void HLEDECL sceAtracSetHalfwayBufferAndGetID()
	{
		LOG(HLE, "UNIMPL sceAtracSetHalfwayBufferAndGetID");
		RETURN(0);
	}
	void HLEDECL sceAtracStartEntry()
	{
		LOG(HLE, "UNIMPL sceAtracStartEntry");
		RETURN(0);
	}
	void HLEDECL sceAtracSetLoopNum()
	{
		LOG(HLE, "UNIMPL sceAtracSetLoopNum(%i, %i)", PARAM(0), PARAM(1));
		RETURN(0);
	}
}

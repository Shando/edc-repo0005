#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPSInt.h"
#include "../../MIPS/MIPSCodeUtils.h"
#include "../../MIPS/MIPS.h"

#include "sceAudio.h"
#include "sceKernel.h"
#include "sceKernelMemory.h"
#include "sceKernelThread.h"
#include "sceKernelModule.h"

#include <queue>

namespace PSPHLE
{
	enum ThreadStatus
	{
		THREADSTATUS_RUN = 1,
		THREADSTATUS_READY = 2,
		THREADSTATUS_WAIT = 4,
		THREADSTATUS_SUSPEND = 8,
		THREADSTATUS_DORMANT = 16,
		THREADSTATUS_DEAD = 32
	};

	struct SceKernelSysClock {
		u32 low;
		u32 hi;
	};

	struct NativeThread
	{
		u32 nativeSize;
		char name[KERNELOBJECT_MAX_NAME_LENGTH+1];

		// Threading stuff
		u32	attr;
		u32 status;
		u32 entrypoint;
		u32 initialStack;
		int stackSize;
		u32 gpreg;

		int initialPriority;
		int currentPriority;
		WaitType waitType;
		SceUID waitID;
		int wakeupCount;
		int exitStatus;
		SceKernelSysClock runForClocks;
		int numInterruptPreempts;
		int numThreadPreempts;
		int numReleases;
	};

	struct Context
	{
		u32 r[32];
		float f[32];
		float v[128];
		u32 vfpuCtrl[15];

		u32 hi;
		u32 lo;
		u32 pc;
		u32 fpcond;
	};

	class Thread : public KernelObject
	{
	public:
		const char *GetName() {return nt.name;}
		const char *GetTypeName() {return "Thread";}
		void GetQuickInfo(char *ptr, int size)
		{
			sprintf_s(ptr, size, "pc= %08x sp= %08x %s %s %s %s %s (wt=%i wid=%i wv= %08x )",
				context.pc, context.r[MIPS_REG_SP],
				(nt.status & THREADSTATUS_RUN) ? "RUN" : "", 
				(nt.status & THREADSTATUS_READY) ? "READY" : "", 
				(nt.status & THREADSTATUS_WAIT) ? "WAIT" : "", 
				(nt.status & THREADSTATUS_SUSPEND) ? "SUSPEND" : "", 
				(nt.status & THREADSTATUS_DORMANT) ? "DORMANT" : "",
				nt.waitType,
				nt.waitID,
				waitValue);
		}
		void GrabStack(int stacksize)
		{
			stackBlock = userMemory.Alloc(stacksize, true, "stack");
			context.r[MIPS_REG_SP] = stackBlock+stacksize;
			nt.initialStack = context.r[MIPS_REG_SP];
			context.r[MIPS_REG_K0] = context.r[MIPS_REG_SP] - 512;
			context.r[MIPS_REG_SP] -= 512;
		}
		~Thread()
		{
			userMemory.Free(stackBlock);
		}

		NativeThread nt;

		u32 waitValue;
		bool sleeping;

		bool isProcessingCallbacks;

		// Okay, the other silly stuff comes here
		// context
		Context context;

		std::queue<SceUID> callbacks;

		u32 stackBlock;
	};




	//////////////////////////////////////////////////////////////////////////
	//STATE BEGIN
	//////////////////////////////////////////////////////////////////////////
	struct Wakeup
	{
		u32 time;
		SceUID threadId;
	};
	Thread *currentThread;
	u32 threadReturnHackAddr;
	std::vector<Thread *> threadqueue; //Change to SceUID
	std::list<Wakeup> wakeups;

	//u32 guard2[64];

	//////////////////////////////////////////////////////////////////////////
	//STATE END
	//////////////////////////////////////////////////////////////////////////

	void __KernelThreadingInit()
	{
		threadReturnHackAddr = kernelMemory.Alloc(8, false, "threadrethack");
		WriteMem32(threadReturnHackAddr, MIPS_MAKE_JR_RA());
		WriteSyscall("FakeSysCalls",0xc0debabe,threadReturnHackAddr+4);
	}

	void __KernelThreadingShutdown()
	{
		kernelMemory.Free(threadReturnHackAddr);
		threadReturnHackAddr=0;
		currentThread=0;
		threadqueue.clear();
	}

	u32 __KernelGetWaitValue(SceUID threadID, u32 &error)
	{
		Thread *t = kernelObjects.Get<Thread>(threadID, error);
		if (t)
		{
			return t->waitValue;
		}
		else
		{
			LOG(HLE, "__KernelGetWaitValue ERROR: thread %i", threadID);
			return 0;
		}
	}

	void __KernelWakeThread(SceUID threadID, u32 returnStatus)
	{
		u32 error;
		Thread *t = kernelObjects.Get<Thread>(threadID, error);
		if (t)
		{
			t->nt.status &= ~THREADSTATUS_WAIT;
			if (t->nt.status & (THREADSTATUS_SUSPEND | THREADSTATUS_WAIT))
			{
				//damn, still sleeping..
			}
			else
			{
				t->nt.status |= THREADSTATUS_READY;
			}
			//no need to clear waittype etc
		}
		else
		{
			LOG(HLE, "__KernelWakeThread ERROR: thread %i", threadID);
		}
	}


	void HLEDECL sceKernelReferThreadStatus()
	{
		SceUID threadID = PARAM(0);
		if (threadID == 0)
			threadID = __KernelGetCurThread();

		u32 error;
		Thread *t = kernelObjects.Get<Thread>(threadID, error);
		if (t)
		{
			LOG(HLE,"sceKernelReferThreadStatus(%i, %08x)", threadID, PARAM(1));
			void *outptr = (void*)GetMemPointer(PARAM(1));
			int sz = sizeof(NativeThread);
			t->nt.nativeSize = sz;
			memcpy(outptr, &(t->nt), sz);
			RETURN(0);
		}
		else
		{
			LOG(HLE,"Error %08x", error);
			RETURN(error);
		}
	}

	void __KernelSaveVFPUContext(int t)
	{
		//TODO	
	}
	void __KernelLoadVFPUContext(int t)
	{
		//TODO
	}

	// Saves the current CPU context
	void __KernelSaveContext(Thread *t)
	{
		for (int i=0; i<32; i++)
		{
			t->context.r[i] = currentMIPS->r[i];
			t->context.f[i] = currentMIPS->f[i];
		}
		for (int i=0; i<128; i++)
		{
			t->context.v[i] = currentMIPS->v[i];
		}
		for (int i=0; i<15; i++)
		{
			t->context.vfpuCtrl[i] = currentMIPS->vfpuCtrl[i];
		}
		t->context.hi = currentMIPS->hi;
		t->context.lo = currentMIPS->lo;
		t->context.pc = currentMIPS->pc;
		t->context.fpcond = currentMIPS->fpcond;
		//todo: deal with VFPU
		LOG(HLE,"Context saved: %i - %s",t->GetUID(), t->GetName());
	}

	// Loads a CPU context
	void __KernelLoadContext(Thread *t)
	{
		for (int i=0; i<32; i++)
		{
			currentMIPS->r[i] = t->context.r[i];
			currentMIPS->f[i] = t->context.f[i];
		}
		for (int i=0; i<128; i++)
		{
			currentMIPS->v[i] = t->context.v[i];
		}
		for (int i=0; i<15; i++)
		{
			currentMIPS->vfpuCtrl[i] = t->context.vfpuCtrl[i];
		}
		currentMIPS->hi = t->context.hi;
		currentMIPS->lo = t->context.lo;
		currentMIPS->pc = t->context.pc;
		currentMIPS->fpcond = t->context.fpcond;
		//todo: deal with VFPU
		currentThread = t;
		LOG(HLE,"Context loaded:%i - %s", t->GetUID(), t->GetName());
	}

	// DANGEROUS
	// Only run when you can safely accept a context switch
	// Triggers a waitable event, that is, it wakes up all threads that waits for it
	// If any changes were made, it will context switch
	bool __KernelTrigger(WaitType type, int id)
	{
		bool doneAnything = false;

		for (std::vector<Thread *>::iterator iter = threadqueue.begin(); iter != threadqueue.end(); iter++)
		{
			Thread *t = *iter;
			if (t->nt.status & THREADSTATUS_WAIT)
			{
				if (t->nt.waitType == type && t->nt.waitID == id)
				{
					// This threads is waiting for the triggered object
					t->nt.status &= ~THREADSTATUS_WAIT;
					if (t->nt.status == 0)
						t->nt.status = THREADSTATUS_READY;
					doneAnything = true;
				}
			}
		}

		if (doneAnything)
		{
			__KernelReSchedule();
			return true;
		}
		return false;
	}

	// makes the current thread wait for an event
	void __KernelWaitCurThread(WaitType type, SceUID id, u32 value, bool processCallbacks)
	{
		currentThread->nt.status = THREADSTATUS_WAIT;
		currentThread->nt.waitID = id;
		currentThread->nt.waitType = type;
		currentThread->nt.numReleases++;
		currentThread->waitValue = value;
		currentThread->isProcessingCallbacks = processCallbacks;
		mipsr4k.pc-=4;
		RETURN(0); //pretend all went OK
		__KernelReSchedule();
		//Remove thread from Ready queue?
	}

	void __KernelScheduleWakeup(SceUID threadID, int usFromNow)
	{
		Wakeup w;
		w.time = pspMicroSeconds+usFromNow;
		w.threadId = threadID;
		wakeups.push_back(w);
	}

	bool __KernelIdle()
	{
		//No threads want to run : increase timers, skip time in general
		//MessageBox(0,"Error: no thread to transition to",0,0);

		LOG(HLE,"No thread to transition to - sleeping 30ms");
		Sleep(20);
		__AudioUpdate();
		// If we return true, there MUST be a thread to run.
		// We don't want to return false anyway it's just for debugging
		return true;
	}


	void __KernelReSchedule()
	{
		// round-robin scheduler
		// seems to work
retry:
		int bestthread = -1;
		int prio=0xffffff;

		int next = 0;
		for (unsigned int i=0; i<threadqueue.size(); i++)
		{
			if (currentThread == threadqueue[i])
			{
				next = i;
				break;
			}
		}

		for (unsigned int i=0; i<threadqueue.size(); i++)
		{
			next = (next+1) % threadqueue.size();

			Thread *t = threadqueue[next];
			if (t->nt.currentPriority < prio)
			{
				if (t->nt.status & THREADSTATUS_READY)
				{
					bestthread = next;
					prio = t->nt.currentPriority;
				}
			}
		}

		if (bestthread != -1)
		{
			u32 pc = MIPS_GetNextPC();
			MIPS_ClearDelaySlot();
			__KernelSaveContext(currentThread);
			currentThread->context.pc = pc;
			__KernelLoadContext(threadqueue[bestthread]);
			currentMIPS->pc -= 4; //compensate for +=4
			return;
		}
		else
		{
			bool woken = false;

			//TODO: find closest one in time, move forward to that time, and go!
			//Let everything happen instantly except framerate
			for (std::list<Wakeup>::iterator iter = wakeups.begin(); iter!=wakeups.end(); iter++)
			{
				Wakeup &w = *iter;
				__KernelWakeThread(w.threadId, 0);
				LOG(HLE,"Scheduled wakeup happened. %i", w.threadId)
				woken=true;
				wakeups.erase(iter);
				break;
			}

			if (woken)
				goto retry;
			if (__KernelIdle())
				goto retry;
		}
	}




	//////////////////////////////////////////////////////////////////////////
	// Thread Management
	//////////////////////////////////////////////////////////////////////////
	void HLEDECL sceKernelCheckThreadStack()
	{
		LOG(HLE, "sceKernelCheckThreadStack() (returned 65536 (lie))");
		RETURN(65536); //Blatant lie
	}



	Thread *__KernelCreateThread(SceUID &id, SceUID moduleID, const char *name, u32 entryPoint, u32 priority, int stacksize, u32 attr)
	{
		Thread *t = new Thread;
		id = kernelObjects.Create(t);

		threadqueue.push_back(t);

		for (int i = 0; i<32; i++)
		{
			t->context.r[i] = 0;
			t->context.f[i] = 0.0f;
		}
		for (int i = 0; i<128; i++)
		{
			t->context.v[i] = 0.0f;
		}
		for (int i = 0; i<15; i++)
		{
			t->context.vfpuCtrl[i] = 0x00000000;
		}
		t->context.vfpuCtrl[VFPU_CTRL_SPREFIX] = 0xe4; //passthru
		t->context.vfpuCtrl[VFPU_CTRL_TPREFIX] = 0xe4; //passthru
		t->context.vfpuCtrl[VFPU_CTRL_CC] = 0x3f; 

		t->nt.attr = attr;
		t->nt.initialPriority = t->nt.currentPriority = priority;
		t->context.hi = 0;
		t->context.lo = 0;
		t->context.pc = entryPoint;
		memset(&t->nt, 0xCD, sizeof(t->nt));
		t->nt.stackSize = stacksize;
		t->nt.status = THREADSTATUS_DORMANT;
		t->nt.waitType = WAITTYPE_NONE;
		t->nt.waitID = 0;
		t->waitValue = 0;
		t->nt.exitStatus = 0;
		t->nt.numInterruptPreempts = 0;
		t->nt.numReleases = 0;
		t->nt.numThreadPreempts = 0;
		t->nt.runForClocks.low = 0;
		t->nt.runForClocks.hi = 0;
		t->nt.wakeupCount = 0;
		strncpy_s(t->nt.name, name, _TRUNCATE);
		t->context.r[MIPS_REG_GP] = __KernelGetModuleGP(moduleID); //m->gp_value;
		t->context.r[MIPS_REG_RA] = threadReturnHackAddr; //hack! TODO fix
		t->GrabStack(stacksize);
		return t;
	}

	SceUID curModule;
	void __KernelSetupRootThread(SceUID moduleID, int args, const char *argp, int prio, int stacksize, int attr) 
	{
		curModule = moduleID;
		//grab mips regs
		SceUID id;
		currentThread = __KernelCreateThread(id, moduleID, "rootthread", currentMIPS->pc, prio, stacksize, attr);
		currentThread->nt.status = THREADSTATUS_READY; // do not schedule

		strncpy_s(currentThread->nt.name, "rootthread", _TRUNCATE);

		__KernelLoadContext(currentThread);
		mipsr4k.r[4] = args;
		mipsr4k.r[MIPS_REG_SP] -= 256;
		u32 location = mipsr4k.r[MIPS_REG_SP];
		mipsr4k.r[5] = location;
		for (int i=0; i<args; i++)
			WriteMem8(location+i, argp[i]); 
	}


	void HLEDECL sceKernelCreateThread()
	{
		u32 nameAddr = PARAM(0);
		const char *threadName = (const char*)GetMemPointer(nameAddr);
		u32 entry = PARAM(1);
		u32 prio  = PARAM(2);
		int stacksize = PARAM(3);
		u32 attr  = PARAM(4);
		//ignore PARAM(5) 
		SceUID id;
		Thread *t = __KernelCreateThread(id, curModule, threadName, entry, prio, stacksize, attr);
		LOG(HLE,"%i = sceKernelCreateThread(name=\"%s\", entry= %08x, stacksize=%i )", id, threadName, entry, stacksize);
		RETURN(id);
	}


	void HLEDECL sceKernelStartThread()
	{
		int threadToStartID = PARAM(0);
		u32 argSize = PARAM(1);
		u32 argBlockPtr = PARAM(2);

		if (threadToStartID != currentThread->GetUID())
		{
			u32 error;
			Thread *startThread = kernelObjects.Get<Thread>(threadToStartID, error);

			if (startThread->nt.status != THREADSTATUS_DORMANT)
			{
				//Not dormant, WTF? TODO
			}

			LOG(HLE,"sceKernelStartThread(thread=%i, argSize=%i, argPtr= %08x )",
				threadToStartID,argSize,argBlockPtr);

			RETURN(0); //return success (this does not exit this function)
			
			//then do the context switch, taking ugly delay slot into account :(
			//Actually, todo, remove the JR RA from syscalls and just do that in the syscall handler
			u32 pc = MIPS_GetNextPC();
			MIPS_ClearDelaySlot();
			
			startThread->nt.status = THREADSTATUS_READY;
			u32 sp = startThread->context.r[MIPS_REG_SP];
			startThread->context.r[MIPS_REG_A0] = argSize;
			startThread->context.r[MIPS_REG_A1] = sp; 

			//now copy argument to stack
			for (int i=0; i<(int)argSize; i++)
				WriteMem8(sp + i, ReadMem8(argBlockPtr + i));
		}
		else
		{
			LOG(HLE,"thread %i trying to start itself", threadToStartID);
			RETURN(-1);
		}
	}

	//This one is fake but necessary :)
	void HLEDECL _sceKernelReturnFromThread()
	{
		LOG(HLE,"_sceKernelReturnFromThread");
		currentThread->nt.exitStatus = currentThread->context.r[2];
		currentThread->nt.status = THREADSTATUS_DORMANT;

		//Find threads that waited for me
		// Wake them
		if (!__KernelTrigger(WAITTYPE_THREADEND, __KernelGetCurThread()))
			__KernelReSchedule();
	}

	void HLEDECL sceKernelExitThread()
	{
		//Thread &t = threadqueue[currentThread];
		LOG(HLE,"sceKernelExitThread FAKED");
		//Find threads that waited for me
		// Wake them
		if (!__KernelTrigger(WAITTYPE_THREADEND, __KernelGetCurThread()))
			__KernelReSchedule();
	}

	void HLEDECL sceKernelExitDeleteThread()
	{
		LOG(HLE,"sceKernelExitDeleteThread FAKED");
		currentThread->nt.status = THREADSTATUS_DORMANT;
		currentThread->nt.exitStatus = currentThread->context.r[2];
		//Find threads that waited for me
		// Wake them
		//RETURN(kernelObjects.Destroy<Thread>(currentThread->GetUID()));
		//dont' really delete it, causes crashes now
		RETURN(0);
		if (!__KernelTrigger(WAITTYPE_THREADEND, __KernelGetCurThread()))
			__KernelReSchedule();
	}	


	void _sceKernelExitThread()
	{
		//Thread &t = threads[currentThread];
		LOG(HLE,"_sceKernelExitThread FAKED");
		currentThread->nt.status = THREADSTATUS_DORMANT;
		currentThread->nt.exitStatus = currentThread->context.r[2];
		//Find threads that waited for me
		// Wake them
		if (!__KernelTrigger(WAITTYPE_THREADEND, __KernelGetCurThread()))
			__KernelReSchedule();
	}


	void HLEDECL sceKernelRotateThreadReadyQueue()
	{
		LOG(HLE,"sceKernelRotateThreadReadyQueue : rescheduling");
		__KernelReSchedule();
	}
	void HLEDECL sceKernelDeleteThread()
	{
		int threadno = PARAM(0);
		if (threadno != currentThread->GetUID())
		{
			//TODO: remove from threadqueue!
			LOG(HLE,"sceKernelDeleteThread(%i)",threadno);
			RETURN(kernelObjects.Destroy<Thread>(threadno));
			if (!__KernelTrigger(WAITTYPE_THREADEND, threadno))
				__KernelReSchedule();
		}
		else
		{
			LOG(HLE, "Thread \"%s\" tries to delete itself! :(",currentThread->GetName());
			RETURN(-1);
		}
	}


	void HLEDECL sceKernelTerminateDeleteThread()
	{
		int threadno = PARAM(0);
		if (threadno != currentThread->GetUID())
		{
			//TODO: remove from threadqueue!
			LOG(HLE,"sceKernelTerminateDeleteThread(%i)",threadno);
			RETURN(0); //kernelObjects.Destroy<Thread>(threadno));
			if (!__KernelTrigger(WAITTYPE_THREADEND, threadno))
				__KernelReSchedule();
		}
		else
		{
			LOG(HLE, "Thread \"%s\" tries to delete itself! :(",currentThread->GetName());
			RETURN(-1);
		}
	}



	SceUID __KernelGetCurThread()
	{
		return currentThread->GetUID();
	}


	void HLEDECL sceKernelGetThreadId()
	{
		u32 retVal = currentThread->GetUID();
		LOG(HLE,"%i = sceKernelGetThreadId()", retVal);
		RETURN(retVal);
	}
	void HLEDECL sceKernelChangeCurrentThreadAttr()
	{
		int clearAttr = PARAM(0);
		int setAttr = PARAM(1);
		LOG(HLE,"0 = sceKernelChangeCurrentThreadAttr(clear = %08x, set = %08x", clearAttr, setAttr);
		currentThread->nt.attr = (currentThread->nt.attr & ~clearAttr) | setAttr;
		RETURN(0);
	}

	void HLEDECL sceKernelChangeThreadPriority()
	{
		int id = PARAM(0);
		if (id == 0) id = currentThread->GetUID(); //special

		u32 error;
		Thread *thread = kernelObjects.Get<Thread>(id, error);
		if (thread)
		{
			LOG(HLE,"sceKernelChangeThreadPriority(%i, %i)", id, PARAM(1));
			thread->nt.currentPriority = PARAM(1);
			RETURN(0);
		}
		else
		{
			LOG(HLE,"%08x=sceKernelChangeThreadPriority(%i, %i) failed", error);
			RETURN(error);
		}
	}

	void HLEDECL sceKernelDelayThreadCB()
	{
		u32 usec=PARAM(0);
		LOG(HLE,"sceKernelDelayThreadCB(%i usec)",usec);

		__KernelScheduleWakeup(__KernelGetCurThread(), usec);
		__KernelWaitCurThread(WAITTYPE_DELAY, 0, 0, true);
	}
	void HLEDECL sceKernelDelayThread()
	{
		u32 usec=PARAM(0);
		LOG(HLE,"sceKernelDelayThread(%i usec)",usec);
		__KernelScheduleWakeup(__KernelGetCurThread(), usec);
		__KernelWaitCurThread(WAITTYPE_SLEEP, 0, 0, false);
	}

	//////////////////////////////////////////////////////////////////////////
	// WAIT/SLEEP ETC
	//////////////////////////////////////////////////////////////////////////
	void HLEDECL sceKernelWakeupThread()
	{
		SceUID id = PARAM(0);
		u32 error;
		Thread *t = kernelObjects.Get<Thread>(id, error);
		if (t)
		{
			t->nt.wakeupCount++;
			LOG(HLE,"sceKernelWakeupThread(%i) - wakeupCount incremented to %i",id,t->nt.wakeupCount);
			if (t->nt.waitType == WAITTYPE_SLEEP && t->nt.wakeupCount>=0)
			{
				__KernelWakeThread(id, 0);
			}
		}
		RETURN(0);
	}

	void HLEDECL sceKernelSleepThread()
	{
		currentThread->nt.wakeupCount--;
		LOG(HLE,"sceKernelSleepThread() - wakeupCount decremented to %i", currentThread->nt.wakeupCount);
		if (currentThread->nt.wakeupCount < 0)
			__KernelWaitCurThread(WAITTYPE_SLEEP, 0, 0, false);
		else
		{
			RETURN(0);
		}
	}

	//the homebrew PollCallbacks
	void HLEDECL sceKernelSleepThreadCB()
	{
		LOG(HLE,"sceKernelSleepThreadCB()");
		//set it to waiting
		__KernelWaitCurThread(WAITTYPE_SLEEP, 0, 0, true);
	}
	void HLEDECL sceKernelWaitThreadEnd()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"sceKernelWaitThreadEnd(%i)",id);
		u32 error;
		Thread *t = kernelObjects.Get<Thread>(id, error);
		if (t)
		{
			if (t->nt.status != THREADSTATUS_DORMANT)
			{
				__KernelWaitCurThread(WAITTYPE_THREADEND, id, 0, false);
				return;
			}
			LOG(HLE,"sceKernelWaitThreadEnd - thread %i already ended. Doing nothing.", id);
		}
		else
		{
			LOG(HLE,"sceKernelWaitThreadEnd - bad thread %i", id);
		}
		RETURN(0);
	}
	void HLEDECL sceKernelSuspendThread()
	{
		LOG(HLE,"UNIMPL sceKernelSuspendThread");
		RETURN(0);
	}
	void HLEDECL sceKernelResumeThread()
	{
		LOG(HLE,"UNIMPL sceKernelResumeThread");
		RETURN(0);
	}

}


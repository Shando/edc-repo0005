#pragma once

namespace PSPHLE
{
	void sceKernelCreateCallback();
	void sceKernelCheckCallback();
	void sceKernelDeleteCallback();
	void sceKernelNotifyCallback();
	void _sceKernelReturnFromCallback();
}


#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"
#include "../../MIPS/MIPSCodeUtils.h"
#include "../../MIPS/MIPSInt.h"

#include "../../FileSystems/FileSystem.h"
#include "../../FileSystems/MetaFileSystem.h"
#include "../PSPLoaders.h"
#include "../../Tests.h"


#include "sceAudio.h"
#include "sceIo.h"
#include "sceKernel.h"
#include "sceKernelThread.h"
#include "sceKernelMemory.h"

extern MetaFileSystem pspFileSystem;

/*
17: [MIPS32 R4K 00000000 ]: Loader: Type: 1 Vaddr: 00000000 Filesz: 2856816 Memsz: 2856816 
18: [MIPS32 R4K 00000000 ]: Loader: Loadable Segment Copied to 0898dab0, size 002b9770
19: [MIPS32 R4K 00000000 ]: Loader: Type: 1 Vaddr: 002b9770 Filesz: 14964 Memsz: 733156 
20: [MIPS32 R4K 00000000 ]: Loader: Loadable Segment Copied to 08c47220, size 000b2fe4
*/


namespace PSPHLE
{
	//Wraps after 20 fake minutes - ONLY use by subtraction
	u32 pspMicroSeconds;

	bool kernelRunning = false;

	void __KernelInit()
	{
		if (kernelRunning)
			__KernelShutdown();

		__KernelMemoryInit();
		__KernelThreadingInit();
		__IoInit();
		__AudioInit();
		kernelRunning = true;
	}

	void __KernelShutdown()
	{
		if (!kernelRunning)
		{
			LOG(HLE, "Can't shutting down kernel - not running");
		}
		kernelObjects.List();
		LOG(HLE, "Shutting down kernel - %i kernel objects alive", kernelObjects.GetCount());
		kernelObjects.Clear();

		__AudioShutdown();
		__IoShutdown();
		__KernelThreadingShutdown();
		__KernelMemoryShutdown();
		kernelRunning = false;
	}



	void sceKernelExitGame()
	{
		LOG(HLE,"sceKernelExitGame");
		MessageBox(0,"Game exited",0,0);
		RETURN(0);
	}
	void sceKernelRegisterExitCallback()
	{
		LOG(HLE,"UNIMPL sceKernelRegisterExitCallback");
		RETURN(0);
	}


//////////////////////////////////////////////////////////////////////////
// INTERRUPT MANAGEMENT
//////////////////////////////////////////////////////////////////////////
	bool interruptsEnabled = true;
	void sceKernelCpuSuspendIntr()
	{
		//spammy
//		LOG(HLE,"sceKernelCpuSuspendIntr");
		interruptsEnabled = false;
		RETURN(0);
	}
	void sceKernelCpuResumeIntr()
	{
		//spammy
//		LOG(HLE,"sceKernelCpuResumeIntr");
		interruptsEnabled = true;
		RETURN(0);
	}
	void sceKernelIsCpuIntrEnable()
	{
		u32 retVal = (u32)interruptsEnabled; 
		LOG(HLE,"%i=sceKernelIsCpuIntrEnable()",retVal);
		RETURN(retVal);
	}

	void sceKernelCpuResumeIntrWithSync()
	{
		LOG(HLE,"sceKernelCpuResumeIntrWithSync");
		RETURN(0);
	}


	enum PspInterrupts
	{
		PSP_VBLANK_INT = 30
	};
	//int sceKernelRegisterSubIntrHandler(int intno, int no, void *handler, void *arg);
	void sceKernelRegisterSubIntrHandler()
	{
		LOG(HLE,"UNIMPL sceKernelRegisterSubIntrHandler(%i, %i, %08x, %08x)", PARAM(0), PARAM(1), PARAM(2), PARAM(3));
		RETURN(0);
	}
	void sceKernelEnableSubIntr()
	{
		LOG(HLE,"sceKernelEnableSubIntr(%i)",PARAM(0));
		RETURN(0);
	}
	void sceKernelDisableSubIntr()
	{
		LOG(HLE,"sceKernelDisableSubIntr(%i)",PARAM(0));
		RETURN(0);
	}


//////////////////////////////////////////////////////////////////////////
// ALLOCATIONS
//////////////////////////////////////////////////////////////////////////



	void sceKernelDevkitVersion()
	{
		LOG(HLE,"sceKernelDevkitVersion");
		RETURN(1);
	}

//////////////////////////////////////////////////////////////////////////
// DEBUG
//////////////////////////////////////////////////////////////////////////


	void sceKernelRegisterKprintfHandler()
	{
		LOG(HLE,"sceKernelRegisterKprintfHandler()");
		RETURN(0);
	}
	void sceKernelRegisterDefaultExceptionHandler()
	{
		LOG(HLE,"sceKernelRegisterDefaultExceptionHandler()");
		RETURN(0);
	}

	void sceKernelSetGPO()
	{
		LOG(HLE,"sceKernelSetGPO(%01x)", PARAM(0));
		//RETURN(0);
	}
	void sceKernelGetGPI()
	{
		LOG(HLE,"0=sceKernelGetGPI()");
		RETURN(0);
	}



	KernelObjectPool kernelObjects;

	KernelObjectPool::KernelObjectPool() 
	{
		memset(occupied, 0, sizeof(bool)*maxCount);
	}
	SceUID KernelObjectPool::Create(KernelObject *obj)
	{
		for (int i=0; i<maxCount; i++)
		{
			if (!occupied[i])
			{
				occupied[i]=true;
				pool[i] = obj;
				pool[i]->uid = i+handleOffset;
				return i+handleOffset;
			}
		}
		_dbg_assert_(HLE, 0);
		return 0;
	}
	bool KernelObjectPool::IsValid(SceUID handle)
	{
		int index = handle - handleOffset;
		if (index < 0)
			return false;
		if (index >= maxCount)
			return false;

		return occupied[index];
	}
	void KernelObjectPool::Clear()
	{
		for (int i=0; i<maxCount; i++)
		{
			//brutally clear everything, no validation
			if (occupied[i])
				delete pool[i];
			occupied[i]=false;
		}
		memset(pool, 0, sizeof(KernelObject*)*maxCount);
	}
	KernelObject *&KernelObjectPool::operator [](SceUID handle)
	{
		_dbg_assert_msg_(HLE, IsValid(handle), "GRABBING UNALLOCED KERNEL OBJ");
		return pool[handle-handleOffset];
	}

	void KernelObjectPool::List()
	{
		for (int i=0; i<maxCount; i++)
		{
			if (occupied[i])
			{
				char buffer[256];
				if (pool[i])
				{
					pool[i]->GetQuickInfo(buffer,256);
				}
				else
				{
					strncpy_s(buffer,"WTF? Zero Pointer",_TRUNCATE);
				}
				LOG(HLE, "KO %i: %s \"%s\": %s", i + handleOffset, pool[i]->GetTypeName(), pool[i]->GetName(), buffer);
			}
		}
	}
	int KernelObjectPool::GetCount()
	{
		int count = 0;
		for (int i=0; i<maxCount; i++)
		{
			if (occupied[i])
				count++;
		}
		return count;
	}

}
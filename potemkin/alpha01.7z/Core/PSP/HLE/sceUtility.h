#pragma once
namespace PSPHLE
{

	void sceUtilitySavedataGetStatus();
	void sceUtilitySavedataInitStart();
	void sceUtilityGetSystemParamInt();
	void sceUtilitySavedataShutdownStart();
	void sceUtilitySavedataUpdate();

}
#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceAudio.h"
#include "sceKernel.h"
#include "sceKernelThread.h"

namespace PSPHLE
{
	CRITICAL_SECTION section;
	struct AudioChannel
	{
		u32 sampleAddress;
		u32 sampleRate;

		u32 samplePos;
		u32 loopSize;

		int running;
		int triggered;

		int vol1;
		int vol2;
	};

	//////////////////////////////////////////////////////////////////////////
	// STATE BEGIN
	AudioChannel chans[8];
	int numChans = 0;
	// STATE END
	//////////////////////////////////////////////////////////////////////////

	void __AudioInit()
	{
		InitializeCriticalSection(&section);

	}

	void __AudioShutdown()
	{

	}

	void __AudioUpdate()
	{
		LOG(HLE,"Updating audio");
		EnterCriticalSection(&section);
		for (int i=0; i<numChans; i++)
		{
			if (chans[i].triggered)
			{
				chans[i].triggered = false;
				__KernelTrigger(WAITTYPE_AUDIOCHANNEL, i+1);
			}
		}
		LeaveCriticalSection(&section);
	}

	int __AudioMix(short *outstereo, int numSamples)
	{
		memset(outstereo,0,numSamples*sizeof(short)*2);
		return numSamples;

		EnterCriticalSection(&section);
		memset(outstereo,0,numSamples*sizeof(short)*2);

		int numActiveChans = 0;

		for (int i=0; i<numChans; i++)
		{
			numActiveChans += chans[i].running ? 1 : 0;
		}

		if (!numActiveChans)
		{
			LeaveCriticalSection(&section);
			return numSamples;
		}

		bool stopMix = false;
		int s;
		for (s = 0; s < numSamples; s++)
		{
			for (int i=0; i<numChans; i++)
			{
				if (chans[i].running)
				{
					s32 sample1 = (s16)ReadMem16(chans[i].sampleAddress+chans[i].samplePos*4);
					s32 sample2 = (s16)ReadMem16(chans[i].sampleAddress+chans[i].samplePos*4+2);

					outstereo[s*2] += sample1/2;//(sample * chans[i].vol1) >> 8;
					outstereo[s*2+1] += sample2/2;//.(sample * chans[i].vol2) >> 8;

					chans[i].samplePos++;

					if (chans[i].samplePos >= chans[i].loopSize)
					{
						chans[i].running = false;
						chans[i].triggered = true;
						stopMix = true; // we need to run a little bit of PSP code
						LOG(HLE,"Stopped mix at %i samples of %i",s,numSamples);
					}
				}
			}
			if (stopMix)
				break;
		}
		LeaveCriticalSection(&section);
		if (!stopMix)
			LOG(HLE,"Did not stop mix, did %i samples",numSamples);

		return s;
	}




	void sceAudioOutputPannedBlocking() // Blocking play
	{
		//__KernelBlockCurThread(0);
		//return; 

		int chanNumber = PARAM(0);
		u32 samplePtr = PARAM(3);

		LOG(HLE,"sceAudioOutputPannedBlocking(%d,%d,%d, %08x )",chanNumber,PARAM(1),PARAM(2),samplePtr);
		if (chanNumber<0 || chanNumber>7)
		{
			LOG(HLE,"sceAudioOutputPannedBlocking() - BAD CHANNEL");
		}
		else
		{
			chans[chanNumber].running=true;
			chans[chanNumber].samplePos=0;
			chans[chanNumber].vol1 = PARAM(1);
			chans[chanNumber].vol2 = PARAM(2);
			chans[chanNumber].sampleAddress = samplePtr;
		}
		__KernelWaitCurThread(WAITTYPE_AUDIOCHANNEL, chanNumber);
	}

	void sceAudioGetChannelRestLen()
	{
		LOG(HLE,"sceAudioGetChannelRestLen(%i)", PARAM(0));

		RETURN(0);
	}

	void sceAudioOutputBlocking()
	{
		int chanNumber = PARAM(0);
		u32 samplePtr = PARAM(3);

		LOG(HLE,"sceAudioOutputBlocking()");
		if (chanNumber<0 || chanNumber>7)
		{
			LOG(HLE,"sceAudioOutputBlocking() - BAD CHANNEL");
		}
		else
		{
			chans[chanNumber].running=false;
			chans[chanNumber].samplePos=0;
			chans[chanNumber].vol1 = PARAM(1);
			chans[chanNumber].vol2 = PARAM(2);
			chans[chanNumber].sampleAddress = samplePtr;
		}
		__KernelWaitCurThread(WAITTYPE_AUDIOCHANNEL, chanNumber);
	}

	void sceAudioChReserve() //.Allocate sound channel
	{
		//return; 
		u32 unknown1 = PARAM(0);
		u32 sampleCount = PARAM(1);
		u32 unknown2 = PARAM(2);
		
		if (numChans < 8)
		{
			chans[numChans].loopSize = sampleCount;
			numChans++;
			LOG(HLE,"sceAudioChReserve");
		}
		else
		{
			LOG(HLE,"sceAudioChReserve failed");
		}
		RETURN(numChans-1); //return handle
	}

	void sceAudioChRelease()
	{
		//return; 
		u32 handle = PARAM(0);

		LOG(HLE,"sceAudioChRelease");
		RETURN(1);
	}

}


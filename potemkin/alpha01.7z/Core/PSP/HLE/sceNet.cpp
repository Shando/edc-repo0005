#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"

#include "sceKernel.h"
#include "sceUtility.h"

#include "../../EmuThread.h"



namespace PSPHLE
{
	void sceNetInit()
	{
		LOG(HLE,"sceNetInit(poolsize=%d, calloutpri=%i, calloutstack=%d, netintrpri=%i, netintrstack=%d)", PARAM(0), PARAM(1), PARAM(2), PARAM(3), PARAM(4));
		RETURN(0); //ERROR
	}
	void sceNetTerm()
	{
		LOG(HLE,"sceNetTerm()");
		RETURN(0);
	}
}

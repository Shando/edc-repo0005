#pragma once

namespace PSPHLE
{
	void _sceSasCore();
	void sceSasInit();
	void sceSasGetEndFlag();
	void sceSasSetVoice();
	void sceSasSetPitch();
	void sceSasSetVolume();
	void sceSasSetADSR();
}


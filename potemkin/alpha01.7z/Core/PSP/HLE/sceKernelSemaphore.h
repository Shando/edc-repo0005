#pragma once

namespace PSPHLE
{

	void HLEDECL sceKernelCancelSema();
	void HLEDECL sceKernelCreateSema();
	void HLEDECL sceKernelDeleteSema();
	void HLEDECL sceKernelPollSema();
	void HLEDECL sceKernelReferSemaStatus();
	void HLEDECL sceKernelSignalSema();
	void HLEDECL sceKernelWaitSema();
	void HLEDECL sceKernelWaitSemaCB();

}


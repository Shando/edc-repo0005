#include "stdafx.h"
#include "../PSPFirmwareHLE.h"
#include "../../MIPS/MIPS.h"
#include "../../MIPS/MIPSCodeUtils.h"

#include "sceKernel.h"
#include "sceKernelThread.h"
#include "sceKernelMemory.h"
#include "sceKernelCallback.h"


namespace PSPHLE
{
	class Callback : public KernelObject
	{
	public:
		const char *GetName() {return name;}
		const char *GetTypeName() {return "CallBack";}

		void GetQuickInfo(char *ptr, int size)
		{
			sprintf_s(ptr, size, "hack= %08x , thread=%i, argument= %08x",
				hackAddress,
				threadId,
				argument);
		}

		~Callback()
		{
			kernelMemory.Free(hackAddress);
		}
		void GrabAndWriteHack()
		{
			hackAddress = kernelMemory.Alloc(8);
			WriteMem32(hackAddress, MIPS_MAKE_JAL(entrypoint));
			WriteMem32(hackAddress+4, MIPS_MAKE_NOP());
		}

		SceUInt size;
		char name[32];
		u32 entrypoint;
		SceUID threadId;
		u32 argument;
		u32 notifyCount;
		u32 hackAddress;

		u32 oldPC;
		u32 oldRA;

		SceUInt 	attr;
		SceUInt 	initPattern;
		SceUInt 	currentPattern;
		int 		numWaitThreads;
	
	};

	//////////////////////////////////////////////////////////////////////////
	// CALLBACKS
	//////////////////////////////////////////////////////////////////////////

	//extern Thread *currentThread;
	void sceKernelCreateCallback()
	{
		u32 entrypoint = PARAM(1);
		u32 argument = PARAM(2);

		const char *name = (const char *)GetMemPointer(PARAM(0));

		Callback *c = new Callback;
		SceUID id = kernelObjects.Create(c);
		LOG(HLE,"%i=sceKernelCreateCallback(name=%s,entry= %08x )", id, name, entrypoint);

		c->size = sizeof(Callback);
		strncpy_s(c->name, 32, name, _TRUNCATE);

		c->entrypoint = entrypoint;
		c->threadId = __KernelGetCurThread();
		c->argument = argument;

		c->GrabAndWriteHack();
		RETURN(id);
	}

	//Hacks should really point to this guy
	void _sceKernelReturnFromCallback()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"_sceKernelReturnFromCallback(%i)", id);
		//blah blah
	}

	void sceKernelDeleteCallback()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"sceKernelDeleteCallback(%i)", id);
		RETURN(kernelObjects.Destroy<Callback>(id));
	}

	void sceKernelNotifyCallback()
	{
		SceUID id = PARAM(0);
		LOG(HLE,"UNIMPL sceKernelNofityCallback(%i)", id);
	}

	void __KernelCallCallback(SceUID id)
	{
		//First, make sure we're on the right thread
		u32 error;
		Callback *c = kernelObjects.Get<Callback>(id, error);
		if (c)
		{
			if (c->threadId == __KernelGetCurThread())
			{
				//Alright, we're on the right thread
				u32 oldPC = currentMIPS->pc;
				u32 oldRA = currentMIPS->r[MIPS_REG_RA];

				currentMIPS->pc = c->entrypoint;
				
			}
		}
		else
		{
			//ARGH!
		}
		//Write  
		//jal callback 
		//nop
		//li a0, callbackno
		//syscall PostCallback
		//to the hack memory area
	}

	void sceKernelCheckCallback()
	{
		//only check those of current thread
		LOG(HLE,"sceKernelCheckCallback");
		RETURN(0);
	}

}


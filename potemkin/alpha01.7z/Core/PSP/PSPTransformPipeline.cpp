#include "stdafx.h"

#include "../System.h"
#include "../MemMap.h"
#include "../Misc.h"
#include "../Host.h"

#include "PSPSystem.h"

#include "PSP3DMath.h"
#include "PSPDisplay.h"
#include "PSPTexture.h"
#include "PSPTransformPipeline.h"
#include "PSPGfxState.h"
#include "PSPvertexDecoder.h"
#include "ge_constants.h"

GLuint glprim[8] =
{
	GL_POINTS,
	GL_LINES,
	GL_LINE_STRIP,
	GL_TRIANGLES,
	GL_TRIANGLE_STRIP,
	GL_TRIANGLE_FAN,
	GL_QUADS // have to do dual glVertex!
};

float worldMatrix[12] =
{1,0,0,
0,1,0,
0,0,1,
0,0,0,};
float viewMatrix[12] =
{1,0,0,
0,1,0,
0,0,1,
0,0,0};
float projMatrix[16] =
{1,0,0,0,
0,1,0,0,
0,0,1,0,
0,0,0,1};
float tgenMatrix[12] =
{1,0,0,
0,1,0,
0,0,1,
0,0,0};
float boneMatrix[8*12];


//Complex commands live here

inline float getcomp(u32 col, int comp)
{
	return ((col>>comp*8)&0xff)/255.0f;
}


void Light(float colorOut[4], float uvInOut[2], float colorIn[4], Vec3 pos, Vec3 normal)
{
	//for (int i=0; i<3; i++)
	//	colorOut[i] += ((gstate.ambientcolor>>i*8)&0xff)/255.0f;
	Color4 emissive;
	emissive.GetFromRGB(gstate.materialemissive);
	Color4 globalAmbient;
	globalAmbient.GetFromRGB(gstate.ambientcolor);
	globalAmbient.GetFromA(gstate.ambientalpha);
	Vec3 norm = normal.Normalized();
	Color4 ambient;
	Color4 diffuse;
	Color4 specular;
	Color4 in(colorIn);

	if (gstate.materialupdate & 1)
	{
		ambient = in;
	}
	else
	{
		ambient.GetFromRGB(gstate.materialambient);   
		ambient.a=1.0f;
	}

	if (gstate.materialupdate & 2)
	{
		diffuse = in;
	}
	else
	{
		diffuse.GetFromRGB(gstate.materialdiffuse);   diffuse.a=1.0f;
	}

	if (gstate.materialupdate & 4)
	{
		specular = in;
	}
	else
	{
		specular.GetFromRGB(gstate.materialspecular); specular.a=1.0f;
	}

	float specCoef = getFloat24(gstate.materialspecularcoef);

	norm.Normalize();

	Vec3 viewer(viewMatrix[8], viewMatrix[9], viewMatrix[10]);

	int tmapMode = gstate.texmode & 3;
	int projStyle = (gstate.texmode >> 8) & 3;

	int uLight = gstate.texshade & 3;
	int vLight = (gstate.texshade>>8) & 3;

	Color4 lightSum = globalAmbient * ambient + emissive;

	for (int l=0; l<4; l++)
	{
		GELightComputation comp = (GELightComputation)(gstate.ltype[l]&3);
		GELightType type = (GELightType)((gstate.ltype[l]>>8)&3);
		if (gstate.lightEnable[l])
		{
			Vec3 toLight, dir;

			if (type == GE_LIGHTTYPE_DIRECTIONAL)
				toLight = Vec3(gstate.lightpos[l]);
			else
				toLight = (Vec3(gstate.lightpos[l]) - pos);

			dir = Vec3(gstate.lightdir[l]);

			bool doSpecular = (comp != GE_LIGHTCOMP_ONLYDIFFUSE);
			bool poweredDiffuse = comp == GE_LIGHTCOMP_BOTHWITHPOWDIFFUSE;

			float distance = toLight.Normalize(); 

			float lightScale = 1.0f;
			if (type != GE_LIGHTTYPE_DIRECTIONAL)
			{
				lightScale = 1.0f/(gstate.lightatt[l][0] + gstate.lightatt[l][1]*distance
					+ gstate.lightatt[l][2]*distance*distance);
				if (lightScale>1.0f) lightScale=1.0f;
			}

			float dot = toLight * norm;
			if (dot<0) dot=0;
			//Do shade mapping while we're here
			switch (tmapMode)
			{
			case 0: break; //don't touch UV
			case 2: //shade mapping
				if (l == uLight)
				{
					uvInOut[0] = 0.5f*(dot+1.0f);
				}
				if (l == vLight)
				{
					uvInOut[1] = 0.5f*(dot+1.0f);
				}
				break;
				//case 1 projection mapping is handled outside since it's not light dependent
			}

			//end shade mapping
			if (poweredDiffuse)
				dot = powf(dot, specCoef);

			Color4 diff = (gstate.lightColor[1][l] * diffuse) * (dot*lightScale);	
			Color4 spec(0,0,0,0);

			if (doSpecular)
			{
				Vec3 halfVec = toLight;
				halfVec += viewer.Normalized();
				halfVec.Normalize();

				dot = halfVec * norm;
				if (dot >= 0)
				{
					spec += (gstate.lightColor[2][l] * specular * (powf(dot, specCoef)*lightScale));
				}	
			}

			lightSum += gstate.lightColor[0][l]*ambient + diff + spec;
		}
	}

	if (tmapMode == 1) // projection mapping
	{
		Vec3 in(0,0,0);
		switch (projStyle)
		{
		case 0:
			in = pos; break;
		case 1:
			in.x = uvInOut[0];
			in.y = uvInOut[1];
			break;
		case 2:
			in = normal;
			break;
		case 3:
			in = norm;
			break;
		}
		float uvw[3];
		Vec3ByMatrix43(uvw, uvInOut, tgenMatrix);
		uvInOut[0] = uvw[0];
		uvInOut[1] = uvw[1];
	}
	for (int i=0; i<3; i++)
		colorOut[i] = lightSum[i];
}


DecodedVertex decoded[65536];


void TransformAndDrawPrim(void *verts, void *inds, int prim, int count)
{
	// First, decode the verts and apply morphing
	VertexDecoder dec;
	dec.SetVertexType(gstate.vertType);
	dec.DecodeVerts(decoded, verts, inds, prim, count);


	// Check if anything needs updating
	if (gstate.textureChanged)
	{
		if (gstate.textureMapEnable && !(gstate.clearmode & 1))
		{
			glEnable(GL_TEXTURE_2D);
			PSPSetTexture();
		}
		else
		{
			glDisable(GL_TEXTURE_2D);
		}
	}


	// Then, transform and draw in one big swoop.


	float v2[3];
	float uv2[2];

	glBegin(glprim[prim]);
	for (int i=0; i<count; i++)
	{	
		int index;
		if ((gstate.vertType & GE_VTYPE_IDX_MASK) == GE_VTYPE_IDX_8BIT)
		{
			index = ((u8*)inds)[i];
		} 
		else if ((gstate.vertType & GE_VTYPE_IDX_MASK) == GE_VTYPE_IDX_16BIT)
		{
			index = ((u16*)inds)[i];
		}
		else
		{
			index = i;
		}

		float v[3];
		float c[4];

		float *uv = decoded[index].uv;

		if (gstate.vertType & GE_VTYPE_THROUGH_MASK)
		{
			//Do not touch the coordinates
			for (int j=0; j<3; j++)
				v[j] = decoded[index].pos[j];
			for (int j=0; j<4; j++)
				c[j] = decoded[index].color[j];
			//Rescale UV?
		}
		else
		{
			uv[0] = uv[0]*gstate.uScale + gstate.uOff;
			uv[1] = uv[1]*gstate.vScale + gstate.vOff;

			//We do software T&L for now
			float out[3], norm[3];
			if ((gstate.vertType & GE_VTYPE_WEIGHT_MASK) == GE_VTYPE_WEIGHT_NONE)
			{
				Vec3ByMatrix43(out, decoded[index].pos, worldMatrix);
				Norm3ByMatrix43(norm, decoded[index].normal, worldMatrix);
			}
			else
			{
				Vec3 psum(0,0,0);
				Vec3 nsum(0,0,0);
				int nweights = (gstate.vertType & GE_VTYPE_WEIGHT_MASK) >> GE_VTYPE_WEIGHT_SHIFT;
				for (int i=0; i<nweights; i++)
				{
					Vec3ByMatrix43(out, decoded[index].pos, boneMatrix+i*12);
					Norm3ByMatrix43(norm, decoded[index].normal, boneMatrix+i*12);
					Vec3 tpos(out), tnorm(norm);
					psum += tpos*decoded[index].weights[i];
					nsum += tnorm*decoded[index].weights[i];
				}
				nsum.Normalize();
				psum.Write(out);
				nsum.Write(norm);
			}

			// Perform lighting here
			if (gstate.lightingEnable && !(gstate.vertType & GE_VTYPE_THROUGH_MASK))
			{
				//c[1] = norm[1];
				Light(c, uv, decoded[index].color, out, norm);
			}
			else
			{
				for (int j=0; j<4; j++)
					c[j] = decoded[index].color[j];
			}
			Vec3ByMatrix43(v, out, viewMatrix);
		}


		//c[2]=(rand()>>2)&1;
		glColor4fv(c);

		//glColor3f((float)rand()/RAND_MAX,(float)rand()/RAND_MAX,(float)rand()/RAND_MAX);
		if (prim == GE_PRIM_RECTANGLES)
		{
			if ((i&1) == 0)
			{
				memcpy(v2, v, sizeof(float)*3);
				memcpy(uv2,uv,sizeof(float)*2);
			}
			else
			{
				LOG(G3D,"TL: %f %f %f - TC %f %f",v2[0],v2[1],v2[2],uv2[0],uv2[1]);
				LOG(G3D,"BR: %f %f %f - TC %f %f",v[0],v[1],v[2],uv[0],uv[1]);

				glTexCoord2fv(uv2);
				glVertex3f(v2[0], v2[1], v[2]);
				glTexCoord2f(uv[0],uv2[1]);
				glVertex3f(v[0], v2[1], v[2]);
				glTexCoord2f(uv[0],uv[1]);
				glVertex3fv(v);
				glTexCoord2f(uv2[0],uv[1]);
				glVertex3f(v2[0], v[1], v[2]);
			}
		}
		else
		{
			LOG(G3D,"TC: %f %f",uv[0],uv[1]);
			glTexCoord2fv(uv);
			LOG(G3D,"V%i: %f %f %f",i,v[0],v[1],v[2]);
			glVertex3fv(v);
		}
	}
	glEnd();
}

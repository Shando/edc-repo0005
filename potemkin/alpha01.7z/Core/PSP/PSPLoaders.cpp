#include "stdafx.h"

#include "../ELF/ElfReader.h"

//EVIL
#include "../../Windows/WindowsDirFileSystem.h"
#include "../FileSystems/ISOFileSystem.h"

#include "../System.h"
#include "../MemMap.h"
#include "../Misc.h"

#include "../MIPS/MIPS.h"
#include "../MIPS/MIPSAnalyst.h"
#include "../MIPS/MIPSCodeUtils.h"

#include "../Host.h"

#include "PSPSystem.h"
#include "PSPLoaders.h"
#include "PSPFirmwareHLE.h"

#include "HLE/sceKernel.h"
#include "HLE/sceKernelThread.h"
#include "HLE/sceKernelModule.h"
#include "HLE/sceKernelMemory.h"


BlockDevice *constructBlockDevice(const TCHAR *filename)
{
	TCHAR firstInExtension = filename[strlen(filename)-3];
	if (firstInExtension == 'c')
	{
		return new CISOFileBlockDevice(filename);
	}
	else
	{
		return new FileBlockDevice(filename);
	}
}

void Load_PSP_ISO(const TCHAR *filename)
{
	ISOFileSystem *umd2 = new ISOFileSystem(&pspFileSystem, constructBlockDevice(filename));

	//pspFileSystem.Mount("host0:",umd2); 
	pspFileSystem.Mount("umd0:",umd2); 
	pspFileSystem.Mount("umd1:",umd2); 
	pspFileSystem.Mount("disc0:",umd2); 
	pspFileSystem.Mount("UMD0:",umd2); 
	pspFileSystem.Mount("UMD1:",umd2); 
	pspFileSystem.Mount("DISC0:",umd2); 

	std::string bootpath("disc0:/PSP_GAME/SYSDIR/BOOT.BIN");
	//std::string bootpath("/PSP_GAME/USRDIR/locoroco/locoroco.prx");
	
	LOG(LOADER,"Loading %s...", bootpath.c_str());
	PSPHLE::__KernelLoadExec(bootpath.c_str(), 0);
}



void Load_PSP_ELF(const TCHAR *filename)
{
	char drive[32];
	char path[532];
	char file[232];
	char ext[32];
	_splitpath_s(filename, drive,path,file,ext);
	char total[512];
	sprintf(total, "%s%s", drive, path);
	WindowsDirFileSystem *fs = new WindowsDirFileSystem(&pspFileSystem, total);
	pspFileSystem.Mount("umd0:/", fs);

	char newfilename[512];
	sprintf(newfilename, "umd0:/%s%s",file,ext);
	PSPHLE::__KernelLoadExec(newfilename, 0);
}


// TODO : Properly mount the containing directory onto the PSP filesystem
void Load_PBP(const TCHAR *filename)
{
	/*
	static const char *FileNames[] =
	{
		"PARAM.SFO", "ICON0.PNG", "ICON1.PMF", "UNKNOWN.PNG",
		"PIC1.PNG", "SND0.AT3", "UNKNOWN.PSP", "UNKNOWN.PSAR"
	};

	std::ifstream in(filename, std::ios::binary);

	char temp[4];
	in.read(temp,4);

	if (memcmp(temp,"\0PBP",4) != 0)
	{
		//This is not a valid file!
		LOG(ROM,"%s is not a valid homebrew PSP1.0 PBP",filename);
		return;
	}

	u32 version, offset0, offsets[16];
	int numfiles;

	in.read((char*)&version,4);

	in.read((char*)&offset0,4);
	numfiles = (offset0 - 8)/4;
	offsets[0] = offset0;
	for (int i=1; i<numfiles; i++)
		in.read((char*)&offsets[i],4);

	in.seekg(offsets[5]);
	//in.read((char*)&id,4);
	{
		u8 *temp = new u8[1024*1024*8];
		in.read((char*)temp, 1024*1024*8);
		PSPHLE::SceUID id;
		PSPHLE::Module *m = PSPHLE::__KernelLoadELFFromPtr(temp, PSP_GetDefaultLoadAddress(), id);
		mipsr4k.pc = m->entry_addr;
		delete [] temp;
	}
	in.close();*/
}

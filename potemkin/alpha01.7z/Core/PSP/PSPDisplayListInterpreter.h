#pragma once

#include "../System.h"
#include "../MemMap.h"
#include "../Host.h"

u32 PSPDisplay_EnqueueList(u32 listpc, u32 stall);
void PSPDisplay_UpdateStall(int listid, u32 newstall);

bool PSPDisplay_InterpretList();

#pragma once

#include "../../Globals.h"

#include "PSPTransformPipeline.h"

void PSPDisplay_Init();
void PSPDisplay_Draw();
void PSPDisplay_Shutdown();


inline float getFloat24(u32 data)
{
	data<<=8;
	return *(float*)(&data);
}


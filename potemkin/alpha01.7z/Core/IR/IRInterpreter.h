#pragma once

#include "IR.h"

void IR_Int_Step();
void IR_Int_RunBlock(IROp *ptr, int count);

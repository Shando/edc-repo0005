#include "stdafx.h"

#include "../ARM/ARM.h"
#include "../ARM/ARMTables.h"
#include "IR.h"
#include "IRTables.h"


void IR_Dis(IROp &op, char *ptr)
{
	int o = op.op;
	char temp[256];
	if (o<IR_FIRSTMUL)
	{
		char temp1[32]; strcpy(temp1,op.in[0].GetDis());
		char temp2[32]; strcpy(temp2,op.in[1].GetDis());
		sprintf(temp,"%s%s r%d, %s, %s", IRNames[o], op.outputFlags?".":" ",op.out[0], temp1, temp2);
	}
	else if (o<IR_FIRSTTWOIN)
	{
		char temp1[32]; strcpy(temp1,op.in[0].GetDis());
		char temp2[32]; strcpy(temp2,op.in[1].GetDis());
		sprintf(temp,"%s%s r%d:r%d, %s, %s", IRNames[o], op.outputFlags?".":" ",op.out[1],op.out[0], temp1, temp2);
	}
	else if (o<IR_FIRSTONEINONEOUT)
	{
		char temp1[32]; strcpy(temp1,op.in[0].GetDis());
		char temp2[32]; strcpy(temp2,op.in[1].GetDis());
		sprintf(temp,"%s%s %s, %s", IRNames[o], op.outputFlags?".":" ",temp1, temp2);
	}
	else if (o<IR_FIRSTLOAD)
	{
		char temp1[32]; strcpy(temp1,op.in[0].GetDis());
		sprintf(temp,"%s  r%d, %s", IRNames[o], op.out[0], temp1);
	}
	else if (o<IR_FIRSTSTORE)
	{
		char temp1[32]; strcpy(temp1,op.in[0].GetDis());
		//loads
		sprintf(temp,"%s  r%d, [%s]", IRNames[o], op.out[0], temp1);
	}
	else if (o<IR_FIRSTCP)
	{
		char temp1[32]; strcpy(temp1,op.in[0].GetDis());
		char temp2[32]; strcpy(temp2,op.in[1].GetDis());
		//stores
		sprintf(temp,"%s  %s, [%s]", IRNames[o], temp2, temp1);
	}
	else if (o < IR_FIRSTBRANCH)
	{
		sprintf(temp,"%s  %s", IRNames[o],op.in[0].GetDis());
	}
	else if (o == IR_BRANCH)
	{
		sprintf(temp,"%s  %s (%d)",IRNames[o],conditionNames[op.in[0].value], op.in[1].value);
	}
	else if (o == IR_BRANCHTARGET)
	{
		sprintf(temp,"%s  (%d)",IRNames[o],op.in[1].value);
	}
	else if (o == IR_LEAVE)
	{
		if (op.in[0].isImmediate)
		{
			TCHAR *tmp;
			u32 addr = op.in[0].value;
			switch (op.in[1].value) {
			case IRL_BRTHUMBSAMEBLOCK:
			case IRL_BRTHUMB:   tmp = "THUMB"; break;
			case IRL_BRARMSAMEBLOCK:
			case IRL_BRARM:     tmp = "ARM"; break;
			case IRL_BRDEPENDS: tmp = addr&1?"THUMB":"ARM"; break;
			case IRL_RTE:       tmp = "RTE"; break;
			case IRL_SWITHUMB:
			case IRL_SWI:       tmp = "SWI"; break;
			}
			addr&=~1;
			sprintf(temp,"%s  %08x (%s)", IRNames[o],addr,tmp);
		}
		else
		{
			TCHAR *tmp;
			switch (op.in[1].value) {
			case IRL_BRTHUMBSAMEBLOCK:
			case IRL_BRTHUMB:   tmp = "THUMB"; break;
			case IRL_BRARMSAMEBLOCK:
			case IRL_BRARM:     tmp = "ARM"; break;
			case IRL_BRDEPENDS: tmp = "DEPENDS"; break;
			case IRL_RTE:       tmp = "RTE"; break;
			case IRL_SWITHUMB:
			case IRL_SWI:       tmp = "SWI"; break;
			}
			sprintf(temp,"%s  %s (%s)", IRNames[o],op.in[0].GetDis(),tmp);
		}
	}
	else
	{
		sprintf(temp,"%s", IRNames[o]);
	}
	sprintf(ptr,"[%c%c%c%c] %s",
		(op.outputFlags&FL_N)?'N':'_',
		(op.outputFlags&FL_Z)?'Z':'_',
		(op.outputFlags&FL_C)?'C':'_',
		(op.outputFlags&FL_V)?'V':'_',temp);
}
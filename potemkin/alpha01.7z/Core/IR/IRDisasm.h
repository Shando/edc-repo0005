#pragma once

#include "IR.h"

void IR_Dis(IROp &op, char *ptr);

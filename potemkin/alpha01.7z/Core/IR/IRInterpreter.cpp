#include "stdafx.h"

#include "../Core.h"

#include "../ARM/ARM.h"
#include "../ARM/ARMTables.h"
#include "IR.h"
#include "../MemMap.h"

//temporary
#include "../GBA/GBASystem.h"

static IROp *base;
static IROp *current;


#define REG(i) currentARM->r[i]

bool tN,tZ,tC,tV;



bool exitIR=false;
u32 exitAddr;
bool exitThumb=false;

bool doSWI = false;

// very freaking slow IR interpreter
// the IR is made to be compiled, not interpreted
void IR_Int_Step()
{
#ifndef _WIN64
	ARMState *currentARM = static_cast<ARMState*>(currentCPU);
	IROp &op = *current;
	switch (op.op) 
	{
	case IR_MOV:
		currentARM->r[op.out[0]] = op.in[0].GetValue();
		if (op.outputFlags)
		{
			int val = currentARM->r[op.out[0]];
			__asm
			{
				mov eax,val
				and eax,0xffffffff
				sets tN
				setz tZ
			}
		}
		break;
	case IR_SEX8:
		currentARM->r[op.out[0]] = (u32)(s32)(s8)op.in[0].GetValue();
		return;
	case IR_SEX16:
		currentARM->r[op.out[0]] = (u32)(s32)(s16)op.in[0].GetValue();
		return;

	case IR_LOADBYTE:
		currentARM->r[op.out[0]] = (u32)ReadMem8(op.in[0].GetValue());
		return;
	case IR_LOADHALF:
		currentARM->r[op.out[0]] = (u32)ReadMem16(op.in[0].GetValue());
		return;
	case IR_LOADWORD:
		currentARM->r[op.out[0]] = ReadMem32(op.in[0].GetValue());
		return;

	case IR_STOREBYTE:
		WriteMem8(op.in[0].GetValue(),op.in[1].GetValue());
		return;
	case IR_STOREHALF:
		WriteMem16(op.in[0].GetValue(),op.in[1].GetValue());
		return;
	case IR_STOREWORD:
		WriteMem32(op.in[0].GetValue(),op.in[1].GetValue());
		return;

	case IR_NOT:
		{
			int val1 = (int)op.in[0].GetValue();
			u32 out = (u32)(~val1); 
			currentARM->r[op.out[0]] = out;
			tZ = (out==0);
			tN = (out>>31) ? true : false;
		}
		break;
	case IR_NEG:
		{
			int val1 = (int)op.in[0].GetValue();
			u32 out = (u32)(-val1); 
			currentARM->r[op.out[0]] = out;
			tC = (val1==0);
			tZ = (out==0);
			tN = (out>>31) ? true : false;
		}
		break;

	case IR_ADD:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				add eax,ecx
				sets tN
				setz tZ
				setc tC
				seto tV
				mov [ebx],eax
			}
		}
		break;
	case IR_ADC:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			tC = currentARM->c;
			__asm
			{
				//movzx eax,tC
				//add eax,0xFFFFFFFF //flag
				sub tC,1
				cmc
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				adc eax,ecx
				sets tN
				setz tZ
				setc tC
				seto tV
				mov [ebx],eax
			}
		}
		break;
	case IR_CMP:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			__asm
			{
				mov eax,val1
				mov ecx,val2
				cmp eax,ecx
				cmc //arm curiosity fix
				sets tN
				setz tZ
				setc tC
				seto tV
			}
		}
		break;
	case IR_CMN:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			__asm
			{
				mov eax,val1
				mov ecx,val2
				add eax,ecx
				sets tN
				setz tZ
				setc tC
				seto tV
			}
		}
		break;
	case IR_TST:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			__asm
			{
				mov eax,val1
				mov ecx,val2
				test eax,ecx
				sets tN
				setz tZ
			}
			op.outputFlags&=~FL_V;
		}
		break;
	case IR_TEQ:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			__asm
			{
				mov eax,val1
				mov ecx,val2
				xor eax,ecx
				sets tN
				setz tZ
			}
		}
		break;
	case IR_SUB:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				sub eax,ecx
				cmc //arm curiosity fix
				sets tN
				setz tZ
				setc tC
				seto tV
				mov [ebx],eax
			}
		}
		break;
	case IR_SBC:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			tC = currentARM->c;
			__asm
			{
				sub tC,1 //move ARM C flag into x86 C flag, do not invert (arm quirk)
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				sbb eax,ecx
				cmc //arm curiosity fix
				sets tN
				setz tZ
				setc tC
				seto tV
				mov [ebx],eax
			}
		}
		break;
	case IR_AND:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				and eax,ecx
				sets tN
				setz tZ
				mov [ebx],eax
			}
		}
		break;
	case IR_OR:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				or eax,ecx
				sets tN
				setz tZ
				mov [ebx],eax
			}
		}
		break;
	case IR_XOR:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				xor eax,ecx
				sets tN
				setz tZ
				mov [ebx],eax
			}
		}
		break;
	case IR_MUL:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				mul ecx
				test eax,eax
				sets tN
				setz tZ
				mov [ebx],eax
			}
		}
		break;
	case IR_MUL64:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();

			u32 *outlo = &currentARM->r[op.out[0]];
			u32 *outhi = &currentARM->r[op.out[1]];
			//TODO: are flags right?
			__asm
			{
				mov ebx,outlo
				mov ecx,outhi
				mov eax,val1
				mov edx,val2
				imul edx
				mov [ebx],eax
				mov [ecx],edx
				test edx,0x80000000
				sets tN
				or eax,edx
				setz tZ
			}
		}
		break;
	case IR_UMUL64:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();

			u32 *outlo  = &currentARM->r[op.out[0]];
			u32 *outhi = &currentARM->r[op.out[1]];

			__asm
			{
				mov ebx,outlo
				mov ecx,outhi
				mov eax,val1
				mov edx,val2
				mul edx
				mov [ebx],eax
				mov [ecx],edx
				test edx,0x80000000
				sets tN
				or eax,edx
				setz tZ
			}
		}
		break;
	case IR_MAD64:
		{
			if (op.outputFlags)
			{
				_dbg_assert_msg_(CPU,0,"Flags from MUL64 unsupported");
			}

			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			int val3 = currentARM->r[op.out[0]];
			int val4 = currentARM->r[op.out[1]];

			u32 *outptr  = &currentARM->r[op.out[0]];
			u32 *outptr2 = &currentARM->r[op.out[1]];

			__asm
			{
				mov ebx,outptr
				mov ecx,outptr2
				mov eax,val1
				mov edx,val2
				imul edx
				add eax,val3
				adc edx,val4
				mov [ebx],eax
				mov [ecx],edx
			}
		}
		break;
	case IR_UMAD64:
		{
			if (op.outputFlags)
			{
				_dbg_assert_msg_(CPU,0,"Flags from MUL64 unsupported");
			}

			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			int val3 = currentARM->r[op.out[0]];
			int val4 = currentARM->r[op.out[1]];

			u32 *outptr  = &currentARM->r[op.out[0]];
			u32 *outptr2 = &currentARM->r[op.out[1]];

			__asm
			{
				mov ebx,outptr
				mov ecx,outptr2
				mov eax,val1
				mov edx,val2
				mul edx
				add eax,val3
				adc edx,val4
				mov [ebx],eax
				mov [ecx],edx
			}
		}
		break;
			
	case IR_LSL:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				shl eax,cl
				setc tC
				sets tN
			//	test eax,eax
				setz tZ
				cmp cl,31
				mov ecx,0
				cmova eax,ecx
				mov [ebx],eax
			}
		}
		break;
	case IR_LSR:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				shr eax,cl
				setc tC
				sets tN
				setz tZ
				cmp cl,31
				mov ecx,0
				cmova eax,ecx
				mov [ebx],eax
			}
		}
		break;
	case IR_ASR:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				sar eax,cl
				setc tC
				sets tN
				setz tZ
				//cmp cl,31
				//cmova eax,0
				mov [ebx],eax
			}
		}
		break;
	case IR_ROR:
		{
			int val1 = op.in[0].GetValue();
			int val2 = op.in[1].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				mov ecx,val2
				ror eax,cl
				setc tC
				sets tN
				setz tZ
				mov [ebx],eax
			}
		}
		break;
	case IR_RRX:
		{
			int val1 = op.in[0].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			tC = currentARM->c;
			__asm
			{
				sub tC,1 //move ARM C flag into x86 C flag
				cmc
				mov ebx,outptr
				mov eax,val1
				rcr eax,1
				setc tC
				sets tN
				setz tZ
				mov [ebx],eax
			}
		}
		break;

	case IR_RSB:	//pseudo
	case IR_RSC:	//pseudo
	case IR_BIC:
		_dbg_assert_msg_(CPU,0,"Found pseudo op while interpreting IR!");
		break;

	case IR_CLZ:
		{
			int val1 = op.in[0].GetValue();
			u32 *outptr = &currentARM->r[op.out[0]];
			__asm
			{
				mov ebx,outptr
				mov eax,val1
				bsr eax,eax
				sets tN
				setz tZ
				mov [ebx],eax
			}
		}
		break;

	case IR_BRANCH:
		{
			int condition = op.in[0].value;
			if (currentARM->EvaluateCondition(condition))
			{
				while (current->op != IR_BRANCHTARGET)
					current++;
				//because of the general current++, the branchtarget will be skipped too
			}
		}
		break;
	case IR_SETFLAG:
		//_dbg_assert_msg_(CPU,0,"IR Interpreter : SETFLAG not emulated!");
		switch(op.outputFlags) {
		case FL_C: tC = op.in[0].value?true:false; break;
		case FL_Z: tZ = op.in[0].value?true:false; break;
		case FL_N: tN = op.in[0].value?true:false; break;
		case FL_V: tV = op.in[0].value?true:false; break;
		}
		break;
	case IR_BRANCHTARGET:
		//nop
		break;
	case IR_LEAVE:
		exitIR=true;
		exitAddr=op.in[0].GetValue();// hack for stupid things ..
		switch (op.in[1].value)
		{
		case IRL_BRARMSAMEBLOCK:
		case IRL_BRARM:		exitThumb = false; exitAddr&=~1; break;
		case IRL_BRTHUMBSAMEBLOCK:
		case IRL_BRTHUMB:	exitThumb = true; exitAddr&=~1;  break;
		case IRL_BRDEPENDS: exitThumb = exitAddr&1;exitAddr&=~1; break;
		case IRL_MODESWITCH:
			exitThumb=false;
			exitAddr&=~1; 
			//do shit
			break;
		case IRL_RTE:
			//exitThumb=exitAddr&1;
			exitAddr&=~1;
			{
				/*
				if (!currentARM->curSPSR)
				{
					_dbg_assert_msg_(CPU,0,"Trying to return from interrupt in user/system mode!");
				}*/
				int newval = currentARM->spsr;
				currentARM->ModeSwitch((ARMMode)(newval&0x1f));
				currentARM->SetCPSR(newval);
				exitThumb = currentARM->thumb;
			}
			//do shit
			break;
		case IRL_SWI:
			LOG(CPU,"SWI Software Interrupt (syscall!)");
			exitThumb=false;
			exitAddr&=~1; 
			doSWI = true;
			break;
		case IRL_SWITHUMB:
			exitThumb=true;
			exitAddr&=~1; 
			doSWI = true;
			//do shit
			break;
		default:
			_dbg_assert_msg_(CPU,0,"IR interpreter - unknown LEAVE reason");
			break;
		}
		break;
	case IR_FLUSHREGS:
		// nop
		break;
	case IR_INTERPRET:
		ARMInterpret(op.in[0].value);
		break;
	default:
		_dbg_assert_msg_(CPU,0,"IR Interpreter : Unknown IR instruction!");
		LOG(CPU,"Unknown instruction: %d",op.op);
		break;
	}
	if (op.outputFlags&FL_N) currentARM->n=tN;
	if (op.outputFlags&FL_Z) currentARM->z=tZ;
	if (op.outputFlags&FL_C) currentARM->c=tC;
	if (op.outputFlags&FL_V) currentARM->v=tV;
#else

#endif
}

void IR_Int_RunBlock(IROp *ptr, int count)
{
	doSWI = false;
	base = ptr;
	current = ptr;
	exitIR=false;
	for (int i=0; i<count; i++)
	{
		IR_Int_Step();
		current++;
		if (exitIR)
			break;
	}
	if (!exitIR)
		_dbg_assert_msg_(CPU,0,"Left block without a LEAVE instruction!");
	
	/*
	if (exitAddr == 0)
	{

		LOG(CPU,"Branch to zero, from %08x",currentCPU->GetPC());
		_dbg_update_();
		Core_Pause();
	}*/

	ARMState *currentARM = static_cast<ARMState*>(currentCPU);

	currentARM->r[15] = exitAddr;
	currentARM->thumb = exitThumb;

	if (doSWI)
	{
		//GBA_SWI();
		currentSystem->SWI();
	}
}


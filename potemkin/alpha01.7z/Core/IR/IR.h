#pragma once

#include "../../Globals.h"

//#include "ARM.h"
#include "../ARM/ARMCompiler.h"

enum IROpID
{
	IR_NOP, //put first to simplify code
	
	IR_ADD,
	IR_ADC,
	IR_SUB,
	IR_SBC,
	IR_AND,
	IR_OR,
	IR_XOR,
	IR_LSL,
	IR_LSR,
	IR_ASR,
	IR_ROR,
	IR_RSB, //pseudo
	IR_RSC, //pseudo
	IR_BIC, //pseudo
	IR_MUL,
	
	IR_MUL64,
	IR_UMUL64,
	IR_MAD64,
	IR_UMAD64,

	IR_TST,
	IR_TEQ,
	IR_CMP,
	IR_CMN, 

	IR_MOV,
	IR_NOT,
	IR_NEG,
	IR_CLZ,
	IR_RRX,
	IR_SEX8,
	IR_SEX16,
	IR_SETFLAG,

	IR_LOADBYTE,
	IR_LOADHALF,
	IR_LOADWORD,

	IR_STOREBYTE, 
	IR_STOREHALF,
	IR_STOREWORD,

	IR_MRS,
	IR_MSR,
	
	IR_MRC,
	IR_MCR,

	IR_STC,
	IR_LDC,

	IR_BRANCH,
	IR_BRANCHTARGET,
	IR_LEAVE,

	IR_FLUSHREGS, //make sure any cached regs are flushed
	IR_INTERPRET,

	IR_NUMIROPS, 

	IR_FIRSTTWOINONEOUT=IR_ADD,
	IR_FIRSTMUL = IR_MUL64,
	IR_FIRSTTWOIN = IR_TST,
	IR_FIRSTONEINONEOUT = IR_MOV,
	IR_FIRSTLOAD = IR_LOADBYTE,
	IR_FIRSTSTORE = IR_STOREBYTE,
	IR_FIRSTCP = IR_MRS,
	IR_FIRSTBRANCH = IR_BRANCH
};

enum
{
	IRLS_ALIGNED,
	IRLS_UNKNOWN,
	IRLS_UNALIGNED
};

enum
{
	IRL_BRDEPENDS,
	IRL_BRTHUMB,
	IRL_BRTHUMBSAMEBLOCK,
	IRL_BRARM,
	IRL_BRARMSAMEBLOCK,
	//IRL_IGNORET,
	IRL_SWI,
	IRL_SWITHUMB,
	IRL_RTE,
	IRL_MODESWITCH
};

enum
{
	IRI_BLOCKEAX=1<<0,
	IRI_BLOCKECX=1<<1,
	IRI_BLOCKEBX=1<<2,
	IRI_BLOCKEDX=1<<3,
	IRI_BLOCKEDI=1<<4,
	IRI_BLOCKESI=1<<5,
	IRI_BLOCKEBP=1<<6,
};

enum
{
	IRTEMP0=16,
	IRTEMP1=17,
	IRTEMP2=18,
	IRNUMREGS=19
};

template<class T>
struct IRInput
{
	union
	{
		T reg; //or immediate, sign extended if so
		T value;
	};
	bool isImmediate; 

	IRInput(){}
	IRInput(T val, bool isImm = false)
	{
		reg=val;
		isImmediate = isImm;
	}
	bool operator == (const IRInput &o) const
	{
		return (reg==o.reg) && (isImmediate == o.isImmediate);
	}
	u32 GetValue();
	char *GetDis()
	{
		static char desc[16];
		if (isImmediate)
			sprintf(desc,"0x%08x",value);
		else
			sprintf(desc,"r%d",reg);
		return desc;
	}
};

template<class T>
inline IRInput<T> IRImm(T imm)
{
	return IRInput<T>(imm,true);
}

inline IRInput<u32> IRReg(int reg)
{
	return (reg==15)?IRImm(compiler_pc+8):IRInput<u32>(reg);
}

inline IRInput<u32> IRRegT(int reg)
{
	return (reg==15)?IRImm(compiler_pc+4):IRInput<u32>(reg);
}

struct IROp
{
	IROpID op;
	IRInput<u32> in[3];
	int outputFlags; 
	int out[2];
	u32 pc;
	IROp *next; //linked list, want it easy to remove things
};

typedef u32 IROutput;

void IR_Start();
void IR_Add(IROpID id, int outFlags, IROutput out, IRInput<u32> in1, IRInput<u32> in2 = IRInput<u32>(0,true), IRInput<u32> in3 = IRInput<u32>(0,true), int out2=0);
void IR_InsertBranchTarget(u32 pc, int cond, int id);
void IR_End(int numCycles);

int IR_DisasmToLog();

int IR_Count();
void IR_Linearize(IROp *dest);
void IR_StartBranch(int condition);
void IR_EndBranch();
bool IR_IsInBranch();
int IR_GetCycles();



IROp *IR_First();
IROp *IR_Last();
IROp *IR_Alloc();
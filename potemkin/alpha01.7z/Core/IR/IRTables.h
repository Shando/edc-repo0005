#pragma once

#include "IR.h"

struct IROpInfo
{
	int numInputRegs;
	int numOutputRegs;
	int blockedRegs;
};
extern const IROpInfo irOpInfo[IR_NUMIROPS];
extern const char *IRNames[IR_NUMIROPS];

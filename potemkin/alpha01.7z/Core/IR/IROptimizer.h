#pragma once

void IR_Transform();
void IR_Optimize();
void IR_ConstantPropagate();

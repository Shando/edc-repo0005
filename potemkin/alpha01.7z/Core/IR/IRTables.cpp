#include "stdafx.h"
#include "IRTables.h"

const IROpInfo irOpInfo[IR_NUMIROPS] =
{
	{0,0,0}, //NOP
	{2,1,0}, //add 
	{2,1,0}, //adc
	{2,1,0}, //sub
	{2,1,0}, //sbc
	{2,1,0}, //and
	{2,1,0}, //or
	{2,1,0}, //xor
	{2,1,IRI_BLOCKECX}, //lsl
	{2,1,IRI_BLOCKECX}, //lsr
	{2,1,IRI_BLOCKECX}, //asr
	{2,1,IRI_BLOCKECX}, //ror
	{2,1,0}, //rsb
	{2,1,0}, //rsc
	{2,1,0}, //bic
	{2,1,IRI_BLOCKEAX|IRI_BLOCKEDX}, //mul

	{2,0,0}, //tst
	{2,0,0}, //teq
	{2,0,0}, //cmp
	{2,0,0}, //cmn

	// ARM specialized instructions
	{2,2,IRI_BLOCKEAX|IRI_BLOCKEDX}, //mul64
	{2,2,IRI_BLOCKEAX|IRI_BLOCKEDX}, //umul64
	{2,2,IRI_BLOCKEAX|IRI_BLOCKEDX}, //mad64
	{2,2,IRI_BLOCKEAX|IRI_BLOCKEDX}, //umad64

	{1,1,0}, //mov
	{1,1,0}, //not
	{1,1,0}, //neg
	{1,1,0}, //clz
	{1,1,0}, //rrx
	{1,1,0}, //sex8
	{1,1,0}, //sex16
	{0,0,0}, //setflag

	{1,1,0}, //loadbyte
	{1,1,0}, //loadhalf
	{1,1,0}, //loadword

	{2,0,0}, //storebyte
	{2,0,0}, //storehalf
	{2,0,0}, //storeword

	{0,1,0}, //mrs
	{1,0,0}, //msr

	{1,0,0}, //mrc
	{1,0,0}, //mcr

	{1,0,0}, //stc
	{1,0,0}, //ldc

	{0,0,0}, //branch (cond, branchid)
	{0,0,0}, //branchtarget
	{1,0,0}, //leave

	{0,0,0}, //flushregs
	{0,0,0}, //interpret
};

const char *IRNames[IR_NUMIROPS] = 
{
	"NOP ",
	"ADD ", //IR_FIRSTTWOINONEOUT
	"ADC ",
	"SUB ",
	"SBC ",
	"AND ",
	"OR  ",
	"XOR ",
	"LSL ",
	"LSR ",
	"ASR ",
	"ROR ",
	"RSB ",
	"RSC ",
	"BIC ",
	"MUL ",

	"MUL64",//firstmul
	"UMUL64",
	"MAD64",
	"UMAD64",

	"TEST", //IR_FIRSTTWOIN
	"TEQ ",
	"CMP ",
	"CMN ",

	"MOV ", //IR_FIRSTONEINONEOUT 
	"NOT ",
	"NEG ",
	"CLZ ",
	"RRX ",
	"SX8 ",
	"SX16",
	"SETF",

	"LDB ",
	"LDH ",
	"LDW ",

	"STB ",
	"STH ",
	"STW ",

	"MRS ",
	"MSR ",

	"MRC ",
	"MCR ",

	"STC ",
	"LDC ",

	"BRA ",
	"BT  ",
	"LEAV",
	
	"FLSH",
	"INTR"
};

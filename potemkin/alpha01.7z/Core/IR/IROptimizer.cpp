#include "stdafx.h"

#include "../ARM/ARM.h"
#include "../ARM/ARMTables.h"
#include "IR.h"
#include "IRTables.h"
#include "IROptimizer.h"

extern IROp *last;
//before optimize
//does things like constant propagation
void IR_Transform()
{
	IROp *prev = IR_First(); 
	if (!prev) return;
	IROp *op = prev->next;

	//first pass, cleanup of ridiculous shit
	//also checks for pc writes
	while (op)
	{
		switch (op->op) {
		case IR_RSB:
		case IR_RSC:
			if (op->op == IR_RSB || op->op == IR_RSC)
			{
				op->op = op->op == IR_RSB?IR_SUB:IR_SBC;
				IRInput<u32> tmp = op->in[0];
				op->in[0] = op->in[1];
				op->in[1] = tmp;
			}
			break;
		//case IR_NOT:
		case IR_BIC:
			//insert a not
			{
				IROp *not = IR_Alloc();
				prev->next = not;
				not->next = op;
				op->op = (op->op==IR_BIC?IR_AND:IR_CMP);
				not->op = IR_NOT;
				not->out[0] = IRTEMP2;
				not->in[0] = op->in[1];
				op->in[1] = IRTEMP2;
			}
			break;
			/*
		case IR_LSL:
			{
				if (op->in[1].isImmediate)
				{
					if (op->in[1]==0)
						op->op=IR_MOV;
				}
			}*/
		}

		int numOut = irOpInfo[op->op].numInputRegs;
		/*
		if (numOut && op->out[0] == ARM_REG_PC)
		{
			//Writing to PC! have to insert a leave op
			//_dbg_assert_msg_(CPU,0,"PC written!!");
			IROp *n = IR_Alloc();
			n->next=op->next;
			op->next=n;
			n->op = IR_LEAVE;
			n->in[0] = ARM_REG_PC;
			n->in[1] = compiler_thumb ? IRL_BRTHUMB : IRL_BRARM;
			//return;
		}*/

		prev = op;
		op=op->next;
	}
}


template<class T>
struct ConstPoolEntry
{
	T value;
	bool isConst;
};

void IR_ConstantPropagate()
{
	ConstPoolEntry<u32> constPool[19]; //make room for temps, but they won't be stored out

	IROp *prev = IR_First(); 
	if (!prev) return;
	IROp *op = prev->next;

	//setup constant pool to no constants
	for (int i=0; i<19; i++)
		constPool[i].isConst=false; //no need to clear values

	//PC is always const, no need to specialcase
	constPool[15].isConst=true; //always

	bool inBranch = false;
	bool pcWritten = false;

	// do the constant propagation
	while (op)
	{
		bool noNext = false;

		// make sure that PC reads are properly accounted for
		int pcoff = compiler_thumb?4:8;
		if (op->op == IR_STOREWORD) //maybe the others too?
			pcoff+=compiler_thumb?2:4;

		if (!pcWritten) //pc is sometimes written in last few instructions of a block, if so don't set the value
			constPool[15].value = op->pc + pcoff;

		// go through inputs of op, if any are in constant pool, change them to constants
		for (int i=0; i<irOpInfo[op->op].numInputRegs; i++)
		{
			if (!op->in[i].isImmediate)
			{
				if (constPool[op->in[i].reg].isConst)
				{
					op->in[i].isImmediate = true;
					op->in[i].value = constPool[op->in[i].reg].value;
				}
			}
		}

		for (int i=0; i<irOpInfo[op->op].numOutputRegs; i++)
		{
			if (op->out[i] == ARM_REG_PC)
			{
				pcWritten = true;
				constPool[ARM_REG_PC].isConst = false;
			}
		}
		//assume it wasn't constant
		bool writeWasConstant[2] = {false,false};

		switch(op->op) {
		case IR_BRANCH:
			inBranch = true;
			break;
		case IR_BRANCHTARGET:
			if (inBranch)
			{
				inBranch = false;
			}
			else
			{
				IROp *oldlast = last;
				last=prev;
				//insert all lost constants!
				//should invalidate all variables THAT ARE CHANGED inside the loop.
				//TODO: add detailed check for this
				for (int i=0; i<15; i++)
				{
					if (constPool[i].isConst)
					{
						IR_Add(IR_MOV,0,i,IRImm(constPool[i].value));
						constPool[i].isConst = false;
						constPool[i].value = 0xbaadf00d;
					}
				}
				last->next=op;
				last=oldlast;
				//op=op->next;
				//noNext = true;
				//we've found a backward branch (not supported yet)
				//here we must kill all constants BEFORE doing anything
			}
			break;
		case IR_MOV:
			{
				/*
				// add to constant pool
				if (op->out[0]!=15 && op->in[0!=15 && op->in[0].isImmediate && !inBranch) //do not create constants in conditionals
				{
					constPool[op->out[0]].isConst = true;
					constPool[op->out[0]].value = op->in[0].value;
					writeWasConstant[0] = true;
					//remove this op
					prev->next = op->next;
					op=op->next;
					noNext = true;
				}*/
			}
			break;


#define FIXUPOP(THEIR,THEOP) \
		case THEIR: \
			{ \
				if (!inBranch && op->in[0].isImmediate && op->in[1].isImmediate && !op->outputFlags) \
				{ \
					constPool[op->out[0]].isConst = true; \
					constPool[op->out[0]].value = op->in[0].value THEOP op->in[1].value; \
					writeWasConstant[0] = true; \
					prev->next = op->next; \
					op=op->next; \
					noNext = true; \
				} \
			} \
			break; 

		//constant propagation
		FIXUPOP(IR_OR,  |  );
		FIXUPOP(IR_AND, &  );
		FIXUPOP(IR_XOR, ^  );
		FIXUPOP(IR_ADD, +  );
		FIXUPOP(IR_SUB, -  );
		FIXUPOP(IR_LSL, << );
		FIXUPOP(IR_LSR, >> );


		case IR_LEAVE: 
			{
				last=prev;
				//insert all lost constants!
				//note! does not invalidate constants, we will continue compiling if the branch is conditional
				for (int i=0; i<15; i++)
				{
					if (constPool[i].isConst)
					{
						IR_Add(IR_MOV,0,i,IRImm(constPool[i].value));
						//if (op->next == 0 || op->next->next==0)
						//	constPool[i].isConst == false;
					}
				}
				last->next=op;
				//op->next=0;
				//if (!inBranch)
				//	return;
			}
			break;
		}

		if (!noNext)
		{
			// invalidate constants in the pool if the current instruction has overwritten them with something non const
			for (int i=0; i<irOpInfo[op->op].numOutputRegs; i++)
			{
				if (constPool[op->out[i]].isConst && !writeWasConstant[i])
				{
					constPool[op->out[i]].isConst = false;
				}
			}
			prev=op;
			op=op->next;
		}
	}
	last=prev;
	//readd all the constant loads!
	for (int i=0; i<15; i++)
	{
		if (constPool[i].isConst)
		{
			IR_Add(IR_MOV,0,i,IRImm(constPool[i].value));
		}
	}
}



void IR_Optimize()
{
	IROp *prev = IR_First();
	if (!prev) return;
	IROp *op = prev->next;
	bool inBranch = false;
	bool canMerge = true;
	int rFlags=0;
	while (op)
	{
		bool noNext = false;
		if (inBranch && ((op->outputFlags & rFlags)!=0))
			canMerge = false;

		switch (op->op) 
		{
		case IR_BRANCH:
			inBranch = true;
			canMerge = true;
			rFlags = relevantFlags[op->in[0].value];
			break;
		case IR_BRANCHTARGET:
			//merging should NOT be done if an instruction inside the branch modifies relevant flags!!
			if (inBranch)
			{
				if (canMerge && op->next && op->next->next)
				{
					if (op->next->op == IR_BRANCH && op->next->in[0].value == op->in[0].value) //same condition?
					{
						prev->next = op->next->next;
						op=op->next->next;
						noNext = true;
					}
					else
						inBranch=false;
				}
				else
					inBranch = false;
			}
			break;
		case IR_AND:
		case IR_OR:
		case IR_ADD:
		case IR_XOR:
		case IR_MUL:
		case IR_TST:
		case IR_TEQ:
			{
				if (op->in[0].isImmediate && !op->in[1].isImmediate)
				{
					IRInput<u32> temp=op->in[0];
					op->in[0] = op->in[1];
					op->in[1] = temp;
				}
			}
			break; 
		}
		if (!noNext)
		{
			prev=op;
			op=op->next;
		}
	}
}


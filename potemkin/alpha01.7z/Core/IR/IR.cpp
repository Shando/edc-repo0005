#include "stdafx.h"

#include "../ARM/ARM.h"
#include "../ARM/ARMTables.h"
#include "IR.h"
#include "IRTables.h"
#include "IRDisasm.h"
#include "IROptimizer.h"
#include "../Util/Pool.h"

Pool<IROp,32768> opPool;


static IROp *first;
static bool inBranch;
static u32 branchCond;
static int irCycles;

IROp *last;

IROp *IR_First() {return first;}
IROp *IR_Last()  {return last;}
IROp *IR_Alloc() {return opPool.Alloc();}

u32 IRInput<u32>::GetValue()
{
	if (isImmediate)
		return value;
	else
		return currentCPU->GetGPR32Value(reg);
}

u32 branchID;

void IR_Start()
{
	branchID=0;
	opPool.Reset();
	first=last=opPool.Alloc();
	first->op = IR_NOP;
}

void IR_Add(IROpID id, int outFlags, IROutput out, IRInput<u32> in1, IRInput<u32> in2, IRInput<u32> in3, int out2)
{
	IROp *op = opPool.Alloc();
	last->next=op;
	last=op;
	op->next=0;
	op->op = id;
	op->in[0] = in1;
	op->in[1] = in2;
	op->in[2] = in3;
	op->out[0] = out;
	op->out[1] = out2;
	op->pc = compiler_pc;
	op->outputFlags = outFlags;
}

void IR_InsertBranchTarget(u32 pc, int cond, int id)
{
	IROp *nop = opPool.Alloc();
	
	nop->pc = pc;
	nop->op = IR_BRANCHTARGET;
	nop->in[0] = IRImm((u32)cond);
	nop->in[1] = IRImm((u32)id);

	IROp *prev = first;
	IROp *op = prev->next;
	
	while (op)
	{
		if (op->pc == pc)
		{
			nop->next=op;
			prev->next=nop;
			return;
		}
		else if (op->pc > pc)
		{
			return;
		}
		prev=op;
		op=op->next;
	}
}

int IR_Count()
{
	if (!first)
		return 0;
	IROp *op = first->next;
	int count = 0;
	while (op)
	{
		count++;
		op=op->next;
	}
	return count;
}

void IR_Linearize(IROp *dest)
{
	_dbg_assert_msg_(CPU,first!=0,"Attempted to linearize an empty IR list");
	IROp *op = first->next;
	while (op)
	{
		*dest = *op;
		dest->next=dest+1; // setup next pointers anyway..
		dest++;
		op=op->next;
	}
}


void IR_StartBranch(int condition)
{
	if (condition != COND_AL && condition != COND_ERR)
	{
		IR_Add(IR_BRANCH,0,0,IRImm(conditionOpposite[condition]),IRImm(branchID));
		branchCond = conditionOpposite[condition];
		inBranch=true;
	}
	else
		inBranch=false;
}

void IR_EndBranch()
{
	if (inBranch)
	{
		IR_Add(IR_BRANCHTARGET,0,0,IRImm(branchCond),IRImm(branchID));
		branchID++;
	}
}

bool IR_IsInBranch()
{
	return inBranch;
}



void IR_End(int numCycles)
{
	IR_Transform();
	irCycles=numCycles;
}

int IR_GetCycles()
{
	return irCycles;
}

int IR_DisasmToLog()
{
	int count=0;
	if (!first)
		return 0;
	IROp *op = first->next;
	while (op)
	{
		char temp[256];
		IR_Dis(*op,temp);
		LOG(CPU,"%08x | %s",op->pc,temp);
		op=op->next;
		count++;
	}
	return count;
}



int IR_FindNextReadUse(IROp *start, int reg)
{
	int count = 0;
	IROp *op = start;
	while (op)
	{
		for (int i=0; i<irOpInfo[op->op].numInputRegs; i++)
		{
			if (op->in[i]==reg)
				return count;
		}
		op=op->next;
		count++;
	}
	return 0xffffff; //far away
}

int IR_FindNextWriteUse(IROp *start, int reg)
{
	int count = 0;
	IROp *op = start;
	while (op)
	{
		for (int i=0; i<irOpInfo[op->op].numOutputRegs; i++)
		{
			if (op->out[i]==reg)
				return count;
		}
		op=op->next;
		count++;
	}
	return 0xffffff; //far away
}

// could be useful for the regalloc ..
int IR_FindNextUse(IROp *start, int reg)
{
	int a = IR_FindNextWriteUse(start,reg);
	int b = IR_FindNextReadUse(start,reg);
	return min(a,b);
}

struct RegAllocation
{
	int x86regs[8]; //contains the arm reg they contain, if any (else -1)
};

void Reconcile(RegAllocation &target, RegAllocation &other)
{
	for (int i=0; i<8; i++)
	{
		int r = target.x86regs[i];
		if (r != -1)
		{
			if (other.x86regs[i] == r)
			{
				//do nothing
			}
			else
			{
				//two cases: either the reg is elsewhere, or it isn't mapped
				//find out if it's the first ..
				int index = -1;
				for (int j=0; j<8; j++)
				{
					if (other.x86regs[i] == r)
					{
						index = j;
						break;
					}
				}

				if (index != -1)
				{
					//MOV_Reg2ToReg1(1,i,index);
				}
				else
				{
					//load the reg
				}
			}
		}
	}
	//we also have to flush the regs of other that are not mapped in target .. how to do that ..
}


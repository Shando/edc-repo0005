#pragma	once

bool Test(TCHAR *text);
#pragma once

#include "../../Globals.h"

extern u32 disPC;

namespace SH4Dis
{
	void Dis_Unknown(u32 op, char *out);
	void Dis_Unimpl(u32 op, char *out);

	void Dis_RelBranch2(u32 op, char *out);
	void Dis_RelBranch(u32 op, char *out);
	void Dis_Generic(u32 op, char *out);
	void Dis_IType(u32 op, char *out);
	void Dis_ITypeMem(u32 op, char *out);
	void Dis_RType3(u32 op, char *out);
	void Dis_ShiftType(u32 op, char *out);

	void Dis_JumpType(u32 op, char *out);
}

#pragma once

#include "../../Globals.h"


namespace SH4Int
{
	void Int_Unknown(u32 op);
	void Int_Unimpl(u32 op);

	void Int_RelBranch2(u32 op);
	void Int_RelBranch(u32 op);
	void Int_Generic(u32 op);
	void Int_IType(u32 op);
	void Int_ITypeMem(u32 op);
	void Int_RType3(u32 op);
	void Int_ShiftType(u32 op);

	void Int_JumpType(u32 op);
}

#include "stdafx.h"
#include "SH4.h"
#include "SH4Tables.h"

SH4State SH4r4k;
SH4State *currentSH4;


void SH4State::Reset()
{
	for (int i=0; i<32; i++)
		r[i]=0;

  hi=0;
  lo=0;
}



TCHAR *SH4State::GetName()
{
	return _T("SH432 R4K");
}



void SH4State::Irq()
{
//	if (IRQEnabled())
	{
//		spsr_irq = GetCPSR();
//		r14_irq = r[SH4_REG_PC] - (thumb ? 2 : 4);
//		ModeSwitch(SH4MODE_IRQ,true);
//		cpsr = (cpsr & 0xFFFFFF80 | SH4_F_MASK) | SH4MODE_IRQ | SH4_I_MASK;
//		thumb = 0;
//
//		r[SH4_REG_PC] = highVectors?0xFFFF0018:0x00000018;
	}
}


void SH4State::SWI()
{
//	bool savedThumb = thumb;
//	r14_svc = r[SH4_REG_PC] /* + (thumb ? 2 : 4)*/; //should be instruction after current one
//	spsr_svc = GetCPSR();
//	ModeSwitch(SH4MODE_SUPER,true);
//	cpsr = (cpsr & 0xFFFFFF80) | SH4MODE_SUPER | SH4_I_MASK;
//	thumb=0;
//	r[SH4_REG_PC] = highVectors ? 0xFFFF0008:0x00000008;
}
 
void SH4State::UndefInstr()
{

}

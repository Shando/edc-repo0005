#include "stdafx.h"
#include "SH4Dis.h"
#include "SH4Tables.h"


namespace SH4Dis
{
	void Dis_Generic(u32 op, char *out)
	{
		sprintf(out, "%s\t ", SH4GetName(op));
	}

	void Dis_RelBranch(u32 op, char *out)
	{
		u32 off = disPC;
		int imm = (signed short)(op&0xFFFF)<<2;
		int rs = (op>>21) & 0x1F;
		off += imm + 4;

		const char *name = SH4GetName(op);
		sprintf(out, "%s\tr%d, ->$%08x",name,rs,off);
	}


	void Dis_RelBranch2(u32 op, char *out)
	{
		u32 off = disPC;
		int imm = (signed short)(op&0xFFFF)<<2;
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		off += imm + 4;

		const char *name = SH4GetName(op);
		sprintf(out, "%s\tr%d, r%d, ->$%08x",name,rt,rs,off);
	}

	void Dis_IType(u32 op, char *out)
	{
		int imm = (signed short)(op&0xFFFF);
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		const char *name = SH4GetName(op);
		sprintf(out, "%s\tr%d, r%d, %i",name,rt,rs,imm);
	}

	void Dis_ITypeMem(u32 op, char *out)
	{
		int imm = (signed short)(op&0xFFFF);
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		const char *name = SH4GetName(op);
		sprintf(out, "%s\tr%d, %i(r%d)",name,rt,imm,rs);
	}

	void Dis_RType3(u32 op, char *out)
	{
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		int rd = (op>>11) & 0x1F;
		int sa = (op>>6) & 0x1F;
		const char *name = SH4GetName(op);
		sprintf(out, "%s\tr%d, r%d, r%d",name,rd,rs,rt);
	}

	void Dis_ShiftType(u32 op, char *out)
	{
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		int rd = (op>>11) & 0x1F;
		int sa = (op>>6) & 0x1F;
		const char *name = SH4GetName(op);
		sprintf(out, "%s\tr%d, r%d, %d",name,rd,rt,sa);
	}

	void Dis_JumpType(u32 op, char *out)
	{
		u32 off = ((op & 0x3FFFFFF) << 2);
		u32 addr = (disPC & 0xF0000000) | off;
		const char *name = SH4GetName(op);
		sprintf(out, "%s\t->$%08x",name,addr);
		
	}
}

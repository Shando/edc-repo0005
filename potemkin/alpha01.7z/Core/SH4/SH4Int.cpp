#include "stdafx.h"
#include "SH4.h"
#include "SH4Int.h"
#include "SH4Tables.h"


namespace SH4Int
{
	void Int_Generic(u32 op)
	{
		//sprintf(out, "%s\t ", SH4GetName(op));
	}

	void Int_RelBranch(u32 op)
	{
		u32 off = currentSH4->GetPC();
		int imm = (signed short)(op&0xFFFF)<<2;
		int rs = (op>>21) & 0x1F;
		off += imm + 4;

//		sprintf(out, "%s\tr%d, ->$%08x",name,rs,off);
	}


	void Int_RelBranch2(u32 op)
	{
		u32 off = currentSH4->GetPC();
		int imm = (signed short)(op&0xFFFF)<<2;
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		off += imm + 4;

//		sprintf(out, "%s\tr%d, r%d, ->$%08x",name,rt,rs,off);
	}

	void Int_IType(u32 op)
	{
		int simm = (signed short)(op&0xFFFF);
		unsigned int uimm = (unsigned short)(op&0xFFFF);
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		if (rt == 0) //destination register is zero register
			return; //nop
		switch (op>>26) 
		{
		case 8: //addi
			currentSH4->r[rt] = currentSH4->r[rs] + simm;
			//do more shit
			break;
		case 9: //addiu
			currentSH4->r[rt] = currentSH4->r[rs] + simm;
			break;
		case 10: //slti
			currentSH4->r[rt] = (int)currentSH4->r[rs] < simm;
			break;
		case 11: //sltiu
			currentSH4->r[rt] = currentSH4->r[rs] < uimm;
			break;
		case 12: //andi
			currentSH4->r[rt] = currentSH4->r[rs] & uimm;
			break;
		case 13: //xori
			currentSH4->r[rt] = currentSH4->r[rs] ^ uimm;
			break;
		case 14: //ori
			currentSH4->r[rt] = currentSH4->r[rs] | uimm;
			break;
		case 15: //lui
			currentSH4->r[rt] = uimm<<16;
			break;
		}
//		sprintf(out, "%s\tr%d, r%d, %i",name,rt,rs,imm);
	}

	void Int_ITypeMem(u32 op)
	{
		int imm = (signed short)(op&0xFFFF);
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		u32 addr = currentSH4->r[rs] + imm;
		switch (op >> 26) 
		{
		case 32: //lb
			currentSH4->r[rt] = ReadMem8(addr); 
			break;
		case 33: //lh
			currentSH4->r[rt] = ReadMem16(addr); 
			break;
		case 34: //lwl
			//currentSH4->r[rt] = ReadMem32(addr); 
			break;
		case 35: //lw
			currentSH4->r[rt] = ReadMem32(addr); 
			break;

		case 40: //sb
			WriteMem8(addr, currentSH4->r[rt]); 
			break;
		case 41: //sh
			WriteMem16(addr, currentSH4->r[rt]); 
			break;
		case 42: //swl
			//currentSH4->r[rt] = ReadMem32(addr); 
			break;
		case 43: //sw
			WriteMem32(addr, currentSH4->r[rt]); 
			break;



		}
//		sprintf(out, "%s\tr%d, %i(r%d)",name,rt,imm,rs);
	}

	void Int_RType3(u32 op)
	{
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		int rd = (op>>11) & 0x1F;
		int sa = (op>>6) & 0x1F;

		switch (op & 31) 
		{
		case 32: //add
			currentSH4->r[rd] = currentSH4->r[rs] + currentSH4->r[rt];
			//more?
			break;
		case 33: //addu
			currentSH4->r[rd] = currentSH4->r[rs] + currentSH4->r[rt];
			break;
		case 34: //sub
			currentSH4->r[rd] = currentSH4->r[rs] - currentSH4->r[rt];
			//more?
			break;
		case 35: //subu
			currentSH4->r[rd] = currentSH4->r[rs] - currentSH4->r[rt];
			break;

		case 36: //and
			currentSH4->r[rd] = currentSH4->r[rs] & currentSH4->r[rt];
			break;
		case 37: //or
			currentSH4->r[rd] = currentSH4->r[rs] | currentSH4->r[rt];
			break;
		case 38: //xor
			currentSH4->r[rd] = currentSH4->r[rs] ^ currentSH4->r[rt];
			break;
		case 39: //nor
			currentSH4->r[rd] = ~(currentSH4->r[rs] | currentSH4->r[rt]);
			break;

		case 42: //slt
//			currentSH4->r[rd] = (int)currentSH4->r[rs] < (int)currentSH4->r[rt];
			break;

		case 43: //sltu
//			currentSH4->r[rd] = currentSH4->r[rs] < currentSH4->r[rt];
			break;

		}
//		sprintf(out, "%s\tr%d, r%d, r%d",name,rd,rs,rt);
	}


	void Int_ShiftType(u32 op)
	{
		int rt = (op>>16) & 0x1F;
		int rs = (op>>21) & 0x1F;
		int rd = (op>>11) & 0x1F;
		int sa = (op>>6) & 0x1F;
		
		switch (op & 31)
		{
		case 0: //sll
			currentSH4->r[rd] = currentSH4->r[rt] << sa;
			break;
		case 2: //srl
			currentSH4->r[rd] = currentSH4->r[rt] >> sa;
			break;
		case 3: //sra
			currentSH4->r[rd] = ((s32)currentSH4->r[rt]) >> sa;
			break;
		case 4: //sllv
			currentSH4->r[rd] = currentSH4->r[rt] << currentSH4->r[rs];
			break;
		case 6: //srlv
			currentSH4->r[rd] = currentSH4->r[rt] >> sa;
			break;
		case 7: //srav
			currentSH4->r[rd] = ((s32)currentSH4->r[rt]) >> currentSH4->r[rs];
			break;
		}
	}

	void Int_JumpType(u32 op)
	{
		u32 off = ((op & 0x3FFFFFF) << 2);
//		u32 addr = (disPC & 0xF0000000) | off;
//		sprintf(out, "%s\t->$%08x",name,addr);
	}
}

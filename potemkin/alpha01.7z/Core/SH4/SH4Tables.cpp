#include "stdafx.h"
#include "SH4Tables.h"

#include "SH4.h"
#include "SH4Dis.h"
#include "SH4Int.h"

/*
#include "SH4Compiler.h"
#include "SH4Info.h"
#include "SH4LoadStore.h"
#include "SH4Branch.h"
#include "SH4DataProcessing.h"
#include "SH4Interpret.h"
*/

typedef void (CDECL *SH4CompileFunc)(u32 opcode);
typedef void (CDECL *SH4DisFunc)(u32 opcode, TCHAR *out);
typedef SH4InstructionInfo (CDECL *SH4InfoFunc)(u32 opcode);
typedef void (CDECL *SH4InterpretFunc)(u32 opcode);


// convert to table index
#define CRUNCH_SH4_OP(op) (((op>>16)&0xFF0)|((op>>4)&0xF))


enum SH4Encoding
{
	Imme, Spec, Spe2, Spe3, RegI, Cop2, Cop2BC2, Cop0, Cop0CO, Cop2Rese, CopU, NumEncodings, Rese
};

const int encodingFirstBit[NumEncodings] =
{
	26, //IMME
	0,  //Special
	0,  //special2
	0,  //special3
	16, //RegImm
	21, //Cop2
	16, //Cop2BC2
	21, //Cop0
	0,  //Cop0CO
};


const int encodingBits[NumEncodings] =
{
	6, //IMME
	6, //Special
	6, //special2
	6, //special3
	5, //RegImm;
	5, //Cop2
	2, //Cop2BC2
	5, //Cop0
	6  //Cop0CO
};


const SH4Encoding encodingType[64] = 
{
	Spec, RegI, Imme, Imme, Imme, Imme, Imme, Imme, 
	Imme, Imme, Imme, Imme, Imme, Imme, Imme, Imme, 
	Cop0, CopU, Cop2, CopU, Imme, Imme, Imme, Imme,
	Rese, Rese, Rese, Rese, Spe2, Imme, Rese, Spe3,
	Imme, Imme, Imme, Imme, Imme, Imme, Imme, Rese,
	Imme, Imme, Imme, Imme, Rese, Rese, Imme, Imme, 
	Imme, CopU, Imme, Imme, Rese, CopU, Rese, Rese,
	Imme, CopU, Imme, Rese, Rese, CopU, Rese, Rese,
};


struct SH4Instruction
{
	int altEncoding;
	char *name;
	SH4CompileFunc compile;
	SH4DisFunc disasm;
	SH4InterpretFunc interpret;
	SH4InstructionInfo information;
};

using namespace SH4Dis;
using namespace SH4Int;
//regregreg instructions
const SH4Instruction tableImmediate[64] = 
{
	//0
	{-2},//invalid
	{-2},//invalid 
	{-1, "j",    0, Dis_JumpType},
	{-1, "jal",  0, Dis_JumpType},
	{-1, "beq",  0, Dis_RelBranch2},
	{-1, "bne",  0, Dis_RelBranch2},
	{-1, "blez", 0, Dis_RelBranch},
	{-1, "bgtz", 0, Dis_RelBranch},
	//8
	{-1, "addi",  0, Dis_IType, Int_IType},
	{-1, "addiu", 0, Dis_IType, Int_IType},
	{-1, "slti",  0, Dis_IType, Int_IType},
	{-1, "sltiu", 0, Dis_IType, Int_IType},
	{-1, "andi",  0, Dis_IType, Int_IType},
	{-1, "ori",   0, Dis_IType, Int_IType},
	{-1, "xori",  0, Dis_IType, Int_IType},
	{-1, "lui",   0, Dis_IType, Int_IType},
	//16
	{-2}, //cop0
	{-2}, //copU
	{-2}, //cop2
	{-2}, //copU
	{-1, "beql", 0, Dis_RelBranch2}, //L = likely
	{-1, "bnel", 0, Dis_RelBranch2},
	{-1, "blezl", 0, Dis_RelBranch},
	{-1, "bgtzl", 0, Dis_RelBranch},
	//24
	{-2},{-2},{-2},{-2},
	{-2},//special2
	{-1, "jalx", 0, Dis_Generic},
	{-2},
	{-2},//special3
	//32
	{-1, "lb",  0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "lh",  0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "lwl", 0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "lw",  0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "lbu", 0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "lhu", 0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "lwr", 0, Dis_ITypeMem, Int_ITypeMem},
	{-2},
	//40
	{-1, "sb",  0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "sh",  0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "swl", 0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "sw",  0, Dis_ITypeMem, Int_ITypeMem},
	{-2},
	{-2},
	{-1, "swr", 0, Dis_ITypeMem, Int_ITypeMem},
	{-1, "cache", 0, Dis_Generic},
	//48
	{-1, "ll", 0, Dis_Generic},
	{-2}, //copU
	{-1, "lwc2", 0, Dis_Generic},
	{-1, "pref", 0, Dis_Generic},
	{-2},
	{-2}, //copU
	{-2},
	{-2},
	//56
	{-1, "sc", 0, Dis_Generic},
	{-2}, //copU
	{-1, "lwc2", 0, Dis_Generic},
	{-2}, {-2},
	{-2}, //copU
	{-2}, {-2},
};

const SH4Instruction tableSpecial[64] = 
{
	{-1, "sll",   0, Dis_ShiftType, Int_ShiftType},
	{-2}, //copu
	
	{-1, "slr",   0, Dis_ShiftType, Int_ShiftType},
	{-1, "sra",   0, Dis_ShiftType, Int_ShiftType},
	{-1, "sllv",  0, Dis_ShiftType, Int_ShiftType},
	{-2},
	{-1, "srlv",  0, Dis_ShiftType, Int_ShiftType},
	{-1, "srav",  0, Dis_ShiftType, Int_ShiftType},

	//8
	{-1, "jr",    0, Dis_JumpType},
	{-1, "jalr",  0, Dis_JumpType},
	{-1, "movz",  0, Dis_Generic},
	{-1, "movn",  0, Dis_Generic},
	{-1, "syscall", 0, Dis_Generic},
	{-1, "break", 0, Dis_Generic},
	{-2},
	{-1, "sync",  0, Dis_Generic},

	//16
	{-1, "mfhi",  0, Dis_Generic},
	{-1, "mthi",  0, Dis_Generic},
	{-1, "mflo",  0, Dis_Generic},
	{-1, "mtlo",  0, Dis_Generic},
	{-2},
	{-2},
	{-2},
	{-2},

	//24
	{-1, "mult",  0, Dis_Generic},
	{-1, "multu", 0, Dis_Generic},
	{-1, "div",   0, Dis_Generic},
	{-1, "divu",  0, Dis_Generic},
	{-2},
	{-2},
	{-2},
	{-2},

	//32
	{-1, "add",  0, Dis_RType3, Int_RType3},
	{-1, "addu", 0, Dis_RType3, Int_RType3},
	{-1, "sub",  0, Dis_RType3, Int_RType3},
	{-1, "subu", 0, Dis_RType3, Int_RType3},
	{-1, "and",  0, Dis_RType3, Int_RType3},
	{-1, "or",   0, Dis_RType3, Int_RType3},
	{-1, "xor",  0, Dis_RType3, Int_RType3},
	{-1, "nor",  0, Dis_RType3, Int_RType3},

	//40
	{-2},
	{-2},
	{-1, "slt",  0, Dis_RType3, Int_RType3},
	{-1, "sltu", 0, Dis_RType3, Int_RType3},
	{-2},
	{-2},
	{-2},
	{-2},

	//48
	{-1, "tge",  0, Dis_RType3},
	{-1, "tgeu", 0, Dis_RType3},
	{-1, "tlt",  0, Dis_RType3},
	{-1, "tltu", 0, Dis_RType3},
	{-1, "teq",  0, Dis_RType3},
	{-2},
	{-1, "tne",  0, Dis_RType3},
	{-2},

	//56
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
};

const SH4Instruction tableSpecial2[64] = 
{
	{-1, "madd", 0, Dis_Generic},
	{-1, "maddu", 0, Dis_Generic},
	{-1, "mul", 0, Dis_Generic},
	{-2},
	{-1, "msub", 0, Dis_Generic},
	{-1, "msubu", 0, Dis_Generic},
	{-2},
	{-2},

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	{-1, "clz", 0, Dis_Generic},
	{-1, "clo", 0, Dis_Generic},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, 

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, 
	{-1, "sdbbp", 0, Dis_Generic},
};

const SH4Instruction tableSpecial3[64] = 
{
	{-1, "ext", 0, Dis_Generic},
	{-2},
	{-2},
	{-2},
	{-1, "ins", 0, Dis_Generic},
	{-2},
	{-2},
	{-2},

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	{-1, "bshfl", 0, Dis_Generic},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	{-2}, {-2}, {-2}, 
	{-1, "rdhwr", 0, Dis_Generic},
	{-2}, {-2}, {-2}, {-2},
};


const SH4Instruction tableRegImm[32] = 
{
	{-1, "bltz", 0, Dis_RelBranch},
	{-1, "bgez", 0, Dis_RelBranch},
	{-1, "bltzl", 0, Dis_RelBranch},
	{-1, "bgezl", 0, Dis_RelBranch},
	{-2},
	{-2},
	{-2},
	{-2},

	{-1, "tgei", 0, Dis_Generic},
	{-1, "tgeiu", 0, Dis_Generic},
	{-1, "tlti", 0, Dis_Generic},
	{-1, "tltiu", 0, Dis_Generic},
	{-1, "teqi", 0, Dis_Generic},
	{-2},
	{-1, "tnei", 0, Dis_Generic},
	{-2},

	{-1, "bltzal", 0, Dis_RelBranch},  
	{-1, "bgezal", 0, Dis_RelBranch},
	{-1, "bltzall", 0, Dis_RelBranch}, //L = likely
	{-1, "bgezall", 0, Dis_RelBranch},
	{-2},
	{-2},
	{-2},
	{-2},

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, 
	{-1, "synci", 0, Dis_Generic},
};

const SH4Instruction tableCop2[32] = 
{
	{-1, "mfc2", 0, Dis_Generic},
	{-2},
	{-1, "cfc2", 0, Dis_Generic},
	{-1, "mfhc2", 0, Dis_Generic},
	{-1, "mtc2", 0, Dis_Generic},
	{-2},
	{-1, "ctc2", 0, Dis_Generic},
	{-1, "mthc2", 0, Dis_Generic},

	{Cop2BC2},
	{-1, "??", 0, Dis_Generic},
	{-1, "??", 0, Dis_Generic},
	{-1, "??", 0, Dis_Generic},
	{-1, "??", 0, Dis_Generic},
	{-1, "??", 0, Dis_Generic},
	{-1, "??", 0, Dis_Generic},
	{-1, "??", 0, Dis_Generic},

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
};

const SH4Instruction tableCop2BC2[4] = 
{
	{-1, "bc2f", 0, Dis_Generic},
	{-1, "bc2t", 0, Dis_Generic},
	{-1, "bc2fl", 0, Dis_Generic},
	{-1, "bc2tl", 0, Dis_Generic},
};

const SH4Instruction tableCop0[32] = 
{
	{-1, "mfc0", 0, Dis_Generic},
	{-2}, 
	{-2}, 
	{-2}, 
	{-1, "mtc0", 0, Dis_Generic},
	{-2}, 
	{-2}, 
	{-2}, 

	{-2}, 
	{-2}, 
	{-1, "rdpgpr", 0, Dis_Generic},
	{-1, "mfmc0", 0, Dis_Generic},

	{-2}, 
	{-2}, 
	{-1, "wrpgpr", 0, Dis_Generic},
	{-2}, 

	{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},
	{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},
};

SH4Instruction tableCop0CO[64] = 
{
	{-2}, 
	{-1, "tlbr", 0, Dis_Generic},
	{-1, "tlbwi", 0, Dis_Generic},
	{-2}, 
	{-2}, 
	{-2}, 
	{-1, "tlbwr", 0, Dis_Generic},
	{-2}, 

	{-1, "tlbp", 0, Dis_Generic},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, 
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	{-1, "eret", 0, Dis_Generic},
	{-1, "iack", 0, Dis_Generic},
	{-2}, {-2}, {-2}, {-2}, {-2}, 
	{-1, "deret", 0, Dis_Generic},

	{-1, "wait", 0, Dis_Generic},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
};


const SH4Instruction *SH4Tables[NumEncodings] =
{
	tableImmediate,
	tableSpecial,
	tableSpecial2,
	tableSpecial3,
	tableRegImm,
	tableCop2,
	tableCop2BC2,
	tableCop0,
	tableCop0CO
};

//arm encoding table
//const SH4Instruction SH4instructions[] = 
//{
//{Comp_Unimpl,Dis_Unimpl, Info_NN,    0, 0x601,       0x1FE,0}, //could be used for drec hook :) bits 5-24 plus 0-3 are available, 19 bits are more than enough
// DATA PROCESSING INSTRUCTIONS
//                        S
//	{Comp_AND,   Dis_AND,    Info_DP,    0, DATAP(0, 0), 0x20F, {0}},
//};

struct SH4TableRow
{
	SH4CompileFunc compile;
	SH4DisFunc disasm;
	SH4InfoFunc getinfo;
	SH4InterpretFunc interpret;
	SH4InstructionInfo information;
};


const SH4Instruction *SH4GetInstruction(u32 op)
{
	SH4Encoding encoding = encodingType[op >> 26];
	SH4Encoding original = encoding;
	const SH4Instruction *instr = 0;
	do 
	{
		const SH4Instruction *table = SH4Tables[encoding];
		int mask = ((1<<encodingBits[encoding])-1);
		int shift = encodingFirstBit[encoding];
		int subop = (op >> shift) & mask;
		instr = &table[subop];
		if (encoding == Rese || encoding == CopU)
			return 0; //invalid instruction
		if (!instr)
			return 0;
		if (instr->altEncoding == -2)
		{
			//BAD!!
			return 0; //invalid instruction
		}
		encoding = (SH4Encoding)instr->altEncoding;
	} while (encoding != -1);
	//alright, we have a valid SH4 instruction!
	return instr;
}



void SH4CompileOp(u32 op)
{
	const SH4Instruction *instr = SH4GetInstruction(op);
	if (instr)
		instr->compile(op);
}


void SH4DisAsm(u32 op, u32 pc, char *out)
{
	if (op == 0)
	{
		//ANDEQ R0,R0,R0 is probably not used for legitimate purposes :P
		sprintf(out,"---\t---");
	}
	else
	{
		disPC = pc;
		const SH4Instruction *instr = SH4GetInstruction(op);
		if (instr && instr->disasm)
			instr->disasm(op, out);
		else
			strcpy(out, "");
	}
}


void SH4Interpret(u32 op) //only for those rare ones
{
	//if (atable[CRUNCH_SH4_OP(op)].interpret)
	//		atable[CRUNCH_SH4_OP(op)].interpret(op);
	//	else
	//		_dbg_assert_msg_(SH4,0,"Trying to interpret instruction that can't be interpreted");
	const SH4Instruction *instr = SH4GetInstruction(op);
	if (instr && instr->interpret)
		instr->interpret(op);
	else
		_dbg_assert_msg_(CPU,0,"Trying to interpret instruction that can't be interpreted");
}

const char *SH4GetName(u32 op)
{
	static const char *noname = "unk";
	const SH4Instruction *instr = SH4GetInstruction(op);
	if (!instr)
		return noname;
	else
		return instr->name;
}


SH4InstructionInfo SH4GetInfo(u32 op)
{
	//	int crunch = CRUNCH_SH4_OP(op);
	SH4InstructionInfo info;// = atable[crunch].information;
	return info;
}


#pragma once

#include "../../Globals.h"
//#include "BlockCache.h"
#include "../CPU.h"

enum
{
	SH4_SCRATCH_1=0,
	SH4_SCRATCH_2=1,
	SH4_REG_SP=13,
	SH4_REG_LR=14,
};

class ALIGN16 SH4State : public CPU
{
public:
	SH4State() 
	{
		//		blockCache.armState = this;
	}
	~SH4State() {}
	void Reset();

	u32 r[36]; //space for temp regs
	u32 pc;
	u32 hi;
	u32 lo;

	//	BlockCache blockCache;

	void Irq();
	void SWI();
	void Abort();
	void UndefInstr();


	//overridden functions
	TCHAR *GetName();
	int GetNumGPRs() { return 16; }
	int GetGPRSize() { return GPR_SIZE_32;}
	u32 GetGPR32Value(int reg) {return r[reg];}
	u32 GetPC() {return pc;}
	int GetInstructionSize() {return 2;}
	void SetPC(u32 _pc) {pc=_pc;}
	CPUType GetType() {return CPUTYPE_SH4;}
};


//The one we are compiling or running currently
extern SH4State *currentSH4;

extern SH4State SH4r4k;

void SH4_Init();

void SH4_Shutdown();

void SH4_Irq();
void SH4_SWI();
#pragma once

#include "../../Globals.h"

#define END_BASIC_BLOCK 0x80
#define UNCONDITIONAL 0x40
#define BAD_INSTRUCTION 0x20

struct SH4InstructionInfo
{
  u8 flags;
};

void SH4CompileOp(u32 op);
void SH4DisAsm(u32 op, u32 pc, char *out);
SH4InstructionInfo SH4GetInfo(u32 op);
void SH4Interpret(u32 op); //only for those rare ones

const char *SH4GetName(u32 op);


void FillSH4Tables();

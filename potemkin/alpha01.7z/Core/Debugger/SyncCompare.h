#pragma once

//  Purpose: maintains interprocess communication to make it possible
//  to easily compare any two cpu cores by running two instances of DaSh and 
//  comparing them to each other.

class CPUCompare
{
public:

	// start the server
	static void StartServer(void);

	// connect as client
	static void ConnectAsClient(void);

	// stop
	static void Stop(void);

	// sync
	static void Sync(void);

	// IsEnabled
	static bool IsEnabled(void);

	// IsServer
	static bool IsServer(void);

private:

	static HANDLE m_hPipe;
	static bool   m_bIsServer;
	static bool   m_bEnabled;
};
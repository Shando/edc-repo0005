#include "stdafx.h"

#include "SyncCompare.h"
#include "../MIPS/MIPS.h"


HANDLE CPUCompare::m_hPipe;
bool   CPUCompare::m_bIsServer;
bool   CPUCompare::m_bEnabled;
#define PIPENAME "\\\\.\\pipe\\cpucompare"


void CPUCompare::StartServer(void)
{
	if (m_bEnabled)
		return;
	//TODO: error checking
	m_hPipe = CreateNamedPipe(
		PIPENAME,
		PIPE_ACCESS_OUTBOUND,
		PIPE_WAIT | PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE,
		1, //maxinst
		0x1000, //outbufsize
		0x1000, //inbufsize
		INFINITE, //timeout
		0);
	m_bIsServer = true;
	m_bEnabled = true;
}

void CPUCompare::ConnectAsClient(void)
{
	if (m_bEnabled)
		return;

	//TODO: error checking
	m_hPipe = CreateFile(
		PIPENAME,
		GENERIC_READ,
		0, //share
		NULL,
		OPEN_EXISTING,
		0,
		NULL);
	m_bEnabled = true;

	m_bIsServer = false;
}

void CPUCompare::Stop(void)
{
	if (m_bEnabled)
	{
		if (m_bIsServer)
		{
			DisconnectNamedPipe(m_hPipe);
			//CloseHandle(m_hPipe); ?
		}
		else
		{
			CloseHandle(m_hPipe); //both for server and client i guess
		}
		m_bEnabled=false;
	}
}

void CPUCompare::Sync(void)
{
	//static PowerPC::PowerPCState state;
	if (m_bEnabled)
	{
		if (m_bIsServer)
		{
			//write cpu state to m_hPipe
			/*
			HRESULT result;
			u32 written;
			_dbg_update_();
			//result = WriteFile(m_hPipe, &PowerPC::ppcState, sizeof(PowerPC::ppcState), (LPDWORD)&written,FALSE);
			if (FAILED(result))
			{
				LOG(CPU,"Failed to write cpu state to named pipe");
				Stop();
			}
			_dbg_update_();*/
		}
		else
		{
			/*
			HRESULT result;
			u32 read;
			_dbg_update_();
			//result = ReadFile(m_hPipe, &state, sizeof(state), (LPDWORD)&read,FALSE);
			
			//read cpu state to m_hPipe and compare
			//if any errors, print report
			if (FAILED(result))
			{
				LOG(CPU,"Failed to read cpu state from named pipe");
				Stop();
			}
			else
			{
			//	if ((memcmp(PowerPC::ppcState.gpr,state.gpr,sizeof(state.gpr))!=0) ||
//					(PowerPC::ppcState.Helper[1] != state.Helper[1]) ||
//					(PowerPC::ppcState.cr != state.cr) ||
			//		(PowerPC::ppcState.pc != state.pc))
				{
					int i = 0;
				}
//				else
				{
				}
				
				if (memcmp(&PowerPC::ppcState,&state,sizeof(state))!=0)
				{
					LOG(CPU,"DIFFERENCE!!!!"); //add more info of course
				}
				else
				{
					LOG(CPU,"No difference!");
				}
			}
			*/
			_dbg_update_();
		}
	}
}

bool CPUCompare::IsEnabled(void)
{
	return m_bEnabled;
}

bool CPUCompare::IsServer(void)
{
	return m_bIsServer;
}


#include "stdafx.h"
#include "Logger.h"
#include <windowsx.h>

#include "../../Windows/resource.h"
#include "../../Core/Debugger/SymbolMap.h"
#include "../../globals.h"
#include "../../Core/Core.h"
#include "../../Core/CPU.h"
//extern W32Util::IniFile iniFile;

#define USE_LOG_COUNTER 1

 
CDebugger_Log::CDebugger_Log(const char* _szShortName, const char* _szName)
{
	strcpy((char*)m_szName, _szName);
	strcpy((char*)m_szShortName, _szShortName);
	sprintf((char*)m_szFilename, "logs\\%s.txt", _szShortName);
	
	unlink(m_szFilename);

	m_pFile=fopen(m_szFilename,"w");
/*
	iniFile.SetSection("Logging");

	char temp[256];
	sprintf(temp, "%s_LogToFile", m_szShortName);
	m_bLogToFile = iniFile.ReadBool(temp, true);

	sprintf(temp, "%s_ShowInLog", m_szShortName);
	m_bShowInLog = iniFile.ReadBool(temp, true);

	sprintf(temp, "%s_Enable", m_szShortName);
	m_bEnable    = iniFile.ReadBool(temp, true);
*/
	m_bEnable = true;
	m_bLogToFile = true;
	m_bShowInLog = true;

}

CDebugger_Log::~CDebugger_Log(void)
{
/*	iniFile.SetSection("Logging");
	char temp[256];
	sprintf(temp, "%s_LogToFile", m_szShortName);
	iniFile.WriteBool(temp, m_bLogToFile);
	sprintf(temp, "%s_ShowInLog", m_szShortName);
	iniFile.WriteBool(temp, m_bShowInLog);
	sprintf(temp, "%s_Enable", m_szShortName);
	iniFile.WriteBool(temp, m_bEnable);
	if (m_pFile)
	{
		fclose(m_pFile);
		m_pFile = NULL;
	}*/
}


CDebugger_LogManager::SMessage	CDebugger_LogManager::m_Messages[MAX_MESSAGES];
int						CDebugger_LogManager::m_nextMessages = 0;

CDebugger_Log*			CDebugger_LogManager::m_Log[NUMBER_OF_LOGS];
bool					CDebugger_LogManager::m_bDirty = true;


void
CDebugger_LogManager::Init()
{

	// create Logs
	m_Log[MASTER_LOG]			= new CDebugger_Log("All", "Master Log");
	m_Log[CPU]			        = new CDebugger_Log("CPU", "CPU core(s)");
	m_Log[LOADER]			    = new CDebugger_Log("Loader", "File loaders");
	m_Log[ROM]                  = new CDebugger_Log("ROM", "ROM memory");
	m_Log[IO]					= new CDebugger_Log("IO",  "Input/Output");
	m_Log[COPROCESSOR]			= new CDebugger_Log("CP", "CoProcessor");			
	m_Log[DISPLAYREGS]          = new CDebugger_Log("DISP", "DisplayRegs");			
	m_Log[G2D]					= new CDebugger_Log("G2D", "GBA 2D");		
	m_Log[G3D]					= new CDebugger_Log("G3D", "DS 3D");		
	m_Log[FILESYS]				= new CDebugger_Log("FILE", "File Systems");		
	m_Log[DMA]					= new CDebugger_Log("DMA", "DirectMemoryAccess");	
	m_Log[INTC]					= new CDebugger_Log("INTC", "Interrupt Controller");
	m_Log[MEMMAP]				= new CDebugger_Log("MEM", "Memory Map");			
	m_Log[SOUND]				= new CDebugger_Log("SND", "Sound");	
	m_Log[HLE]				    = new CDebugger_Log("HLE", "High Level Emulation");
	m_Log[TIMER]			    = new CDebugger_Log("TIMER", "Timers");
	m_Log[VIDEO]			    = new CDebugger_Log("Video", "Video-Plugin");
	m_Log[DYNAREC]			    = new CDebugger_Log("DYNA", "Dynamic Recompiler");
	m_Log[G3D]->m_bShowInLog = false;
	m_Log[G3D]->m_bEnable= false;
}



void CDebugger_LogManager::GetContents(TCHAR *out, int activeLog)
{
	TCHAR *p = out;
	int count = 0;
	int i = m_nextMessages;
	while (count < MAX_MESSAGES)
	{
		count++;		

		if (m_Messages[i].m_bInUse)
		{
			int len = m_Messages[i].m_dwMsgLen;
			if (activeLog == MASTER_LOG)
			{
				if (m_Log[m_Messages[i].m_type]->m_bShowInLog)
				{
					memcpy(p,m_Messages[i].m_szMessage,len);
					p+=len;
				}
			}
			else
			{
				if (m_Messages[i].m_type == activeLog)
				{
					memcpy(p,m_Messages[i].m_szMessage,len);
					p+=len;
				}
			}
		}

		i++;
		if (i >= MAX_MESSAGES)
			i = 0;
	}
	*p=0;
}


void CDebugger_LogManager::Clear(void)
{
	for (int i=0;i<MAX_MESSAGES;i++)
	{
		strcpy(m_Messages[i].m_szMessage,"");
		m_Messages[i].m_dwMsgLen = 0;
		m_Messages[i].m_bInUse = false;
	}
	m_nextMessages=0;
	_dbg_update_();
}


void CDebugger_LogManager::Shutdown(void)
{
	// delete all loggers
	for (int i=0; i<NUMBER_OF_LOGS; i++)
	{
		if (m_Log[i] != NULL)
		{
			delete m_Log[i];
			m_Log[i] = NULL;
		}
	}
}










void CDebugger_LogManager::Log(LOG_TYPE _type, char* _fmt, ...)
{
	if (m_Log[_type] == NULL) return;

	if (!m_Log[_type]->m_bEnable)
		return;

	char Msg[512], Msg2[562];
	va_list ap;

	va_start( ap, _fmt );
	vsnprintf_s( Msg, 512, 511, _fmt, ap );
	va_end( ap );
	
	SMessage& Message = m_Messages[m_nextMessages];

#if USE_LOG_COUNTER
	static int count = 0;
	u32 loc = currentCPU->GetPC();
	if (_type == HLE)
		loc = currentCPU->GetLR()-8;
	sprintf(Msg2, "%i: [%s %08x ]: %s", ++count, currentCPU->GetName(), loc, m_Log[_type]->m_szShortName);
#else
	strcpy(Msg2, m_Log[_type]->m_szShortName);
#endif
	
	strcat(Msg2, ": ");
	strcat(Msg2, Msg);

	int symb = Debugger_GetSymbolNum(currentCPU->GetPC());
	if (symb!=-1)
	{
		strcat(Msg2, " (");
		strcat(Msg2, Debugger_GetSymbolName(symb));
		strcat(Msg2, ")");
	}
	Msg2[125]=0;
	strcat(Msg2,"\x0D\x0A");
	Message.Set(_type, Msg2);

	if (m_Log[_type] && m_Log[_type]->m_pFile && m_Log[_type]->m_bLogToFile)
		fprintf(m_Log[_type]->m_pFile,Msg2);
	if (m_Log[MASTER_LOG] && m_Log[MASTER_LOG]->m_pFile && m_Log[_type]->m_bShowInLog)
		fprintf(m_Log[MASTER_LOG]->m_pFile,Msg2);

	m_nextMessages++;
	if (m_nextMessages >= MAX_MESSAGES)
		m_nextMessages = 0;
	m_bDirty=true;

}
#include "stdafx.h"

#include <windowsx.h>

#include "string.h"
#include "../../globals.h"

//#include "../HW/memmap.h"

#include "../../Core/MemMap.h"
#include "SymbolMap.h"

#include <vector>
#include <map>


//need improvement
u32 hasher(u32 last, u32 value)
{
	return _rotl(last,3) ^ value;
}


//#define BWLINKS

u32 ComputeHash(u32 start, u32 size)
{
	u32 hash=0;
	for (unsigned int i=start; i<start+size; i+=4)
		hash = hasher(hash, ReadMem32Unchecked(i));			
	return hash;
}


struct MapEntry
{
	u32 address;
	u32 vaddress;
	u32 size;
	u32 unknown;

	u32 runCount;

	SymbolType type;

#ifdef BWLINKS
	std::vector <u32> backwardLinks;
#endif BWLINKS

	char name[128];

	void UndecorateName()
	{
		
//		char temp[128];
//		char temp2[128];
//		strcpy(temp,name);
//		strcpy(temp2,name);
//		temp[6]=0;
//		if (strcmp(temp,"__ct__"))
//		{
//			sprintf(temp2,"Constructor: %s",temp+7);
//		}
//		else if (strcmp(temp,"__dt__"))
//		{
//			sprintf(temp2,"Destructor: %s",temp+7);
//		}
//		strcpy(name,temp2);
		
	}
};

int numEntries;

MapEntry entries[65536*2];


int compareEntries(const void *p1, const void *p2)
{
	const MapEntry *e1 = (const MapEntry*)p1,
		           *e2 = (const MapEntry*)p2;

	return e1->vaddress - e2->vaddress;
}


void Debugger_SortSymbols()
{
	qsort(entries,numEntries,sizeof(MapEntry),compareEntries);
}

void Debugger_AnalyzeBackwards()
{
#ifndef BWLINKS
	return;
#else
	for (int i=0; i<numEntries; i++)
	{
		u32 ptr = entries[i].vaddress;
		if (ptr)
		{
			if (entries[i].type == ST_FUNCTION)
			{
				for (int a = 0; a<entries[i].size/4; a++)
				{
					u32 inst = CMemory::ReadUncheckedu32(ptr);

					switch (inst>>26)
					{
					case 18:
						{
							if (LK) //LK
							{
								u32 addr;
								if(AA)
									addr = SignExt26(LI << 2);
								else
									addr = ptr + SignExt26(LI << 2);

								int funNum = Debugger_GetSymbolNum(addr);
								if (funNum>=0) 
									entries[funNum].backwardLinks.push_back(ptr);
							}
							break;
						}
					default:
						;
					}

					ptr+=4;
				}
			}
		}
	}
#endif
}


void Debugger_ResetSymbolMap()
{
#ifdef BWLINKS
	for (int i=0; i<numEntries; i++)
	{
		entries[i].backwardLinks.clear();
	}
#endif
	numEntries=0;
}


void Debugger_AddSymbol(const char *symbolname, unsigned int vaddress, size_t size, SymbolType st)
{
	MapEntry &e = entries[numEntries++];
	strcpy(e.name, symbolname);
	e.vaddress = vaddress;
	e.size = size;
	e.type=st;
}

bool Debugger_LoadSymbolMap(const char *filename)
{
	Debugger_ResetSymbolMap();
	numEntries=0;
	FILE *f = fopen(filename,"r");
	if (!f)
		return false;
	//char temp[256];
	//fgets(temp,255,f); //.text section layout
	//fgets(temp,255,f); //  Starting        Virtual
	//fgets(temp,255,f); //  address  Size   address
	//fgets(temp,255,f); //  -----------------------

	bool started=false;

	while (!feof(f))
	{
		char line[512],temp[256];
		fgets(line,511,f);
		if (strlen(line)<4)
			continue;

		sscanf(line,"%s",temp);
		if (strcmp(temp,"UNUSED")==0) continue;
		if (strcmp(temp,".text")==0)  {started=true;continue;};
		if (strcmp(temp,".init")==0)  {started=true;continue;};
		if (strcmp(temp,"Starting")==0) continue;
		if (strcmp(temp,"extab")==0) continue;
		if (strcmp(temp,".ctors")==0) break;
		if (strcmp(temp,".dtors")==0) break;
		if (strcmp(temp,".rodata")==0) continue;
		if (strcmp(temp,".data")==0) continue;
		if (strcmp(temp,".sbss")==0) continue;
		if (strcmp(temp,".sdata")==0) continue;
		if (strcmp(temp,".sdata2")==0) continue;
		if (strcmp(temp,"address")==0)  continue;
		if (strcmp(temp,"-----------------------")==0)  continue;
		if (strcmp(temp,".sbss2")==0) break;
		if (temp[1]==']') continue;

		if (!started) continue;
		MapEntry &e = entries[numEntries++];
		sscanf(line,"%08x %08x %08x %i %s",&e.address,&e.size,&e.vaddress,&e.type,e.name);
		
		if (e.type == ST_DATA && e.size==0)
			e.size=4;
		//e.vaddress|=0x80000000;
		if (strcmp(e.name,".text")==0 || strcmp(e.name,".init")==0 || strlen(e.name)<=1)
			numEntries--;

	}
	for (int i=0; i<numEntries; i++)
		entries[i].UndecorateName();
	fclose(f);
	Debugger_SortSymbols();
//	Debugger_AnalyzeBackwards();
	return true;
}


void Debugger_SaveSymbolMap(const char *filename)
{
	FILE *f = fopen(filename,"w");
	if (!f)
		return;
	bool started=false;
	fprintf(f,".text\n");
	for (int i=0; i<numEntries; i++)
	{
		MapEntry &e = entries[i];
		fprintf(f,"%08x %08x %08x %i %s\n",e.address,e.size,e.vaddress,e.type,e.name);
	}
	fclose(f);
}




int Debugger_GetSymbolNum(unsigned int address, SymbolType symmask)
{
	int start=0;

	int i;
	
	for (i=0; i<numEntries; i+=100)
	{
		if (address >= entries[i].vaddress)
			start = i;
		else
			break;

	}
	
	if (start<0) start=0;

	for (i=start; i<numEntries; i++)
	{
		unsigned int addr = entries[i].vaddress;
		if ((address >= addr))
		{
			if (address < addr+entries[i].size)
			{
				if (entries[i].type & symmask)
					return i;
				else
					return -1;
			}
		}
		else
			break;
	}
	return -1;
}


char temp[256];

char *Debugger_GetDescription(unsigned int address)
{
	int fun = Debugger_GetSymbolNum(address);
	//if (address == entries[fun].vaddress)
	//{
	if (fun!=-1)
		return entries[fun].name;
	else
	{
		sprintf(temp, "(%08x)", address);
		return temp;
	}
	//}
	//else
	//	return "";
}

void Debugger_FillSymbolListBox(HWND listbox,SymbolType symmask)
{
	ShowWindow(listbox,SW_HIDE);
	ListBox_ResetContent(listbox);
		
	//int style = GetWindowLong(listbox,GWL_STYLE);

	ListBox_AddString(listbox,"(0x80003100)");
	ListBox_SetItemData(listbox,0,0x80003100);
	
	//ListBox_AddString(listbox,"(0x80002000)");
	//ListBox_SetItemData(listbox,1,0x80002000);
	
	for (int i=0; i<numEntries; i++)
	{
		if (entries[i].type & symmask)
		{
			char temp[256];
			sprintf(temp,"%s (%d)",entries[i].name,entries[i].size);
			int index = ListBox_AddString(listbox,temp);
			ListBox_SetItemData(listbox,index,entries[i].vaddress);
		}
	}

	ShowWindow(listbox,SW_SHOW);
}

void Debugger_FillSymbolComboBox(HWND listbox,SymbolType symmask)
{
	ShowWindow(listbox,SW_HIDE);
	ComboBox_ResetContent(listbox);

	//int style = GetWindowLong(listbox,GWL_STYLE);

	ComboBox_AddString(listbox,"(0x02000000)");
	ComboBox_SetItemData(listbox,0,0x02000000);

	//ListBox_AddString(listbox,"(0x80002000)");
	//ListBox_SetItemData(listbox,1,0x80002000);

	for (int i=0; i<numEntries; i++)
	{
		if (entries[i].type & symmask)
		{
			char temp[256];
			sprintf(temp,"%s (%d)",entries[i].name,entries[i].size);
			int index = ComboBox_AddString(listbox,temp);
			ComboBox_SetItemData(listbox,index,entries[i].vaddress);
		}
	}
	
	ShowWindow(listbox,SW_SHOW);
}

void Debugger_FillListBoxBLinks(HWND listbox, int num)
{	
	ListBox_ResetContent(listbox);
		
	int style = GetWindowLong(listbox,GWL_STYLE);

	MapEntry &e = entries[num];
#ifdef BWLINKS
	for (int i=0; i<e.backwardLinks.size(); i++)
	{
		u32 addr = e.backwardLinks[i];
		int index = ListBox_AddString(listbox,Debugger_GetSymbolName(Debugger_GetSymbolNum(addr)));
		ListBox_SetItemData(listbox,index,addr);
	}
#endif
}

int Debugger_GetNumSymbols()
{
	return numEntries;
}
char *Debugger_GetSymbolName(int i)
{
	return entries[i].name;
}
void Debugger_SetSymbolName(int i, const char *newname)
{
	strcpy(entries[i].name, newname);
}

u32 Debugger_GetSymbolAddr(int i)
{
	return entries[i].vaddress;
}

u32 Debugger_GetSymbolSize(int i)
{
	return entries[i].size;
}
int Debugger_FindSymbol(const char *name)
{
	for (int i=0; i<numEntries; i++)
		if (strcmp(entries[i].name,name)==0)
			return i;
	return -1;
}
DWORD Debugger_GetAddress(int num)
{
	return entries[num].vaddress;
}

void Debugger_IncreaseRunCount(int num)
{
	entries[num].runCount++;
}

unsigned int Debugger_GetRunCount(int num)
{
	if (num>=0)
		return entries[num].runCount;
	else
		return 0;
}



//deprecated shit since this didn't really work out: 

// Load an elf with symbols, use debugger_compilefuncsignaturesfile 
// to make a symbol map, load a dol or somethin without symbols, then apply 
// the map with debugger_usefuncsignaturesfile.

void Debugger_CompileFuncSignaturesFile(const char *filename)
{
	// Store name,length,first instruction,hash into file
	FILE *f = fopen(filename, "w");
	fprintf(f,"00000000\n");
	int count=0;
	for (int i=0; i<numEntries; i++)
	{
		int size = entries[i].size;
		if (size>=16 && entries[i].type == ST_FUNCTION)
		{
			u32 inst = ReadMem32Unchecked(entries[i].vaddress); //try to make a bigger number of different vals sometime
			if (inst != 0)
			{
				char temp[64];
				strncpy(temp,entries[i].name,63);
				fprintf(f, "%08x\t%08x\t%08x\t%s\n", inst, size, ComputeHash(entries[i].vaddress,size), temp);    
				count++;
			}
		}
	}
	fseek(f,0,SEEK_SET);
	fprintf(f,"%08x",count);
	fclose(f);
}


struct Sig
{
	u32 inst;
	u32 size;
	u32 hash;
	char name[64];
	Sig(){}
	Sig(u32 _inst, u32 _size, u32 _hash, char *_name) : inst(_inst), size(_size), hash(_hash)
	{
		strncpy(name,_name,63);
	}
	
};

int compare (const void *s1, const void *s2)
{
	return ((Sig *)s2)->inst - ((Sig *)s1)->inst;
}

#define MAXSIGS 65536*2
Sig sigs[MAXSIGS];
int numSigs;

typedef std::map <u32,Sig *> Sigmap;
Sigmap sigmap;

void Debugger_UseFuncSignaturesFile(const char *filename, u32 maxAddress)
{
	SetStatusBar("Loading signature file...");
	numSigs=0;
	//Debugger_ResetSymbolMap();
	//#1: Read the signature file and put them in a fast data structure
	FILE *f = fopen(filename, "r");
	int count;
	fscanf(f,"%08x\n",&count);
	u32 inst,size,hash;
	char name[256];
	for (int a=0; a<count; a++)
	{
		if (fscanf(f,"%08x\t%08x\t%08x\t%s\n",&inst,&size,&hash,name)!=EOF)
			sigs[numSigs++]=Sig(inst,size,hash,name);
		else
			break;
	}
	
	fclose(f);
	SetStatusBar("Sorting...");
	qsort(sigs, numSigs,sizeof(Sig),compare);

	f = fopen("C:\\mojs.txt", "w");
	fprintf(f,"00000000\n");
	for (int j=0; j<numSigs; j++)
		fprintf(f, "%08x\t%08x\t%08x\t%s\n", sigs[j].inst, sigs[j].size, sigs[j].hash, sigs[j].name);    
	fseek(f,0,SEEK_SET);
	fprintf(f,"%08x",numSigs);
	fclose(f);

	SetStatusBar("Compiling data structure...");

	u32 last = 0xc0d3babe;
	int i;
	for (i=0; i<numSigs; i++)
		if (sigs[i].inst != last)
		{
			sigmap.insert(Sigmap::value_type(sigs[i].inst,sigs+i));
			last=sigs[i].inst;
		}
	sigs[i].inst=0;

	//#2: Scan/hash the memory and locate functions
	char temp[256];
	u32 lastAddr=0;
	for (u32 addr = 0x80000000; addr<maxAddress; addr+=4)
	{
		if ((addr&0xFFFF0000) != (lastAddr&0xFFFF0000))
		{
			sprintf(temp,"Scanning: %08x",addr);
			SetStatusBar(temp);
			lastAddr=addr;
		}
		u32 inst = ReadMem32Unchecked(addr);
		if (!inst) 
			continue;

		Sigmap::iterator iter = sigmap.find(inst);
		if (iter != sigmap.end())
		{
			Sig *sig = iter->second;
			while (true)
			{
				if (sig->inst != inst)
					break;

				u32 hash = ComputeHash(addr,sig->size);				
				if (hash==sig->hash)
				{
					//MATCH!!!!
					MapEntry &e = entries[numEntries++];
					e.address=addr;
					e.size= sig->size;
					e.vaddress = addr;
					e.type=ST_FUNCTION;
					strcpy(e.name,sig->name);
					addr+=sig->size-4; //don't need to check function interior
					break;
				}
				sig++;
			}
		}
	}
	SetStatusBar("Sorting symbols...");
	//ensure code coloring even if symbols were loaded before
	Debugger_SortSymbols();
	SetStatusBar("Ready");
}
#pragma once
#include <stdio.h>



// should be inside the LogManager ...
struct CDebugger_Log
{
	char m_szName[128];
	char m_szShortName[10];
	char m_szFilename[MAX_PATH];
	bool m_bLogToFile;
	bool m_bShowInLog;
	bool m_bEnable;
	FILE *m_pFile;
	// constructor
	CDebugger_Log(const char* _szShortName, const char* _szName);

	// destructor
	~CDebugger_Log(void);
};


class CDebugger_LogManager 
{
public:
	enum LOG_TYPE
	{
		MASTER_LOG,
		CPU,
		LOADER,
		ROM,
		IO,
		DISPLAYREGS,
		COPROCESSOR,
		G2D,
		G3D,
		DMA,
		FILESYS,
		INTC,
		MEMMAP,
		SOUND,
		HLE,
		TIMER,
		VIDEO,
		DYNAREC,
		NUMBER_OF_LOGS
	};

#define	MAX_MESSAGES 20000   // the old value was to large
#define MAX_MSGLEN  256

	// Message
	struct SMessage
	{
		bool		m_bInUse;
		LOG_TYPE	m_type;
		char m_szMessage[MAX_MSGLEN];
		size_t m_dwMsgLen;

		// constructor
		SMessage(void) : m_bInUse(false) {}

		// set
		void Set(LOG_TYPE _type, char* _szMessage)
		{
			strncpy(m_szMessage,_szMessage,MAX_MSGLEN-1);
			m_dwMsgLen = strlen(m_szMessage); 
			m_szMessage[m_dwMsgLen]=0;

			m_type = _type;
			m_bInUse = true;
		}
	};
	static bool m_bDirty;

	static SMessage m_Messages[MAX_MESSAGES];
	static int m_nextMessages;

	static CDebugger_Log* m_Log[NUMBER_OF_LOGS];

	static void GetContents(TCHAR *out,int activeLog);

	static void Init();
	static void Clear(void);

	// shutdown
	static void Shutdown(void);

	//
	static void Log(LOG_TYPE _type, char* _fmt, ...);
};

#ifdef LOGGING

#define _dbg_clear_()                           CDebugger_LogManager::Clear();
#define LOG(_t_, ...)						CDebugger_LogManager::Log(CDebugger_LogManager::_t_,__VA_ARGS__);

extern void doLogUpdate();

#define _dbg_update_() doLogUpdate(); 
#define _dbg_assert_(_t_,_a_)	if (!(_a_)){\
	char szError [512];\
	sprintf(szError,"Error localized at...\n\n  Line: %d\n  File: %s\n  Time: %s\n\nIgnore and continue?",__LINE__,__FILE__,__TIMESTAMP__);\
	LOG(_t_,szError);\
	if(MessageBox(NULL,szError,"*** Assertion Report ***",MB_YESNO|MB_ICONERROR)==IDNO) DebugBreak();\
}
#define _dbg_assert_msg_(_t_,_a_,_desc_, ...)	if (!(_a_)){\
	char szError [512];char szError2[535];\
	sprintf (szError,_desc_,__VA_ARGS__);\
	sprintf (szError2,"%s\n\nIgnore and continue?", szError);\
	LOG(_t_,szError);\
	if(MessageBox (NULL,szError2,"*** ASSERT ***",MB_YESNO|MB_ICONERROR)==IDNO) DebugBreak();\
}


#else
#define LOG(_t_, ...)	
#define _dbg_clear_()
#define _dbg_assert_(_t_,_a_) ;
#define _dbg_assert_msg_(_t_,_a_,_desc_) ;
#define _dbg_update_() ;
#endif


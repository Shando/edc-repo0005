/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "../Core.h"
//#include "Debugger_SymbolMap.h"
#include "BreakPoints.h"
//#include "Debugger_Misc.h"
//#include "..\HW\iCPU.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////
// I M P L E M E N T A T I O N //////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

std::vector<BreakPoint>    CBreakPoints::m_iBreakPoints;
std::vector<MemCheck>		CBreakPoints::MemChecks;
u32						CBreakPoints::m_iBreakOnCount = 0;

// __________________________________________________________________________________________________
// MemCheck 
//
MemCheck::MemCheck(void)
{
	numHits=0;
}

// __________________________________________________________________________________________________
// Action 
//
void MemCheck::Action(u32 iValue, u32 addr, bool write, int size, u32 pc)
{
	if ((write && bOnWrite) || (!write && bOnRead))
	{
		if (bLog)
		{
			char temp[256];
			//sprintf(temp,"CHK %08x %s%i at %08x (%s), PC=%08x (%s)",iValue,write?"Write":"Read",size*8,addr,Debugger_GetDescription(addr),pc,Debugger_GetDescription(pc));
			LOG(MEMMAP,temp);
		}
		
		if (bBreak)
			Core_Pause();
	}
}

// __________________________________________________________________________________________________
// IsAddressBreakpoint 
//
bool 
CBreakPoints::IsAddressBreakPoint(u32 _iAddress)
{
	std::vector<BreakPoint>::iterator iter;

	for (iter = m_iBreakPoints.begin(); iter != m_iBreakPoints.end(); ++iter)
		if ((*iter).iAddress == _iAddress)
			return true;

	return false;
}

// __________________________________________________________________________________________________
// IsTempBreakPoint 
//
bool 
CBreakPoints::IsTempBreakPoint(u32 _iAddress)
{
	std::vector<BreakPoint>::iterator iter;

	for (iter = m_iBreakPoints.begin(); iter != m_iBreakPoints.end(); ++iter)
		if ((*iter).iAddress == _iAddress && (*iter).bTemporary)
			return true;

	return false;
}

// __________________________________________________________________________________________________
// GeMemCheck 
//
MemCheck *
CBreakPoints::GetMemCheck(u32 address)
{
	std::vector<MemCheck>::iterator iter;
	for (iter = MemChecks.begin(); iter != MemChecks.end(); ++iter)
	{
		if ((*iter).bRange)
		{
			if (address >= (*iter).iStartAddress && address <= (*iter).iEndAddress)
				return &(*iter);
		}
		else
		{
			if ((*iter).iStartAddress==address)
				return &(*iter);
		}
	}

	//none found
	return 0;
}

// __________________________________________________________________________________________________
// IsBreakOnCount 
//
bool
CBreakPoints::IsBreakOnCount(u32 _iCount)
{
	if ((_iCount == m_iBreakOnCount) && 
		(m_iBreakOnCount != 0))
		return true;

	return false;
}

// __________________________________________________________________________________________________
// AddBreakPoint 
//
void 
CBreakPoints::AddBreakPoint(u32 _iAddress, bool temp)
{
	if (!IsAddressBreakPoint(_iAddress))
	{
		BreakPoint pt;
		pt.bOn=true;
		pt.bTemporary=temp;
		pt.iAddress = _iAddress;

		m_iBreakPoints.push_back(pt);
	}
}

// __________________________________________________________________________________________________
// RemoveBreakpoint 
//
void 
CBreakPoints::RemoveBreakPoint(u32 _iAddress)
{
	std::vector<BreakPoint>::iterator iter;

	for (iter = m_iBreakPoints.begin(); iter != m_iBreakPoints.end(); ++iter)
		if ((*iter).iAddress == _iAddress)
		{
			m_iBreakPoints.erase(iter);
			break;
		}
}

// __________________________________________________________________________________________________
// ClearAllBreakPoints 
//
void
CBreakPoints::ClearAllBreakPoints()
{
	m_iBreakPoints.clear();
}

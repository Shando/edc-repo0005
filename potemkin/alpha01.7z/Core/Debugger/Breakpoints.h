#pragma once


#include "../../Globals.h"

struct BreakPoint
{
	u32    iAddress;
	bool	bOn;
	bool    bTemporary;
};

struct MemCheck
{
	MemCheck();
	u32 iStartAddress;
	u32 iEndAddress;

	bool	bRange;

	bool	bOnRead;
	bool	bOnWrite;

	bool	bLog;
	bool	bBreak;

	u32 numHits;

	void Action(u32 _iValue, u32 addr, bool write, int size, u32 pc);
};

class CBreakPoints
{
private:

	enum { MAX_NUMBER_OF_CALLSTACK_ENTRIES = 16384};
	enum { MAX_NUMBER_OF_BREAKPOINTS = 16};
	
	static std::vector<BreakPoint> m_iBreakPoints;

	static u32	m_iBreakOnCount;
	

public:
	static std::vector<MemCheck> MemChecks;

	// is address breakpoint
	static bool IsAddressBreakPoint(u32 _iAddress);

	//memory breakpoint
	static MemCheck *GetMemCheck(u32 address);
					
	// is break on count
	static bool IsBreakOnCount(u32 _iAddress);

	static bool IsTempBreakPoint(u32 _iAddress);

	// AddBreakPoint
	static void AddBreakPoint(u32 _iAddress, bool temp=false);

	// Remove Breakpoint
	static void RemoveBreakPoint(u32 _iAddress);

	static void ClearAllBreakPoints();
};



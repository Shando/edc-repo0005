#pragma once

#include "../Globals.h"


#define MEMDECL __cdecl

typedef u8   (MEMDECL *RM8Func) (u32 address);
typedef u16  (MEMDECL *RM16Func)(u32 address);
typedef u32  (MEMDECL *RM32Func)(u32 address);
typedef void (MEMDECL *WM8Func) (u32 address, u8  value);
typedef void (MEMDECL *WM16Func)(u32 address, u16 value);
typedef void (MEMDECL *WM32Func)(u32 address, u32 value);
typedef TCHAR* (MEMDECL *GetNameFunc)(u32 address);



// If function exists, use it

// this is so that reads don't get unnecessarily slow while we're still able to handle
// writes properly

struct MemRegion
{
	u32 addrOffset; 
	RM8Func  read8;
	RM16Func read16;
	RM32Func read32;
	WM8Func  write8;
	WM16Func write16;
	WM32Func write32;
	RM32Func read32NoEffect;
	GetNameFunc getAddressName;
	bool initialized;
};

enum GBARegions
{
	GBAREGION_ROM,
	GBAREGION_ROMMIRROR1,
	GBAREGION_ROMMIRROR2,
	GBAREGION_BIOS,
	GBAREGION_WRAM,
	GBAREGION_IWRAM,
	GBAREGION_IO,
	GBAREGION_PALETTES,
	GBAREGION_VRAM,
	GBAREGION_SRAM
};

/*
 *	theoretical read from ecx
 mov eax,memtable
 mov edx,ecx
 shr edx,16
 mov eax,[eax+edx*4]
 test [eax+4]
 cmove eax,[eax+edx]
 je skip
 push ecx
 call read32
 skip:
 */

#define MEMTABLE_BITS  17 //granularity of the table
#define MEMTABLE_SHIFT (32-MEMTABLE_BITS)
#define MEMTABLE_SIZE  (1<<MEMTABLE_BITS)
#define MEMTABLE_MASK  ~((1<<MEMTABLE_SHIFT)-1)


enum MemRegionType
{
	MRTYPE_INVALID,
	MRTYPE_ROM,
	MRTYPE_MEMORY,
	MRTYPE_SPECIAL,
	MRTYPE_MIRROR  //of previous
};

enum MemoryError
{
	MEMERR_NONE,
	MEMERR_NOTHINGMAPPED
};


enum
{
	CPU_0=1,
	CPU_1=2,
	CPU_2=4,
	CPU_3=8
};


struct MemRegionInfo
{
	char *name; 
	u32 cpumask;
	MemRegionType type;
	u32 start, end, mirrorMask;
	RM8Func  read8;
	RM16Func read16;
	RM32Func read32;
	WM8Func  write8;
	WM16Func write16;
	WM32Func write32;
	RM32Func read32NoEffect;
	GetNameFunc getAddressName;
	u8 *memPointer;
};

void MemMap_Init(MemRegionInfo *regions, int nRegions, int numMirrors, int mirrorAdd);
void MemMap_Shutdown();


struct MemMap
{
	MemMap()
	{
		memTable = new MemRegion[MEMTABLE_SIZE];
		memset(memTable,0,sizeof(MemRegion)*MEMTABLE_SIZE);
		regions = new MemRegionInfo[32];
		memset(regions,0,sizeof(MemRegionInfo)*32);
	}
	~MemMap()
	{
		delete [] memTable;
		delete [] regions;
	}
	MemRegion *memTable;
	MemRegionInfo *regions;
	int numRegions;

	u8* MEMDECL GetMemPointer(u32 address);
	TCHAR *GetAddressName(u32 address);

	u16  MEMDECL ReadMem16Unchecked(u32 address);
	u32  MEMDECL ReadMem32Unchecked(u32 address);

	bool IsExecutable(u32 address);
};



void LogInvalidAccesses(bool log);
void ResetMemError();
MemoryError GetLastMemError();


u8   MEMDECL ReadMem8 (u32 address);
u16  MEMDECL ReadMem16(u32 address);
u32  MEMDECL ReadMem32(u32 address);

inline float MEMDECL ReadMemFloat(u32 address)
{
	u32 u = ReadMem32(address);
	return *((float*)&u);
}

u16 ReadOp16(u32 address);
u32 ReadOp32(u32 address);

void MEMDECL WriteMem8 (u32 address, u8  value);
void MEMDECL WriteMem16(u32 address, u16 value);
void MEMDECL WriteMem32(u32 address, u32 value);

inline void MEMDECL WriteMemFloat(u32 address, float f)
{
	u32 u = *((u32*)&f);
	WriteMem32(address,u);
}

void MEMDECL WriteMemString(u32 address, const char *string);

u8   MEMDECL ReadIllegal8 (u32 address);
u16  MEMDECL ReadIllegal16(u32 address);
u32  MEMDECL ReadIllegal32(u32 address);
void MEMDECL WriteIllegal8 (u32 address, u8  value);
void MEMDECL WriteIllegal16(u32 address, u16 value);
void MEMDECL WriteIllegal32(u32 address, u32 value);

u16  MEMDECL ReadMem16Unchecked(u32 address);
u32  MEMDECL ReadMem32Unchecked(u32 address);

u8* MEMDECL GetMemPointer(u32 address);

#pragma once


class DynaBlockCache
{
public:

	virtual int GetNumBlocks() = 0;
	virtual u32 GetBlockAddr(int i) = 0;
	virtual u32 GetBlockSize(int i) = 0;
	virtual u32 GetBlockCompiledSize(int i) = 0;
	virtual void DisassembleCompiledBlock(int i, char *ptr) = 0;
}
#include "stdafx.h"	
#include "MemMap.h"
#include "ARM/ARM.h"
#include "HW.h"

#include "GBA/GBASystem.h"
#include "DS/DSSystem.h"
#include "GP32/GP32System.h"
#include "PSP/PSPSystem.h"	


static bool hwInited = false;


EmuMode mode;
void HW_Init(EmuMode _mode)
{
	mode=_mode;
	//setup the FPU
	/*
	unsigned int orig_cw = _controlfp(0,0);
	_controlfp (_PC_24, MCW_PC);*/

	//global stuff
	ARM_Init();

	switch(mode) 
	{
	case MODE_DS:
		DS_Init();
		break;
	case MODE_GBA:
		GBA_Init();
		break;
	case MODE_GP32:
		GP32_Init();
		break;
	case MODE_PSP:
		PSP_Init();
		break;
	}

	LOG(MASTER_LOG,"Emulated hardware initialized.");	
	_dbg_update_();
	hwInited = true;
}


void HW_Shutdown()
{
	hwInited = false;
	switch (mode)
	{
	case MODE_DS:
		ARM_Shutdown();
		break;
	case MODE_PSP:
		PSP_Shutdown();
		break;
	}

	//restore the FPU
	//_controlfp (orig_cw, 0xfffff);
}


bool HW_IsInited()
{
	return hwInited;
}
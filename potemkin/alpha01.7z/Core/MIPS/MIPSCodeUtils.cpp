#include "stdafx.h"
#include "MIPS.h"
#include "MIPSTables.h"
#include "MIPSCodeUtils.h"
#include "../Host.h"


namespace MIPSCodeUtils
{

#define FULLOP_JR_RA 0x03e00008
#define OP_SYSCALL   0x0000000c
#define OP_SYSCALL_MASK 0xFC00003F

	u32 GetJumpTarget(u32 addr)
	{
		u32 op = ReadMem32Unchecked(addr);
		if (op)
		{
			op &= 0xFC000000;
			if (op == 0x0C000000 || op == 0x08000000) //jal
			{
				u32 target = (addr & 0xF0000000)|((op&0x03FFFFFF) << 2);
				return target;
			}
			else
				return INVALIDTARGET;
		}
		else
			return INVALIDTARGET;
	}

	u32 GetBranchTarget(u32 addr)
	{
		u32 op = ReadMem32Unchecked(addr);
		if (op)
		{
			u32 info = MIPSGetInfo(op);
			if (info & IS_CONDBRANCH)
			{
				return addr + ((signed short)(op&0xFFFF)<<2);
			}
			else
				return INVALIDTARGET;	
		}
		else
			return INVALIDTARGET;
	}

	u32 GetSureBranchTarget(u32 addr)
	{
		u32 op = ReadMem32Unchecked(addr);
		if (op)
		{
			u32 info = MIPSGetInfo(op);
			if (info & IS_CONDBRANCH)
			{
				//TODO: safer check
				if ((op & 0xFFFF0000) == 0x10000000)
					return addr + ((signed short)(op&0xFFFF)<<2);
				else
					return INVALIDTARGET;
			}
			else
				return INVALIDTARGET;	
		}
		else
			return INVALIDTARGET;
	}
}

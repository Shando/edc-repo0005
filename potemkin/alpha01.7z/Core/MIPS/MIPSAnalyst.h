#pragma once

namespace MIPSAnalyst
{
	void Analyze(u32 address);
	struct AnalysisResults
	{
		bool used;
		u32 firstRead;
		u32 lastRead;
		u32 firstWrite;
		u32 lastWrite;
		u32 firstReadAsAddr;
		u32 lastReadAsAddr;

		int readCount;
		int writeCount;
		int readAsAddrCount;
		bool usesVFPU;

		int TotalReadCount() {return readCount+readAsAddrCount;}
		int FirstRead() {return min(firstReadAsAddr,firstRead);}
		int LastRead() {return max(lastReadAsAddr,lastRead);}
	};
	extern AnalysisResults regAnal[32]; //hoho
	bool IsRegisterUsed(int reg, u32 addr);
	void ScanForFunctions(u32 startAddr, u32 endAddr);
	void CompileLeafs();

	std::vector<int> GetInputRegs(u32 op);
	std::vector<int> GetOutputRegs(u32 op);
}

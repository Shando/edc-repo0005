#include "stdafx.h"	
#include "../CPU.h"
#include "MIPS.h"
#include "MIPSRegCache.h"
#include "MIPSCompiler.h"

// Simple register caching
// TODO: Immediate Catching to find writes (MOVLI)
//       All accesses go to RAM, n first times run? recompile block with that assumption

namespace MIPSComp
{
#define NUMREGS 8
	struct CachedXReg 
	{
		int shReg;
		int mapTime;
		bool mapped;
		bool locked;
		bool dirty;
		bool containsAddress;
	};

	struct MIPSRegInfo
	{
		bool hasImmValue;
		u32 immValue;
		int xReg;
	};

	static CachedXReg regs[NUMREGS];

	u32 *shrPointers[32+3+2] =
	{
		&mipsr4k.r[0],
		&mipsr4k.r[1],
		&mipsr4k.r[2],
		&mipsr4k.r[3],
		&mipsr4k.r[4],
		&mipsr4k.r[5],
		&mipsr4k.r[6],
		&mipsr4k.r[7],
		&mipsr4k.r[8],
		&mipsr4k.r[9],
		&mipsr4k.r[10],
		&mipsr4k.r[11],
		&mipsr4k.r[12],
		&mipsr4k.r[13],
		&mipsr4k.r[14],
		&mipsr4k.r[15],
		&mipsr4k.r[16],
		&mipsr4k.r[17],
		&mipsr4k.r[18],
		&mipsr4k.r[19],
		&mipsr4k.r[20],
		&mipsr4k.r[21],
		&mipsr4k.r[22],
		&mipsr4k.r[23],
		&mipsr4k.r[24],
		&mipsr4k.r[25],
		&mipsr4k.r[26],
		&mipsr4k.r[27],
		&mipsr4k.r[28],
		&mipsr4k.r[29],
		&mipsr4k.r[30],
		&mipsr4k.r[31],
		&mipsr4k.lo,
		&mipsr4k.hi,
		&mipsr4k.fpcond,
	};
#define NUMMAPPABLEREGS 5

	TX86Regs regOrder[NUMMAPPABLEREGS] = 
	{
		EBX,ESI,EDI,EDX,ECX             //prefer to put in regs we rarely need to lock
	};

	void LoadMIPSToX86(int sh4reg, TX86Regs reg)
	{
		MOV_MemoryToReg(1,reg,ModRM_disp32,(u32)shrPointers[sh4reg]);
	}
	void StoreX86ToMIPSfile(TX86Regs reg, int sh4reg)
	{
		MOV_RegToMemory(1,reg,ModRM_disp32,(u32)shrPointers[sh4reg]);
	}

	void WriteImmToMIPSReg(int n, u32 imm)
	{
		ForgetMIPSReg(n);
		MOV_ImmToMemory(1,ModRM_disp32,(u32)shrPointers[n], imm);
	}
	void ForgetMIPSReg(int n)
	{
		for (int i=0; i<NUMMAPPABLEREGS; i++)
		{
			TX86Regs r = regOrder[i];
			if (regs[r].mapped && regs[r].shReg == n)
			{
				regs[r].mapped=false;
			}
		}
	}

	//TODO
	void AddrifyMIPSReg(int n)
	{
		FlushAll();
		int xreg = MapMIPSReg(n, true);
		PUSH_RegToStack(xreg);
		CALLFunc((u32)&GetMemPointer);
		ADD_ImmToReg(1,ESP,4,0);
		MOV_Reg2ToReg1(1,xreg,EAX);
		regs[xreg].containsAddress=true;
		regs[xreg].dirty=false;
	}


	void FlushX86Reg(TX86Regs reg)
	{
		if (regs[reg].locked)
		{
			MessageBox(0,"Trying to flush a locked reg? Something strange is going on ..",0,0);
			//CPU_Halt("Trying to flush a locked reg? Something strange is going on ..");
			DebugBreak();
			return;
		}
		if (!regs[reg].mapped)
		{
			return;
		}
		if (regs[reg].dirty)
		{
			StoreX86ToMIPSfile(reg,regs[reg].shReg);
			regs[reg].dirty = false;
		}
		regs[reg].mapped = false;
	}

	TX86Regs GetX86Mapping(int shReg)
	{
		for (int i=0; i<NUMMAPPABLEREGS; i++)
		{
			TX86Regs r = regOrder[i];
			if (regs[r].mapped && regs[r].shReg == shReg)
				return r;
		}
		return (TX86Regs)-1;
	}

	void FlushAllExcept(int n)
	{
		for (int i=0; i<NUMMAPPABLEREGS; i++)
			if (regOrder[i] != n)
				FlushX86Reg(regOrder[i]);
	}

	void FlushAll()
	{
		FlushAllExcept(-1);
	}


	TX86Regs FindFreeReg()
	{
		//search, and find oldest at the same time
		int oldestMapTime = 0x7fffffff;
		TX86Regs oldestReg = (TX86Regs)-1;
		for (int i=0; i<NUMMAPPABLEREGS; i++)
		{
			TX86Regs r = regOrder[i];
			if (!regs[r].mapped) //if unmapped, then we'll just use it
				return r;

			if (!regs[r].locked) 
			{
				if (regs[r].mapTime < oldestMapTime)
				{
					oldestReg = r;
					oldestMapTime = regs[r].mapTime;
				}
			}
		}
		// no free reg found, let's flush the oldest
		if (oldestReg != (TX86Regs)-1)
		{
			//we have to flush it..
			FlushX86Reg(oldestReg);
			return oldestReg;
		}
		else
		{
			// WE ARE IN TROUBLE
			MessageBox(0,"RAN OUT OF REGS, HELP!!!",0,0);
			LOG(DYNAREC,"Dynarec regalloc ran out of registers! This shouldn't happen!");
			return EAX;
		}
	}

	bool IsMappedAs(int shreg, TX86Regs reg)
	{
		if (!regs[reg].mapped)
			return false;
		if (regs[reg].shReg != shreg)
			return false;
		//more checks?
		return true;
	}

	TX86Regs MapMIPSReg(int n, bool load /*= true*/)
	{
		for (int i=0; i<NUMMAPPABLEREGS; i++)
		{
			TX86Regs reg = regOrder[i];
			if (regs[reg].mapped && regs[reg].shReg == n)
			{
				regs[reg].mapTime = MIPSComp::GetInstructionCount();
				return reg;
			}
		}
		//Not found in cache, so:
		TX86Regs reg     = FindFreeReg();
		regs[reg].mapped = true;
		regs[reg].shReg  = n;
		regs[reg].dirty  = false;
		regs[reg].mapTime = MIPSComp::GetInstructionCount();
		if (load)
			LoadMIPSToX86(n,reg);
		return reg;
	}

	void UnmapX86Reg(TX86Regs reg, bool store /*= false*/)
	{
		if (regs[reg].dirty && store)
			StoreX86ToMIPSfile(reg,regs[reg].shReg);
		regs[reg].mapped=false;
		regs[reg].dirty = false;
	}

	void UnmapMIPSReg(int s)
	{
		for (int i=0; i<NUMMAPPABLEREGS; i++)
		{
			TX86Regs reg = regOrder[i];
			if (regs[reg].mapped == true && regs[reg].shReg == s)
			{
				FlushX86Reg(reg);
				break;
			}
		}
	}

	//todo: add a forced reg as parameter
	void LockX86Reg(TX86Regs reg)
	{
		FlushX86Reg(reg);
		regs[reg].locked=true;
		regs[reg].dirty=false;
	}

	void UnlockX86Reg(TX86Regs reg)
	{
		if (regs[reg].dirty)
			LOG(DYNAREC,"Trying to unlock dirty register");
		if (regs[reg].mapped)
			LOG(DYNAREC,"Trying to unlock mapped register");
		regs[reg].locked=false;
	}

	void SetDirty(TX86Regs reg)
	{
		if (regs[reg].mapped)
			regs[reg].dirty = true;
		else
			LOG(DYNAREC,"Trying to dirty a non-mapped register");
	}

	void FlushSHReg(int n)
	{
		TX86Regs r = GetX86Mapping(n);
		if (r!=-1)
			FlushX86Reg(r);
	}


	// NOT DONE
	void Remap(TX86Regs reg, int newSHReg,bool flush)
	{
		if (regs[reg].shReg==newSHReg)
			return;
		int currentMap = GetX86Mapping(newSHReg);
		if (currentMap==-1)
		{
			if (flush)
				FlushX86Reg(reg);
			regs[reg].shReg=newSHReg;
		}
		else
		{
			MapMIPSReg(newSHReg,true);
		}
	}


	void StartRegCache()
	{
		for (int i=0; i<NUMREGS; i++)
		{
			regs[i].locked = false;
			regs[i].mapped = false;
			regs[i].dirty = false;
		}
		regs[Reg_EAX].locked = true; // used for temps
		regs[Reg_ESP].locked = true; // stack - dangerous
		regs[Reg_EBP].locked = true; // base pointer - dangerous for now ?
		//XMMStart();
	}

	void StopRegCache()
	{
		FlushAll();
//		FlushAllXMM();
	}
}
#pragma once

#include "../../Globals.h"

u32 MIPS_GetNextPC();
void MIPS_ClearDelaySlot();
void MIPS_SingleStep();

namespace MIPSInt
{
	void Int_SV(u32 op);
	void Int_SVQ(u32 op);
	void Int_Mftv(u32 op);
	void Int_MatrixSet(u32 op);
	void Int_VecDo3(u32 op);
	void Int_Vcst(u32 op);
	void Int_VMatrixInit(u32 op);
	void Int_VVectorInit(u32 op);
	void Int_Vmmul(u32 op);
	void Int_Vmmov(u32 op);
	void Int_VV2Op(u32 op);
	void Int_Vrot(u32 op);
	void Int_VDot(u32 op);
	void Int_Vfad(u32 op);
	void Int_Vtfm(u32 op);
	void Int_Viim(u32 op);
	void Int_VScl(u32 op);
	void Int_Vidt(u32 op);
	void Int_Vcmp(u32 op);
	void Int_Vcrs(u32 op);
	void Int_Vcmov(u32 op);
	void Int_CrossQuat(u32 op);
	void Int_VPFX(u32 op);
	void Int_Vflush(u32 op);
	void Int_Vbfy(u32 op);
	void Int_Vf2i(u32 op);
	void Int_Vi2f(u32 op);
	void Int_Vi2x(u32 op);
	void Int_VBranch(u32 op);
}


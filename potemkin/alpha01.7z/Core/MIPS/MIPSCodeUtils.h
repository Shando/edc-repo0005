#pragma once
#include "../../Globals.h"


#define MIPS_MAKE_J(addr)   (0x08000000 | ((addr)>>2))
#define MIPS_MAKE_JAL(addr) (0x0C000000 | ((addr)>>2))
#define MIPS_MAKE_JR_RA()   (0x03e00008)
#define MIPS_MAKE_NOP()     (0)
#define MIPS_MAKE_LUI(reg, value) (0x3c000000 | (reg<<16) | value)

#define MIPS_GET_RS(op) ((op>>21) & 0x1F)
#define MIPS_GET_RT(op) ((op>>16) & 0x1F)
#define MIPS_GET_RD(op) ((op>>11) & 0x1F)

#define MIPS_GET_FS(op) ((op>>11) & 0x1F)
#define MIPS_GET_FT(op) ((op>>16) & 0x1F)
#define MIPS_GET_FD(op) ((op>>6 ) & 0x1F)


#define MIPS_MAKE_EMUHACK(op, value) (0x68000000 | (op<<24) | (value))
#define EMUOP_RUNBLOCK 0
#define EMUOP_RETKERNEL 1

#define INVALIDTARGET 0xFFFFFFFF

namespace MIPSCodeUtils
{
	u32 GetCallTarget(u32 addr);
	u32 GetBranchTarget(u32 addr);
	u32 GetJumpTarget(u32 addr);
	u32 GetSureBranchTarget(u32 addr);
	void RewriteSysCalls(u32 startAddr, u32 endAddr);
}

#pragma once

#include "../x86BackEnd/x86.h"


namespace MIPSComp
{
	//So far only caching integer registers
	//Should do something similar with SSE/sh4fpu i think.

	//Various regcache constants
	enum 
	{
		TEMPREG = EAX,

		REG_LO = 32,
		REG_HI = 33,
		REG_FPUFLAG = 34,
	};


	//public interfaces
	void StartRegCache();
	void StopRegCache();

	TX86Regs MapMIPSReg(int n, bool load = true);
	void AddrifyMIPSReg(int n);
	void WriteImmToMIPSReg(int n, u32 imm);
	void UnmapX86Reg(TX86Regs reg, bool store = false);
	void LockX86Reg(TX86Regs reg);
	void UnlockX86Reg(TX86Regs reg);
	void FlushAll();
	void FlushAllExcept(int n);
	void FlushMIPSReg(int n);
	void FlushX86Reg(TX86Regs reg);
	void ForgetMIPSReg(int n);
	bool IsMappedAs(int shreg, TX86Regs reg);
	void SetDirty(TX86Regs reg);
	TX86Regs GetX86Mapping(int shReg);
	void Remap(TX86Regs reg, int newSHReg, bool flush=false);
}
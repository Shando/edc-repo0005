#pragma once

#include "../../Globals.h"

namespace MIPSComp
{
	//Compiled ops should ignore delay slots
	// the compiler will take care of them by itself
	// OR NOT
	void Comp_Generic(u32 op);

	void Init();
	void CompileAt(u32 addr);
	void Comp_RunBlock(u32 op);
	u8 *GetStartPtr();
	u32 GetStartPC();
	int GetNumBlocks();
	u32 GetBlockAddr(int i);
	u32 GetBlockSize(int i);
	size_t GetBlockCompiledSize(int i);
	int GetNumHits(int i);
	
	int GetInstructionCount();
	u32  GetOriginalOp(u32 op);
	void WriteEpilogue();
	extern bool compiling;
	extern u32 compilerPC;
}


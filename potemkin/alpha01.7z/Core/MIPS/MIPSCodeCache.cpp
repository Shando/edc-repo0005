#include "stdafx.h"

#include "MIPS.h"
#include "MIPSInt.h"
#include "MIPSDis.h"
#include "MIPSTables.h"
#include "MIPSCodeCache.h"

void CodeCache::Init()
{

}



void MIPSCodeCacheInit()
{


}
#pragma once



enum DataSize
{
	V_Single,
	V_Pair,
	V_Triple,
	V_Quad,
	V_2x2,
	V_3x3,
	V_4x4,
	V_Invalid
};

#define _VD (op & 0x7F)
#define _VS ((op>>8) & 0x7F)
#define _VT ((op>>16) & 0x7F)

inline int Xpose(int v)
{
	return v^0x20;
}

#define VFPU_FLOAT16_EXP_MAX	0x1f
#define VFPU_SH_FLOAT16_SIGN	15
#define VFPU_MASK_FLOAT16_SIGN	0x1
#define VFPU_SH_FLOAT16_EXP	10
#define VFPU_MASK_FLOAT16_EXP	0x1f
#define VFPU_SH_FLOAT16_FRAC	0
#define VFPU_MASK_FLOAT16_FRAC	0x3ff


void ReadMatrix(float *rd, DataSize size, int outMatrixWidth, int reg);
void WriteMatrix(const float *rs, DataSize size, int inMatrixWidth, int reg);

void SetWriteMask(bool wm[4]);

inline void WriteVector(const float *rs, DataSize N, int reg)
{
	WriteMatrix(rs, N, 0, reg);
}

inline void ReadVector(float *rd, DataSize N, int reg)
{
	ReadMatrix(rd, N, 0, reg);
}

DataSize GetVecSize(u32 op);
DataSize GetMtxSize(u32 op);
DataSize GetHalfSize(DataSize sz);
int GetNumElements(DataSize sz);
int GetMatrixSide(DataSize sz);
const char *GetVRNotation(int reg, DataSize size);

float Float16ToFloat32(unsigned short l);

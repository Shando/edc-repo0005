#pragma once

namespace MIPSComp
{
	void Comp_IType(u32 op);
	void Comp_RType3(u32 op);
	void Comp_ShiftType(u32 op);

}
#pragma once

#include "../../Globals.h"

u32 MIPS_GetNextPC();
void MIPS_ClearDelaySlot();
void MIPS_SingleStep();

namespace MIPSInt
{
	void Int_Unknown(u32 op);
	void Int_Unimpl(u32 op);
	void Int_Syscall(u32 op);

	void Int_mxc1(u32 op);
	void Int_RelBranch(u32 op);
	void Int_RelBranchRI(u32 op);
	void Int_IType(u32 op);
	void Int_ITypeMem(u32 op);
	void Int_RType2(u32 op);
	void Int_RType3(u32 op);
	void Int_ShiftType(u32 op);
	void Int_MulDivType(u32 op);
	void Int_JumpType(u32 op);
	void Int_JumpRegType(u32 op);
	void Int_Allegrex2(u32 op);
	void Int_FPULS(u32 op);
	void Int_FPU3op(u32 op);
	void Int_FPU2op(u32 op);
	void Int_Allegrex(u32 op);
	void Int_FPUComp(u32 op);
	void Int_FPUBranch(u32 op);
	void Int_Emuhack(u32 op);
	void Int_Special3(u32 op);
	void Int_Interrupt(u32 op);
	void Int_Cache(u32 op);

}

#include "stdafx.h"
#include "MIPSTables.h"

#include "MIPS.h"
#include "MIPSDis.h"
#include "MIPSDisVFPU.h"
#include "MIPSInt.h"
#include "MIPSIntVFPU.h"
#include "MIPSCompiler.h"
#include "MIPSCodeUtils.h"
#include "MIPSCompALU.h"
#include "MIPSCompLoadStore.h"
#include "MIPSCompBranch.h"

enum MipsEncoding
{
	Imme, 
	Spec, 
	Spe2, 
	Spe3, 
	RegI, 
	Cop0, 
	Cop0CO, 
	Cop1,
	Cop1BC,
	Cop2, 
	Cop2BC2, 
	Cop2Rese,
	VFPU0, 
	VFPU1, 
	VFPU3,
	VFPU4Jump,
	VFPU7,
	VFPU4,
	VFPU5,
	VFPU6,
	VFPUMatrix1,
	VFPU9,
	ALLEGREX0,
	Emu, 
	Rese, 
	NumEncodings 
};

struct MIPSInstruction
{
	int altEncoding;
	char *name;
	MIPSCompileFunc compile;
#ifndef FINAL
	MIPSDisFunc disasm;
#endif
	MIPSInterpretFunc interpret;
	//MIPSInstructionInfo information;
	u32 information;
};

#define INVALID {-2}
#define N(a) a

#ifndef FINAL
#define ENCODING(a) {a}
#define INSTR(name, comp, dis, inter, flags) {-1, N(name), comp, dis, inter, flags}
#else
#define ENCODING(a) {a}
#define INSTR(name, comp, dis, inter, flags) {-1, comp, inter, flags}
#endif


using namespace MIPSDis;
using namespace MIPSInt;
using namespace MIPSComp;
//regregreg instructions
const MIPSInstruction tableImmediate[64] =  //xxxxxx .....
{
	//0
	ENCODING(Spec),
	ENCODING(RegI),
	INSTR("j",    Comp_Jump, Dis_JumpType, Int_JumpType, IS_JUMP|IN_IMM26|DELAYSLOT),
	INSTR("jal",  Comp_Jump, Dis_JumpType, Int_JumpType, IS_JUMP|IN_IMM26|OUT_RA|DELAYSLOT),
	INSTR("beq",  Comp_RelBranch, Dis_RelBranch2, Int_RelBranch, IS_CONDBRANCH|IN_RS|IN_RT|DELAYSLOT),
	INSTR("bne",  Comp_RelBranch, Dis_RelBranch2, Int_RelBranch, IS_CONDBRANCH|IN_RS|IN_RT|DELAYSLOT),
	INSTR("blez", Comp_RelBranch, Dis_RelBranch,  Int_RelBranch, IS_CONDBRANCH|IN_RS|DELAYSLOT),
	INSTR("bgtz", Comp_RelBranch, Dis_RelBranch,  Int_RelBranch, IS_CONDBRANCH|IN_RS|DELAYSLOT),
	//8
	INSTR("addi",  Comp_IType, Dis_addi,   Int_IType, IN_RS|IN_IMM16|OUT_RT),
	INSTR("addiu", Comp_IType, Dis_addi,   Int_IType, IN_RS|IN_IMM16|OUT_RT),
	INSTR("slti",  Comp_IType, Dis_IType,  Int_IType, IN_RS|IN_IMM16|OUT_RT),
	INSTR("sltiu", Comp_IType, Dis_IType,  Int_IType, IN_RS|IN_IMM16|OUT_RT),
	INSTR("andi",  Comp_IType, Dis_IType,  Int_IType, IN_RS|IN_IMM16|OUT_RT),
	INSTR("ori",   Comp_IType, Dis_ori,    Int_IType, IN_RS|IN_IMM16|OUT_RT),
	INSTR("xori",  Comp_IType, Dis_IType,  Int_IType, IN_RS|IN_IMM16|OUT_RT),
	INSTR("lui",   Comp_IType, Dis_IType1, Int_IType, IN_IMM16|OUT_RT),
	//16
	ENCODING(Cop0), //cop0
	ENCODING(Cop1), //cop1
	ENCODING(Cop2), //cop2
	INVALID, //copU

	INSTR("beql",  Comp_RelBranch, Dis_RelBranch2, Int_RelBranch, IS_CONDBRANCH|IN_RS|IN_RT|DELAYSLOT), //L = likely
	INSTR("bnel",  Comp_RelBranch, Dis_RelBranch2, Int_RelBranch, IS_CONDBRANCH|IN_RS|IN_RT|DELAYSLOT),
	INSTR("blezl", Comp_RelBranch, Dis_RelBranch,  Int_RelBranch, IS_CONDBRANCH|IN_RS|DELAYSLOT),
	INSTR("bgtzl", Comp_RelBranch, Dis_RelBranch,  Int_RelBranch, IS_CONDBRANCH|IN_RS|DELAYSLOT),
	//24
	{VFPU0},
	{VFPU1},
	{Emu},
	{VFPU3},
	{Spe2},//special2
	{-2}, //, "jalx", 0, Dis_JumpType, Int_JumpType},
	{-2},
	{Spe3},//special3
	//32
	INSTR("lb",  Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_MEM|IN_IMM16|IN_RS_ADDR|OUT_RT),
	INSTR("lh",  Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_MEM|IN_IMM16|IN_RS_ADDR|OUT_RT),
	INSTR("lwl", Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_MEM|IN_IMM16|IN_RS_ADDR|OUT_RT),
	INSTR("lw",  Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_MEM|IN_IMM16|IN_RS_ADDR|OUT_RT),
	INSTR("lbu", Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_MEM|IN_IMM16|IN_RS_ADDR|OUT_RT),
	INSTR("lhu", Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_MEM|IN_IMM16|IN_RS_ADDR|OUT_RT),
	INSTR("lwr", Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_MEM|IN_IMM16|IN_RS_ADDR|OUT_RT),
	{-2},
	//40
	INSTR("sb",  Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_IMM16|IN_RS_ADDR|IN_RT|OUT_MEM),
	INSTR("sh",  Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_IMM16|IN_RS_ADDR|IN_RT|OUT_MEM),
	INSTR("swl", Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_IMM16|IN_RS_ADDR|IN_RT|OUT_MEM),
	INSTR("sw",  Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_IMM16|IN_RS_ADDR|IN_RT|OUT_MEM),
	{-2},
	{-2},
	INSTR("swr", Comp_ITypeMem, Dis_ITypeMem, Int_ITypeMem, IN_IMM16|IN_RS_ADDR|IN_RT|OUT_MEM),
	INSTR("cache", Comp_Generic, Dis_Generic, Int_Cache, 0),
	//48
	INSTR("ll", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("lwc1", Comp_Generic, Dis_FPULS, Int_FPULS, 0),
	INSTR("lv.s", Comp_Generic, Dis_SV, Int_SV, IS_VFPU),
	{-2}, // HIT THIS IN WIPEOUT
	{VFPU4Jump},
	INSTR("lv", Comp_Generic, Dis_SVLRQ, Int_SVQ, IS_VFPU),
	INSTR("lv.q", Comp_Generic, Dis_SVQ, Int_SVQ, IS_VFPU), //copU
	{VFPU5},
	//56
	INSTR("sc", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("swc1", Comp_Generic, Dis_FPULS, Int_FPULS, 0), //copU
	INSTR("sv.s", Comp_Generic, Dis_SV, Int_SV,IS_VFPU),
	{-2}, 
	//60
	{VFPU6},
	INSTR("sv", Comp_Generic, Dis_SVLRQ, Int_SVQ, IS_VFPU), //copU
	INSTR("sv.q", Comp_Generic, Dis_SVQ, Int_SVQ, IS_VFPU),
	INSTR("vflush", Comp_Generic, Dis_Vflush, Int_Vflush, IS_VFPU),
};

const MIPSInstruction tableSpecial[64] = 
{
	INSTR("sll",   Comp_ShiftType, Dis_ShiftType, Int_ShiftType, OUT_RD|IN_RT|IN_SA),
	{-2}, //copu
	
	INSTR("srl",   Comp_ShiftType, Dis_ShiftType, Int_ShiftType, OUT_RD|IN_RT|IN_SA),
	INSTR("sra",   Comp_ShiftType, Dis_ShiftType, Int_ShiftType, OUT_RD|IN_RT|IN_SA),
	INSTR("sllv",  Comp_ShiftType, Dis_VarShiftType, Int_ShiftType, OUT_RD|IN_RT|IN_RS_SHIFT),
	{-2},
	INSTR("srlv",  Comp_ShiftType, Dis_VarShiftType, Int_ShiftType, OUT_RD|IN_RT|IN_RS_SHIFT),
	INSTR("srav",  Comp_ShiftType, Dis_VarShiftType, Int_ShiftType, OUT_RD|IN_RT|IN_RS_SHIFT),

	//8
	INSTR("jr",    Comp_JumpReg, Dis_JumpRegType, Int_JumpRegType,0),
	INSTR("jalr",  Comp_JumpReg, Dis_JumpRegType, Int_JumpRegType,0),
	INSTR("movz",  Comp_Generic, Dis_RType3, Int_RType3, OUT_RD|IN_RS|IN_RT),
	INSTR("movn",  Comp_Generic, Dis_RType3, Int_RType3, OUT_RD|IN_RS|IN_RT),
	INSTR("syscall", Comp_Syscall, Dis_Syscall, Int_Syscall,0),
	INSTR("break", Comp_Generic, Dis_Generic, 0, 0),
	{-2},
	INSTR("sync",  Comp_Generic, Dis_Generic, 0, 0),

	//16
	INSTR("mfhi",  Comp_Generic, Dis_FromHiloTransfer, Int_MulDivType, OUT_RD|IN_OTHER),
	INSTR("mthi",  Comp_Generic, Dis_ToHiloTransfer,   Int_MulDivType, IN_RS|OUT_OTHER),
	INSTR("mflo",  Comp_Generic, Dis_FromHiloTransfer, Int_MulDivType, OUT_RD|IN_OTHER),
	INSTR("mtlo",  Comp_Generic, Dis_ToHiloTransfer,   Int_MulDivType, IN_RS|OUT_OTHER),
	{-2},
	{-2},
	INSTR("clz",   Comp_Generic, Dis_RType2, Int_RType2, OUT_RD|IN_RS|IN_RT),
	INSTR("clo",   Comp_Generic, Dis_RType2, Int_RType2, OUT_RD|IN_RS|IN_RT),

	//24
	INSTR("mult",  Comp_Generic, Dis_MulDivType, Int_MulDivType, IN_RS|IN_RT|OUT_OTHER),
	INSTR("multu", Comp_Generic, Dis_MulDivType, Int_MulDivType, IN_RS|IN_RT|OUT_OTHER),
	INSTR("div",   Comp_Generic, Dis_MulDivType, Int_MulDivType, IN_RS|IN_RT|OUT_OTHER),
	INSTR("divu",  Comp_Generic, Dis_MulDivType, Int_MulDivType, IN_RS|IN_RT|OUT_OTHER),
	INSTR("madd",  Comp_Generic, Dis_MulDivType, Int_MulDivType, IN_RS|IN_RT|OUT_OTHER),
	INSTR("maddu", Comp_Generic, Dis_MulDivType, Int_MulDivType, IN_RS|IN_RT|OUT_OTHER),
	{-2},
	{-2},

	//32
	INSTR("add",  Comp_RType3, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("addu", Comp_RType3, Dis_addu,   Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("sub",  Comp_RType3, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("subu", Comp_RType3, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("and",  Comp_RType3, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("or",   Comp_RType3, Dis_addu,   Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("xor",  Comp_RType3, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("nor",  Comp_RType3, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),

	//40
	{-2},
	{-2},
	INSTR("slt",  Comp_Generic, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("sltu", Comp_Generic, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("max",  Comp_Generic, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),
	INSTR("min",  Comp_Generic, Dis_RType3, Int_RType3,IN_RS|IN_RT|OUT_RD),
	{-2},
	{-2},

	//48
	INSTR("tge",  Comp_Generic, Dis_RType3, 0, 0),
	INSTR("tgeu", Comp_Generic, Dis_RType3, 0, 0),
	INSTR("tlt",  Comp_Generic, Dis_RType3, 0, 0),
	INSTR("tltu", Comp_Generic, Dis_RType3, 0, 0),
	INSTR("teq",  Comp_Generic, Dis_RType3, 0, 0),
	{-2},
	INSTR("tne",  Comp_Generic, Dis_RType3, 0, 0),
	{-2},

	//56
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
};

const MIPSInstruction tableSpecial2[64] = 
{
	INSTR("add.s",  Comp_Generic, Dis_FPU3op, Int_FPU3op, 0),
	INSTR("sub.s",  Comp_Generic, Dis_FPU3op, Int_FPU3op, 0),
	INSTR("mul.s",  Comp_Generic, Dis_FPU3op, Int_FPU3op, 0),
	INSTR("div.s",  Comp_Generic, Dis_FPU3op, Int_FPU3op, 0),
	INSTR("sqrt.s", Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
	INSTR("abs.s",  Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
	INSTR("mov.s",  Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
	INSTR("neg.s",  Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
//8
	{-2}, {-2}, {-2}, {-2},
	INSTR("round.w.s",  Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
	INSTR("trunc.w.s",  Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
	INSTR("ceil.w.s",   Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
	INSTR("floor.w.s",  Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
//16	
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
//24
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
//32
	INSTR("cvt.s.w", Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
	{-2}, {-2}, {-2}, 
//36
	INSTR("cvt.w.s", Comp_Generic, Dis_FPU2op, Int_FPU2op, 0),
	{-2}, 
	INSTR("dis.int", Comp_Generic, Dis_Generic, Int_Interrupt, 0), 
	{-2}, 
//40
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
//48
	INSTR("c.f",   Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.un",  Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.eq",  Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.ueq", Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.olt", Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.ult", Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.ole", Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.ule", Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.sf",  Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.ngle",Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.seq", Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.ngl", Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.lt",  Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.nge", Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.le",  Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
	INSTR("c.ngt", Comp_Generic, Dis_FPUComp, Int_FPUComp, 0),
};


const MIPSInstruction tableSpecial3[64] = 
{
	INSTR("ext", Comp_Generic, Dis_Special3, Int_Special3, IN_RS|OUT_RT),
	{-2},
	{-2},
	{-2},
	INSTR("ins", Comp_Generic, Dis_Special3, Int_Special3, IN_RS|OUT_RT),
	{-2},
	{-2},
	{-2},
	//8
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	//16
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	//32
	{ALLEGREX0}, 
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	//40
	{ALLEGREX0},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	{-2}, {-2}, {-2}, 
	INSTR("rdhwr", Comp_Generic, Dis_Generic, 0, 0),
	{-2}, {-2}, {-2}, {-2},
};


const MIPSInstruction tableRegImm[32] = 
{
	INSTR("bltz",  Comp_RelBranchRI, Dis_RelBranch, Int_RelBranchRI, IS_CONDBRANCH|IN_RS),
	INSTR("bgez",  Comp_RelBranchRI, Dis_RelBranch, Int_RelBranchRI, IS_CONDBRANCH|IN_RS),
	INSTR("bltzl", Comp_RelBranchRI, Dis_RelBranch, Int_RelBranchRI, IS_CONDBRANCH|IN_RS),
	INSTR("bgezl", Comp_RelBranchRI, Dis_RelBranch, Int_RelBranchRI, IS_CONDBRANCH|IN_RS),
	{-2},
	{-2},
	{-2},
	{-2},

	INSTR("tgei",  Comp_Generic, Dis_Generic, 0, 0),
	INSTR("tgeiu", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("tlti",  Comp_Generic, Dis_Generic, 0, 0),
	INSTR("tltiu", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("teqi",  Comp_Generic, Dis_Generic, 0, 0),
	{-2},
	INSTR("tnei",  Comp_Generic, Dis_Generic, 0, 0),
	{-2},

	INSTR("bltzal",  0, Dis_RelBranch, 0, IS_CONDBRANCH|IN_RS|OUT_RA),  
	INSTR("bgezal",  0, Dis_RelBranch, 0, IS_CONDBRANCH|IN_RS|OUT_RA),
	INSTR("bltzall", 0, Dis_RelBranch, 0, IS_CONDBRANCH|IN_RS|OUT_RA), //L = likely
	INSTR("bgezall", 0, Dis_RelBranch, 0, IS_CONDBRANCH|IN_RS|OUT_RA),
	{-2},
	{-2},
	{-2},
	{-2},

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, 
	INSTR("synci", Comp_Generic, Dis_Generic, 0, 0),
};

const MIPSInstruction tableCop2[32] = 
{
	INSTR("mfc2", Comp_Generic, Dis_Generic, 0, OUT_RT),
	{-2},
	INSTR("cfc2", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("mfv", Comp_Generic, Dis_Mftv, Int_Mftv, 0),
	INSTR("mtc2", Comp_Generic, Dis_Generic, 0, IN_RT),
	{-2},
	INSTR("ctc2", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("mtv", Comp_Generic, Dis_Mftv, Int_Mftv, 0),

	{Cop2BC2},
	INSTR("??", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("??", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("??", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("??", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("??", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("??", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("??", Comp_Generic, Dis_Generic, 0, 0),

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
};

const MIPSInstruction tableCop2BC2[4] = 
{
	INSTR("bvf", 0, Dis_VBranch,Int_VBranch,IS_CONDBRANCH),
	INSTR("bvt", 0, Dis_VBranch,Int_VBranch,IS_CONDBRANCH),
	INSTR("bvfl", 0, Dis_VBranch,Int_VBranch,IS_CONDBRANCH),
	INSTR("bvtl", 0, Dis_VBranch,Int_VBranch,IS_CONDBRANCH),
};

const MIPSInstruction tableCop0[32] = 
{
	INSTR("mfc0", Comp_Generic, Dis_Generic, 0, OUT_RT),
	{-2}, 
	{-2}, 
	{-2}, 
	INSTR("mtc0", Comp_Generic, Dis_Generic, 0, IN_RT),
	{-2}, 
	{-2}, 
	{-2}, 

	{-2}, 
	{-2}, 
	INSTR("rdpgpr", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("mfmc0", Comp_Generic, Dis_Generic, 0, 0),

	{-2}, 
	{-2}, 
	INSTR("wrpgpr", Comp_Generic, Dis_Generic, 0, 0),
	{-2}, 

	{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},
	{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},{Cop0CO},
};


//we won't encounter these since we only do user mode emulation
MIPSInstruction tableCop0CO[64] = 
{
	{-2}, 
	INSTR("tlbr", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("tlbwi", Comp_Generic, Dis_Generic, 0, 0),
	{-2}, 
	{-2}, 
	{-2}, 
	INSTR("tlbwr", Comp_Generic, Dis_Generic, 0, 0),
	{-2}, 

	INSTR("tlbp", Comp_Generic, Dis_Generic, 0, 0),
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, 
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	INSTR("eret", Comp_Generic, Dis_Generic, 0, 0),
	INSTR("iack", Comp_Generic, Dis_Generic, 0, 0),
	{-2}, {-2}, {-2}, {-2}, {-2}, 
	INSTR("deret", Comp_Generic, Dis_Generic, 0, 0),

	INSTR("wait", Comp_Generic, Dis_Generic, 0, 0),
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},

	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
	{-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2}, {-2},
};


MIPSInstruction tableCop1[32] = 
{
	INSTR("mfc1",Comp_Generic, Dis_mxc1,Int_mxc1, OUT_RT),
	{-2},
	INSTR("cfc1",Comp_Generic, Dis_mxc1,Int_mxc1, 0),
	{-2},
	INSTR("mtc1",Comp_Generic, Dis_mxc1,Int_mxc1, IN_RT),
	{-2},
	INSTR("ctc1",Comp_Generic, Dis_mxc1,Int_mxc1, 0),
	{-2},

	{Cop1BC}, {-2},	{-2},	{-2},	{-2},	{-2},	{-2},	{-2},

	{Spe2},	{-2},	{-2},	{-2},
	{Spe2},	{-2},	{-2},	{-2},

	{-2},{-2},{-2},{-2},{-2},{-2},{-2},{-2},
};

MIPSInstruction tableCop1BC[32] = 
{
	{-1,"bc1f",  Comp_FPUBranch, Dis_FPUBranch, Int_FPUBranch,IS_CONDBRANCH|IN_FPUFLAG},
	{-1,"bc1t",  Comp_FPUBranch, Dis_FPUBranch, Int_FPUBranch,IS_CONDBRANCH|IN_FPUFLAG},
	{-1,"bc1fl", Comp_FPUBranch, Dis_FPUBranch, Int_FPUBranch,IS_CONDBRANCH|IN_FPUFLAG},
	{-1,"bc1tl", Comp_FPUBranch, Dis_FPUBranch, Int_FPUBranch,IS_CONDBRANCH|IN_FPUFLAG},
	{-2},{-2},{-2},{-2},
	{-2},{-2},{-2},{-2},{-2},{-2},{-2},{-2},
	{-2},{-2},{-2},{-2},{-2},{-2},{-2},{-2},
	{-2},{-2},{-2},{-2},{-2},{-2},{-2},{-2},
};

MIPSInstruction tableVFPU0[8] = 
{
	INSTR("vadd",Comp_Generic, Dis_VectorSet3, Int_VecDo3, IS_VFPU),
	INSTR("vsub",Comp_Generic, Dis_VectorSet3, Int_VecDo3, IS_VFPU), 
	INSTR("vsbn",Comp_Generic, Dis_VectorSet3, 0, IS_VFPU), 
	{-2}, {-2}, {-2}, {-2}, 
	
	INSTR("vdiv",Comp_Generic, Dis_VectorSet3, Int_VecDo3, IS_VFPU),
};

MIPSInstruction tableVFPU1[8] = 
{
	INSTR("vmul",Comp_Generic, Dis_VectorSet3, Int_VecDo3, IS_VFPU),
	INSTR("vdot",Comp_Generic, Dis_VectorDot, Int_VDot, IS_VFPU), 
	INSTR("vscl",Comp_Generic, Dis_VScl, Int_VScl, IS_VFPU),
	INSTR("vhdp",Comp_Generic, Dis_Generic, 0, IS_VFPU), 
	{-2}, 
	INSTR("vcrs",Comp_Generic, Dis_Vcrs, Int_Vcrs, IS_VFPU), 
	INSTR("vdet",Comp_Generic, Dis_Generic, 0, IS_VFPU), 
	{-2},
};

MIPSInstruction tableVFPU3[8] = //011011 xxx
{
	INSTR("vcmp",Comp_Generic, Dis_Vcmp, Int_Vcmp, IS_VFPU),
	INSTR("v???",Comp_Generic, Dis_Generic, 0, IS_VFPU), 
	INSTR("vmin",Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vmax",Comp_Generic, Dis_Generic, 0, IS_VFPU), 
	{-2}, 
	INSTR("vscmp",Comp_Generic, Dis_Generic, 0, IS_VFPU), 
	INSTR("vsge",Comp_Generic, Dis_Generic, 0, IS_VFPU), 
	INSTR("vslt",Comp_Generic, Dis_Generic, 0, IS_VFPU),
};


MIPSInstruction tableVFPU4Jump[32] = //110100 xxxxx
{
	{VFPU4},
	{VFPU7},
	{VFPU9},
	INSTR("vcst", Comp_Generic, Dis_Vcst, Int_Vcst, IS_VFPU),
	{-2},{-2},{-2},{-2},

	//8
	{-2},{-2},{-2},{-2},
	{-2},{-2},{-2},{-2},

	//16
	INSTR("vf2in", Comp_Generic, Dis_Vf2i, Int_Vf2i, IS_VFPU),
	INSTR("vf2iz", Comp_Generic, Dis_Vf2i, Int_Vf2i, IS_VFPU),
	INSTR("vf2iu", Comp_Generic, Dis_Vf2i, Int_Vf2i, IS_VFPU),
	INSTR("vf2id", Comp_Generic, Dis_Vf2i, Int_Vf2i, IS_VFPU),
	//20
	INSTR("vi2f", Comp_Generic, Dis_Vf2i, Int_Vi2f, IS_VFPU),
	INSTR("vcmov", Comp_Generic, Dis_Vcmov,Int_Vcmov,IS_VFPU),
	{-2},
	{-2},

	INSTR("vwbn.s", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vwbn.s", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vwbn.s", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vwbn.s", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vwbn.s", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vwbn.s", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vwbn.s", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vwbn.s", Comp_Generic, Dis_Generic, 0, IS_VFPU),
};

MIPSInstruction tableVFPU7[32] = 
{
	INSTR("vrnds", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vrndi", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vrndf1", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vrndf2", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	
	{-2},{-2},{-2},{-2},
	//8
	{-2},{-2},{-2},{-2},
	{-2},{-2},{-2},{-2},
	//16
	{-2},
	{-2},
	INSTR("vf2h", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vh2f", Comp_Generic, Dis_Generic, 0, IS_VFPU),

	{-2},
	{-2},
	{-2},
	INSTR("vlgb", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	//24
	{-2},
	{-2},
	INSTR("vus2i", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vs2i", Comp_Generic, Dis_Generic, 0, IS_VFPU),

	INSTR("vi2uc", Comp_Generic, Dis_Vi2x, Int_Vi2x, IS_VFPU),
	INSTR("vi2c",  Comp_Generic, Dis_Vi2x, Int_Vi2x, IS_VFPU),
	INSTR("vi2us", Comp_Generic, Dis_Vi2x, Int_Vi2x, IS_VFPU),
	INSTR("vi2s",  Comp_Generic, Dis_Vi2x, Int_Vi2x, IS_VFPU),
};

// 110100 00000 10100 0000000000000000
// 110100 00000 10111 0000000000000000
MIPSInstruction tableVFPU4[32] =  //110100 00000 xxxxx
{
	INSTR("vmov", Comp_Generic, Dis_VectorSet2, Int_VV2Op,IS_VFPU), 
	INSTR("vabs", Comp_Generic, Dis_VectorSet2, Int_VV2Op,IS_VFPU), 
	INSTR("vneg", Comp_Generic, Dis_VectorSet2, Int_VV2Op,IS_VFPU), 
	INSTR("vidt", Comp_Generic, Dis_VectorSet1, Int_Vidt,IS_VFPU), 
	INSTR("vsat0", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	INSTR("vsat1", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	INSTR("vzero", Comp_Generic, Dis_VectorSet1, Int_VVectorInit, IS_VFPU),
	INSTR("vone",  Comp_Generic, Dis_VectorSet1, Int_VVectorInit, IS_VFPU),
//8
	{-2},{-2},{-2},{-2},{-2},{-2},{-2},{-2},
//16
	INSTR("vrcp", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	INSTR("vrsq", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	INSTR("vsin", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	INSTR("vcos", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	INSTR("vexp2", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	INSTR("vlog2", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	INSTR("vsqrt", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	INSTR("vasin", Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
//24
	INSTR("vnrcp", Comp_Generic, Dis_VectorSet2, Int_VV2Op,IS_VFPU),
	{-2},
	INSTR("vnsin", Comp_Generic, Dis_VectorSet2, Int_VV2Op,IS_VFPU), 
	{-2},
	INSTR("vrexp2",Comp_Generic, Dis_VectorSet2, Int_VV2Op, IS_VFPU),
	{-2},{-2},{-2},
//32
};

MIPSInstruction tableVFPU5[8] =  //110111 xxx
{
	INSTR("vpfxs",Comp_Generic, Dis_VPFXST, Int_VPFX, IS_VFPU),
	INSTR("vpfxs",Comp_Generic, Dis_VPFXST, Int_VPFX, IS_VFPU),
	INSTR("vpfxt",Comp_Generic, Dis_VPFXST, Int_VPFX, IS_VFPU),
	INSTR("vpfxt",Comp_Generic, Dis_VPFXST, Int_VPFX, IS_VFPU),
	INSTR("vpfxd",Comp_Generic, Dis_VPFXD, Int_VPFX, IS_VFPU),
	INSTR("vpfxd",Comp_Generic, Dis_VPFXD, Int_VPFX, IS_VFPU),
	INSTR("viim.s",Comp_Generic,Dis_Viim,Int_Viim, IS_VFPU),
	INSTR("vfim.s",Comp_Generic,Dis_Viim,Int_Viim, IS_VFPU),
};

MIPSInstruction tableVFPU6[32] =  //111100 xxx
{
//0
	INSTR("vmmul",Comp_Generic, Dis_MatrixMult, Int_Vmmul, IS_VFPU),
	INSTR("vmmul",Comp_Generic, Dis_MatrixMult, Int_Vmmul, IS_VFPU),
	INSTR("vmmul",Comp_Generic, Dis_MatrixMult, Int_Vmmul, IS_VFPU),
	INSTR("vmmul",Comp_Generic, Dis_MatrixMult, Int_Vmmul, IS_VFPU),

	INSTR("v(h)tfm2",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	INSTR("v(h)tfm2",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	INSTR("v(h)tfm2",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	INSTR("v(h)tfm2",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
//8
	INSTR("v(h)tfm3",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	INSTR("v(h)tfm3",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	INSTR("v(h)tfm3",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	INSTR("v(h)tfm3",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),

	INSTR("v(h)tfm4",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	INSTR("v(h)tfm4",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	INSTR("v(h)tfm4",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	INSTR("v(h)tfm4",Comp_Generic, Dis_Vtfm, Int_Vtfm, IS_VFPU),
	//16
	INSTR("vmscl",Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vmscl",Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vmscl",Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vmscl",Comp_Generic, Dis_Generic, 0, IS_VFPU),

	INSTR("vcrsp/vqm",Comp_Generic, Dis_CrossQuat, Int_CrossQuat, IS_VFPU),
	INSTR("vcrsp/vqm",Comp_Generic, Dis_CrossQuat, Int_CrossQuat, IS_VFPU),
	INSTR("vcrsp/vqm",Comp_Generic, Dis_CrossQuat, Int_CrossQuat, IS_VFPU),
	INSTR("vcrsp/vqm",Comp_Generic, Dis_CrossQuat, Int_CrossQuat, IS_VFPU),
//24
	{-2},
	{-2},
	{-2},
	{-2},

	{VFPUMatrix1},
	INSTR("vrot",Comp_Generic, Dis_VRot, Int_Vrot, IS_VFPU),
	{-2},
	{-2},
};

MIPSInstruction tableVFPUMatrixSet1[16] = //111100 11100 0xxxx   (rm x is 16)
{
	INSTR("vmmov",Comp_Generic, Dis_MatrixSet2, Int_Vmmov, IS_VFPU),
	{-2},
	{-2},
	INSTR("vmidt",Comp_Generic, Dis_MatrixSet1, Int_VMatrixInit, IS_VFPU),

	{-2},
	{-2},
	INSTR("vmzero", Comp_Generic, Dis_MatrixSet1, Int_VMatrixInit, IS_VFPU),
	INSTR("vmone",  Comp_Generic, Dis_MatrixSet1, Int_VMatrixInit, IS_VFPU),

	{-2},{-2},{-2},{-2},{-2},{-2},{-2},{-2},
};

MIPSInstruction tableVFPU9[32] = //110100 00010 xxxxx
{
	INSTR("vsrt1", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vsrt2", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vbfy1", Comp_Generic, Dis_Vbfy, Int_Vbfy, IS_VFPU),
	INSTR("vbfy2", Comp_Generic, Dis_Vbfy, Int_Vbfy, IS_VFPU),
	//4
	INSTR("vocp", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vsocp", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vfad", Comp_Generic, Dis_Vfad, Int_Vfad, IS_VFPU),
	INSTR("vavg", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	//8
	INSTR("vsrt3", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vsrt4", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vsgn", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	{-2},
	//12
	{-2},
	{-2},
	{-2},
	{-2},

	//16
	INSTR("vmfvc", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vmtvc", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	{-2},
	{-2},

	//20
	{-2},{-2},{-2},{-2},
	//24
	{-2},
	INSTR("vt4444", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vt5551", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	INSTR("vt5650", Comp_Generic, Dis_Generic, 0, IS_VFPU),
	
	//28
	{-2},{-2},{-2},{-2},
};

MIPSInstruction tableALLEGREX0[32] =  //111111
{
	{-2},
	{-2},
	INSTR("wsbh",Comp_Generic, Dis_Allegrex2,Int_Allegrex2,0),
	INSTR("wsbw",Comp_Generic, Dis_Allegrex2,Int_Allegrex2,0),
	{-2},	{-2},	{-2},	{-2},
//8
	{-2},	{-2},	{-2},	{-2},	{-2},	{-2},	{-2},	{-2},
//16
	INSTR("seb", Comp_Generic, Dis_Allegrex,Int_Allegrex, IN_RT|OUT_RD),
	{-2},
	{-2},
	{-2},
//20
	INSTR("bitrev",Comp_Generic, Dis_Allegrex,Int_Allegrex, IN_RT|OUT_RD),
	{-2},
	{-2},
	{-2},
//24
	INSTR("seh", Comp_Generic, Dis_Allegrex,Int_Allegrex, IN_RT|OUT_RD),
	{-2},
	{-2},
	{-2},
//28
	{-2},
	{-2},
	{-2},
	{-2},
};


MIPSInstruction tableEMU[4] = 
{
	INSTR("RUNBLOCK",Comp_RunBlock,Dis_Emuhack,Int_Emuhack, 0xFFFFFFFF),
	INSTR("RetKrnl", 0,Dis_Emuhack,Int_Emuhack, 0),
	{-2},
	{-2},
};

const int encodingBits[NumEncodings][2] = //huh?
{
	26, 6, //IMME
	0,  6, //Special
	0,  6, //special2
	0,  6, //special3
	16, 5, //RegImm
	21, 5, //Cop0
	0,  6, //Cop0CO
	21, 5, //Cop1
	16, 5, //Cop1BC
	21, 5, //Cop2
	16, 2, //Cop2BC2
	0,  0, //Cop2Rese
	23, 3, //VFPU0
	23, 3, //VFPU1
	23, 1, //VFPU3
	21, 5, //VFPU4Jump
	16, 5, //VFPU7
	16, 5, //VFPU4
	23, 3, //VFPU5
	21, 5, //VFPU6
	16, 3, //VFPUMatrix1
	16, 5, //VFPU9
	6,  5, //ALLEGREX0
	24, 2, //EMUHACK
};		


const MIPSInstruction *mipsTables[NumEncodings] =
{
	tableImmediate,
	tableSpecial,
	tableSpecial2,
	tableSpecial3,
	tableRegImm,
	tableCop0,
	tableCop0CO,
	tableCop1,
	tableCop1BC,
	tableCop2,
	tableCop2BC2,
	0,
	tableVFPU0, //vfpu0
	tableVFPU1, //vfpu1
	tableVFPU3, //vfpu3
	tableVFPU4Jump,
	tableVFPU7, //vfpu4     110100 00001
	tableVFPU4, //vfpu4     110100 00000
	tableVFPU5, //vfpu5     110111
	tableVFPU6, //vfpu6     111100
	tableVFPUMatrixSet1,
	tableVFPU9,
	tableALLEGREX0,
	tableEMU
};



//arm encoding table
//const MIPSInstruction mipsinstructions[] = 
//{
//{Comp_Unimpl,Dis_Unimpl, Info_NN,    0, 0x601,       0x1FE,0}, //could be used for drec hook :) bits 5-24 plus 0-3 are available, 19 bits are more than enough
// DATA PROCESSING INSTRUCTIONS
//                        S
//	{Comp_AND,   Dis_AND,    Info_DP,    0, DATAP(0, 0), 0x20F, {0}},
//};


//Todo : generate dispatcher functions from above tables
//instead of this horribly slow abomination

const MIPSInstruction *MIPSGetInstruction(u32 op)
{
	MipsEncoding encoding = Imme;
	const MIPSInstruction *instr = &tableImmediate[op>>26];
	while (instr->altEncoding != -1) 
	{
		const MIPSInstruction *table = mipsTables[encoding];
		int mask = ((1<<encodingBits[encoding][1])-1);
		int shift = encodingBits[encoding][0];
		int subop = (op >> shift) & mask;
		instr = &table[subop];
		if (encoding == Rese)
			return 0; //invalid instruction
//		if (encoding == Spe3)
//			__asm int 3
		if (!instr)
			return 0;
		if (instr->altEncoding == -2)
		{
			//BAD!!
			return 0; //invalid instruction
		}
		encoding = (MipsEncoding)instr->altEncoding;
	} 
	//alright, we have a valid MIPS instruction!
	return instr;
}



void MIPSCompileOp(u32 op)
{
	if (op==0)
		return;
	const MIPSInstruction *instr = MIPSGetInstruction(op);
	if (instr)
	{
		if (instr->compile)
			instr->compile(op);
		else
		{
			LOG(CPU,"MIPSCompileOp %08x failed",op);
			//MessageBox(0,"ARGH2",0,0);//compile an interpreter call
		}
	}
	else
	{
		MessageBox(0,"ARGH",0,0);
	}
}


void MIPSDisAsm(u32 op, u32 pc, char *out)
{
	if (op == 0)
	{
		//ANDEQ R0,R0,R0 is probably not used for legitimate purposes :P
		sprintf(out,"---\t---");
	}
	else
	{
		disPC = pc;
		const MIPSInstruction *instr = MIPSGetInstruction(op);
		if (instr && instr->disasm)
			instr->disasm(op, out);
		else
		{
			strcpy(out, "no instruction :(");
			//__asm int 3
			MIPSGetInstruction(op);
		}
	}
}


void MIPSInterpret(u32 op) //only for those rare ones
{
	//if ((op&0xFFFFF000) == 0xd0110000)
	//	DebugBreak();
	//if (atable[CRUNCH_MIPS_OP(op)].interpret)
	//		atable[CRUNCH_MIPS_OP(op)].interpret(op);
	//	else
	//		_dbg_assert_msg_(MIPS,0,"Trying to interpret instruction that can't be interpreted");
	const MIPSInstruction *instr = MIPSGetInstruction(op);
	if (instr && instr->interpret)
		instr->interpret(op);
	else
		_dbg_assert_msg_(CPU,0,"Trying to interpret instruction that can't be interpreted");
}

const char *MIPSGetName(u32 op)
{
	static const char *noname = "unk";
	const MIPSInstruction *instr = MIPSGetInstruction(op);
	if (!instr)
		return noname;
	else
		return instr->name;
}


u32 MIPSGetInfo(u32 op)
{
	//	int crunch = CRUNCH_MIPS_OP(op);
	const MIPSInstruction *instr = MIPSGetInstruction(op);
	if (instr)
		return instr->information;
	else
		return 0;
}


MIPSInterpretFunc MIPSGetInterpretFunc(u32 op)
{
	const MIPSInstruction *instr = MIPSGetInstruction(op);
	if (instr->interpret)
		return instr->interpret;
	else
		return 0;
}




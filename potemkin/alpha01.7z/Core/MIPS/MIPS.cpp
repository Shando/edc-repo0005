#include "stdafx.h"
#include "MIPS.h"
#include "MIPSTables.h"
#include "MIPSCompiler.h"
#include "MIPSBlockCache.h"


MIPSState mipsr4k;
MIPSState *currentMIPS = &mipsr4k;


void MIPSState::Reset()
{
	for (int i=0; i<32; i++)
		r[i]=0;

  hi=0;
  lo=0;
}

 

TCHAR *MIPSState::GetName()
{
	return _T("R4");
}


void MIPSState::SingleStep()
{
	currentMIPS = this;
	MIPS_SingleStep();
//	MIPSComp::RunBlock(mipsr4k.pc);
}

void MIPSState::FastRun()
{
	currentMIPS = this;
	for (int i=0; i<100; i++)
	{
//		MIPSComp::RunBlock(mipsr4k.pc);
		MIPS_SingleStep();
	}
}


void MIPSState::Irq()
{
//	if (IRQEnabled())
	{
//		spsr_irq = GetCPSR();
//		r14_irq = r[MIPS_REG_PC] - (thumb ? 2 : 4);
//		ModeSwitch(MIPSMODE_IRQ,true);
//		cpsr = (cpsr & 0xFFFFFF80 | MIPS_F_MASK) | MIPSMODE_IRQ | MIPS_I_MASK;
//		thumb = 0;
//
//		r[MIPS_REG_PC] = highVectors?0xFFFF0018:0x00000018;
	}
}


void MIPSState::SWI()
{
//	bool savedThumb = thumb;
//	r14_svc = r[MIPS_REG_PC] /* + (thumb ? 2 : 4)*/; //should be instruction after current one
//	spsr_svc = GetCPSR();
//	ModeSwitch(MIPSMODE_SUPER,true);
//	cpsr = (cpsr & 0xFFFFFF80) | MIPSMODE_SUPER | MIPS_I_MASK;
//	thumb=0;
//	r[MIPS_REG_PC] = highVectors ? 0xFFFF0008:0x00000008;
}
 
void MIPSState::UndefInstr()
{

}

const TCHAR *MIPSState::GetRegName(int cat, int index)
{
	static int access=0;
	access++;
	access&=3;

	static const TCHAR *regName[32] = {
		"zero",		"at",          "v0",           "v1",           
		"a0",		"a1",          "a2",           "a3",           
		"t0",		"t1",          "t2",           "t3",          
		"t4",		"t5",          "t6",           "t7",          
		"s0",		"s1",          "s2",           "s3",           
		"s4",		"s5",          "s6",           "s7",           
		"t8",		"t9",          "k0",           "k1",         
		"gp",		"sp",          "fp",           "ra"
	};
	if (cat == 0)
		return regName[index];
	else if (cat == 1)
	{
		static char temp[4][16];
		sprintf(temp[access],"f%i",index);
		return temp[access];
	}
	else if (cat == 2)
	{
		static char temp[4][16];
		sprintf(temp[access],"v%03x",index);
		return temp[access];
	}
	else
		return "boo";
}


#include "stdafx.h"
#include "MIPSCompiler.h"
#include "MIPSCompALU.h"
#include "MIPSRegCache.h"
#include "MIPSAnalyst.h"
#include "../MemMap.h"


#define _RS ((op>>21) & 0x1F)
#define _RT ((op>>16) & 0x1F)
#define _RD ((op>>11) & 0x1F)
#define _FS ((op>>11) & 0x1F)
#define _FT ((op>>16) & 0x1F)
#define _FD ((op>>6 ) & 0x1F)
#define _POS  ((op>>6 ) & 0x1F)
#define _SIZE ((op>>11 ) & 0x1F)


namespace MIPSComp
{
	void Comp_ITypeMem(u32 op)
	{
		int imm = (signed short)(op&0xFFFF);
		int rt = _RT;
		int rs = _RS;
		int o = op>>26;
		switch (o) 
		{
		case 37: //R(rt) = ReadMem16(addr); break; //lhu
		case 36: //R(rt) = ReadMem8 (addr); break; //lbu
		case 35: //R(rt) = ReadMem32(addr); break; //lw
			{
				TX86Regs s = MapMIPSReg(rs, true);
				FlushAll();
				ADD_ImmToReg(1,s,imm,0);
				PUSH_RegToStack(s);
				
				switch (o) {
				case 37:CALLFunc((u32)&ReadMem16); break;
				case 36:CALLFunc((u32)&ReadMem8); break;
				case 35:CALLFunc((u32)&ReadMem32); break;
				}

				::ADD_ImmToReg(1,ESP,4,0);
				TX86Regs t = MapMIPSReg(rt, false);
				MOV_Reg2ToReg1(1,t,EAX);
				SetDirty(t);
			}
			break;
		case 132: //R(rt) = (u32)(s32)(s8) ReadMem8 (addr); break; //lb
		case 133: //R(rt) = (u32)(s32)(s16)ReadMem16(addr); break; //lh
		case 136: //R(rt) = ReadMem8 (addr); break; //lbu
		case 140: //WriteMem8 (addr, R(rt)); break; //sb
			
		case 40:
		case 41: //WriteMem16(addr, R(rt)); break; //sh
		case 43: //WriteMem32(addr, R(rt)); break; //sw
			{
				TX86Regs s = MapMIPSReg(rs,true);
				TX86Regs t = MapMIPSReg(rt,true);
				FlushAll();
				ADD_ImmToReg(1,s,imm,0);
				PUSH_RegToStack(t);
				PUSH_RegToStack(s);
				switch (o) {
				case 41:CALLFunc((u32)&WriteMem16); break;
				case 40:CALLFunc((u32)&WriteMem8); break;
				case 43:CALLFunc((u32)&WriteMem32); break;
				}
				::ADD_ImmToReg(1,ESP,8,0);
			}
			break;

		case 134: //lwl
			{
				DebugBreak();
				//u32 shift = (addr & 3) << 3;
				//u32 mem = ReadMem32(addr & 0xfffffffc);
				//R(rt) = ( u32(R(rt)) & (0x00ffffff >> shift) ) | ( mem << (24 - shift) );
			}
			break;

		case 138: //lwr
			{
				DebugBreak();
				//u32 shift = (addr & 3) << 3;
				//u32 mem = ReadMem32(addr & 0xfffffffc);

				//R(rt) = ( u32(rt) & (0xffffff00 << (24 - shift)) ) | ( mem  >> shift );
			}
			break;
 
		case 142: //swl
			{
				DebugBreak();
				//u32 shift = (addr & 3) << 3;
				//u32 mem = ReadMem32(addr & 0xfffffffc);
				//WriteMem32((addr & 0xfffffffc),  ( ( u32(R(rt)) >>  (24 - shift) ) ) |
				//	(  mem & (0xffffff00 << shift) ));
			}
			break;
		case 146: //swr
			{
				DebugBreak();
				//	u32 shift = (addr & 3) << 3;
			//	u32 mem = ReadMem32(addr & 0xfffffffc);
//
//				WriteMem32((addr & 0xfffffffc), ( ( u32(R(rt)) << shift ) |
//					(mem  & (0x00ffffff >> (24 - shift)) ) ) );
			}
			break;
		default:
			Comp_Generic(op);
			return ;
		}

	}
}
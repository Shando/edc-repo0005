#include "stdafx.h"

#include "../MemMap.h"
#include "../Core.h"

#include "MIPS.h"
#include "MIPSCompiler.h"
#include "MIPSBlockCache.h"
#include "MIPSTables.h"
#include "MIPSCodeUtils.h"
#include "MIPSRegCache.h"
#include "MIPSAnalyst.h"


#include "../x86Backend/X86.h"
#include "../x86Backend/x86Disasm.h"

namespace MIPSComp
{
	typedef void (*BlockFunc)(void);


	struct BlockInfo
	{
		u32 originalOp;
		u32 addr;
		int size;
		size_t compiledSize;  //although even u16 should be ok :P
		int hits;
	};

#define MAX_BLOCKS 655360

	BlockFunc codePtrs[MAX_BLOCKS];
	BlockInfo blocks[MAX_BLOCKS];

	int numBlocks;
	extern int instructionCount;

	u32  GetOriginalOp(u32 op)
	{
		int blockNum = op&0xFFFFFF;
		if (blockNum < numBlocks)
			return blocks[blockNum].originalOp;
		else
			return 0;
	}

	int GetNumBlocks() {return numBlocks;}
	u32 GetBlockAddr(int i) {return blocks[i].addr;}
	u8 *GetBlockPtr(int i) {return (u8*)codePtrs[i];}
	u32 GetBlockSize(int i){return blocks[i].size;}
	size_t GetBlockCompiledSize(int i) {return blocks[i].compiledSize;}
	int GetNumHits(int i) {return blocks[i].hits;}

	extern u32 startPC;
	extern u8* startPtr;

	int GetBlockNumFromAddr(u32 addr)
	{
		for (int i=0; i<numBlocks; i++)
		{
			if (blocks[i].addr <= addr && blocks[i].addr+blocks[i].size > addr)
				return i;
		}
		return -1;
	}

	int CompileBlock(u32 pc, u32 op)
	{
		startPC = pc;
		BlockInfo &b = blocks[numBlocks];
		
		//First pass : Reg allocation
		MIPSAnalyst::Analyze(pc);

		//Set up a block
		b.originalOp = op;
		b.addr=pc;
		WriteMem32(pc, MIPS_MAKE_EMUHACK(EMUOP_RUNBLOCK,numBlocks));

		//Second pass : Straightforward classic recompiler, but using the precalculated regalloc
		//::INT3();
		u8 *ptr = x86GetPtr();
		codePtrs[numBlocks] = (BlockFunc)(void*)ptr;
		compilerPC = pc;
		compiling = true;
		instructionCount=0;
		//INT3();
		//PUSHAD();
		startPtr = x86GetPtr();
		StartRegCache();
		while (compiling && coreState != CORE_ERROR)
		{
			CompileAt(compilerPC);
			compilerPC += 4;
			instructionCount++;
			//LOG(CPU,"%08x",compilerPC);
		}
		StopRegCache();

		::RET();
		b.size = compilerPC - pc + 4; //include delay slot
		b.compiledSize = x86GetPtr() - ptr;
		
		//write epilog
		if (coreState == CORE_ERROR)
			return -1;

		return numBlocks++;
	}

	
	void WriteEpilogue()
	{
		ADD_ImmToMemory((u32)&(blocks[numBlocks].hits),1);
	}

	void RunBlock(u32 pc)
	{
		//currentSystem->advance(3);
		u32 *memptr = (u32*)GetMemPointer(pc);
		if (memptr == 0)
		{
			Core_Pause();
			return;
		}
		u32 op = *memptr;
		
		if ((op&0xFF000000) == MIPS_MAKE_EMUHACK(EMUOP_RUNBLOCK,0))
		{
			int blockNum = op&0xFFFFFF;
			//if (blockNum>12)LOG(CPU,"Cached block %i", blockNum);
#ifndef _WIN64
			__asm push esi
			__asm push edi
#endif
			codePtrs[blockNum]();
#ifndef _WIN64
			__asm pop edi
			__asm pop esi
#endif
			return;
		}

		int block = CompileBlock(pc, op);
#ifndef _WIN64
		__asm push esi
		__asm push edi
#endif
		codePtrs[block]();
#ifndef _WIN64
		__asm pop edi
		__asm pop esi
#endif
	}

	//UGLY
	void DisassembleBlock(int i, char *ptr)
	{
		char *p = ptr;
		for (u32 addr=GetBlockAddr(i); addr<GetBlockAddr(i)+GetBlockSize(i); addr+=4)
		{
			char temp[256];
			MIPSDisAsm(ReadMem32Unchecked(addr),addr,temp);
			strcat(temp,"\r\n");
			strcpy(p,temp);
			p+=strlen(temp);
		}
	}

	//UGLY
	void DisassembleCompiledBlock(int i, char *ptr)
	{
		//strcpy(ptr, "the x86 disasm has no known licence: don't dare to include it");
		int len = 32768;
		ptr[0]=0;
		BYTE *code = (BYTE*)codePtrs[i];
		for (;;)
		{
			strcat(ptr, disasmx86(code, (u32)code, &len));
			strcat(ptr,"\r\n");
			
			code += len;
			if (code >= (BYTE*)codePtrs[i] + blocks[i].compiledSize)
				break;
		}
		
		//code[0]=0;
	}

	//if we happen across an already recompiled block	
	void Comp_RunBlock(u32 op)
	{
		//oops, we hit an already compiled blockstart :)
		u32 blockNumber = op & 0xFFFFFF;
		MIPSCompileOp(blocks[blockNumber].originalOp);
	}

}
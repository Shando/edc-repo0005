#pragma once

#include "../../Globals.h"

namespace MIPSComp
{
	void RunBlock(u32 pc);
	int CompileBlock(u32 pc);

	int GetNumBlocks();
	u32 GetBlockAddr(int i);
	u32 GetBlockSize(int i);
	u8 *GetBlockPtr(int i);
	size_t GetBlockCompiledSize(int i);
	int GetBlockNumFromAddr(u32 addr);
	void DisassembleBlock(int i, char *ptr);
	void DisassembleCompiledBlock(int i, char *ptr);
}
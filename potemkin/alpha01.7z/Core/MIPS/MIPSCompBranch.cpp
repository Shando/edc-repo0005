#include "stdafx.h"
#include "MIPS.h"
#include "MIPSCodeUtils.h"
#include "MIPSTables.h"

#include "MIPSCompiler.h"
#include "MIPSRegCache.h"
#include "MIPSBlockCache.h"
#include "MIPSCompBranch.h"
#include "../x86Backend/X86.h"
#include "../PSP/PSPFirmwareHLE.h"

#define _RS ((op>>21) & 0x1F)
#define _RT ((op>>16) & 0x1F)
#define _RD ((op>>11) & 0x1F)
#define _FS ((op>>11) & 0x1F)
#define _FT ((op>>16) & 0x1F)
#define _FD ((op>>6 ) & 0x1F)
#define _POS  ((op>>6 ) & 0x1F)
#define _SIZE ((op>>11 ) & 0x1F)

#define LOOPOPTIMIZATION 0

namespace MIPSComp
{
	int GetOutReg(u32 op)
	{
		u32 opinfo = MIPSGetInfo(op);
		if (opinfo & OUT_RT)
			return MIPS_GET_RT(op);
		if (opinfo & OUT_RD)
			return MIPS_GET_RD(op);
		if (opinfo & OUT_RA)
			return MIPS_REG_RA;
		return -1;
	}

	bool ReadsFromReg(u32 op, int reg)
	{
		u32 opinfo = MIPSGetInfo(op);
		if (opinfo & IN_RT)
		{
			if (MIPS_GET_RT(opinfo) == reg)
				return true;
		}
		if ((opinfo & IN_RS) || (opinfo & IN_RS_ADDR) || (opinfo & IN_RS_SHIFT))
		{
			if (MIPS_GET_RS(opinfo) == reg)
				return true;
		}
		return false; //TODO: there are more cases!
	}

	bool IsDelaySlotNice(u32 branch, u32 delayslot)
	{
		int outReg = GetOutReg(delayslot);
		if (outReg != -1)
		{
			if (ReadsFromReg(branch, outReg))
			{
				return false; //evil :(
			}
			else
			{
				return false; //aggh this should be true but doesn't work
			}
		}
		else
		{
			return true; //nice :)
		}
	}

	///
	bool OptimizedJump(u32 addr)
	{
		u32 opAtDest = ReadMem32Unchecked(addr);
		if ((opAtDest & 0xFF000000) == MIPS_MAKE_EMUHACK(EMUOP_RUNBLOCK,0))
		{
			WriteEpilogue();
			JMPFunc((u32)MIPSComp::GetBlockPtr(opAtDest & 0xFFFFFF));
			LOG(CPU, "Quickresolved jump from %08x to %08x", compilerPC, addr);
			return true;
		}
		else
		{
			::MOV_ImmToMemory(1, ModRM_disp32, (u32)(&(currentMIPS->pc)), addr);
			return false;
		}
	}

	void BranchRSRTComp(u32 op, u8 *(*jump)(u8), bool likely)
	{
		int imm = (signed short)(op&0xFFFF)<<2;
		int rt = _RT;
		int rs = _RS;
		u32 addr = compilerPC + imm + 4;
		
		u32 delaySlotOp = ReadMem32Unchecked(compilerPC+4);

		//simple case - early out
		if (rs == 0 && rt == 0)
		{
			CompileAt(compilerPC + 4);
			if (!OptimizedJump(addr))
			{
				WriteEpilogue();
			}
			compiling=false;
			return;
		}

		//Compile the delay slot
		bool delaySlotIsNice = GetOutReg(delaySlotOp) != rt && GetOutReg(delaySlotOp) != rs;// IsDelaySlotNice(op, delaySlotOp);

		if (delaySlotIsNice && !likely)
		{
			CompileAt(compilerPC + 4);
		}

		FlushAll();

		u8 *ptr;

		if (rs == 0)
			MOV_ImmToReg(1,EAX,0,false);
		else
			MOV_MemoryToReg(1,EAX,ModRM_disp32,(u32)&(currentMIPS->r[rs]));

		if (rt == 0)
			MOV_ImmToReg(1,EBX,0,false);
		else
			MOV_MemoryToReg(1,EBX,ModRM_disp32,(u32)&(currentMIPS->r[rt]));

		if (!likely)
		{
			CMP_Reg1WithReg2(1,EAX,EBX);
			if (!delaySlotIsNice && delaySlotOp)
			{
				PUSHF();
				CompileAt(compilerPC+4);
				FlushAll();
				POPF();
			}
			ptr = jump(0);
		}
		else
		{
			CMP_Reg1WithReg2(1,EAX,EBX);
			ptr = jump(0);
			CompileAt(compilerPC+4);
			FlushAll();
		}
		//Take the branch
		//Done, let's jump
		u8 *exiter = 0;

		if (LOOPOPTIMIZATION && addr == GetStartPC())
		{
			u8 *ptr = GetStartPtr();
			WriteEpilogue();
			JMPFunc((u32)ptr);
		}
		else
		{
			//MOV_ImmToMemory(1,ModRM_disp32,(u32)&(currentMIPS->pc),addr);
			if (!OptimizedJump(addr))
				exiter = JMP8(0);
		}
		x86SetJ8(ptr);
		//MOV_ImmToMemory(1,ModRM_disp32,(u32)&(currentMIPS->pc),compilerPC+8);
		OptimizedJump(compilerPC+8);
		//here we could continue compiling if we wanted to
		if (exiter)
			x86SetJ8(exiter);

		WriteEpilogue();

		compiling=false;
	}

	void BranchRSZeroComp(u32 op, u8 *(*jump)(u8), bool likely)
	{
		int imm = (signed short)(op&0xFFFF)<<2;
		int rs = _RS;
		u32 addr = compilerPC + imm + 4;

		u32 delaySlotOp = ReadMem32Unchecked(compilerPC+4);

		bool delaySlotIsNice = GetOutReg(delaySlotOp) != rs; //IsDelaySlotNice(op, delaySlotOp);

		if (delaySlotIsNice && !likely)
		{
			CompileAt(compilerPC+4);
		}

		//FlushAll();

		//Compile the delay slot
		//MOV_MemoryToReg(1,EAX,ModRM_disp32,(u32)&(currentMIPS->r[rs]))
		int s = MapMIPSReg(rs, true);
		FlushAll();
		u8 *ptr;
		if (!likely)
		{
			CMP_RegWithImm(1,s,0);
			if (!delaySlotIsNice && delaySlotOp)
			{
				PUSHF();
				CompileAt(compilerPC+4);
				FlushAll();
				POPF();
			}
			ptr = jump(0);
		}
		else
		{
			CMP_RegWithImm(1,s,0);
			ptr = jump(0);
			CompileAt(compilerPC+4);
			FlushAll();
		}
		//Take the branch
		//Done, let's jump
		u8 *exiter = 0;
		if (LOOPOPTIMIZATION && addr == GetStartPC())
		{
			u8 *ptr = GetStartPtr();
			WriteEpilogue();
			JMPFunc((u32)ptr);
		}
		else
		{
			//MOV_ImmToMemory(1,ModRM_disp32,(u32)&(currentMIPS->pc),addr);
			if (!OptimizedJump(addr))
				exiter = JMP8(0);
		}

		x86SetJ8(ptr);
		bool opt = OptimizedJump(compilerPC+8);
		//here we could continue compiling if we wanted to
		if (exiter) 
			x86SetJ8(exiter);

		compiling=false;
		WriteEpilogue();
		RET();

	}

	void BranchFPFlag(u32 op, u8 *(*jump)(u8), bool likely)
	{
		int imm = (signed short)(op&0xFFFF)<<2;
		int rs = _RS;
		u32 addr = compilerPC + imm + 4;

		u32 delaySlotOp = ReadMem32Unchecked(compilerPC+4);

		bool delaySlotIsNice = false; // IsDelaySlotNice(op, delaySlotOp);

		FlushAll();
		//Compile the delay slot
		MOV_MemoryToReg(1,EAX,ModRM_disp32,(u32)&(currentMIPS->r[rs]));

		u8 *ptr;
		if (!likely)
		{
			TEST_ImmWithMemory((u32)&(currentMIPS->fpcond), 1);
			PUSHF();
			CompileAt(compilerPC+4);
			FlushAll();
			POPF();
			ptr = jump(0);
		}
		else
		{
			TEST_ImmWithMemory((u32)&(currentMIPS->fpcond), 1);
			ptr = jump(0);
			CompileAt(compilerPC+4);
			FlushAll();
		}
		//Take the branch
		//Done, let's jump
		MOV_ImmToMemory(1,ModRM_disp32,(u32)&(currentMIPS->pc),addr);
		u8 *exiter = JMP8(0);
		x86SetJ8(ptr);
		MOV_ImmToMemory(1,ModRM_disp32,(u32)&(currentMIPS->pc),compilerPC+8);
		//here we could continue compiling if we wanted to
		x86SetJ8(exiter);

		compiling=false;

	}
	void Comp_RelBranch(u32 op)
	{
		switch (op>>26) 
		{
		case 4: BranchRSRTComp(op, &JNZ8, false); break;//beq
		case 5: BranchRSRTComp(op, &JZ8,  false); break;//bne

		case 6: BranchRSZeroComp(op, &JG8,  false); break;//blez
		case 7: BranchRSZeroComp(op, &JLE8, false); break;//bgtz

		case 20: BranchRSRTComp(op, &JNZ8, true); break;//beql
		case 21: BranchRSRTComp(op, &JZ8,  true); break;//bnel

		case 22: BranchRSZeroComp(op, &JG8,  true); break;//blezl
		case 23: BranchRSZeroComp(op, &JLE8, true); break;//bgtzl
		default:
			_dbg_assert_msg_(CPU,0,"Trying to compile instruction that can't be compiled");
			break;
		}
	}

	void Comp_RelBranchRI(u32 op)
	{
		switch ((op>>16) & 0x1F)
		{
		case 0: BranchRSZeroComp(op, &JGE8, false); break; //if ((s32)R(rs) <  0) DelayBranchTo(addr); else PC += 4; break;//bltz
		case 1: BranchRSZeroComp(op, &JL8, false);  break; //if ((s32)R(rs) >= 0) DelayBranchTo(addr); else PC += 4; break;//bgez
		case 2: BranchRSZeroComp(op, &JGE8, true);  break; //if ((s32)R(rs) <  0) DelayBranchTo(addr); else PC += 8; break;//bltzl
		case 3: BranchRSZeroComp(op, &JL8, true);   break; //if ((s32)R(rs) >= 0) DelayBranchTo(addr); else PC += 8; break;//bgezl
		default:
			_dbg_assert_msg_(CPU,0,"Trying to compile instruction that can't be compiled");
			break;
		}
	}

	void Comp_FPUBranch(u32 op)
	{
		switch((op>>16)&0x1f)
		{
		case 0:	BranchFPFlag(op, &JNZ8, false); break; //bc1f
		case 1: BranchFPFlag(op, &JZ8,  false); break; //bc1t
		case 2: BranchFPFlag(op, &JNZ8, true);  break;  //bc1fl
		case 3: BranchFPFlag(op, &JZ8,  true);  break;  //bc1tl
		default:
			_dbg_assert_msg_(CPU,0,"Trying to interpret instruction that can't be interpreted");
			break;
		}

	}

	void Comp_Jump(u32 op)
	{
		u32 off = ((op & 0x3FFFFFF) << 2);
		u32 addr = (compilerPC & 0xF0000000) | off;
		//Delay slot
		CompileAt(compilerPC+4);

		FlushAll();
		switch (op>>26) 
		{
		case 2: break; //j
		case 3: //jal
			::MOV_ImmToMemory(1,ModRM_disp32,(u32)(&(currentMIPS->r[MIPS_REG_RA])), compilerPC+8);
			break;
		default:
			_dbg_assert_msg_(CPU,0,"Trying to compile instruction that can't be compiled");
			break;
		}
		u32 opAtDest = ReadMem32Unchecked(addr);
		if ((opAtDest & 0xFF000000) == MIPS_MAKE_EMUHACK(EMUOP_RUNBLOCK,0))
		{
			JMPFunc((u32)MIPSComp::GetBlockPtr(opAtDest&0xFFFFFF));
			LOG(CPU,"Quickresolved jump from %08x to %08x",compilerPC,addr);
		}
		else
		{
			::MOV_ImmToMemory(1,ModRM_disp32,(u32)(&(currentMIPS->pc)), addr);
		}
		WriteEpilogue();
		//compilerPC = addr-4;
		compiling=false;
	}

	void Comp_JumpReg(u32 op)
	{
		int rs = (op>>21)&0x1f;


		u32 delaySlotOp = ReadMem32Unchecked(compilerPC+4);
		bool delaySlotIsNice = GetOutReg(delaySlotOp) != rs;

		FlushAll(); // remove?

		::MOV_MemoryToEAX(1,(u32)(&(currentMIPS->r[rs])));
		if (delaySlotOp)
		{
			::PUSH_RegToStack(EAX);
			//Delay slot
			CompileAt(compilerPC+4);
			FlushAll();
			::POP_RegFromStack(EAX);
		}
		::MOV_RegToMemory(1,EAX,ModRM_disp32,(u32)(&(currentMIPS->pc)));

		switch (op & 0x3f) 
		{
		case 8: //jr
			break;
		case 9: //jalr
			::MOV_ImmToMemory(1,ModRM_disp32,(u32)(&(currentMIPS->r[MIPS_REG_RA])), compilerPC+8);
			break;
		default:
			_dbg_assert_msg_(CPU,0,"Trying to compile instruction that can't be compiled");
			break;
		}

		WriteEpilogue();
		compiling=false;
	}

	
	void Comp_Syscall(u32 op)
	{
		FlushAll();

		::MOV_MemoryToEAX(1,(u32)(&(currentMIPS->r[MIPS_REG_RA])));
		::MOV_RegToMemory(1,EAX,ModRM_disp32,(u32)(&(currentMIPS->pc)));

		::PUSH_WordToStack(op);
		::CALLFunc((u32)(void*)&PSPHLE::CallSyscall);
		::ADD_ImmToReg(1,ESP,4,0);
		WriteEpilogue();
		compiling=false;
	}
}
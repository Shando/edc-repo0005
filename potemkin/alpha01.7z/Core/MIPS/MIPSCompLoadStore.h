#pragma once


namespace MIPSComp
{
	
	void Comp_ITypeMem(u32 op);
}
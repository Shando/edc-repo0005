#pragma once


// sizeof : 16
struct MIPSCodeBlock
{
	char *code;
	u32 originalAddr;
	int size;
	int hash;
};

#define MIPSMAXCODEBLOCKS 65536





struct CodeCache
{
	MIPSCodeBlock blocks[MIPSMAXCODEBLOCKS];
	int numUsedBlocks;
	u8 *code;

	void Init();
};


MIPSCodeBlock *GetBlock(CodeCache *cache, u32 addr);
#pragma once

#include "../../Globals.h"

extern u32 disPC;

namespace MIPSDis
{
	void Dis_Mftv(u32 op, char *out);

	void Dis_SV(u32 op, char *out);
	void Dis_SVQ(u32 op, char *out);
	void Dis_SVLRQ(u32 op, char *out);

	void Dis_MatrixSet1(u32 op, char *out);
	void Dis_MatrixSet2(u32 op, char *out);
	void Dis_MatrixSet3(u32 op, char *out);
	void Dis_MatrixMult(u32 op, char *out);

	void Dis_VectorDot(u32 op, char *out);
	void Dis_Vfad(u32 op, char *out);
	void Dis_VectorSet1(u32 op, char *out);
	void Dis_VectorSet2(u32 op, char *out);
	void Dis_VectorSet3(u32 op, char *out);
	void Dis_VRot(u32 op, char *out);
	void Dis_VScl(u32 op, char *out);

	void Dis_VPFXST(u32 op, char *out);
	void Dis_VPFXD(u32 op, char *out);
	void Dis_Vcrs(u32 op, char *out);
	void Dis_Viim(u32 op, char *out);
	void Dis_Vcst(u32 op, char *out);
	void Dis_CrossQuat(u32 op, char *out);
	void Dis_Vtfm(u32 op, char *out);
	void Dis_Vcmp(u32 op, char *out);
	void Dis_Vcmov(u32 op, char *out);
	void Dis_Vflush(u32 op, char *out);
	void Dis_Vbfy(u32 op, char *out);
	void Dis_Vf2i(u32 op, char *out);
	void Dis_Vi2x(u32 op, char *out);
	void Dis_VBranch(u32 op, char *out);
}

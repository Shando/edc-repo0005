#include "stdafx.h"	
#include "../CPU.h"
#include "MIPS.h"

#include "MIPSVFPUUtils.h"

#include <limits>

#define V(i)   (currentMIPS->v[i])
#define VI(i)   (*(u32*)(&(currentMIPS->v[i])))

static bool writeMask[4] = {false, false, false, false};

void SetWriteMask(bool wm[4])
{
	for (int i=0; i<4; i++)
		writeMask[i] = wm[i];
}

void ReadMatrix(float *rd, DataSize size, int outMatrixWidth, int reg)
{
	int mtx = (reg>>2)&7;
	int idx = reg&3;
	int fsl = 0;
	int k,l;

	int transpose = (reg>>5)&1;

	switch (size)
	{
	case V_Single:	fsl=(reg>>5)&3;  k=1; l=1;	break;
	case V_Pair:	fsl=(reg>>5)&2;  k=2; l=1;	break;
	case V_Triple:	fsl=(reg>>6)&1;  k=3; l=1;	break;
	case V_Quad:	fsl=(reg>>5)&2;  k=4; l=1;	break;

	case V_2x2:		fsl=(reg>>5)&2;  k=2; l=2;	break;
	case V_3x3:		fsl=(reg>>6)&1;  k=3; l=3;	break;
	case V_4x4:		fsl=(reg>>5)&2;  k=4; l=4;	break;
	}

	for (int i=0; i<k; i++)
	{
		for (int j=0; j<l; j++)
		{
			if (transpose)
				rd[j*outMatrixWidth+i] = V(mtx*4+((idx+i)&3)+((fsl+j)&3)*32);
			else
				rd[j*outMatrixWidth+i] = V(mtx*4+((idx+j)&3)+((fsl+i)&3)*32);
		}
	}
}

void WriteMatrix(const float *rd, DataSize size, int inMatrixWidth, int reg)
{
	int mtx = (reg>>2)&7;
	int col = reg&3;
	int row = 0;
	int k,l;

	int transpose = (reg>>5)&1;

	switch (size)
	{
	case V_Single:	row=(reg>>5)&3;  k=1; l=1;	break;
	case V_Pair:	row=(reg>>5)&2;  k=2; l=1;	break;
	case V_Triple:	row=(reg>>6)&1;  k=3; l=1;	break;
	case V_Quad:	row=(reg>>5)&2;  k=4; l=1;	break;

	case V_2x2:		row=(reg>>5)&2;  k=2; l=2;	break;
	case V_3x3:		row=(reg>>6)&1;  k=3; l=3;	break;
	case V_4x4:		row=(reg>>5)&2;  k=4; l=4;	break;
	}

	for (int i=0; i<k; i++)
	{
		for (int j=0; j<l; j++)
		{
			if (!writeMask[i])
			{
				if (transpose)
					V(mtx*4+((col+i)&3)+((row+j)&3)*32) = rd[j*inMatrixWidth+i];
				else
					V(mtx*4+((col+j)&3)+((row+i)&3)*32) = rd[j*inMatrixWidth+i];
			}
		}
	}
}


int GetNumElements(DataSize sz)
{
	switch (sz)
	{
		case V_Single: return 1;
		case V_Pair:   return 2;
		case V_Triple: return 3;
		case V_Quad:   return 4;

		case V_2x2:	   return 4;
		case V_3x3:    return 9;
		case V_4x4:    return 16;
	}
	return 0;
}


DataSize GetHalfSize(DataSize sz)
{
	switch (sz)
	{
	case V_Pair: return V_Single;
	case V_Quad: return V_Pair;
	case V_2x2: return V_Single;
	case V_4x4: return V_2x2;
	}
}

DataSize GetVecSize(u32 op)
{
	int a = (op>>7)&1;
	int b = (op>>15)&1;
	a += (b<<1);
	switch (a)
	{
		case 0: return V_Single;
		case 1: return V_Pair;
		case 2: return V_Triple;
		case 3: return V_Quad;
		default: return V_Invalid;
	}
}

DataSize GetMtxSize(u32 op)
{
	int a = (op>>7)&1;
	int b = (op>>15)&1;
	a += (b<<1);
	switch (a)
	{
	case 1: return V_2x2;
	case 2: return V_3x3;
	case 3: return V_4x4;
	default: return V_Invalid;
	}
}

int GetMatrixSide(DataSize sz)
{
	switch (sz)
	{
	case V_2x2: return 2;
	case V_3x3: return 3;
	case V_4x4: return 4;
	default: return 0;
	}
}


const char *GetVRNotation(int reg, DataSize size)
{
	static char hej[4][16];
	static int yo=0;yo++;yo&=3;
	int mtx = (reg>>2)&7;
	int idx = reg&3;
	int fsl = 0;
	int transpose = (reg>>5)&1;
	char c;
	switch (size)
	{
	case V_Single:	transpose=0; c='S'; fsl=(reg>>5)&3; break;
	case V_Pair:	c='C'; fsl=(reg>>5)&2; break;
	case V_Triple:	c='C'; fsl=(reg>>6)&1; break;
	case V_Quad:	c='C'; fsl=(reg>>5)&2; break;

	case V_2x2:		c='M'; fsl=(reg>>5)&2; break;
	case V_3x3:		c='M'; fsl=(reg>>6)&1; break;
	case V_4x4:		c='M'; fsl=(reg>>5)&2; break;
	case V_Invalid: c='I'; fsl=0; break;
	}
	if (transpose && c=='C') c='R';
	if (transpose && c=='M') c='E';
	//if (transpose)
	//	sprintf(hej[yo],"%c%i%i%i",c,mtx,fsl,idx);
	//else
		sprintf(hej[yo],"%c%i%i%i",c,mtx,idx,fsl);
	return hej[yo];
}


float Float16ToFloat32(unsigned short l)
{
	union float2int {
		unsigned int i;
		float f;
	} float2int;

	unsigned short float16 = l;
	unsigned int sign = (float16 >> VFPU_SH_FLOAT16_SIGN) & VFPU_MASK_FLOAT16_SIGN;
	int exponent = (float16 >> VFPU_SH_FLOAT16_EXP) & VFPU_MASK_FLOAT16_EXP;
	unsigned int fraction = float16 & VFPU_MASK_FLOAT16_FRAC;

	float signf = (sign == 1) ? -1.0f : 1.0f;

	float f;
	if (exponent == VFPU_FLOAT16_EXP_MAX)
	{
		if (fraction == 0)
			f = std::numeric_limits<float>::infinity(); //(*info->fprintf_func) (info->stream, "%cInf", signchar);
		else
			f = std::numeric_limits<float>::quiet_NaN(); //(*info->fprintf_func) (info->stream, "%cNaN", signchar);
	}
	else if (exponent == 0 && fraction == 0)
	{
		f=0.0f * signf;
	}
	else
	{
		if (exponent == 0)
		{
			do
			{
				fraction <<= 1;
				exponent--;
			}
			while (!(fraction & (VFPU_MASK_FLOAT16_FRAC + 1)));

			fraction &= VFPU_MASK_FLOAT16_FRAC;
		}

		/* Convert to 32-bit single-precision IEEE754. */
		float2int.i = sign << 31;
		float2int.i |= (exponent + 112) << 23;
		float2int.i |= fraction << 13;
		f=float2int.f;
	}
	return f;
}
#pragma once

#include "../../Globals.h"

#define IS_CONDBRANCH 0x100
#define IS_JUMP 0x200
#define IS_VFPU 0x80000000
#define UNCONDITIONAL 0x40
#define BAD_INSTRUCTION 0x20
#define DELAYSLOT 0x10

#define IN_RS_ADDR   0x800
#define IN_RS_SHIFT  0x400
#define IN_RS   0x1000
#define IN_RT   0x2000
#define IN_SA   0x4000
#define IN_IMM16 0x8000
#define IN_IMM26 0x10000
#define IN_MEM   0x20000
#define IN_OTHER 0x40000
#define IN_FPUFLAG 0x80000

#define OUT_RT  0x100000
#define OUT_RD  0x200000
#define OUT_RA  0x400000
#define OUT_MEM 0x800000
#define OUT_OTHER 0x1000000
#define OUT_FPUFLAG 0x2000000

typedef void (CDECL *MIPSCompileFunc)(u32 opcode);
typedef void (CDECL *MIPSDisFunc)(u32 opcode, TCHAR *out);
typedef void (CDECL *MIPSInterpretFunc)(u32 opcode);


void MIPSCompileOp(u32 op);
void MIPSDisAsm(u32 op, u32 pc, char *out);
u32  MIPSGetInfo(u32 op);
void MIPSInterpret(u32 op); //only for those rare ones
MIPSInterpretFunc MIPSGetInterpretFunc(u32 op);

const char *MIPSGetName(u32 op);


void FillMIPSTables();

#include "stdafx.h"
#include "MIPSCompiler.h"
#include "MIPSCompALU.h"
#include "MIPSRegCache.h"
#include "MIPSAnalyst.h"
using namespace MIPSAnalyst;
#define _RS ((op>>21) & 0x1F)
#define _RT ((op>>16) & 0x1F)
#define _RD ((op>>11) & 0x1F)
#define _FS ((op>>11) & 0x1F)
#define _FT ((op>>16) & 0x1F)
#define _FD ((op>>6 ) & 0x1F)
#define _POS  ((op>>6 ) & 0x1F)
#define _SIZE ((op>>11 ) & 0x1F)

#define OLDD
namespace MIPSComp
{

	struct X86Reg
	{
		bool available;
		bool active;
		int mipsReg;
	};

	X86Reg regs[8];

	int MapReg(int mipsReg)
	{
		bool found=false;
		for (int i=0; i<8; i++)
		{
			if (regs[i].available)
			{
				if (!regs[i].active)
				{
					regs[i].mipsReg = mipsReg;
					found=true;
				}
			}
		}
		if (!found)
		{
			// find the oldest one and chuck it
		}
		return 0;
	}


	void CompImmLogic(u32 op, void (*arith)(u32, u32, u32, u32), void (*arithmem)(u32, u32), bool zeroClears)
	{
		u32 uimm = (u16)(op & 0xFFFF);
		int rt = _RT;
		int rs = _RS;
		TX86Regs s = MapMIPSReg(rs, true);
		TX86Regs t = MapMIPSReg(rt, false);
		MOV_Reg2ToReg1(1,t,s);
		arith(1,t,uimm,0);
		SetDirty(t);
	}

#define OLDD Comp_Generic(op); return;

	void Comp_IType(u32 op)
	{		
//		OLDD
		s32 simm = (s16)(op & 0xFFFF);
		u32 uimm = (u16)(op & 0xFFFF);

		int rt = _RT;
		int rs = _RS;

		if (rt == 0) //destination register is zero register
			return; //nop

		switch (op>>26) 
		{
		case 8:  
		case 9:  //R(rt) = R(rs) + simm; break;  //addiu
			{
				if (rs!=0)
				{
					TX86Regs s = MapMIPSReg(rs, true);
					TX86Regs t = MapMIPSReg(rt, false);
					//MOV_Reg2ToReg1(1,t,s);
					//ADD_ImmToReg(1,t,(u32)simm,0);
					LEA(1,t,ModRM_disp32_EAX+s,(u32)simm);
					SetDirty(t);
				}
				else
				{
					if (regAnal[rt].readCount == 0) // || regAnal[rt].LastRead()<compilerPC)
					{
						WriteImmToMIPSReg(rt, (u32)simm);
					}
					else
					{
						TX86Regs t = MapMIPSReg(rt, false);
						MOV_ImmToReg(1,t,(u32)simm,0);
						SetDirty(t);
					}
				}
				//FlushAll();
			}
			break;
		//case 10: R(rt) = (s32)R(rs) < simm; break; //slti
		//case 11: R(rt) = R(rs) < uimm; break; //sltiu
		case 12: CompImmLogic(op, AND_ImmToReg,AND_ImmToMemory,false); break;
		case 13: CompImmLogic(op, OR_ImmToReg,OR_ImmToMemory,false); break;
		case 14: CompImmLogic(op, XOR_ImmToReg,XOR_ImmToMemory,false); break;
		case 15: //R(rt) = uimm << 16;   break; //lui
			{

				TX86Regs t = MapMIPSReg(rt, false);
				MOV_ImmToReg(1,t,uimm<<16,0);
				SetDirty(t);
			}
			break;
		default:
			Comp_Generic(op);
			break;
		}
	}


	void CompTriArith(u32 op, void (*arith)(u32, u32, u32, u32), void (*arithmem)(u32, u32, u32, u32), bool zeroClears)
	{
		int rt = _RT;
		int rs = _RS;
		int rd = _RD;
		
		if (zeroClears || (rs != 0 && rt != 0))
		{
			//FlushAll();
			TX86Regs s = MapMIPSReg(rs, true);
			TX86Regs t = MapMIPSReg(rt, true);
			TX86Regs d = MapMIPSReg(rd, false);
			if (!IsMappedAs(rs, s) || !IsMappedAs(rt,t) || !IsMappedAs(rd,d))
				MessageBox(0,"ARGH",0,0);
			MOV_Reg2ToReg1(1,EAX,s);
			arith(1,EAX,t,0);
			MOV_Reg2ToReg1(1,d,EAX);
			SetDirty(d);
		}
		else if (rs == 0)
		{
			TX86Regs t = MapMIPSReg(rt, true);
			TX86Regs d = MapMIPSReg(rd, false);
			MOV_Reg2ToReg1(1,d,t);
			SetDirty(d);
		}
		else if (rt == 0)
		{
			TX86Regs s = MapMIPSReg(rs, true);
			TX86Regs d = MapMIPSReg(rd, false);
			MOV_Reg2ToReg1(1,d,s);
			//negate if Sub?
			SetDirty(d);
		}
		else 
		{
			TX86Regs d = MapMIPSReg(rd, false);
			MOV_ImmToReg(1,d,0,false);
			SetDirty(d);
		}
		//FlushAll();

	}


	void Comp_RType3(u32 op)
	{
		//OLDD
		//Comp_Generic(op);
		
		switch (op & 63) 
		{
		//case 10: if (!R(rt))  R(rd) = R(rs); break; //movz
		//case 11: if (R(rt)) R(rd) = R(rs); break; //movn
		case 32: //R(rd) = R(rs) + R(rt);    break; //add
		case 33: //R(rd) = R(rs) + R(rt);    break; //addu
			CompTriArith(op, ADD_Reg2ToReg1, ADD_MemoryToReg, false);
			break;
		case 134: //R(rd) = R(rs) - R(rt);    break; //sub
		case 135:
			CompTriArith(op, SUB_Reg2FromReg1, SUB_MemoryToReg, true);
			break;
		case 136: //R(rd) = R(rs) & R(rt);    break; //and
			CompTriArith(op, AND_Reg2ToReg1, AND_MemoryToReg, false);
			break;
		case 137: //R(rd) = R(rs) | R(rt);    break; //or
			CompTriArith(op, OR_Reg2ToReg1, OR_MemoryToReg, true);
			break;
		case 138: //R(rd) = R(rs) ^ R(rt);    break; //xor
			CompTriArith(op, XOR_Reg2ToReg1, XOR_MemoryToReg, true);
			break;
		//case 39: R(rd) = ~(R(rs) | R(rt)); break; //nor
		//case 42: R(rd) = (int)R(rs) < (int)R(rt); break; //slt
		//case 43: R(rd) = R(rs) < R(rt);    break; //sltu
		//case 44: R(rd) = (R(rs) > R(rt)) ? R(rs) : R(rt); break; //max
		//case 45: R(rd) = (R(rs) < R(rt)) ? R(rs) : R(rt); break;//min
		default:
			Comp_Generic(op);
			break;
		}
		
	}


	void CompShiftImm(u32 op, void (*shift)(u32, u32, u32))
	{
		int rd = _RD;
		int rt = _RT;
		int sa = _FD;
		TX86Regs t = MapMIPSReg(rt, true);
		TX86Regs d = MapMIPSReg(rd, false);
		MOV_Reg2ToReg1(1,d,t);
		shift(1,d,sa);
		SetDirty(d);
	}
//#define OLDD
	void Comp_ShiftType(u32 op)
	{
		OLDD
		switch (op & 0x3f)
		{
		case 0: CompShiftImm(op, &SHL_RegByImm); break;
		case 2: CompShiftImm(op, &SHR_RegByImm); break; //srl
		case 3: CompShiftImm(op, &SAR_RegByImm); break; //sra
		//case 4: R(rd) = R(rt) << R(rs);        break; //sllv
		//case 6: R(rd) = R(rt) >> R(rs);        break; //srlv
		//case 7: R(rd) = ((s32)R(rt)) >> R(rs); break; //srav
		default:
			Comp_Generic(op);
			//_dbg_assert_msg_(CPU,0,"Trying to interpret instruction that can't be interpreted");
			break;
		}
	}

}
#pragma once

#include "../../Globals.h"

extern u32 disPC;

namespace MIPSDis
{
	void Dis_Unknown(u32 op, char *out);
	void Dis_Unimpl(u32 op, char *out);
	void Dis_Syscall(u32 op, char *out);

	void Dis_mxc1(u32 op, char *out);
	void Dis_addi(u32 op, char *out);
	void Dis_addu(u32 op, char *out);
	void Dis_RelBranch2(u32 op, char *out);
	void Dis_RelBranch(u32 op, char *out);
	void Dis_Generic(u32 op, char *out);
	void Dis_IType(u32 op, char *out);
	void Dis_IType1(u32 op, char *out);
	void Dis_ITypeMem(u32 op, char *out);
	void Dis_RType2(u32 op, char *out);
	void Dis_RType3(u32 op, char *out);
	void Dis_MulDivType(u32 op, char *out);
	void Dis_ShiftType(u32 op, char *out);
	void Dis_VarShiftType(u32 op, char *out);
	void Dis_FPU3op(u32 op, char *out);
	void Dis_FPU2op(u32 op, char *out);
	void Dis_FPULS(u32 op, char *out);
	void Dis_FPUComp(u32 op, char *out);
	void Dis_FPUBranch(u32 op, char *out);
	void Dis_ori(u32 op, char *out);
	void Dis_Special3(u32 op, char *out);

	void Dis_ToHiloTransfer(u32 op, char *out);
	void Dis_FromHiloTransfer(u32 op, char *out);
	void Dis_JumpType(u32 op, char *out);
	void Dis_JumpRegType(u32 op, char *out);

	void Dis_Allegrex(u32 op, char *out);
	void Dis_Allegrex2(u32 op, char *out);

	void Dis_Emuhack(u32 op, char *out);
}

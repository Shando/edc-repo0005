#pragma once

#include "../../Globals.h"
//#include "BlockCache.h"
#include "../CPU.h"

enum
{
	MIPS_SCRATCH_1=0,
	MIPS_SCRATCH_2=1,
	MIPS_REG_A0=4,
	MIPS_REG_A1=5,
	MIPS_REG_A2=5,
	MIPS_REG_A3=6,
	MIPS_REG_K0=26,
	MIPS_REG_GP=28,
	MIPS_REG_SP=29,
	MIPS_REG_RA=31,
};

enum
{
	VFPU_CTRL_SPREFIX,
	VFPU_CTRL_TPREFIX,
	VFPU_CTRL_DPREFIX,
	VFPU_CTRL_CC,
	//unknown....
};

class MIPSState : public CPU
{
public:
	MIPSState() 
	{
		//		blockCache.armState = this;
	}
	~MIPSState() {}
	void Reset();

	u32 r[32]; 
	float f[32];
	float v[128];
	u32 vfpuCtrl[15];

	u32 pc;
	u32 hi;
	u32 lo;

	u32 fpcond; //separate for speed
	
	u32 fcr0;
	u32 fcr31; //fpu control register


	//	BlockCache blockCache;

	void Irq();
	void SWI();
	void Abort();
	void UndefInstr();

	void SingleStep();
	void FastRun();

	//overridden functions
	TCHAR *GetName();
	int GetNumGPRs() { return 32; }
	int GetGPRSize() { return GPR_SIZE_32;}
	u32 GetGPR32Value(int reg) {return r[reg];}
	u32 GetPC() {return pc;}
	u32 GetLR() {return r[MIPS_REG_RA];}
	int GetInstructionSize() {return 4;}
	void SetPC(u32 _pc) {pc=_pc;}
	
	void WriteFCR(int reg, int value)
	{
		if (reg == 31)
		{
			fcr31 = value;
			fpcond = (value >> 23)&1;
		}
		else
		{
			MessageBox(0, "Invalid FCR",0,0);

		}
		LOG(CPU, "FCR%i written to, value %08x", reg, value);
	}

	u32 ReadFCR(int reg)
	{
		LOG(CPU,"FCR%i read",reg);
		if (reg == 31)
		{
			fcr31 = (fcr31 & ~(1<<23)) | ((fpcond&1)<<23);
			return fcr31;
		}
		else if (reg == 0)
		{
			return fcr0;
		}
		else
		{
			MessageBox(0, "Invalid FCR",0,0);
		}
		return 0;
	}
	
	CPUType GetType() {return CPUTYPE_MIPSR4K;}



	const TCHAR *GetCategoryName(int cat)
	{
		const TCHAR *names[3] = {_T("GPR"),_T("FPU"),_T("VFPU")};
		return names[cat];
	}
	int GetNumCategories() { return 3; }
	int GetNumRegsInCategory(int cat) 
	{
		int r[3] = {32,32,32};
		return r[cat];
	}
	const TCHAR *GetRegName(int cat, int index);

	virtual void PrintRegValue(int cat, int index, char *out)
	{
		switch (cat)
		{
		case 0:	sprintf(out, "%08x", r[index]); break;
		case 1:	sprintf(out, "%f", f[index]); break;
		case 2:	sprintf(out, "N/A"); break;
		}
	}

	u32 GetRegValue(int cat, int index)
	{
		return r[index];
	}
};


//The one we are compiling or running currently
extern MIPSState *currentMIPS;

extern MIPSState mipsr4k;

void MIPS_Init();
void MIPS_SingleStep();

void MIPS_Shutdown();

void MIPS_Irq();
void MIPS_SWI();
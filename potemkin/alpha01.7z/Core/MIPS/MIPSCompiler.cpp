#include "stdafx.h"

#include "../System.h"
#include "../Core.h"
#include "MIPS.h"
#include "MIPSCodeUtils.h"
#include "MIPSInt.h"
#include "MIPSTables.h"
#include "MIPSRegCache.h"

#include "../PSP/PSPFirmwareHLE.h"
#include "../x86Backend/X86.h"

extern u32 *pspmainram;

namespace MIPSComp
{
	void Comp_MemRead32KnownRAM(int srcreg, int offset, int reg)
	{
		MOV_MemoryToReg(1, reg, ModRM_disp32_EAX+srcreg, (u32)pspmainram - 0x08000000 + offset);
	}
	void Comp_MemWrite32KnownRAM(int srcreg, int offset, int reg)
	{
		MOV_RegToMemory(1, reg, ModRM_disp32_EAX+srcreg, (u32)pspmainram - 0x08000000 + offset);
	}
/*

#define RM(reg) (&(currentMIPS->r[reg]))
	struct RegInfo
	{
		bool cached;
		int x86reg;
	};

	RegInfo regs[32];

	void MovToReg(int reg, u32 value)
	{
		if (regs[reg].cached)
		{
			::MOV_ImmToReg(1,regs[reg].x86reg,value,0);
		}
		else
		{
			::MOV_ImmToMemory(1,ModRM_disp32,(u32)(RM(reg)),value);
		}
	}
*/

	u32 compilerPC;
	int instructionCount;
	bool compiling;
	u32 startPC;
	u8 *startPtr;
	u32 GetStartPC()
	{
		return startPC;
	}
	u8 *GetStartPtr()
	{
		return startPtr;
	}
	int GetInstructionCount()
	{
		return instructionCount;
	}

	u8 *codeCache;
#define CACHESIZE 16384*1024
	void Init()
	{
		codeCache = (u8*)VirtualAlloc(0,CACHESIZE,MEM_RESERVE|MEM_COMMIT,PAGE_EXECUTE_READWRITE);
		x86SetPtr(codeCache);
	}
	void CompileAt(u32 addr)
	{
		u32 op = ReadOp32(addr);
		MIPSCompileOp(op);
	}




	void Comp_Generic(u32 op)
	{
		MIPSInterpretFunc func = MIPSGetInterpretFunc(op);
		if (op)
		{
			FlushAll();
			//::MOV_ImmToMemory(1,ModRM_disp32,(u32)&(currentMIPS->pc),compilerPC);
			::PUSH_WordToStack(op);
			::CALLFunc((u32)func);
			::ADD_ImmToReg(1,ESP,4,0);
		}
	}




#define _RS ((op>>21) & 0x1F)
#define _RT ((op>>16) & 0x1F)
#define _RD ((op>>11) & 0x1F)
#define _FS ((op>>11) & 0x1F)
#define _FT ((op>>16) & 0x1F)
#define _FD ((op>>6 ) & 0x1F)
#define _POS  ((op>>6 ) & 0x1F)
#define _SIZE ((op>>11 ) & 0x1F)



	void Comp_RelBranch2(u32 op)
	{

	}

	//Reg alloc policy
	//EAX is permanent temp registers, use freely
	//EBX,ESI,EDI,EBP,ECX,EDX are allocatable registers
	//



	/*
u32 dispatchcount;
u32 cyclesRun;
	void Dispatcher()
	{
		__asm
		{
runloop:
			mov eax, mips4k.pc
			//and eax, 0x0fffffff
			mov eax, [pspmainram+eax]
			//eax = opcode
			mov edx,eax
			and eax, 0xFF000000
			cmp eax, MIPS_MAKE_EMUHACK(EMUOP_RUNBLOCK,0)
			jne docompile
			//alright, let's get the block
			and edx, 0xFFFFFF
			mov eax, [firstblock+edx*4]
gottheblock:
			//eax points to code
			call eax
			sub dispatchcount, eax //return value is # cycles
			jnl runloop
docompile:
			call CompileBlock
			j gottheblock
		}
	}*/

	

	void GenerateDispatcher()
	{
		u8 *runloop = x86GetPtr();
		MOV_MemoryToReg(1,EAX,ModRM_disp32,(u32)&mipsr4k.pc);
		//AND_ImmToEAX(1,0x0FFFFFFF);
		MOV_MemoryToReg(1,EAX,ModRM_disp32_EAX,(u32)pspmainram-0x08000000);
		MOV_Reg2ToReg1(1,EDX,EAX);
		AND_ImmToReg(1,EAX,0xFF000000,0);
		CMP_EAXWithImm(1,MIPS_MAKE_EMUHACK(EMUOP_RUNBLOCK,0));
		
		//Jcc_Near(CC_A,(u32)runloop);

	}



	struct UsageBlock
	{
		u32 startAddr;
		u32 endAddr;
		int numReads;
		int numWrites;
	};
	void ScanBlock();


	//memory regions:
	//
	// 08-0A
	// 48-4A
	// 04-05
	// 44-45
	// mov eax, addrreg
    // shr eax, 28
	// mov eax, [table+eax]
	// mov dreg, [eax+offreg]
  
}
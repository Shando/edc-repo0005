#include "stdafx.h"

#include "../System.h"
#include "../MemMap.h"
#include "../Misc.h"



System GCSystem = 
{
	_T("Gamecube"),
	_T("Nintendo"),
	_T("*.elf;*.gcm;*.iso;*.cso;"),
	1, //one cpu
	1, //one display
	4, //four controllers
	0x08000000, // ???????????
	{CPUTYPE_OTHER},
	{486000000}, //486mhz
};
#pragma once

#include "../Globals.h"

u32 AsciiToHex (const char* _szValue);
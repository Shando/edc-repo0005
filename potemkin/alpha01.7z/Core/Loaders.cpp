#include "stdafx.h"
#include "ARM/ARM.h"
#include "MIPS/MIPS.h"
#include "MIPS/MIPSCodeUtils.h"

#include "PSP/PSPFirmwareHLE.h"
#include "PSP/PSPLoaders.h"
#include "PSP/HLE/sceKernelModule.h"
#include "DS/DSLoaders.h"
#include "MemMap.h"
#include "Loaders.h"
#include "PSP/PSPSystem.h"
#include "System.h"

u32 Load_BIN(const TCHAR *file, u32 ptr)
{
	FILE *rom = fopen(file,"rb");
	fseek(rom,0,SEEK_END);
	int size = ftell(rom);
	fseek(rom,0,SEEK_SET);

	u8 *romptr = currentCPU->memMap.GetMemPointer(ptr);
	fread(romptr,size,1,rom);
	fclose(rom);
	return ptr;
}

void Load_GBAELF(const TCHAR *filename)
{
//	std::ifstream in(filename,std::ios::binary);
//	u32 entry = Load_ELF(in);

//	arm7.r[ARM_REG_PC] = entry;
}

void Load_GBAEmpty()
{
	arm7.fakeBios=false;
	arm7.highVectors=false;
	arm7.Reset();
}

//TODO : improve, look in the file
EmuFileType Identify_File(const TCHAR *filename)
{
	//First - pure systems since they have no file
	if (strcmp(filename,"[DS]")==0)
	{
		return FILETYPE_DS_EMPTY;
	}
	else if (strcmp(filename,"[GP32]")==0)
	{
		return FILETYPE_GP32_EMPTY;
	}
	else if (strcmp(filename,"[GBA]")==0)
	{
		return FILETYPE_GBA_EMPTY;
	}

	//then: easy bulletproof IDs.
	FILE *f = fopen(filename, "rb");
	if (!f)
	{
		//File does not exists
		return FILETYPE_ERROR;
	}
	u32 id;
	fread(&id,4,1,f);
	fclose(f);
	if (id == 'FLE\x7F')
	{
		if (strstr(filename,".glf"))
		{
			return FILETYPE_GBA_ELF;
		}
		else if (strstr(filename,".plf") || strstr(filename,"BOOT.BIN") || strstr(filename,".elf") )
		{
			return FILETYPE_PSP_ELF;
		}
		else if (strstr(filename,".nef"))
		{
			return FILETYPE_DS_ELF;
		}
		else
			return FILETYPE_PSP_ELF;
	}
	else if (id == 'PBP\x00')
	{
		return FILETYPE_PSP_PBP;
	}
	else if (id == 0xEA00002E)
	{
		return FILETYPE_GBA_BIN;
	}
	else
	{
		if (strstr(filename,"arm9.bin"))
		{
			return FILETYPE_DS_BIN9;
		}
		else if (strstr(filename,".nds"))
		{
			return FILETYPE_DS_NDS;
		}
		else if (strstr(filename,".pbp"))
		{
			return FILETYPE_PSP_PBP;
		}
		else if (strstr(filename,".iso"))
		{
			return FILETYPE_PSP_ISO;
		}
		else if (strstr(filename,".cso"))
		{
			return FILETYPE_PSP_ISO;
		}
		else if (strstr(filename,".ptru"))
		{
			return FILETYPE_DS_PASSTHRU;
		}
		else if (strstr(filename,".bin"))
		{
			return FILETYPE_UNKNOWN_BIN;
		}
	}
	return FILETYPE_UNKNOWN;
}

extern bool ndslibHLE;

void Load_ROM(const TCHAR *filename)
{
	LOG(ROM,"Identifying %s...",filename);
	switch (Identify_File(filename)) 
	{
	case FILETYPE_DS_BIN9:
		LOG(ROM,"Loading as ARM9 bin");
		Load_DSBIN9(filename);	
		ndslibHLE=true;
		break;
	case FILETYPE_DS_ELF:
		LOG(ROM,"Loading as ELF");
		Load_DSELF(filename);	
		break;
	case FILETYPE_DS_NDS:
		LOG(ROM,"Loading as NDS");
		Load_NDS(filename);
		break;
	case FILETYPE_DS_PASSTHRU:
		LOG(ROM,"Loading as NDS Passthru");
		Load_NDS_PassThru(filename);
		break;
	case FILETYPE_DS_EMPTY:
		LOG(ROM,"Empty Nintendo DS");
		Load_DSEmpty();
		break;
	case FILETYPE_GBA_BIN:
		LOG(ROM,"Loading as GBA binary");
		{
			u16 *ptr = (u16*)currentCPU->memMap.GetMemPointer(0x08000000);
			//to mimic VBA memory init
			for (int i=0; i<0x200000; i++)
			{
				*ptr++ = i;
			}
		}
		Load_BIN(filename,currentSystem->binaryLoadAddress);
		break;
	case FILETYPE_GBA_ELF:
		Load_GBAELF(filename);
		break;
	case FILETYPE_PSP_PBP:
		Load_PBP(filename);
		break;
	case FILETYPE_PSP_ELF:
		{
			Load_PSP_ELF(filename);
		}
		break;
	case FILETYPE_PSP_ISO:
		Load_PSP_ISO(filename);
		break;
	case FILETYPE_GBA_EMPTY:
		LOG(ROM,"Empty GBA");
		Load_GBAEmpty();
		break;
	case FILETYPE_GP32_BIN:
		LOG(ROM,"Loading as GP32 binary");
		Load_BIN(filename,currentSystem->binaryLoadAddress);
		break;
	}
}



#include "stdafx.h"
#include "tests.h"
#include "ARM/ARMCompiler.h"
#include "ARM/ARMTables.h"
#include "MIPS/MIPSCodeUtils.h"
#include "MemMap.h"
#include "IR/IR.h"
#include "IR/IRDisasm.h"
#include "IR/IROptimizer.h"
#include "IR/IRInterpreter.h"
#include "psp/hle/sceKernel.h"
#include "psp/hle/sceKernelThread.h"
#include "psp/hle/sceKernelMemory.h"

#define CASE(x) if (memcmp(text,x,4)==0)

extern u32 debugCycles;

extern u32 prevpc,pprevpc,ppprevpc;
bool Test(TCHAR *text)
{
	CASE("test")
	{
		u32 start;// = 0x000009de; 
		u32 end;// = 0x00000a00;
		sscanf(text+5,"%x %x",&start,&end);
		if (start==0 && end==0)
		{
			start = 0x0000009de;
			end = 0x00000a00;
		}
        Compiler_CompileRange(start, end, text[4]=='t');
		int unopt = IR_DisasmToLog();
		IR_ConstantPropagate();
		LOG(CPU,"Constants propagated:");
		int con = IR_DisasmToLog();
		LOG(CPU,"Constants saved %d instruction(s).",unopt-con);
		IR_Optimize();
		int opt = IR_DisasmToLog();
		LOG(CPU,"Optimize saved %d further instruction(s) for a total of %d, from %d arm.",con-opt,opt,(end-start)/4);
		//IR_Int_SetPtr(IR_First());
		//IR_Int_Step();
		//IR_Int_Step();
		//IR_Int_Step();
		//IR_Int_Step();
		//IR_Int_Step();
		//IR_Int_Step();
		//IR_Int_Step();
		return true;
	}
	CASE("dump")
	{
		u32 start;// = 0x000009de; 
		u32 end;// = 0x00000a00;
		char filename[256];
		sscanf(text+5,"%x %x %s",&start,&end,filename);
		
		u8 *st = GetMemPointer(start);
		FILE *f = fopen(filename,"wb");
		fwrite(st, end, 1, f);
		fclose(f);
		/*

		for (int addr = start; addr!=end+4; addr+=4)
		{
			char buf[256];
			ARMDisAsm(ReadMem32Unchecked(addr),addr,buf);
			fprintf(f,"%08x : %s\n",addr,buf);
		}
		fclose(f);*/
	}
	CASE("kill")
	{
		u32 start;// = 0x000009de; 
		sscanf(text+5,"%x",&start);

		WriteMem32(start, MIPS_MAKE_JR_RA());
		WriteMem32(start+4, MIPS_MAKE_NOP());
		/*

		for (int addr = start; addr!=end+4; addr+=4)
		{
		char buf[256];
		ARMDisAsm(ReadMem32Unchecked(addr),addr,buf);
		fprintf(f,"%08x : %s\n",addr,buf);
		}
		fclose(f);*/
	}
	CASE("klis")
	{
		PSPHLE::kernelObjects.List();
	}
	CASE("umem")
	{
		LOG(HLE,"Kernel Memory");
		PSPHLE::kernelMemory.ListBlocks();
		LOG(HLE,"User Memory");
		PSPHLE::userMemory.ListBlocks();
	}
	CASE("prevpc")
	{
		LOG(CPU,"PrevPC: %08x",prevpc);
	}
	CASE("pprevpc")
	{
		LOG(CPU,"PrevPC: %08x",pprevpc);
	}
	CASE("ppprevpc")
	{
		LOG(CPU,"PrevPC: %08x",ppprevpc);
	}
	CASE("cycl")
	{
		LOG(CPU,"%d debug cycles executed",debugCycles);
	}
	CASE("rota")
	{

		PSPHLE::__KernelReSchedule();
	}
	return false;
}
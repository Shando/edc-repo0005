/*H===========================================================================*/
/* D3-Projekt Chalmers Tekniska H�gskola                                      */
/* =======================                                                    */
/*                                                                            */
/* project         : Augmented Chemistry                                      */
/* module          : acgui                                                    */
/*                                                                            */
/* filename        : acg_font.c                                               */
/* language        : ansi "C"                                                 */
/*                                                                            */
/* ========================================================================== */
/* description of what the code within this file is good for                  */
/* ---------------------------------------------------------                  */
/* really fast bitmap-based text drawing for OpenGL                           */
/* Adapted from the lean and mean D3DFont class from old DX9 SDK (it's gone in*/
/* October 2004 onwards since D3DXFont is now much faster but it's closed src */
/* ========================================================================== */
/* initial author  :  henrik rydg�rd           (tronic@dtek.chalmers.se)      */
/*                    jonas fredriksson      (jonafred@dtek.chalmers.se)      */
/*                                                                            */
/* history of this file ( most actual date on top )                           */
/* ------------------------------------------------                           */
/* [History can be deduced from CVS]                                          */
/*                                                                            */
/* ========================================================================== */
/* Version Control System identifiers                                         */
/* ----------------------------------                                         */
/* (t.b.d.)                                                                   */
/*===========================================================================H*/


#define STRICT

#ifdef _MSC_VER
#include <windows.h>
#endif

#ifdef __APPLE__
  #include <OpenGL/gl.h>
  #include <GLUT/glut.h>
#else
  #include <GL/gl.h>
  #include <GL/glu.h>
#endif

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "acg_common.h"
#include "acg_draw.h" 
#include "acg_font.h"

// Globals
static unsigned int   m_dwTexWidth;                 // Texture dimensions
static unsigned int   m_dwTexHeight;
static float   m_fTexCoords[NUMCHARS+1-32][4];
static unsigned int   m_dwSpacing;                  // Character pixel spacing per side

static GLuint fontTex;

// endian-aware function so we can share font definition file between
// Mac and PC
float readFloat(FILE *file)
{
  union
  {
    char c[4];
    float f;
  } x;
  int i;
#ifdef __APPLE__
  for (i=3; i>=0; i--)
  {
    fread(&x.c[i],1,1,file);
  }
#else
  for (i=0; i<4; i++)
  {
    fread(&x.c[i],1,1,file);
  }
#endif
  return x.f;
}


void ACG_FontLoad(const char *texname, const char *offname)
{
  //unsigned char *pic = ACG_TGALoad(texname, &w, &h);
  FILE *f;
  char temp[1024];

  fontTex = ACG_LoadImage(texname);
  m_dwTexWidth = 512;
  m_dwTexHeight = 512;
  //glGenTextures(1,&fontTex);
  //glBindTexture(GL_TEXTURE_2D, fontTex);
  //if (!pic)
  // return;
  ACG_ApplyImage(fontTex);
  glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE); //use texture alpha
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
  glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);


  strcpy(temp,ACG_GetBasePath());
  strncat(temp,offname,1024);

  f = fopen(temp,"rb");
  if (f)
  {
    int i,j;
    for (i = 0; i < NUMCHARS+1-32; i++)
    {
      for (j = 0; j < 4; j++)
      {
        m_fTexCoords[i][j] = readFloat(f);
      }
    }
    fclose(f);
  }
  m_dwSpacing = (unsigned int)ceil(((m_fTexCoords[0][3] - m_fTexCoords[0][1])*m_dwTexHeight) * 0.07f);
}

void ACG_FontUnload()
{
  //glDeleteTextures(1,&fontTex);
  ACG_UnloadImage(fontTex);
}

void ACG_FontGetTextExtent( const char* strText, ACG_SIZE* pSize )
{
  float fLineHeight = ( m_fTexCoords[4][3] - m_fTexCoords[4][1] ) * m_dwTexHeight;
  float fRowWidth  = 0.0f;
  float fWidth     = 0.0f;
  float fHeight    = fLineHeight;
  float fXScale = 0.5f;
  float fYScale = 0.5f;

  if( NULL==strText || NULL==pSize )
    return;


  while (*strText)
  {
    char c = *strText++;
    float tx1,tx2;

    if (c == '\n')
    {
      fRowWidth = 0.0f;
      fHeight  += fLineHeight;
    }

    if ((c-32) < 0 || (c-32) >= NUMCHARS-32)
      continue;

    tx1 = m_fTexCoords[c-32][0];
    tx2 = m_fTexCoords[c-32][2];

    fRowWidth += (tx2-tx1)*m_dwTexWidth - 2*m_dwSpacing;

    if (fRowWidth > fWidth)
      fWidth = fRowWidth;
  }

  pSize->w = (int)(fWidth*fXScale);
  pSize->h = (int)(fHeight*fYScale);
}


void ACG_FontDrawTextScaled(float x, float y, float scale, const char* pstrText, unsigned int dwFlags)
{
  float fLineHeight = ( m_fTexCoords[4][3] - m_fTexCoords[4][1] ) * m_dwTexHeight;

  float sx,sy,sz,
    z = 0.0f,
    fStartX=x,
    fXScale=scale*0.5f,
    fYScale=scale*0.5f;

  const unsigned char *strText = (const unsigned char*)pstrText;
  if (!strText) 
	  return;

  glBindTexture(GL_TEXTURE_2D,fontTex);
  glEnable(GL_TEXTURE_2D);
  glDisable(GL_DEPTH_TEST);
  glEnable(GL_BLEND);
  
  glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
  glDisable(GL_CULL_FACE);

  // Centering
  if (dwFlags & ACG_FONT_CENTERED_X)
  {
    const unsigned char* strTextTmp = strText;
    float xFinal = 0.0f;

    while (*strTextTmp)
    {
      int c = *strTextTmp++;
      float tx1,tx2,w;

      if (c == '\n')
        break;  // Isn't supported.
      if ((c-32) < 0 || (c-32) >= NUMCHARS-32)
        continue;

      tx1 = m_fTexCoords[c-32][0];
      tx2 = m_fTexCoords[c-32][2];

      w = (tx2-tx1)*m_dwTexWidth*fXScale;

      xFinal += w - (2 * m_dwSpacing)*fXScale;
    }
    x -= xFinal/2;
  }

  //vertical centering
  if (dwFlags & ACG_FONT_CENTERED_Y)
  {
    y -= fLineHeight*fYScale/2;
  }

  sx  = x;
  sy  = y;
  sz  = z;

  // Adjust for character spacing
  sx -= m_dwSpacing * fXScale;
  fStartX = sx;

  glBegin(GL_QUADS);

  while (*strText)
  {
    int c = *strText++;
    float w,h;
    float tx1,tx2,ty1,ty2;

    if (c == '\n')
    {
      sx  = fStartX;
      sy += fYScale*fLineHeight;
    }

    if ((c - 32) < 0 || (c - 32) >= NUMCHARS - 32) 
      continue;

    tx1 = m_fTexCoords[c-32][0];
    ty1 = m_fTexCoords[c-32][1];
    tx2 = m_fTexCoords[c-32][2];
    ty2 = m_fTexCoords[c-32][3];

    w = (tx2-tx1)*m_dwTexWidth;
    h = (ty2-ty1)*m_dwTexHeight;

    w *= fXScale;
    h *= fYScale;

    if (c != ' ')
    {
      glTexCoord2f(tx1,ty1);
      glVertex2f(sx,sy);
      glTexCoord2f(tx2,ty1);
      glVertex2f(sx+w,sy);
      glTexCoord2f(tx2,ty2);
      glVertex2f(sx+w,sy+h);
      glTexCoord2f(tx1,ty2);
      glVertex2f(sx,sy+h);
    }

    sx += w - (2 * m_dwSpacing) * fXScale;
  }

  glEnd();
  glDisable(GL_TEXTURE_2D);
}





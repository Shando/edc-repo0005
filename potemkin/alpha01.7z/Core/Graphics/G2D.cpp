#include "stdafx.h"

#include "../MemMap.h"

#include "G2D.h"


G2DCore g2dCores[2];

// dirty hack version


inline u32 SEX28(u32 x) {return (x&0x08000000) ? (x|0xF0000000) : (x&0x7FFFFFF);}

u16 *G2DCore::GetPointer()
{
	return framebuffer;
}

union DispControl
{
	u16 hex;
	struct  
	{
		unsigned mode : 3;
		unsigned reserved : 1;
		unsigned frameSelect : 1;
		unsigned allowOAMinHBlank : 1;
		unsigned objMapping : 1;  //0=2d 1=1d
		unsigned forceBlank : 1;
		unsigned displayBGs : 4;
		unsigned displayObj : 1;
		unsigned window1 : 1;
		unsigned window2 : 1;
		unsigned objWindow : 1;
	};
};


union BGControl
{
	u16 hex;
	struct 
	{
		unsigned priority : 2;
		unsigned charBaseBlock : 2;
		unsigned notUsed : 2;
		unsigned mosaicEnable : 1;
		unsigned bigPalette : 1;
		unsigned mapBaseBlock : 5;
		unsigned wrap : 1;
		unsigned screenSize : 2;
	};
};

union SpriteAttr0
{
	u16 hex;
	struct 
	{
		unsigned yPos : 8;
		unsigned aff : 1;
		unsigned doubleSizeOrDisable : 1;
		unsigned blend : 1;
		unsigned window : 1;
		unsigned mosaicEnable : 1;
		unsigned bigPalette : 1;
		unsigned shape : 1;
	};
};

union SpriteAttr1
{
	u16 hex;
	struct 
	{
		signed xPos : 9;
		unsigned affIndex : 3;
		unsigned hFlip : 1;
		unsigned vFlip : 1;
		unsigned size : 2;
	};
};

union SpriteAttr2
{
	u16 hex;
	struct 
	{
		unsigned tileIndex : 10;
		unsigned priority : 2;
		unsigned palIndex : 4;
	};
};


/*
 *	screen size
 Value  Text Mode      Rotation/Scaling Mode
 0      256x256 (2K)   128x128   (256 bytes)
 1      512x256 (4K)   256x256   (1K)
 2      256x512 (4K)   512x512   (4K)
 3      512x512 (8K)   1024x1024 (16K)
 */


void G2DCore::DrawBGNormal(int b, int yline)
{
	BGControl bgcnt;
	bgcnt.hex = g2->bgCNT[b];

	u16 *p = lineBuffers[b];
    
	int xy = g2->bgOffset[b];

	int x = xy&0x1FF;
	int y = ((xy>>16)&0x1FF) + yline;

	int mosaicX = (g2->mosaic) & 0xF;
	int mosaicY = (g2->mosaic>>4) & 0xF;

	int window0R = g2->win0h&0xFF;
	int window0L = g2->win0h>>8;
	int window0B = g2->win1v&0xFF;
	int window0T = g2->win1v>>8;
	int window1R = g2->win1h&0xFF;
	int window1L = g2->win1h>>8;
	int window1B = g2->win1v&0xFF;
	int window1T = g2->win1v>>8;

	bool lineInWindow0 = (yline>=window0T && yline<window0B);
	bool lineInWindow1 = (yline>=window1T && yline<window1B);

	u8 *charPtr = bgvram + (bgcnt.charBaseBlock * 0x4000);
	u16 *mapPtr = (u16 *)((u8*)bgvram + (bgcnt.mapBaseBlock * 0x800));

	int screenSize = bgcnt.screenSize;

	for (int c=xres; c; c--, x++)
	{
		int u = x>>3;
		int v = y>>3;
		int ix = x&7;
		int iy = y&7;

		//let's ignore additional screens for now
		int xScreen = (u>>5) & 1;
		int yScreen = (v>>5) & 1;
		u &= 31;
		v &= 31;
		
		int screen = xScreen & (screenSize&1);
		screen += (yScreen<<1) & (screenSize&2);

		u16 entry = mapPtr[v*32+u+32*32*screen];
        
		int tile = entry & 0x3FF;
		

		if (entry & 0x400) ix^=7; //hflip
		if (entry & 0x800) iy^=7; //vflip

        int color;
		int flag;
		if (bgcnt.bigPalette)
		{
			color = charPtr[tile*64 + iy*8 + ix];
			flag = color ? 0x8000 : 0; //transparency!
		}
		else
		{
			int colors = charPtr[tile*32 + iy*4 + (ix/2)];
			int palnum = (entry >> 8) & 0xF0;
			if (ix&1)
			{
				color = (colors >> 4);
			}
			else 
			{
				color = (colors & 0xF);
			}
			flag = color ? 0x8000 : 0; //transparency!
			color+=palnum;
		}

		*p++ = ((u16 *)paletteram)[color] | flag;
	}
}


void G2DCore::DrawRotBG(int b, int y)
{
	BGControl bgcnt;
	bgcnt.hex = g2->bgCNT[b];

	int mosaicX = (g2->mosaic) & 0xF;
	int mosaicY = (g2->mosaic>>4) & 0xF;

	u16 *p = lineBuffers[b];

	u8 *charPtr = bgvram + (bgcnt.charBaseBlock * 0x4000);
	u8 *mapPtr = (bgvram + (bgcnt.mapBaseBlock * 0x800));

	int u = b==3?internal_bg3x:internal_bg2x;
	int v = b==3?internal_bg3y:internal_bg2y;

	int du = b==3?(s32)(s16)(g2->bg3PA):(s32)(s16)(g2->bg2PA);
	int dv = b==3?(s32)(s16)(g2->bg3PC):(s32)(s16)(g2->bg2PC);

	int size = 16 << bgcnt.screenSize;
	int mask = size-1;

	for (int i=0; i<xres; i++)
	{
		int x = u>>8;
		int y = v>>8;

		int iu = x>>3;
		int iv = y>>3;

		int color;
		/*
		if (!bgcnt.wrap && (iu<0 || iv<0 || iu>mask || iv>mask))
		{
			color=0;
		}
		else*/
		{
			int ix = x&7;
			int iy = y&7;

			int tile = mapPtr[(iu&mask) + size*(iv&mask)];
			color = charPtr[tile*64 + iy*8 + ix];
		}
		
		int flag = color ? 0x8000 : 0; //transparency!
		*p++ = ((u16 *)paletteram)[color] | flag;

		u+=du;
		v+=dv;
	}
}


int sizeTable[3][4][2] =
{
	{{8,8}, {16,16}, {32,32}, {64,64}},
	{{8,16}, {8,32}, {16,32}, {32,64}},
	{{16,8}, {32,8}, {32,16}, {64,32}},
};


void G2DCore::DrawSprites(int cury, u16 dispcnt)
{
	u8 *spriteBase = objvram;
	u16 *spritePal = (u16*)(paletteram+0x200);
	u16 *oamBase = (u16 *)oam;
	SpriteAttr0 attr0;
	SpriteAttr1 attr1;
	SpriteAttr2 attr2;
	
	u16 *p = lineBuffers[4];
	memset(p,0,sizeof(u16)*xres);


	int mosaicX = (g2->mosaic>>8) & 0xF;
	int mosaicY = (g2->mosaic>>12) & 0xF;

	for (int i=0; i<128; i++)
	{
		attr0.hex = ((u16*)oam)[i*4];		
		attr1.hex = ((u16*)oam)[i*4+1];		
		attr2.hex = ((u16*)oam)[i*4+2];

		int x = attr1.xPos;
		int y = attr0.yPos;

		int w = sizeTable[attr0.shape][attr1.size][0];
		int h = sizeTable[attr0.shape][attr1.size][1];

		int xtiles = w >> 3;
		int ytiles = h >> 3;

		int bboxw = w;
		int bboxh = h;

		if (attr0.doubleSizeOrDisable)
		{
			if (attr0.aff)
			{
				bboxw<<=1;
				bboxh<<=1;
			}
			else
			{
				continue;
			}
		}

		if(y + bboxh > 256)
			y -= 256;

		if (cury < y) continue;
		if (cury >= y+h) continue;

		int iy = cury-y;

		if (attr1.vFlip)
			iy ^= (h-1);

		int pitch;
		int tileIndex = attr2.tileIndex;

		if (attr0.bigPalette)
		{
			tileIndex>>=1;

			if (!(dispcnt & (1<<6)))
				pitch = 16;//2d mapping
			else
				pitch = xtiles;
 
			while (iy>=8)
			{
				iy-=8;
				tileIndex+=pitch;
			}
			
			int source = tileIndex * 64 + iy * 8;
			
			for (int ix = 0; ix < w; ix++)
			{
				int xix = ix;
				if (attr1.hFlip)
					xix^=(w-1);
				
				int n = xix>>3;
				int c = spriteBase[(source + (n*64 + (xix&7)))&0x7FFF];
				if (c && (x+ix)>=0 && (x+ix)<xres)
					p[x+ix] = 0x8000|spritePal[c];
			}
		}
		else
		{
			if (!(dispcnt & (1<<6)))
				pitch = 32;//2d mapping
			else
				pitch = xtiles;

			while (iy >= 8)
			{
				iy-=8;
				tileIndex += pitch;
			}

			int source = tileIndex * 32 + iy * 4;

			int palIndex = attr2.palIndex * 16;

			for (int ix = 0; ix < w; ix++)
			{
				int xix = ix;
				if (attr1.hFlip)
					xix^=(w-1);

				int n = xix>>3;
				int c = spriteBase[(source + n*32 + ((xix&7)>>1))&0x7FFF];

				if (!(xix&1))
				{
					c=(c&0xF);
				}
				else
				{
					c=(c>>4);
				}
				if (c && (x+ix)>=0 && (x+ix)<xres)
					p[x+ix] = 0x8000 | spritePal[c + palIndex];
			}
		}
	}
}


u16 combine(u16 src1, u16 src2)
{
	//for (int i=0; i<count; i++)
	{
		u16 val1 = src1;
		u16 val2 = src2;
		if (val2&0x8000)
			return val2;
		else
			return val1;
	}
}

void G2DCore::DrawLine(int y, u16 dispcnt, u16 dispstat)
{
	u8 *palettePtr = (u8*)paletteram;

	DispControl dcnt;
	dcnt.hex = dispcnt;

	switch (dcnt.mode) 
	{
	case 0:
		{
			u16 *dest = framebuffer + y*PITCH;

			for (int b=0; b<4; b++)
			{
				if (dcnt.displayBGs & (1<<b))
				{
					DrawBGNormal(b,y);
				}
				else
				{
					memset(lineBuffers[b],0,xres*sizeof(u16));
				}
			}

			if (dcnt.displayObj)
			{
				DrawSprites(y,dispcnt);
			}
			else
			{
				memset(lineBuffers[4],0,xres*sizeof(u16));
			}

			for (int i=0; i<xres; i++)
			{
				//int c = vp[i];
				//int b = c>>10;
				//int g = (c>>5) & 0x1f;
				//int r = c&0x1f;
				dest[i] = combine(combine(combine(combine(lineBuffers[0][i],lineBuffers[1][i]),lineBuffers[2][i]),lineBuffers[3][i]), lineBuffers[4][i]);
				//(b<<10) | (g<<5) | r;
			}
		}
		break;
	case 1:
		{
			u16 *dest = framebuffer + y*PITCH;

			for (int b=0; b<2; b++)
			{
				if (dcnt.displayBGs & (1<<b))
				{
					DrawBGNormal(b,y);
				}
				else
				{
					memset(lineBuffers[b],0,xres*sizeof(u16));
				}
			}

			if (dcnt.displayBGs&4)
				DrawRotBG(2,y);

			if (dcnt.displayObj)
			{
				DrawSprites(y,dispcnt);
			}
			else
			{
				memset(lineBuffers[4],0,xres*sizeof(u16));
			}

			for (int i=0; i<xres; i++)
			{
				//int c = vp[i];
				//int b = c>>10;
				//int g = (c>>5) & 0x1f;
				//int r = c&0x1f;
				dest[i] = combine(combine(combine(lineBuffers[0][i],lineBuffers[1][i]),lineBuffers[2][i]), lineBuffers[4][i]);
				//(b<<10) | (g<<5) | r;
			}
		}
		break;
	case 2:
		{
			u16 *dest = framebuffer + y*PITCH;

			for (int b=2; b<4; b++)
			{
				if (dcnt.displayBGs & (1<<b))
				{
					DrawRotBG(b,y);
				}
				else
				{
					memset(lineBuffers[b],0,xres*sizeof(u16));
				}
			}
			if (dcnt.displayObj)
			{
				DrawSprites(y,dispcnt);
			}
			else
			{
				memset(lineBuffers[4],0,xres*sizeof(u16));
			}

			for (int i=0; i<xres; i++)
			{
				//int c = vp[i];
				//int b = c>>10;
				//int g = (c>>5) & 0x1f;
				//int r = c&0x1f;
				dest[i] = combine(lineBuffers[0][i] + lineBuffers[1][i] + lineBuffers[2][i] + lineBuffers[3][i], lineBuffers[4][i]);
				//(b<<10) | (g<<5) | r;
			}
		}
		break;
	case 3:
		{
			u16 *vp = (u16*)bgvram;
			u16 *dest = framebuffer + y*PITCH;
			
			int u = internal_bg2x;
			int v = internal_bg2y;

			if (dcnt.displayObj)
			{
				DrawSprites(y,dispcnt);
			}
			else
			{
				memset(lineBuffers[4],0,xres*sizeof(u16));
			}

			//todo: add bilinear filter
			for (int i=0; i<xres; i++)
			{
				int x = u>>8;
				int y = v>>8;
				int c;
				if (x>=0 && y>=0 && x < xres && y < yres)
					c = vp[y*xres+x];
				else
					c = 0;
				dest[i] = combine( (0x8000 | c), lineBuffers[4][i]);
				u+=(s32)(s16)(g2->bg2PA);
				v+=(s32)(s16)(g2->bg2PC);
			}

		}
		break;
	case 4:
		{
			if (dcnt.displayObj)
			{
				DrawSprites(y,dispcnt);
			}
			else
			{
				memset(lineBuffers[4],0,xres*sizeof(u16));
			}

			u8 *vp = (u8*)(bgvram + dcnt.frameSelect*0xA000);
			int u = internal_bg2x;
			int v = internal_bg2y;

			u16 *dest = framebuffer + y*PITCH;
			u16 *pal = (u16*)palettePtr;

			for (int i=0; i<xres; i++)
			{
				int x = u>>8;
				int y = v>>8;

				int paletteIndex;
				
				if (x>=0 && y>=0 && x < xres && y < yres)
					paletteIndex = vp[y*xres + x];
				else
					paletteIndex = 0;

				int c = pal[paletteIndex];
				
				int a = paletteIndex!=0;
				int bgr = c&0x7FFF;
				dest[i] = combine( ((c?0x8000:0) | bgr), lineBuffers[4][i]);
				u+=(s32)(s16)(g2->bg2PA);
				v+=(s32)(s16)(g2->bg2PC);
			}
		}
		break;
	case 5:
		{
			if (dcnt.displayObj)
			{
				DrawSprites(y,dispcnt);
			}
			else
			{
				memset(lineBuffers[4],0,xres*sizeof(u16));
			}

			/*
			vp += y*160;
			u16 *dest = framebuffer + y*PITCH + 40;
			for (int i=0; i<160; i++)
			{
				int c = *vp++;
				dest[i] = 0x8000 | c;
			}*/
			u16 *vp = (u16*)(bgvram + dcnt.frameSelect * 0xA000);
			int u = internal_bg2x;
			int v = internal_bg2y;

			u16 *dest = framebuffer + y*PITCH;
			u16 *pal = (u16*)palettePtr;

			for (int i=0; i<xres; i++)
			{
				int x = u>>8;
				int y = v>>8;

				int c;

				if (x>=0 && y>=0 && x < 160 && y < 120)
					c = vp[y*160+x];
				else
					c = 0;

				int bgr = c&0x7FFF;
				dest[i] = combine( (0x8000 | bgr), lineBuffers[4][i]);
				u+=(s32)(s16)(g2->bg2PA);
				v+=(s32)(s16)(g2->bg2PC);
			}
		}
		break;
	default:
		LOG(G2D,"Unsupported mode %i",dcnt.mode);
		break;
	}
}


void G2DCore::VBlank()
{
    internal_bg2x = SEX28(g2->bg2X); 
	internal_bg2y = SEX28(g2->bg2Y);
    internal_bg3x = SEX28(g2->bg3X); 
	internal_bg3y = SEX28(g2->bg3Y);
}
void G2DCore::HBlank()
{
    internal_bg2x += (s32)(s16)(g2->bg2PB); 
	internal_bg2y += (s32)(s16)(g2->bg2PD);
	internal_bg3x += (s32)(s16)(g2->bg3PB); 
	internal_bg3y += (s32)(s16)(g2->bg3PD);
}


void G2DCore::Write32Notify(u32 address, u32 value)
{
	address&=0xfff;
	switch (address) 
	{
	case 0x28: internal_bg2x = SEX28(value); break;
	case 0x2C: internal_bg2y = SEX28(value); break;
	case 0x38: internal_bg3x = SEX28(value); break;
	case 0x3C: internal_bg3y = SEX28(value); break;
	}
}

void G2DCore::Write16Notify(u32 address, u16 value)
{
	address&=0xfff;
	/*
	switch (address) 
	{
	case :
		break;
	case :
		break;
	default:
	}*/
}

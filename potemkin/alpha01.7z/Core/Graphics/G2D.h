#pragma once

#include "../../Globals.h"
// GBA / DS 2D graphics hardware implementation

struct G2 //start at 0x008, subscreen at 0x1008
{
	u16 bgCNT[4];
	u32 bgOffset[4];
	u16 bg2PA;
	u16 bg2PB;
	u16 bg2PC;
	u16 bg2PD;
	u32 bg2X;
	u32 bg2Y;
	u16 bg3PA;
	u16 bg3PB;
	u16 bg3PC;
	u16 bg3PD;
	u32 bg3X;
	u32 bg3Y;
	u16 win0h;
	u16 win1h;
	u16 win0v;
	u16 win1v;
	u16 winin;
	u16 winout;
	u16 mosaic;
	u16 blendCNT;
	u16 blendAlpha;
	u16 blendY;
};


enum
{
	G2DMODE_GBA = 0,
	G2DMODE_DS  = 1
};


// GBA/DS 2D Core
struct G2DCore
{
private:
	u16 *framebuffer;

	int xres,yres; // support both DS and GBA, different resolutions
	enum
	{
		PITCH = 256,
		INTERNALHEIGHT = 256
	};

	u16 lineBuffers[5][256];

	u32 internal_bg2x;
	u32 internal_bg2y;
	u32 internal_bg3x;
	u32 internal_bg3y;
	
public:
	void Init(int _xres, int _yres)
	{
		xres=_xres;yres=_yres;
		framebuffer = new u16[PITCH*INTERNALHEIGHT];
	}
	void Shutdown()
	{
		delete framebuffer;
	}
	u8 *bgvram;
	u8 *objvram;
	u8 *paletteram;
	u8 *oam;

	G2 *g2;
	void DrawLine(int y, u16 dispcnt, u16 dispstat);
	void DrawBGNormal(int b, int y);
	void DrawRotBG(int b, int y);
	void DrawSprites(int y, u16 dispcnt);
	void HBlank();
	void VBlank();

	u16 *GetPointer();

	void Write16Notify(u32 address, u16 value);
	void Write32Notify(u32 address, u32 value);
};

extern G2DCore g2dCores[2];
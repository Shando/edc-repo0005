/*H===========================================================================*/
/* D3-Projekt Chalmers Tekniska H�gskola                                      */
/* =======================                                                    */
/*                                                                            */
/* project         : Augmented Chemistry                                      */
/* module          : acgui                                                    */
/*                                                                            */
/* filename        : acg_font.h                                               */
/* language        : ansi "C"                                                 */
/*                                                                            */
/* ========================================================================== */
/* description of what the code within this file is good for                  */
/* ---------------------------------------------------------                  */
/* really fast bitmap-based text drawing for OpenGL                           */
/* Adapted from the lean and mean D3DFont class from old DX9 SDK (it's gone in*/
/* October 2004 onwards since D3DXFont is now much faster but it's closed src */
/* ========================================================================== */
/* initial author  :  henrik rydg�rd           (tronic@dtek.chalmers.se)      */
/*                    jonas fredriksson      (jonafred@dtek.chalmers.se)      */
/*                                                                            */
/* history of this file ( most actual date on top )                           */
/* ------------------------------------------------                           */
/* [History can be deduced from CVS]                                          */
/*                                                                            */
/* ========================================================================== */
/* Version Control System identifiers                                         */
/* ----------------------------------                                         */
/* (t.b.d.)                                                                   */
/*===========================================================================H*/



#ifndef ACG_FONT_H
#define ACG_FONT_H

//#include <tchar.h>

// Font creation flags
#define ACG_FONT_BOLD        0x0001
#define ACG_FONT_ITALIC      0x0002
#define ACG_FONT_ZENABLE     0x0004

// Font rendering flags
#define ACG_FONT_CENTERED_X  0x0001
#define ACG_FONT_CENTERED_Y  0x0002
#define ACG_FONT_TWOSIDED    0x0004
#define ACG_FONT_FILTERED    0x0008

#define NUMCHARS 255

  // 2D and 3D text drawing functions
void ACG_FontLoad(const char *texname, const char *offname);
void ACG_FontUnload();
void ACG_FontDrawTextScaled(float x, float y, float scale, const char* strText, unsigned int dwFlags);
void ACG_FontRender3DText( const char* strText, unsigned int dwFlags);
  
// Function to get extent of text
typedef struct 
{
  int w, h;
} ACG_SIZE;

void ACG_FontGetTextExtent(const char* strText, ACG_SIZE* pSize);

#endif



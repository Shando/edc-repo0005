/*H===========================================================================*/
/* D3-Projekt Chalmers Tekniska H�gskola                                      */
/* =======================                                                    */
/*                                                                            */
/* project         : Augmented Chemistry                                      */
/* module          : acgui                                                    */
/*                                                                            */
/* filename        : acgui_imageloader.h                                      */
/* language        : ansi "C"                                                 */
/*                                                                            */
/* ========================================================================== */
/* description of what the code within this file is good for                  */
/* ---------------------------------------------------------                  */
/* provides tga image format loading                                          */
/*                                                                            */
/* ========================================================================== */
/* initial author  :  jonas fredriksson      (jonafred@dtek.chalmers.se)      */
/*                    henrik rydg�rd           (tronic@dtek.chalmers.se)      */
/*                                                                            */
/* history of this file ( most actual date on top )                           */
/* ------------------------------------------------                           */
/* [History can be deduced from CVS]                                          */
/*                                                                            */
/* ========================================================================== */
/* Version Control System identifiers                                         */
/* ----------------------------------                                         */
/* (t.b.d.)                                                                   */
/*===========================================================================H*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "acg_common.h"

#include "acg_imageloader.h"


/* TGA Loader */

#define _TGA_MAX_PALETTE_LENGTH 256
#define _MAX_IMAGE_SIZE _MAX_IMAGE_WIDTH*_MAX_IMAGE_HEIGHT

#ifdef __APPLE__
#define MACRO_ENDIAN_CONVS(a) a = ((a << 8) & 0xff00) + ((a >> 8) & 0xff)
#else
#define MACRO_ENDIAN_CONVS(a)
#endif

typedef struct _TGAinternal
{
  unsigned char idFieldLength;
  unsigned char colorMapType;
  unsigned char imageTypeCode;

  //  Color Map Specs.
  unsigned short int colorMapOrigin;
  unsigned short int colorMapLength;
  unsigned char colorMapEntrySize;

  //  Image specifications
  unsigned short int xOrigin;
  unsigned short int yOrigin;
  unsigned short int width;
  unsigned short int height;
  unsigned char imagePixelSize;
  unsigned char imageDescription;


  char imageIdentificationField[256];
  char colorMapData[_TGA_MAX_PALETTE_LENGTH];

} TGAinternal;

//#define _TGA_VERBOSE_ //  Should probably only be defined for debugging sessions.  

#define TGA_ERROR_UNSUPPORTED_IMAGE_TYPE 1

void postProcessFlipVertical(unsigned char *imageData, int width, int height){  
  unsigned char *temp = (unsigned char *)malloc(width * height * 4);  
  int y;
  memcpy(temp,imageData,width*height*4);  //  Copy image data to temporary location.

  //  Bring back image data in scanline reversed order.  
  for (y=0;y<height-1;y++){
    memcpy(imageData+y*width*4,temp+(height-1-y)*width*4,width*4);
  }

  free(temp);
}

void postProcessXchangeRB(unsigned char *imageData , int width, int height){ 
  unsigned char t;
  int i;
  for (i=0;i<width*height*4;i+=4) {
    t=imageData[(i)+0];
    imageData[(i)+0]=imageData[(i)+2];  
    imageData[(i)+2]=t;    
  }
}

/*F===========================================================================*/
/*                                                                            */
/* FUNCTION        : AGC_TGALoad()                                            */
/*                                                                            */
/* ========================================================================== */
/* loads a TGA format image                                                   */
/* currently only supports 24 and 32-bit (with alpha channel) formats         */
/* ------------------------------------------------------------               */
/*                                                                            */
/* ========================================================================== */
/*                                                                            */
/* PARAMETERS      : char filename[], unsigned short *width, unsigned short *height */
/*                                                                            */
/* RETURN          : unsigned char                                            */
/*                                                                            */
/* NOTES           : caller is responsible for freeing the returned memory    */
/*                                                                            */
/*===========================================================================F*/
unsigned char *ACG_TGALoad(const char *filename, unsigned int *_width, unsigned int *_height)
{
  FILE *in;
  unsigned char *imageData;
  TGAinternal tga;
  char temp[512];
  unsigned short w,h;
  int width, height;

  strcpy(temp, ACG_GetBasePath());
  strcat(temp, filename);

  in = fopen(temp,"rb");

  if (!in) 
    return NULL;

  fread(&tga.idFieldLength,1,1,in);
  fread(&tga.colorMapType,1,1,in);
  fread(&tga.imageTypeCode,1,1,in);

  // Only used if the color map exists.
  fread(&tga.colorMapOrigin,2,1,in);
  fread(&tga.colorMapLength,2,1,in);
  fread(&tga.colorMapEntrySize,1,1,in);

  if ((tga.imageTypeCode != 2) && (tga.imageTypeCode != 10))
  {
#ifdef _TGA_VERBOSE_  //  Prints out info about the loading process.
    printf("TGA loader says:\n");
    printf("----------------\n");
    printf("Unsupported image type (%i)!\n", tga.imageTypeCode);
#endif
    fclose(in);
    return 0;
  }

  fread(&tga.xOrigin,2,1,in);
  fread(&tga.yOrigin,2,1,in);
  MACRO_ENDIAN_CONVS(tga.xOrigin);
  MACRO_ENDIAN_CONVS(tga.yOrigin); 
  fread(&w,2,1,in);
  fread(&h,2,1,in);
  MACRO_ENDIAN_CONVS(w);
  MACRO_ENDIAN_CONVS(h); 
  width = w;
  height = h;

  fread(&tga.imagePixelSize,1,1,in);
  fread(&tga.imageDescription,1,1,in);

#ifdef _TGA_VERBOSE_  //  Prints out info about the loading process.
  printf("TGA loader says:\n");
  printf("----------------\n");
  printf("Id field length: %i\n", tga.idFieldLength);
  printf("width: %i height: %i\n", *width, *height);

  printf("Color map: %i\n", tga.colorMapType);
  if (tga.colorMapType)
    printf("Yes\n");
  else
    printf("No\n");

  printf("Image type code: %i \n", tga.imageTypeCode);
  if (tga.imageTypeCode==2)
    printf("- Uncompressed, RGB image\n");

  if (tga.imageTypeCode==10)
    printf("- RLE compressed, RGB image\n");

  printf("Color map origin: %i\n", tga.idFieldLength);
#endif

  imageData = (unsigned char *)malloc(width * height * 4);  
  switch (tga.imageTypeCode) 
  {  
  case 2:
    {   //  Unmapped RGB
      switch (tga.imagePixelSize)
      {        
      case 16: 
        {
          unsigned char *dest = imageData;
          unsigned short color;
          int i;
          for (i = 0; i < width * height; i++)
          {         

            color = (unsigned short)(fgetc(in) + (fgetc(in)<<8));


            dest[i*4+0] = (unsigned char)(((color)>>0)&31)<<3;
            dest[i*4+1] = (unsigned char)(((color)>>5)&31)<<3;
            dest[i*4+2] = (unsigned char)(((color)>>10)&31)<<3;
            //  dest[i*4+3] = (((color)>>15)&1)*255;  
            dest[i*4+3] = 0xFF;  //  Attrib bit in 16-bit format doesn't seem to be used for alpha
            //  so set alpha channel to no transparancy.	      
          }
        }
        break;
      case 24:
      case 32:
        {
          unsigned char *dest = imageData;
          int i, channel;
          for (i=0;i<width * height;i++)
          {        
            dest[i*4+3] = 0xFF;  //  Set alpha channel to no transparancy.
            for (channel=0;channel<(3+(tga.imagePixelSize==32));channel++)
              dest[i*4+channel] = fgetc(in);		
          }
        }
        break; 
      default:
        return 0;    
      }
    }
    break;

  case 10:  // RLE compressed RGB
    {
      int pixelCount=0;
      unsigned char rleHeader;      
      unsigned char packageLength;
      unsigned char r=0,g=0,b=0,a=0;  
      unsigned char *dest = imageData;
      int i;
      for (;;)
      {
        rleHeader = (unsigned char)fgetc(in);
        packageLength = (rleHeader&127)+1;	
        for (i=0;i<packageLength;i++)
        {
          if ((rleHeader<128) || (i==0))
          {  //  Bit 7 is not set so we are in a raw package and must thus read new values for each pixel.
            r=(unsigned char)fgetc(in);
            g=(unsigned char)fgetc(in);
            b=(unsigned char)fgetc(in);
            if (tga.imagePixelSize==32)
              a=(unsigned char)fgetc(in);
            else
              a=255;
          }  
          dest[(pixelCount*4)+0]=r;
          dest[(pixelCount*4)+1]=g;
          dest[(pixelCount*4)+2]=b;
          dest[(pixelCount*4)+3]=a;
          pixelCount++;
        }

        if (pixelCount >= width * height) 
          break;
      };
      //printf("%i, %i",pixelCount,width * height);  
      pixelCount = 0;  
    }
    break;
  }
  fclose(in);

  //  Flip along the y axis if necessary.
  if (!(tga.imageDescription & 32)) 
    postProcessFlipVertical(imageData, width, height);

  //  Change to our internal format.
  postProcessXchangeRB(imageData, width, height);

  *_width = width;
  *_height = height;
  return imageData;  // No errors
}

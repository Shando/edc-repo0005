/*H===========================================================================*/
/* D3-Projekt Chalmers Tekniska H�gskola                                      */
/* =======================                                                    */
/*                                                                            */
/* project         : Augmented Chemistry                                      */
/* module          : acgui                                                    */
/*                                                                            */
/* filename        : acgui_imageloader.h                                      */
/* language        : ansi "C"                                                 */
/*                                                                            */
/* ========================================================================== */
/* description of what the code within this file is good for                  */
/* ---------------------------------------------------------                  */
/* provides tga image format loading                                          */
/*                                                                            */
/* ========================================================================== */
/* initial author  :  jonas fredriksson      (jonafred@dtek.chalmers.se)      */
/*                    henrik rydg�rd           (tronic@dtek.chalmers.se)      */
/*                                                                            */
/* history of this file ( most actual date on top )                           */
/* ------------------------------------------------                           */
/* [History can be deduced from CVS]                                          */
/*                                                                            */
/* ========================================================================== */
/* Version Control System identifiers                                         */
/* ----------------------------------                                         */
/* (t.b.d.)                                                                   */
/*===========================================================================H*/

#ifndef _ACG_IMAGELOADER_H
#define _ACG_IMAGELOADER_H

unsigned char *ACG_TGALoad(const char *filename, unsigned int *width, unsigned int *height);

#endif
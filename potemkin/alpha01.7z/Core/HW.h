#pragma once

#include "../Globals.h"

void HW_Init(EmuMode mode);

void HW_Shutdown();

bool HW_IsInited();

struct RegInfo
{
	bool r,w;
	TCHAR *name;
	TCHAR *description;
};

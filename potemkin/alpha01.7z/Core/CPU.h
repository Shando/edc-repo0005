
#pragma once

#include "../Globals.h"

#include "MemMap.h"
#include "Core.h"

enum
{
	GPR_SIZE_32=0,
	GPR_SIZE_64=1
};

enum CPUType
{
	CPUTYPE_OTHER=-1,
	CPUTYPE_ARM7=1,
	CPUTYPE_ARM9=2,
	CPUTYPE_MIPSR4K=3,
	CPUTYPE_SH4,
};

class CPU
{
public:
	MemMap memMap;
private:
	u32 id;
	//virtual functions - slower, only for IR interpreter and debugger
	// DO NOT use in dynarec
public:
	virtual void SingleStep() {}
	virtual void FastRun() 
	{	
		//lame default implementation
		while (coreState == CORE_RUNNING)
		{
			SingleStep();
		}
	}

	virtual TCHAR *GetName() = 0;
	virtual int GetNumGPRs() = 0; 
	virtual int GetGPRSize() = 0; //32 or 64
	virtual u32 GetGPR32Value(int reg) {return 0;}
	virtual u32 GetGPR64Value(int reg) {return 0;}
	virtual void SetGPR32Value(int reg) {}
	virtual void SetGPR64Value(int reg) {}
	virtual u32 GetPC() = 0;
	virtual void SetPC(u32 _pc) = 0;
	virtual u32 GetLR() {return GetPC();}
	virtual int GetInstructionSize() {return 4;}
	virtual CPUType GetType() {return CPUTYPE_OTHER;}
	virtual void DisAsm(u32 op, u32 pc, int align, char *out) {sprintf(out,"[%08x] UNKNOWN", op);}
	//More stuff for debugger
	virtual int GetNumCategories() {return 0;}
	virtual int GetNumRegsInCategory(int cat) {return 0;}
	virtual const TCHAR *GetCategoryName(int cat) {return 0;}
	virtual const TCHAR *GetRegName(int cat, int index) {return 0;}
	virtual void PrintRegValue(int cat, int index, char *out)
	{
		sprintf(out,"%08x",GetGPR32Value(index));
	}
	virtual u32 GetRegValue(int cat, int index) {return 0;}
	virtual void SetRegValue(int cat, int index, u32 value) {}
};

#define MAX_NUM_CPU 2


extern CPU *cpus[MAX_NUM_CPU];
extern CPU *currentCPU;
extern int numCPUs;

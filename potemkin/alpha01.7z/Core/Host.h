#pragma once

#include "../Globals.h"


class Mixer
{
public:
	Mixer() {}
	virtual int Mix(short *stereoout, int numSamples) {memset(stereoout,0,numSamples*2*sizeof(short)); return numSamples;}
};



class Host
{
public:
	//virtual void StartThread()
	virtual void UpdateUI() {}
	
	virtual void UpdateMemView() {}
	virtual void UpdateDisassembly() {}

	virtual void SetDebugMode(bool mode) { }

	virtual void InitGL() = 0;
	virtual void BeginFrame() {}
	virtual void EndFrame() {}
	virtual void ShutdownGL() = 0;

	virtual void InitSound(Mixer *mixer) = 0;
	virtual void UpdateSound() {};
	virtual void ShutdownSound() = 0;

	//allocate executable memory
	virtual u8 *AllocExecMemory(size_t size) = 0;
	virtual void FreeExecMemory(u8 *ptr) = 0;


	//this is sent from EMU thread! Make sure that Host handles it properly!
	virtual void BootDone() {} 
	virtual void PrepareShutdown() {}

	virtual bool IsDebuggingEnabled() {return true;}
	virtual bool AttemptLoadSymbolMap() {return false;}
	virtual void ResetSymbolMap() {}
	virtual void AddSymbol(std::string name, u32 addr, u32 size, int type=0) = 0;
};

extern Host *host;
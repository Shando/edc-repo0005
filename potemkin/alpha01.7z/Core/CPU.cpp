#include "stdafx.h"

#include "CPU.h"

u32 debugCycles;

class PseudoCPU : public CPU
{
public:
	TCHAR *GetName() {return _T("None");}
	int GetNumGPRs() {return 0;}
	int GetGPRSize() {return 0;}
	u32 GetPC() {return 0;}
	void SetPC(u32 _pc) {}
};

CPU *cpus[MAX_NUM_CPU];
PseudoCPU mojs[2];
CPU *currentCPU = &mojs[0];

int numCPUs;

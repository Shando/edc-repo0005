#pragma once

#include "../../Globals.h"

enum
{
	DMAADDR_INC=0,
	DMAADDR_DEC,
	DMAADDR_FIX,
	DMAADDR_INCRELOAD
};

enum 
{
	DMATIMING_IMMEDIATELY=0,
	DMATIMING_VBLANK=1,
	DMATIMING_HBLANK=2,
	DMATIMING_SPECIAL=3 //sound?
};

enum 
{
	DMATIMINGDS_IMMEDIATELY=0,
	DMATIMINGDS_VBLANK=1,
	DMATIMINGDS_HBLANK=2,
	DMATIMINGDS_DISP=3,
	DMATIMINGDS_DISP_MMEM=4,
	DMATIMINGDS_CARD=5,
	DMATIMINGDS_CARTRIDGE=6,
	DMATIMINGDS_GXFIFO=7
};

enum
{
	DMATRANSFER_16BIT=0,
	DMATRANSFER_32BIT=1
};


union DMACNT
{
	u32 hex;
	struct 
	{
		unsigned wordCount     : 16; //have to put it here, unions can't be 16 bits :(
		unsigned unused        : 5;
		unsigned destControl   : 2;
		unsigned sourceControl : 2;
		unsigned repeat        : 1;
		unsigned type          : 1;
		unsigned gamepak       : 1;
		unsigned startTiming   : 2;
		unsigned irq           : 1;
		unsigned enable        : 1;
	};
};

struct DMAChan
{
	u32 sourceAddr;
	u32 destAddr;
	DMACNT dmaCNT;
};

struct DMAC //start at 0xb0
{
	DMAChan channels[4];
};

int  DMAC_DoDMA(DMAC *dmac, int channel);
void DMAC_CntWrite16(DMAC *dmac, int channel, u16 value);
void DMAC_CntWrite32(DMAC *dmac, int channel, u32 value);
int  DMAC_HBlank(DMAC *dmac);
void DMAC_SrcWrite32(DMAC *dmac, int channel, u32 value);
void DMAC_DstWrite32(DMAC *dmac, int channel, u32 value);
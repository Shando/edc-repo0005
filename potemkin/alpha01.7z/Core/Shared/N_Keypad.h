#pragma once

#include "../../Globals.h"

void N_Keypad_UpdateKeys(u16 &keyinput);

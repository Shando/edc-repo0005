#include "stdafx.h"

#include "../MemMap.h"

#include "../System.h"

#include "N_DMA.h"

//internal DMA pointers
static int DMASource[4];
static int DMADest[4];

//returns number of cycles

int DMAC_DoDMA(DMAC *dmac, int channel)
{
	DMAChan &c = dmac->channels[channel];

	int sdelta, ddelta, cycles;
	
	switch (c.dmaCNT.destControl) 
	{
	case DMAADDR_INC: ddelta=1;  break;
	case DMAADDR_DEC: ddelta=-1; break;
	case DMAADDR_FIX: ddelta=0; break;
	case DMAADDR_INCRELOAD: ddelta=1; DMADest[channel] = c.destAddr; break;
	}

	switch (c.dmaCNT.sourceControl) 
	{
	case DMAADDR_INC: sdelta=1;  break;
	case DMAADDR_DEC: sdelta=-1; break;
	case DMAADDR_FIX: sdelta=0; break;
	default:
		LOG(DMA,"Unsupported Source control");
	}

	int count = c.dmaCNT.wordCount;
	
	if (channel != 3)
		count&=0x3fff;

	if (count == 0)
		count = (channel==3) ? 0x10000 : 0x4000;

	LOG(DMA,"DMA Transfer : %08x -> %08x, %d words",DMASource[channel],DMADest[channel],count);

	if (c.dmaCNT.type == DMATRANSFER_32BIT)
	{
		sdelta*=4;
		ddelta*=4;
		cycles=count*3;

		while (count--) // dma:s steal all cycles on GBA
		{
			//TODO: special case optimize this
			WriteMem32(DMADest[channel],ReadMem32(DMASource[channel]));
			DMADest[channel]   += ddelta;
			DMASource[channel] += sdelta;
		}
	}
	else
	{
		sdelta*=2;
		ddelta*=2;
		cycles=count*2;
		while (count--) // dma:s steal all cycles on GBA
		{
			WriteMem16(DMADest[channel],ReadMem16(DMASource[channel]));
			DMADest[channel]   += ddelta;
			DMASource[channel] += sdelta;
		}
	}

	if (!c.dmaCNT.repeat)
	{
		c.dmaCNT.enable = false;
		c.dmaCNT.wordCount=0;
	}

	if (c.dmaCNT.irq)
	{
		//cause a "DMA finished" interrupt

	}
	return cycles;
}


void DMAC_TriggerInstant(DMAC *dmac, int channel)
{
	DMAChan &c = dmac->channels[channel];
	if (c.dmaCNT.enable)
	{
		if (c.dmaCNT.startTiming == DMATIMING_IMMEDIATELY)
		{
			//launch instant dma!
			DMASource[channel] = c.sourceAddr;
			DMADest[channel]   = c.destAddr;
			currentSystem->advance(DMAC_DoDMA(dmac,channel));
			c.dmaCNT.enable = false;
			c.dmaCNT.unused=0;
		}
		else
		{
			LOG(DMA,"Appears we shouldn't launch DMA. %04x, timing=%d",c.dmaCNT.hex>>16,c.dmaCNT.startTiming);
		}
	}
	else
	{
		LOG(DMA,"Appears we shouldn't launch DMA (2). %04x",c.dmaCNT.hex>>16);
	}
}

void DMAC_CntWrite16(DMAC *dmac, int channel, u16 value)
{
	DMAChan &c = dmac->channels[channel];
	((u16*)(&c.dmaCNT))[1] = value;
	DMAC_TriggerInstant(dmac,channel);
}
void DMAC_CntWrite32(DMAC *dmac, int channel, u32 value)
{
	DMAChan &c = dmac->channels[channel];
	LOG(DMA,"DMACNTW32 %08x",value);
	c.dmaCNT.hex = value;
	DMAC_TriggerInstant(dmac,channel);
}

void DMAC_SrcWrite32(DMAC *dmac, int channel, u32 value)
{
	DMASource[channel] = value;
}
void DMAC_DstWrite32(DMAC *dmac, int channel, u32 value)
{
	DMADest[channel] = value;
}


int DMAC_HBlank(DMAC *dmac)
{
	int sum = 0;
	for (int i=0; i<4; i++)
	{
		DMAChan &c = dmac->channels[i];
		if (c.dmaCNT.startTiming == DMATIMING_HBLANK && c.dmaCNT.enable)
		{
			sum += DMAC_DoDMA(dmac,i);
		}
	}
	return sum;
}
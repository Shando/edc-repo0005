#include "stdafx.h"
#include "N_Keypad.h"


void N_Keypad_UpdateKeys(u16 &keyinput)
{
	int key[10] = 
	{
		'Z','X','C','V',VK_RIGHT,VK_LEFT,VK_UP,VK_DOWN,'S','A'
	};
	keyinput = 0x3FF;
	for (int i=0; i<10; i++)
	{
		if (GetAsyncKeyState(key[i]))
		{
			keyinput &= ~(1<<i);
		}
	}
}

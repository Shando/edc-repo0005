#pragma	once

enum EmuFileType
{
	FILETYPE_ERROR,

	FILETYPE_DS_ELF,
	FILETYPE_DS_NDS,
	FILETYPE_DS_BIN9,
	FILETYPE_DS_PASSTHRU,
	FILETYPE_DS_EMPTY,
	FILETYPE_GBA_BIN,
	FILETYPE_GBA_ELF,
	FILETYPE_GBA_EMPTY,
	FILETYPE_GP32_BIN,
	FILETYPE_GP32_EMPTY,

	FILETYPE_PSP_PBP,
	FILETYPE_PSP_ELF,
	FILETYPE_PSP_ISO,

	FILETYPE_UNKNOWN_BIN,
	FILETYPE_UNKNOWN_ELF,

	FILETYPE_UNKNOWN
};

EmuFileType Identify_File(const TCHAR *filename);

u32 Load_ELF(const TCHAR *filename);
void Load_NDS(const TCHAR *filename);
void Load_PBP(const TCHAR *filename);
void Load_ROM(const TCHAR *filename);
u32 Load_BIN(const TCHAR *file, u32 ptr);
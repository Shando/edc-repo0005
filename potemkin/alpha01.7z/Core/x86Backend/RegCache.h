#pragma once

#include "X86.h"

namespace RegCache
{
	//So far only caching integer registers
	//Should do something similar with SSE/sh4fpu i think.

	enum RegisterStatus
	{
		REG_UNCACHED	= 0,
		REG_MAPPED		= 1,
		REG_CONSTANT	= 2,
	};

	//Various regcache constants
	enum 
	{
		TEMPREG = EAX
	};

/*
	u32 *contentsPtrs[] = 
	{
		&MACL,
		&MACR,
		&rGR,
		&rGR_RBANK,
		&FR,
		&XF,
	};
*/
	enum FlagContents
	{
		Nothing,
		T,
		InvT
	};
	enum X86Flag
	{
		FLAG_C=1, FLAG_Z=2, FLAG_V=4, FLAG_S=8, FLAG_ALL = 15 //s=sign
	};
    
	void EatFlags(X86Flag flags);
	void SetFlagContents(X86Flag flag, FlagContents c);

	//public interfaces
	void Start();
	void Stop();

	TX86Regs MapARMReg(int n, bool load = true);
	void UnmapX86Reg(TX86Regs reg, bool store = false);
	void LockX86Reg(TX86Regs reg);
	void UnlockX86Reg(TX86Regs reg);
	void FlushAll();
	void SetDirty(TX86Regs reg);

	FlagContents getCFlag();
	FlagContents getZFlag();
}
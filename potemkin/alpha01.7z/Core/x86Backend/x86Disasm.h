#pragma once

char *disasmx86(BYTE *opcode1,int codeoff1,int *len);

#include "stdafx.h"
#include "../IR/IR.h"
#include "../ARM/ARM.h"
#include "../ARM/ARMAnalyst.h"
#include "IRCompiler.h"
#include "x86.h"

// x86 backend

u8 *curCondJump;

#define JE8 JZ8
#define JNE8 JNZ8
bool inCondition;
void ConditionalTest_Insert(u32 op)
{
	ARMState *currentARM = static_cast<ARMState*>(currentCPU);
	
	inCondition=false;
	curCondJump=0;
	switch(op>>28) {
	case COND_EQ:
		TEST_ImmWithMemory((u32)&currentARM->z,1);
		curCondJump = JE8(0);
		break;
	case COND_NE:
		TEST_ImmWithMemory((u32)&currentARM->z,1);
		curCondJump = JNE8(0);
		break;
	case COND_CS:
		TEST_ImmWithMemory((u32)&currentARM->c,1);
		curCondJump = JE8(0);
		break;
	case COND_CC:
		TEST_ImmWithMemory((u32)&currentARM->c,1);
		curCondJump = JNE8(0);
		break;
	case COND_MI:
		TEST_ImmWithMemory((u32)&currentARM->n,1);
		curCondJump = JE8(0);
		break;
	case COND_PL:
		TEST_ImmWithMemory((u32)&currentARM->n,1);
		curCondJump = JNE8(0);
		break;
	case COND_VS:
		TEST_ImmWithMemory((u32)&currentARM->v,1);
		curCondJump = JE8(0);
		break;
	case COND_VC:
		TEST_ImmWithMemory((u32)&currentARM->v,1);
		curCondJump = JNE8(0);
		break;
	case COND_HI:
		MOV_MemoryToReg(0,EAX,ModRM_disp32,(u32)&currentARM->z);
		XOR_ImmToReg(0,EAX,1,0);
		AND_MemoryToReg(0,EAX,ModRM_disp32,(u32)&currentARM->c);
		curCondJump = JZ8(0);
		break;
	case COND_LS:
		MOV_MemoryToReg(0,EAX,ModRM_disp32,(u32)&currentARM->c);
		OR_ImmToReg(0,EAX,1,0);
		AND_MemoryToReg(0,EAX,ModRM_disp32,(u32)&currentARM->z);
		curCondJump = JZ8(0);
		break;
	case COND_GE:
		MOV_MemoryToReg(0,EAX,ModRM_disp32,(u32)&currentARM->n);
		CMP_RegWithMemory(0,EAX,(u32)&currentARM->v);
		curCondJump = JNE8(0);
		break;
	case COND_LT:
		MOV_MemoryToReg(0,EAX,ModRM_disp32,(u32)&currentARM->n);
		CMP_RegWithMemory(0,EAX,(u32)&currentARM->v);
		curCondJump = JE8(0);
		break;
	case COND_GT:
		_dbg_assert_msg_(CPU,0,"Unimplemented GT");
		//MOV_MemoryToReg(0,EAX,ModRM_disp32,(u32)&currentARM->n);
		//CMP_RegWithMemory(0,EAX,ModRM_disp32,(u32)&currentARM->v);
		//curCondJump = JE8(0);
		break;
	case COND_LE:
		_dbg_assert_msg_(CPU,0,"Unimplemented LE");
		//MOV_MemoryToReg(0,EAX,ModRM_disp32,(u32)&currentARM->n);
		//CMP_RegWithMemory(0,EAX,ModRM_disp32,(u32)&currentARM->v);
		//curCondJump = JE8(0);
		break;
	}
	if (curCondJump!=0)
		inCondition=true;
}
void SetNFlag(InstructionInfo &info)
{
	if (info.flagsOut&FL_N)
	{
		ARMState *currentARM = static_cast<ARMState*>(currentCPU);
		SETcc_Reg(CC_S,EAX);
		MOV_RegToMemory(0,EAX,ModRM_disp32,(u32)&currentARM->n);
	}
}
void SetCFlag(InstructionInfo &info)
{
	if (info.flagsOut&FL_C)
	{
		ARMState *currentARM = static_cast<ARMState*>(currentCPU);
		SETcc_Reg(CC_C,EAX);
		MOV_RegToMemory(0,EAX,ModRM_disp32,(u32)&currentARM->c);
	}
}
void SetVFlag(InstructionInfo &info)
{
	if (info.flagsOut&FL_V)
	{
		ARMState *currentARM = static_cast<ARMState*>(currentCPU);
		SETcc_Reg(CC_O,EAX);
		MOV_RegToMemory(0,EAX,ModRM_disp32,(u32)&currentARM->v);
	}
}
void SetZFlag(InstructionInfo &info)
{
	if (info.flagsOut&FL_Z)
	{
		ARMState *currentARM = static_cast<ARMState*>(currentCPU);
		SETcc_Reg(CC_Z,EAX);
		MOV_RegToMemory(0,EAX,ModRM_disp32,(u32)&currentARM->z);
	}
}

void ConditionalTest_End()
{
	if (inCondition)
		x86SetJ8(curCondJump);
}


typedef void (*CoolOp)(unsigned int, unsigned int, unsigned int, unsigned int);
CoolOp coolops[7]=
{
	ADD_Reg2ToReg1,
	0,//ADC
	SUB_Reg2FromReg1,
	0,//SBC
	AND_Reg2ToReg1,
	OR_Reg2ToReg1,
	XOR_Reg2ToReg1
};


void IR_Compile()
{
	IROp *opptr=IR_First()->next;

	while (opptr)
	{
		IROp &op = *opptr;

		switch(op.op) {
		case IR_ADD:
		case IR_ADC:
		case IR_SUB:
		case IR_SBC:
		case IR_XOR:
		case IR_OR:
		case IR_AND:
			{
				if (!op.in[0].isImmediate && !op.in[1].isImmediate)
				{
					//regular
					if (op.out[0] == op.in[0].reg)
					{
		//				int dest = RegCache::MapARMReg(op.out[0]);
		//				int src = RegCache::MapARMReg(op.in[1].reg);
		//				ADD_Reg2ToReg1(1,dest,src,op.outputFlags?true:false);
					}
					else
					{
						if (op.op == IR_ADD && op.outputFlags==0)
						{
							//special case LEA
						}
						else
						{

						}
					}
				}
				else if (!op.in[0].isImmediate && op.in[1].isImmediate)
				{
					//second immediate - only happens with sub and sbc
		//			MOV_ImmToReg(1,EAX,op.in[1].value,0);
		//			int src = RegCache::MapARMReg(op.in[0].reg);
		//			int dest = RegCache::MapARMReg(op.out[0]);
		//			SUB_Reg2FromReg1(1,EAX,src,1);
					//if ()
				}
				/*
				else if (op.in[0].isImmediate && op.in[1].isImmediate)
				{
					//both constants
					constPool[op.out[0]].isConst=true;
					constPool[op.out[0]].value = op.in[0].value + op.in[1].value;
					//TODO : generate flags
				}*/
			}
			break;
		case IR_MUL:
			{
				if (!op.in[0].isImmediate && !op.in[1].isImmediate)
				{
		//			int src1 = RegCache::MapARMReg(op.in[0].reg);
		//			MOV_Reg2ToReg1(1,EAX,src1);
		///			int src2 = RegCache::MapARMReg(op.in[1].reg);
		//			MUL_EAXWithReg(1,src2);
		//			int dest = RegCache::MapARMReg(op.out[0]);
		//			MOV_Reg2ToReg1(1,dest,EAX);
				}
				else if (!op.in[0].isImmediate && op.in[1].isImmediate)
				{
					//second immediate					
				}
			}
			break;
		case IR_NOT:
		case IR_NEG:
			if (!op.in[0].isImmediate)
			{
				if (op.out[0] == op.in[0].reg)
				{
		//			int src = RegCache::MapARMReg(op.out[0]);
		//			(op.op==IR_NOT?NOT_Reg:NEG_Reg)(1,src);
					//TODO flags
				}
				else
				{
		//			int src = RegCache::MapARMReg(op.in[0].reg);
		//			int dest = RegCache::MapARMReg(op.out[0]);
		//			MOV_Reg2ToReg1(1,dest,src);
		//			(op.op==IR_NOT?NOT_Reg:NEG_Reg)(1,dest);
					//TODO flags
				}
			}
			break;
		case IR_LOADWORD:

			break;
		
		case IR_INTERPRET:
			
			break;

		default:
			_dbg_assert_msg_(CPU,0,"Unknown IR instruction! see log");
			LOG(CPU,"Unknown IR instruction %i encountered",op.op);
			break;
		}
		opptr=opptr->next;
	}
}
//MOV_ImmToMemory(0,ModRM_disp32,(u32)&currentARM->c, shifter_carry_out);

/*
switch (shiftType) 
{
case SHIFT_LSL:
MOV_Reg2ToReg1(1,ECX,_rs);   // ECX = shift
MOV_Reg2ToReg1(1,EAX,_rm);
SHL_RegByCL(1,EAX);          // EAX = rm << rs
arith(1,EAX,_rn,true);
MOV_Reg2ToReg1(1,_rd,EAX);
break;
default:
_dbg_assert_msg_(CPU,0,"Unimplemented reg shift");
break;
}
RegCache::UnlockX86Reg(ECX);*/

/*
MOV_Reg2ToReg1(1,EAX,_rm);
switch(shiftType) 
{
case SHIFT_LSL:	
if (shiftAmt!=0)
SHL_RegByImm(1,EAX,shiftAmt); break;
case SHIFT_LSR: SHR_RegByImm(1,EAX,shiftAmt); break;
case SHIFT_ASR: SAR_RegByImm(1,EAX,shiftAmt); break;
case SHIFT_RORRRX:
if (shiftAmt==0)
;//rrx
else
;//ror
_dbg_assert_msg_(CPU,0,"Unimplemented imm shift");
break;
}
SetCFlag(info);*/
/*
*	
SetNFlag(info);
SetZFlag(info);
*/
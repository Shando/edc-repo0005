#pragma once

#include "../../Globals.h"

#define RECOMPCODE_SIZE		1024 * 1024 * 16
//#define RECOMPCODE_SIZE		65536*16 //tests the recompile buffer by smaller size

enum TX86Regs
{
	CONSTANT = -2, //mapped to a constant ppc gpr
	INVALID_X86 = -1,
	EAX = 0,
	EBX = 3,
	ECX = 1,
	EDX = 2,
	ESI = 6,
	EDI = 7,
	EBP = 5,
	ESP = 4
};
#define DIRTY				1

#define Reg_EAX				0x0
#define Reg_AX				Reg_EAX
#define Reg_AL				Reg_EAX
#define Reg_ECX				0x1
#define Reg_CX				Reg_ECX
#define Reg_CL				Reg_ECX
#define Reg_EDX				0x2
#define Reg_DX				Reg_EDX
#define Reg_DL				Reg_EDX
#define Reg_EBX				0x3
#define Reg_BX				Reg_EBX
#define Reg_BL				Reg_EBX
#define Reg_ESP				0x4
#define Reg_SP				Reg_ESP
#define Reg_AH				Reg_ESP
#define Reg_EBP				0x5
#define Reg_BP				Reg_EBP
#define Reg_CH				Reg_EBP
#define Reg_ESI				0x6
#define Reg_SI				Reg_ESI
#define Reg_DH				Reg_ESI
#define Reg_EDI				0x7
#define Reg_DI				Reg_EDI
#define Reg_BH				Reg_EDI

#define ModRM_EAX			0x0
#define ModRM_EBX			0x3
#define ModRM_ECX			0x1
#define ModRM_EDX			0x2
#define ModRM_SIB			0x4
#define ModRM_disp32		0x5
#define ModRM_EBP			0x5
#define ModRM_ESI			0x6
#define ModRM_EDI			0x7

#define ModRM_disp8_EAX		0x40
#define ModRM_disp8_EBX		0x43
#define ModRM_disp8_ECX		0x41
#define ModRM_disp8_EDX		0x42
#define ModRM_disp8_SIB		0x44
#define ModRM_disp8_EBP		0x45
#define ModRM_disp8_ESI		0x46
#define ModRM_disp8_EDI		0x47

#define ModRM_disp32_EAX	0x80
#define ModRM_disp32_EBX	0x83
#define ModRM_disp32_ECX	0x81
#define ModRM_disp32_EDX	0x82
#define ModRM_disp32_SIB	0x84
#define ModRM_disp32_EBP	0x85
#define ModRM_disp32_ESI	0x86
#define ModRM_disp32_EDI	0x87

/* Condition codes */
#define CC_O			0x0
#define CC_NO			0x1
#define CC_B			0x2
#define CC_C			0x2
#define CC_NAE			CC_B
#define CC_NB			0x3
#define CC_NC			0x3
#define CC_AE			CC_NB
#define CC_E			0x4
#define CC_Z			CC_E
#define CC_NE			0x5
#define CC_NZ			CC_NE
#define CC_BE			0x6
#define CC_NA			CC_BE
#define CC_NBE			0x7
#define CC_A			CC_NBE
#define CC_S			0x8
#define CC_NS			0x9
#define CC_P			0xA
#define CC_PE			CC_P
#define CC_NP			0xB
#define CC_PO			CC_NP
#define CC_L			0xC
#define CC_NGE			CC_L
#define CC_NL			0xD
#define CC_GE			CC_NL
#define CC_LE			0xE
#define CC_NG			CC_LE
#define CC_NLE			0xF
#define CC_G			CC_NLE

#define FORMAT_SINGLE	0
#define FORMAT_QUAD		4



//old ps1 linuxappz functions
void	x86SetPtr(u8 *ptr);
u8*	x86GetPtr();

void x86SetJ8(u8 *j8);
void x86SetJ32(u32 *j32);

void	CALLFunc(u32 func);
void JMPFunc(u32 func);
void	CALL32(u32 to);

u8* JZ8 (u8 to);
u8* JG8 (u8 to);
u8* JB8 (u8 to);
u8* JBE8(u8 to);
u8* JA8 (u8 to);
u8* JAE8(u8 to);
u8* JL8 (u8 to);
u8* JNZ8(u8 to);
u8* JMP8(u8 to);
u8* JNC8(u8 to);
u8* JC8 (u8 to);
u8* JLE8(u8 to);
u8* JGE8(u8 to);

void OR32ItoM(u32 to, u32 from);

void SetTranslator(u8 *Code, u32 Pos, u32 Size);
void SetTarget(u8 bIndex);

void WC16(u32 wValue);
void WC32(u32 dwValue);
void WC8(u32 bValue);

void Dummy2(unsigned int, unsigned int);
void Dummy4(unsigned int, unsigned int, unsigned int, unsigned int);

void ADD_Reg2ToReg1(u32 OperandSize, u32 Reg1, u32 Reg2, u32 FlagsMatter);
void SUB_Reg2FromReg1(u32 OperandSize, u32 Reg1, u32 Reg2, u32 FlagsMatter);
void AND_Reg2ToReg1(u32 OperandSize, u32 Reg1, u32 Reg2, u32 FlagsMatter);
void XOR_Reg2ToReg1(u32 OperandSize, u32 Reg1, u32 Reg2, u32 FlagsMatter);
void OR_Reg2ToReg1(u32 OperandSize, u32 Reg1, u32 Reg2, u32 FlagsMatter);

void ADD_ImmToReg(u32 OperandSize, u32 Reg, u32 Data, u32 PreserveFlags);
void SUB_ImmFromReg(u32 OperandSize, u32 Reg1, u32 Data, u32 PreserveFlags);
void XOR_ImmToReg(u32 OperandSize, u32 Reg, u32 Data, u32 FlagsMatter);
void AND_ImmToReg(u32 OperandSize, u32 Reg, u32 Data, u32 FlagsMatter);

void XOR_ImmToEAX(u8 OperandSize, u32 Data, u32 FlagsMatter);
void AND_ImmToEAX(u32 OperandSize, u32 Data);

void ADD_Imm8sxToReg(u32 OperandSize, u32 Reg, u8 Data);
void SUB_Imm8sxToReg(u32 OperandSize, u32 Reg, u8 Data, int FlagsMatter);
void AND_Imm8sxToReg(u32 OperandSize, u32 Reg, u32 Data);

void AND_Imm8sxToMemory(u32 Data, u32 Address);

void ADD_MemoryToReg(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);
void SUB_MemoryToReg(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);
void AND_MemoryToReg(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);
void XOR_MemoryToReg(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);
void OR_MemoryToReg(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);

void ADD_ImmToMemory(u32 Address, u32 Data);
void XOR_ImmToMemory(u32 Address, u32 Data);
void SUB_ImmToMemory(u32 Address, u32 Data);
void AND_ImmToMemory(u32 Address, u32 Data);
void OR_ImmToMemory(u32 Address, u32 Data);

void XOR_ShortToReg(u8 OperandSize, u8 Reg, u8 Data);


void TEST_ImmToEAX(u32 OperandSize, u32 Data);
void TEST_ImmToReg(u32 OperandSize, u32 Reg, u32 Data);
void TEST_ImmWithMemory(u32 dwAddress, u32 Value);
void TEST_EAXWithImm(u8 OperandSize, u32 dwAddress);
void TEST_EAXWithEAX();
void TEST_Reg2WithReg1(u8 OperandSize, u8 Reg1, u8 Reg2);
void TEST_RegWithImm(u8 OperandSize, u8 iReg, u32 Data);

void ROL_RegByImm(u32 OperandSize, u32 Reg, u32 Data, u32 FlagsMatter);

void SAR_RegByImm(u32 OperandSize, u32 Reg, u32 Data);
void SAR_RegByCL(u32 OperandSize, u32 Reg);
void SAR_RegBy1(u8 OperandSize, u8 Reg);

void SHL_RegByImm(u32 OperandSize, u32 Reg, u32 Data);
void SHL_RegByCL(u32 OperandSize, u32 Reg);

void SHR_RegBy1(u32 OperandSize, u32 Reg);
void SHR_RegByImm(u32 OperandSize, u32 Reg, u32 Data);
void SHR_RegByCL(u32 OperandSize, u32 Reg);

void SBB_Reg2FromReg1(u32 OperandSize, u32 Reg1, u32 Reg2);

void XCHG_Reg1WithReg2(u8 OperandSize, u8 Reg1, u8 Reg2);

void CMP_Reg1WithReg2(u32 OperandSize, u32 Reg1, u32 Reg2);
void CMP_Reg2WithReg1(u32 OperandSize, u32 Reg1, u32 Reg2);
void CMP_EAXWithImm(u32 OperandSize, u32 Data);
void CMP_RegWithImm(u32 OperandSize, u32 Reg, u32 Data);
void CMP_RegWithShort(u32 OperandSize, u32 Reg, u32 Data);
void CMP_MemoryWithImm(u32 OperandSize, u32 dwAddress, u32 Data);
void CMP_RegWithMemory(u32 OperandSize, u32 Reg, u32 dwAddress);
void CMP_sImm8WithReg(u32 OperandSize, u32 Reg, u32 Data);

void INC_Reg(u32 OperandSize, u32 Reg);
void DEC_Reg(u32 OperandSize, u32 Reg);

void IDIV_EAXWithReg(u8 OperandSize, u8 Reg);
void DIV_EAXWithReg(u32 OperandSize, u32 Reg);
void CDQ();

void MUL_EAXWithReg(u32 OperandSize, u32 Reg);
void MUL_EAXWithMemory(u32 OperandSize, u32 Address);
void IMUL_EAXWithReg(u32 OperandSize, u32 Reg);
void IMUL_EAXWithMemory(u32 OperandSize, u32 Address);
void IMUL32_ImmWithReg(u32 OperandSize, u32 Reg, u32 Immediate, u32 FlagsMatter);

void LEA(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);

void NOT_Reg(u32 OperandSize, u32 Reg);

void NEG_Reg(u32 OperandSize, u32 Reg);

void NOP();

void OR_ImmToEAX(u32 OperandSize, u32 Data);
void OR_ImmToReg(u32 OperandSize, u32 Reg, u32 Data, u32 FlagsMatter);
void OR_ShortToReg(u32 OperandSize, u32 Reg, u32 Data);
void OR_RegToMemory(u8 OperandSize, u8 Reg, u8 ModRM, u32 Address);


void LAHF();
void SETcc_Reg(u32 ConditionCode, u32 Reg);
void SETcc_ToMemory(u32 ConditionCode, u32 Address);
void SAHF();
void CMC();

void INT3();



void X86_CALL(u32 dwAddress);
void CALL_Reg(u32 Reg);




// F
void FABS();
void FLD1();
void FADD_Memory(u32 OperandSize, u32 dwAddress);
void FCOMP_Memory(u8 OperandSize, u32 dwAddress);
void FCOMIP(int i);
void FUCOMIP(int i);
void FNSTSW();
void FDIV_Memory(u8 OperandSize, u32 dwAddress);
void FILD_Memory(u8 OperandSize, u32 dwAddress);
void FISTP_Memory(u8 OperandSize, u32 dwAddress);
void FLD_Memory(u8 OperandSize, u32 dwAddress);
void FLDCW_Memory(u32 dwAddress);
void FMUL_Memory(u8 OperandSize, u32 dwAddress);
void FNEG();
void FDIVP();
void FRNDINT();
void FSQRT();
void FTEST();
void FCMOVB(int i);
void FFREEP();
void FSTP_Memory(u8 OperandSize, u32 dwAddress);
void FST_Memory(u8 OperandSize, u32 dwAddress);
void FSUB_Memory(u8 OperandSize, u32 dwAddress);

void Jcc(u8 ConditionCode, u8 Offset);
void Jcc_auto(u8 ConditionCode, u32 Index);
int	Jcc_Near(u8 ConditionCode, u32 dwAddress);
void Jcc_Near_auto(u8 ConditionCode, u32 Index);
void JMP_Short(u8 Offset);
void JMP_Short_auto(u32 Index);
void JMP_FAR(u32 dwAddress);
void JMP_Long(u32 dwAddress);
void MOV_Reg2ToReg1(u32 OperandSize, u32 Reg1, u32 Reg2);
void MOV_MemoryToReg(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);
void MOV_ModRMToReg(u32 OperandSize, u32 Reg, u32 ModRM);
void MOV_RegToModRM(u32 OperandSize, u32 Reg, u32 ModRM);
void MOV_MemoryToEAX(u32 OperandSize, u32 Address);
void MOV_RegToMemory(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);
void MOV_EAXToMemory(u32 OperandSize, u32 Address);
void MOV_ImmToReg(u32 OperandSize, u32 Reg, u32 Data, u32 PreserveFlags);
void MOV_ImmToMemory(u8 OperandSize, u8 ModRM, u32 Address, u32 Data);

void MOVSX_MemoryToReg(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);
void MOVZX_MemoryToReg(u32 OperandSize, u32 Reg, u32 ModRM, u32 Address);
void MOVSX_B_Reg2ToReg1(int xreg, int lreg);
void MOVZX_B_Reg2ToReg1(int xreg, int lreg);

void MOVSX_W_Reg2ToReg1(int xreg, int lreg);
void MOVZX_W_Reg2ToReg1(int xreg, int lreg);


void POP_RegFromStack(u32 Reg);
void PUSH_RegToStack(u32 Reg);
void PUSH_WordToStack(unsigned __int32 wWord);
void PUSHF();
void POPF();
void PUSHA();
void PUSHAD();
void POPA();
void POPAD();
void PushMap();
void PopMap();
void RET();

void MOVSS_XMMReg1ToXMMReg2(DWORD Reg1, DWORD Reg2);
void MOVSS_MemoryToXMMReg(DWORD Reg, u32 Address);
void MOVSS_XMMRegToMemory(DWORD Reg, u32 Address);

void MOVSS_ModRM_RegToXMMReg(DWORD RegXMM, DWORD RegX86);
void MOVSS_XMMRegToModRM_Reg(DWORD RegXMM, DWORD RegX86);

void MOVD_XMMToReg(DWORD xmm, DWORD Reg);
void MOVD_RegToXMM(DWORD Reg, DWORD xmm);

void MOVD_XMMToMemory(DWORD Reg, DWORD ModRM, u32 Address);
void MOVD_MemoryToXMM(DWORD Reg, DWORD ModRM, u32 Address);

void MOVSS_XMMToMemory(DWORD Reg, DWORD ModRM, u32 Address);
void MOVSS_MemoryToXMM(DWORD Reg, DWORD ModRM, u32 Address);

void MOVLPS_XMMToMemory(DWORD Reg, DWORD ModRM, u32 Address);
void MOVLPS_MemoryToXMM(DWORD Reg, DWORD ModRM, u32 Address);

void MOVAPS_MemoryToXMM(DWORD Reg, DWORD ModRM, u32 Address);
void MOVAPS_XMMToMemory(DWORD Reg, DWORD ModRM, u32 Address);
void MOVAPS_XMMReg1ToXMMReg2(DWORD Reg1, DWORD Reg2);
void MULPS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void MULPS_MemoryToXMMReg(DWORD Reg1, u32 Address);
void SHUFPS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2, DWORD uMask);
void ADDPS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void MOVHLPS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void MOVLHPS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);


void ADDSS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void ADDSS_MemoryToXMMReg(DWORD Reg1, DWORD Reg2);
void SUBSS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void SUBSS_MemoryToXMMReg(DWORD Reg1, DWORD Reg2);
void DIVSS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void DIVSS_MemoryToXMMReg(DWORD Reg1, DWORD Reg2);
void MULSS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void MULSS_MemoryToXMMReg(DWORD Reg1, u32 Address);
void RSQRTSS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void RSQRTSS_MemoryToXMMReg(DWORD Reg, u32 Address);
void SQRTSS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void SQRTSS_MemoryToXMMReg(DWORD Reg, u32 Address);
void UCOMISS_XMMReg2WithXMMReg1(DWORD Reg1, DWORD Reg2);
void UCOMISS_MemoryWithXMMReg(DWORD Reg, u32 Address);
void ANDPS_MemoryToXMMReg(DWORD Reg, u32 Address);
void XORPS_MemoryToXMMReg(DWORD Reg, u32 Address);
void CVTSI2SS_MemoryToXMMReg(DWORD Reg, u32 Address);
void RCPSS_XMMReg2ToXMMReg1(DWORD Reg1, DWORD Reg2);
void CVTSS2SI_XMMRegToX86Reg(DWORD RegXMM, DWORD RegX86);
void CVTTSS2SI_XMMRegToX86Reg(DWORD RegXMM, DWORD RegX86);
void CVTTSS2SI_MemoryToX86Reg(u32 Address, DWORD RegX86);


void PREFETCHT0_Memory(u32 Address);
void PREFETCHT0_IReg(DWORD uReg);

void	SetNearTarget(u8 bIndex);

/* Encoders */
void	Encode_Slash_R(u32 Reg, u32 ModRM, u32 Address);

// CMOVcc is for Pentium Pro and above
void CMOVcc_Reg2ToReg1(u8 ConditionCode, u8 Reg1, u8 Reg2);

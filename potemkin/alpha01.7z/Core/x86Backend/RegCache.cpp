#include "stdafx.h"	
#include "ARM.h"
#include "RegCache.h"
#include "ARMCompiler.h"


// Simple register caching
// TODO: Immediate Catching to find writes (MOVLI)
//       All accesses go to RAM, n first times run? recompile block with that assumption

namespace RegCache
{
	FlagContents flagc[4];

#define NUMREGS 8
#define NUMFLAGS 4
	struct CachedXReg 
	{
		int shReg;
		int mapTime;
		bool mapped;
		bool locked;
		bool dirty;
		RegisterStatus status;
		u32 value; //if immediate
		void pullData(TX86Regs xreg);
		void flush();
	};

	CachedXReg regs[NUMREGS];

#define NUMMAPPABLEREGS 5

	TX86Regs regOrder[NUMMAPPABLEREGS] = 
	{
		EBX,ESI,EDI,EDX,ECX             //prefer to put in regs we rarely need to lock
	};

	void LoadARMToX86(int armreg, TX86Regs reg)
	{
		MOV_MemoryToReg(1,reg,ModRM_disp32,((u32)currentARM->r)+4*armreg);
	}
	void StoreX86ToARMfile(TX86Regs reg, int armreg)
	{
		MOV_RegToMemory(1,reg,ModRM_disp32,((u32)currentARM->r)+4*armreg);
	}

	void FlushX86Reg(TX86Regs reg)
	{
		if (regs[reg].locked)
		{
			MessageBox(0,"Trying to flush a locked reg? Something strange is going on ..",0,0);
			//CPU_Halt("Trying to flush a locked reg? Something strange is going on ..");
			return;
		}
		if (!regs[reg].mapped)
		{
			return;
		}
		if (regs[reg].dirty)
		{
			StoreX86ToARMfile(reg,regs[reg].shReg);
			regs[reg].dirty = false;
		}
		regs[reg].mapped = false;
	}

	void FlushARMReg(int reg)
	{
		//CPU_Halt("Unimplemented");
		/*
		 *	
		 for (int i=0; i<NUMMAPPABLEREGS; i++)
		 {
			if (regs[regOrder[i]].mapped && regs[regOrder[i]].shReg = reg)
			{
			 . ...
			}
		 }
		 */
	}

	void FlushAll()
	{
		EatFlags(FLAG_ALL);
		for (int i=0; i<NUMMAPPABLEREGS; i++)
			FlushX86Reg(regOrder[i]);
	}


	TX86Regs FindFreeReg()
	{
		//search, and find oldest at the same time
		int oldestMapTime = 0x7fffffff;
		TX86Regs oldestReg = (TX86Regs)-1;
		for (int i=0; i<NUMMAPPABLEREGS; i++)
		{
			TX86Regs r = regOrder[i];
			if (!regs[r].mapped) //if unmapped, then we'll just use it
				return r;
			if (!regs[r].locked) 
			{
				if (regs[r].mapTime < oldestMapTime)
				{
					oldestReg = r;
					oldestMapTime = regs[r].mapTime;
				}
			}
		}
		// no free reg found, let's flush the oldest
		if (oldestReg != (TX86Regs)-1)
		{
			//we have to flush it..
			FlushX86Reg(oldestReg);
			return oldestReg;
		}
		else
		{
			// WE ARE IN TROUBLE
			MessageBox(0,"RAN OUT OF REGS, HELP!!!",0,0);
			//CPU_Halt("Dynarec regalloc ran out of registers! This shouldn't happen!");
			return EAX;
		}
	}

	int CompilerGetInstructionCount()
	{
		static int i=0;
		return i++;
	}
	TX86Regs MapARMReg(int n, bool load /*= true*/)
	{
		for (int i=0; i<NUMMAPPABLEREGS; i++)
		{
			TX86Regs reg = regOrder[i];
			if (regs[reg].mapped == true && regs[reg].shReg == n)
				return reg;
		}
		//Not found in cache, so:
		TX86Regs reg     = FindFreeReg();
		regs[reg].mapped = true;
		regs[reg].shReg  = n;
		regs[reg].dirty  = false;
		regs[reg].mapTime = CompilerGetInstructionCount();

		if (load)
			LoadARMToX86(n,reg);
		return reg;
	}

	void UnmapX86Reg(TX86Regs reg, bool store /*= false*/)
	{
		if (regs[reg].dirty && store)
			StoreX86ToARMfile(reg,regs[reg].shReg);
		regs[reg].mapped=false;
		regs[reg].dirty = false;
	}

	void UnmapARMReg(int s)
	{
		for (int i=0; i<NUMMAPPABLEREGS; i++)
		{
			TX86Regs reg = regOrder[i];
			if (regs[reg].mapped == true && regs[reg].shReg == s)
			{
				FlushX86Reg(reg);
				break;
			}
		}
	}

	//todo: add a forced reg as parameter
	void LockX86Reg(TX86Regs reg)
	{
		FlushX86Reg(reg);
		regs[reg].locked=true;
		regs[reg].dirty=false;
	}

	void UnlockX86Reg(TX86Regs reg)
	{
		if (regs[reg].dirty)
			//CPU_Halt("Trying to unlock dirty register");
			;
		if (regs[reg].mapped)
			//CPU_Halt("Trying to unlock mapped register");
			;
		regs[reg].locked=false;
	}

	void SetDirty(TX86Regs reg)
	{
		if (regs[reg].mapped)
			regs[reg].dirty = true;
		else
			//CPU_Halt("Trying to dirty a non-mapped register");
			;
	}

	void Start()
	{
		for (int i=0; i<NUMREGS; i++)
		{
			regs[i].locked = false;
			regs[i].mapped = false;
			regs[i].dirty = false;
		}
		
		// why lock, mappableregs will fix it anyway
		regs[Reg_EAX].locked = true; // used for temps
		regs[Reg_ESP].locked = true; // stack - dangerous
		regs[Reg_EBP].locked = true; // base pointer - dangerous for now ?
		
		for (int i=0; i<NUMFLAGS; i++)
		{
			flagc[i] = Nothing;
		}
	}

	void Stop()
	{
		FlushAll();
	}


	void EatFlags(X86Flag flags)
	{

	}
	void SetFlagContents(X86Flag flag, FlagContents c)
	{

	}
}

#include "stdafx.h"
#include "Host.h"

Host *host;
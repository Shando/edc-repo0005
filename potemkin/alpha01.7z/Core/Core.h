#pragma once

#include "../Globals.h"




// called from emu thread
void Core_Init(EmuMode mode, TCHAR *file);
void Core_Run();
void Core_Pause();
void Core_Stop();
void Core_Shutdown();
void Core_ErrorPause();
void Core_CmdLine(TCHAR *text);
// called from gui
void Core_EnableStepping(bool step);
void Core_DoSingleStep();

inline void Core_Halt(TCHAR *msg) 
{
	Core_EnableStepping(true);
	_dbg_update_();
	LOG(CPU, "CPU HALTED : %s",msg);
}

bool Core_IsStepping();

enum CoreState
{
	CORE_RUNNING,
	CORE_RUNNINGDEBUG,
	CORE_STEPPING,
	CORE_POWERDOWN,
	CORE_ERROR
};


extern volatile CoreState coreState;



#include "stdafx.h"

#include "../../Globals.h"
#include "DSLoaders.h"

#include "../ARM/ARM.h"
#include "../Loaders.h"

#include "NitroROM.h"

void Load_DSELF(const TCHAR *filename)
{
//	std::ifstream in(filename,std::ios::binary);
//	u32 entry = Load_ELF(in);

//	arm9.r[ARM_REG_PC] = entry;
	arm7.r[ARM_REG_PC] = 0x23f0000;
	arm7.enabled=false;
	WriteMem32(0x23f0000, 0xEAFFFFFE);  //let arm7 sit and branch to itself, moaaha :P
}



void Load_DSBIN9(const TCHAR *filename)
{
	u32 entry = Load_BIN(filename,0x02004000);

	arm9.r[ARM_REG_PC] = entry;
	arm7.r[ARM_REG_PC] = 0x23f0000;
	arm7.enabled=false;

	WriteMem32(0x23f0000, 0xEAFFFFFE);  //let arm7 sit and branch to itself, moaaha :P
}


void Load_DSEmpty()
{
	arm7.r[ARM_REG_PC] = 0x23f0000;

	WriteMem32(0x23f0000, 0xEAFFFFFE);  //let arm7 sit and branch to itself, moaaha :P
}


void Load_NDS(const TCHAR *filename)
{
	FILE *file = fopen(filename,"rb");
	fseek(file,0,SEEK_END);
	int size = ftell(file);
	fseek(file,0,SEEK_SET);


	NitroROMHeader header;
	fread(&header,sizeof(NitroROMHeader),1,file);

	const int headerSize = 0;


	u8 *memptr = arm9.memMap.GetMemPointer(0x02000000);

	//header.main_rom_offset=0;


	arm9.r[ARM_REG_PC] = header.arm9_entry_address;
	arm7.r[ARM_REG_PC] = header.arm7_entry_address;

	LOG(ROM,"Loading ARM9 code: %08x -> %08x, %08x (%d) bytes",
		header.arm9_rom_offset, header.arm9_ram_address, header.arm9_size,  header.arm9_size);
	LOG(ROM,"Loading ARM7 code: %08x -> %08x, %08x (%d) bytes",
		header.arm7_rom_offset, header.arm7_ram_address, header.arm7_size, header.arm7_size);

	LOG(ROM,"ARM9 entry: %08x    ARM7 entry: %08x", header.arm9_entry_address, header.arm7_entry_address);

	//header.arm9_rom_offset=0;
	//header.arm9_size = 0x2000;
	fseek(file, header.arm9_rom_offset + headerSize, SEEK_SET);
	fread(memptr + header.arm9_ram_address - 0x02000000, header.arm9_size, 1, file);

	fseek(file, header.arm7_rom_offset + headerSize, SEEK_SET);
	header.arm7_size = 0x2000;
	fread(memptr + header.arm7_ram_address - 0x02000000, header.arm7_size, 1, file);

	fclose(file);
}



void Load_NDS_PassThru(const TCHAR *filename)
{
	FILE *file = fopen(filename,"rb");
	fseek(file,0,SEEK_END);
	int size = ftell(file);
	fseek(file,0,SEEK_SET);

	u8 *memptr = arm9.memMap.GetMemPointer(0x08000000);


	arm7.r[ARM_REG_PC] = 0x08000000;
	arm9.r[ARM_REG_PC] = 0x20048A0;
	WriteMem32(0x20048A0, 0xEAFFFFFE);  //let arm9 sit and branch to itself, moaaha :P

	arm9.SetCPSR(0xc0);
	//header.arm9_rom_offset=0;
	//header.arm9_size = 0x2000;
	fread(memptr, size, 1, file);
	fclose(file);
}


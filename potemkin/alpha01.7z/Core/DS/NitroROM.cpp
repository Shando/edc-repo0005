#include "stdafx.h"
#include "NitroROM.h"

static FILE *ndsFile = 0;

void NDSTool_OpenROM(TCHAR *filename)
{
	ndsFile = fopen(filename,"rb");


}

void NDSTool_CloseROM()
{
	fclose(ndsFile);
}

//does not work correctly yet
void NDSTool_ExtractIcon(u32 *dest)
{
	NitroROMHeader hdr;
	fseek(ndsFile,0,SEEK_SET);
	fread(&hdr,sizeof(hdr),1,ndsFile);

	fseek(ndsFile,hdr.icon_title_offset,SEEK_SET);
	u8 icondata[NDS_ICON_WIDTH*NDS_ICON_HEIGHT/2];
	fread(icondata,NDS_ICON_WIDTH*NDS_ICON_HEIGHT/2,1,ndsFile);

	for (int y=0; y<32; y++)
	{
		for (int x=0; x<32; x++)
		{
			dest[y*32+x] = ((icondata[(y*32+x)/2] >> ((x&1) * 4))&0xF)*16;
		}
	}
}
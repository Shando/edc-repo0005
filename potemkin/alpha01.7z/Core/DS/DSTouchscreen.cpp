#include "stdafx.h"
#include "DSTouchscreen.h"

#include "../../Globals.h"


void DSTouchWrite(u32 value)
{

}
#pragma once

#include "../MemMap.h"

#include "../Shared/N_DMA.h"

#include "DSIOCommon.h"

void DS7IO_SelfTest();
void DS7IO_Init();

u8   MEMDECL ReadDS7IO8 (u32 address);
u16  MEMDECL ReadDS7IO16(u32 address);
u32  MEMDECL ReadDS7IO32(u32 address);
u32  MEMDECL ReadDS7IONoEffect(u32 address);
TCHAR* MEMDECL GetDS7IORegName(u32 address);

void MEMDECL WriteDS7IO8 (u32 address, u8  value);
void MEMDECL WriteDS7IO16(u32 address, u16 value);
void MEMDECL WriteDS7IO32(u32 address, u32 value);



struct DS7IORegion
{
	u32 dispcnt;
	u32 dispmojs;
//	G2 gfxregs1;
	//0x56
	u32 unused1[3];
	//0x60
	u16 disp3dCNT;
	u16 unused2;
	u32 unused3[(0xb0-0x64) / 4];
	//0xb0 - DMAC
	DMAC dmac;
	u32 unused4[7];
	u32 unused5[(0x280-0x100)/4];
	//0x280
	//0x320
//	G3X2 gfx3d;

	//0x400 16 Sound channels here
  //0x500 Sound master here, and capture

	u32 gxFifoFiller[16];


	//TODO add filler here
//	G2 gfxregs2;
};


extern DS7IORegion ds7IO;
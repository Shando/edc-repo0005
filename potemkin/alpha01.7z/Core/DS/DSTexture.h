#pragma once

#include "../../Globals.h"

enum TexFmt
{
	TF_NONE,
	TF_PALETTE_2BIT,
	TF_A3I5,
	TF_PALETTE_4BIT,
	TF_PALETTE_8BIT,
	TF_COMPRESSED_4X4,
	TF_A5I3,
	TF_DIRECT   //16-bit a1r5g5b5 ?
};

void TextureDecoder_Init();
void TextureDecoder_Decode(u8 *dataptr, int format, int usize, int vsize);
void TextureDecoder_Shutdown();

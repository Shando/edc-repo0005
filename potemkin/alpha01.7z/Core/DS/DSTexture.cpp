#include "stdafx.h"

/*
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glext.h>
*/

#include "DSDisplay.h"
#include "DSTexture.h"

u16 lut_a3i5[256];
u16 lut_a5i3[256];

void TextureDecoder_Init()
{
	for (int i=0; i<255; i++)
	{
		int alpha = (int)((float(i>>5)/7.0f)*255.0f);
		int intensity = (int)((float(i&0x1F)/31.0f)*255.0f);
		lut_a3i5[i] = (alpha<<8) | intensity;

		alpha = (int)((float(i>>3)/31.0f)*255.0f);
		intensity = (int)((float(i&0x7)/7.0f)*255.0f);
		lut_a5i3[i] = (alpha<<8) | intensity;
	}
}

void TextureDecoder_Shutdown()
{

}

void TextureDecoder_Decode(u8 *dataptr, int format, int usize, int vsize)
{
	switch (format) 
	{
	case TF_NONE:
		LOG(G3D,"ERROR: Trying to decode a texture with format 0");
		break;
	case TF_PALETTE_2BIT:
		break;
	case TF_PALETTE_4BIT:
		break;
	case TF_PALETTE_8BIT:
		break;

	case TF_A3I5:
		break;

	case TF_A5I3:
		break;

	case TF_COMPRESSED_4X4:
		LOG(G3D,"Compressed textures are unsupported :(");
		break;

	case TF_DIRECT:
		break;
	}
}

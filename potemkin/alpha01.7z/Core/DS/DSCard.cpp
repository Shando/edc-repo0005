#include "stdafx.h"

#include "DSCard.h"


void DSCardWriteCR1(u32 value)
{
	int enable = value & 0x8000;
	int irq = value & 0x4000;
}

void DSCardWriteCR2(u32 value)
{
	int transferSize = value & 0xFFF;
	int encrypt      = value & 0x4000;
	int someLength   = (value >>16) & 0x1F;
	int commandType  = value & 0x40000000;
	int enable       = value & 0x80000000;
}

u32 DSCardReadCR1()
{
	u32 value = 0;
	return value;
}

u32 DSCardReadCR2()
{
	u32 value = 0;
	return value;
}
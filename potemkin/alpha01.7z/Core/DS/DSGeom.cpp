#include "stdafx.h"
#include "../../Globals.h"
#include "DSGeom.h"

//matrices : 4096==1.0f  so 1.19.12 bit fixed point
//internal matrix operations will be done in floating point
//to maximize precision and performance. may even get rid of 
//jittering seen on the real DS


inline float Fix2F(int f)
{
	return (float)(f) * (1.0f/4096.0f);
}



Matrix worldstack[32];
Matrix vectorstack[32];

Matrix texturestack[32];

Matrix projection[2];

int worldstackptr;
int vectorstackptr;
int texturestackptr;

int stackPtr;
int stackSize;

Matrix *stack = worldstack;


void Geom_Push()
{
	stack[stackPtr+1] = stack[stackPtr];
	stackPtr++;
}


void Geom_Pop(int offset)
{
	// should Pop(offset==0) do stackPtr=0 ?
	stackPtr-=offset;
}


void Geom_Store(int i)
{
	stack[i] = stack[stackPtr];
}


void Geom_Restore(int i)
{
	stack[stackPtr] = stack[i];
}


void Geom_MtxIdentity()
{
	return;
	Matrix &mat = stack[stackPtr];

	for (int y=0; y<4; y++)
		for (int x=0; x<4; x++)
			mat.m[y*4+x] = (x==y) ? 1.0f : 0.0f;
}


void Geom_MtxLoad4x4(u32 *entries)
{
	return;
	Matrix &mat = stack[stackPtr];

	for (int y=0; y<4; y++)
		for (int x=0; x<4; x++)
			mat.m[y*4+x] = Fix2F(*entries++);
	
	
}


void Geom_MtxLoad4x3(u32 *entries)
{
	return;
	Matrix &mat = stack[stackPtr];

	for (int y=0; y<4; y++)
		for (int x=0; x<3; x++)
			mat.m[y*4+x] = Fix2F(*entries++);

	mat._03 = 0.0f;
	mat._13 = 0.0f;
	mat._23 = 0.0f;
	mat._33 = 1.0f;
}

void Geom_MtxMult3x3(u32 *entries)
{
}

void Geom_MtxMult4x3(u32 *entries)
{

}

void Geom_MtxMult4x4(u32 *entries)
{

}

void Geom_MtxTrans(u32 *entries)
{ 
	
}

void Geom_MtxScale(u32 *entries)
{ 

}

void Geom_MtxMode(int mode)
{

}


#pragma once

#include "../../Globals.h"

void DSCardWriteCR1(u32 value);
void DSCardWriteCR2(u32 value);

u32 DSCardReadCR1();
u32 DSCardReadCR2();
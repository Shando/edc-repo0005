#pragma once

#include "../../Globals.h"

extern const int DSFifoNumParameters[0x80];

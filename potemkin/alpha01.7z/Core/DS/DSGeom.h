#pragma once

struct Matrix
{
	union
	{
		float m[16];
		struct 
		{
			float _00,_01,_02,_03;
			float _10,_11,_12,_13;
			float _20,_21,_22,_23;
			float _30,_31,_32,_33;
		};
	};

};



struct Vector
{
	union 
	{
		struct {float x,y,z;};
		struct {float v[3];};
	};
};


void Geom_Push();
void Geom_Pop(int offset);
void Geom_Store(int i);
void Geom_Restore(int i);
void Geom_MtxIdentity();
void Geom_MtxLoad4x4(u32 *entries);
void Geom_MtxLoad4x3(u32 *entries);
void Geom_MtxMult4x4(u32 *entries);
void Geom_MtxMult4x3(u32 *entries);
void Geom_MtxMult3x3(u32 *entries);
void Geom_MtxTrans(u32 *entries);
void Geom_MtxScale(u32 *entries);
void Geom_MtxMode(int mode);

Matrix Geom_GetCurWorldMtx();
Matrix Geom_GetCurProjMtx();
Matrix Geom_GetCurTexMtx();
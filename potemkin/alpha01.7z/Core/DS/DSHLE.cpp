#include "stdafx.h"
#include "DSHLE.h"
#include "../MemMap.h"
#include "../ARM/ARM.h"

#define PARAM(n) ((ARMState*)currentCPU)->r[n]

#define HLEDECL __cdecl

typedef void (*TPatchFunction)();
struct Patch
{
	char m_szPatchName[128];	
	TPatchFunction PatchFunction;
};

// TODO: optimize for source-is-pointer case
void HLEDECL DS_HLE_memcpy()
{
	u32 dest = PARAM(0), source=PARAM(1), count=PARAM(2);

	u8 *s = GetMemPointer(source);
	u8 *d = GetMemPointer(dest);
	if (source && dest)
	{
		memcpy(d,s,count);
	}
	/*
	 *	else if (source) { }
	 */
	else
	{
		if ((count & 3) == 0)
		{
			count >>= 2;
			while (count--)
			{
				WriteMem32(dest,ReadMem32(source));
				source+=4;
				dest+=4;
			}
		}
		else if ((count & 1) == 0)
		{
			count >>= 1;
			while (count--)
			{
				WriteMem16(dest,ReadMem16(source));
				source+=2;
				dest+=2;
			}
		}
		else 
		{
			while (count--)
			{
				WriteMem8(dest,ReadMem8(source));
				source++;
				dest++;
			}
		}
	}
}


void HLEDECL DS_HLE_MTX_Concat33()
{

}

void HLEDECL DS_HLE_MTX_Concat43()
{

}

void HLEDECL DS_HLE_MTX_Concat44()
{

}

void HLEDECL DS_HLE_MTX_Identity44()
{
	u32 ptr = PARAM(0);
	u32 *p = (u32 *)GetMemPointer(ptr);
	_dbg_assert_msg_(HLE,p!=0,"Trying to identity a matrix in non-pointer memory");
	*p++=0x1000; *p++=0; *p++=0; *p++=0;
	*p++=0; *p++=0x1000; *p++=0; *p++=0;
	*p++=0; *p++=0; *p++=0x1000; *p++=0;
	*p++=0; *p++=0; *p++=0; *p++=0x1000; 
	//common to all HLE funcs
}

void HLEDECL DS_HLE_MTX_Identity43()
{
	u32 ptr = PARAM(0);
	u32 *p = (u32 *)GetMemPointer(ptr);
	_dbg_assert_msg_(HLE,p!=0,"Trying to identity a matrix in non-pointer memory");
	*p++=0x1000; *p++=0; *p++=0; 
	*p++=0; *p++=0x1000; *p++=0; 
	*p++=0; *p++=0; *p++=0x1000; 
	*p++=0; *p++=0; *p++=0;
	//common to all HLE funcs
}

void HLEDECL DS_HLE_MTX_MultVec43()
{

}


void HLEDECL DS_HLE_RotAxis33()
{

}

void HLEDECL DS_HLE_FX_GetDivResult()
{

}

void HLEDECL DS_HLE_FX_GetDivResult64()
{

}


Patch DS_HLE_Patches[] = 
{
	{"memcpy", DS_HLE_memcpy},
	{"MTX_Identity43", DS_HLE_MTX_Identity43},
	{"MTX_Identity44", DS_HLE_MTX_Identity44},
};


void __cdecl CallHLEFunc(int index)
{
	//currentARM->r[ARM_REG_PC] = currentARM->r[ARM_REG_LR];
}




void DS_HLE_ARM9SWI(int number)
{
	/*
	switch (number) {
	case :
		break;
	case :
		break;
	default:
	}*/
}

void DS_HLE_ARM7SWI(int number)
{

}
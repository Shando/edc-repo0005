
#pragma once


void Load_DSELF(const TCHAR *filename);
void Load_DSBIN9(const TCHAR *filename);
void Load_DSEmpty();
void Load_NDS(const TCHAR *filename);
void Load_NDS_PassThru(const TCHAR *filename);




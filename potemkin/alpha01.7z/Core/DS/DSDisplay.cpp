#include "stdafx.h"

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glext.h>

#include "DSDisplay.h"

#include "../Graphics/G2D.h"
#include "../Host.h"

static GLuint backbufTex[2];

void DSDisplay_Init()
{
	glPolygonMode (GL_FRONT_AND_BACK, GL_FILL);
	
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);

	glShadeModel(GL_SMOOTH);

	glEnable(GL_TEXTURE_2D);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	

	glGenTextures(2,backbufTex);

	//initialize lights
	for (int i=0; i<4; i++)
	{
		float ones[4]={1,1,1,1};
		float zeros[4]={0,0,0,1};
		glLightfv(i,GL_DIFFUSE,ones);
		glLightfv(i,GL_AMBIENT,zeros);
		glLightfv(i,GL_SPECULAR,ones);
		glDisable(GL_LIGHT0+i);
	}

	//initialize backbuffer textures
	for (int i=0; i<2; i++)
	{
		glBindTexture(GL_TEXTURE_2D,backbufTex[i]);
		glPixelStorei(GL_UNPACK_ALIGNMENT,1);
		glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
 		glTexImage2D(GL_TEXTURE_2D,0,GL_RGB5_A1,256,256,0, GL_RGBA,GL_UNSIGNED_SHORT_1_5_5_5_REV,0);
	}
	//gluBuild2DMipmaps(GL_TEXTURE_2D,GL_RGB5_A1,256,128,GL_RDS,GL_UNSIGNED_BYTE,g2dCores[0].GetPointer());
	//(GL_TEXTURE_2D,0,3,128,128,0,GL_BGR_EXT,GL_UNSIGNED_BYTE,g2dCores[0].GetPointer());
}

void DSDisplay_Draw()
{
	host->BeginFrame();

	glClearColor(1,0,1,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_TEXTURE_2D);

	glColor3f(1,1,1);
	float u1 = 256.0f/256.0f;
	float v1 = 192.0f/256.0f;
	for (int i=0; i<2; i++)
	{
		glBindTexture(GL_TEXTURE_2D,backbufTex[i]);
		glTexSubImage2D(GL_TEXTURE_2D,0,0,0,256, 256, GL_RGBA, GL_UNSIGNED_SHORT_1_5_5_5_REV, g2dCores[i].GetPointer());
		float y = (float)i*192;
		glBegin(GL_TRIANGLE_FAN);
		glTexCoord2f(0,0);
		glVertex3f(0,y,0);
		glTexCoord2f(u1,0);
		glVertex3f(2*256,y,0);
		glTexCoord2f(u1,v1);
		glVertex3f(2*256,y+2*192,0);
		glTexCoord2f(0,v1);
		glVertex3f(0,y+2*192,0);
		glEnd();
	}

	glDisable(GL_TEXTURE_2D);

	host->EndFrame();
}

void DSDisplay_Shutdown()
{
	glDeleteTextures(2,backbufTex);
}
#pragma once

#include "../System.h"
#include "../MemMap.h"

extern System DSSystem;

extern MemRegionInfo DSregions[];

extern const int numDSRegions;

void DS_Init();
void DS_Shutdown();
void DS_HWAdvance(int cycles);
void DS_SWI();

extern bool ndslibHLE;
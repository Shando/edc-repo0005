#include "stdafx.h"

#include "DSTables.h"



//fifo commands
const int DSFifoNumParameters[0x80] = 
{
	0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,
	1, //mode
	0, //push
	1, //pop
	1, //store
	1, //restore
	0, //identity
	16,
	12,
	16,
	12,
	9,
	3,
	3, //1c
	0, //1d
	0, //1e
	0, //1f
	1, //20 color
	1,
	1,
	2, //vtx16
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	32,
	0,0,0,0,0,0,0,0,0,0,0,
	1, //begin
	0, //end
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	1, //swapbuffers
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	1, //viewport
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	3, //boxtest
	2, //postest
	1  //vectest
};


#include "stdafx.h"

#include "../../Globals.h"

#include "DSSPI.h"


void DSSPIWriteCR(u16 value)
{
	
}

void DSSPIWriteData(u8 value)
{
	
}

u32 DSSPIReadCR()
{
	return 0;
}
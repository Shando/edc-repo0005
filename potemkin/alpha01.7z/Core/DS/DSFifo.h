#pragma once

#include "../../Globals.h"

void DSFifoReset();
void DSWriteFifo(u32 word);
void DSRunFifo();

#include "stdafx.h"

#include "../MemMap.h"
#include "../Misc.h"

#include "../ARM/ARM.h"
#include "../Core.h"

#include "DSSystem.h"
#include "DSDisplay.h"
#include "DS7IO.h"
#include "DS9IO.h"

bool ndslibHLE;

typedef struct sTransferRegion {
	u32 heartbeat;         // counts frames

	u16 touchX, touchY;    // TSC X, Y
	u16 touchZ1, touchZ2;  // TSC x-panel measurements
	u16 tdiode1, tdiode2;  // TSC temperature diodes
	u32 temperature;       // TSC computed temperature

	u16 buttons;           // X, Y, /PENIRQ buttons
	u8 curtime[8];         // current time response from RTC

	// Don't rely on these below, will change or be removed in the future
	u32 tweakAddr;
	u32 tweakData;
	u32 readData;
	bool wantToTweak;
	bool tweakReading;
} TransferRegion, * pTransferRegion;


//22:17:27 <[firefly]> aha, my emu is crashing again because Nintendo changed the location of the IRQ handler address :/
//22:18:34 <ector> where is it now?
//22:19:22 <[firefly]> I think 0x23C3FFC

System DSSystem = 
{
	"Nintendo DS",
	"Nintendo",
	"*.nds;*.nef;*.bin",
	2, //two cpus
	2, //two displays
	1, //one controller
	0x02000000,
	{CPUTYPE_ARM9,CPUTYPE_ARM7},
	{66*1024*1024,33*1024*1024},

	DS_HWAdvance,
	DS_SWI
};


TCHAR* MEMDECL GetMemoryPositionName(u32 address);


TCHAR* MEMDECL GetMemoryPositionName(u32 address)
{
	switch(address & 0x7FFFFF) {
	case 0x007ffd80: return "Debugger Stack"; break;
	case 0x007ffda0: return "Arena Information"; break;
	case 0x007ffdf0: return "DMA Clear Buffer"; break;
	case 0x007ffe00: return "Rom-reg area data buffer ?"; break;
	case 0x007fffa0: return "Thread Info Main"; break;
	case 0x007fffa4: return "Thread Info Sub"; break;
	case 0x007fffa8: return "XY button buffer"; break;
	case 0x007fffc0: return "VRAM C Lock"; break;
	case 0x007fffc8: return "VRAM D Lock"; break;
	case 0x007fffd0: return "Work RAM Lock 0"; break;
	case 0x007fffd8: return "Work RAM Lock 1"; break;
	case 0x007fffe0: return "Card Lock"; break;
	case 0x007fffe8: return "Game Pak Lock"; break;
	case 0x007ffff0: return "Initialized Lock"; break;
	case 0x007ffff8: return "Component Sync Param"; break;
	case 0x007ffffc: return "Ram Size Checker"; break;
	case 0x007ffffe: return "MainMem Command Issue"; break;
	}

	return "";
}


MemRegionInfo DSregions[] =
{
	{"00 ITCM",       CPU_0,       MRTYPE_MEMORY, 0x00000000,0x00004000,0},
	{"01 DTCM",       CPU_0,       MRTYPE_MEMORY, 0x00800000,0x00804000,0},
	{"20 Main Memory",CPU_0|CPU_1, MRTYPE_MEMORY, 0x02000000,0x02400000,0,0,0,0,0,0,0,0,GetMemoryPositionName},
	{"24 MExt",       CPU_0|CPU_1, MRTYPE_MIRROR, 0x02400000,0x02800000,0,0,0,0,0,0,0,0,GetMemoryPositionName},
	{"37 WRAM Shared",CPU_0|CPU_1, MRTYPE_MEMORY, 0x037f8000,0x03800000,0},
	{"38 WRAM ARM7",        CPU_1, MRTYPE_MEMORY, 0x03800000,0x03810000,0},
	{"40 IO ARM9",    CPU_0,       MRTYPE_SPECIAL,0x04000000,0x04000800,0,ReadDS9IO8,ReadDS9IO16,ReadDS9IO32,WriteDS9IO8,WriteDS9IO16,WriteDS9IO32,ReadDS9IONoEffect,GetDS9IORegName},
	{"40 IO ARM7",          CPU_1, MRTYPE_SPECIAL,0x04000000,0x04000800,0,ReadDS7IO8,ReadDS7IO16,ReadDS7IO32,WriteDS7IO8,WriteDS7IO16,WriteDS7IO32,ReadDS7IONoEffect,GetDS7IORegName},
	{"50 Palettes",   CPU_0,       MRTYPE_MEMORY, 0x05000000,0x05000800,0},
	{"60 BG VRAM",    CPU_0,       MRTYPE_MEMORY, 0x06000000,0x06080000,0},
	{"62 DB BGVRAM",  CPU_0,       MRTYPE_MEMORY, 0x06200000,0x06220000,0},
	{"64 OBJ VRAM",   CPU_0,       MRTYPE_MEMORY, 0x06400000,0x06440000,0},
	{"66 DB OBJ VRAM",CPU_0,       MRTYPE_MEMORY, 0x06600000,0x06620000,0},
	{"68 LCDC VRAM",  CPU_0,       MRTYPE_MEMORY, 0x06800000,0x068A0000,0},
	{"70 OAM,OAMDB",  CPU_0,       MRTYPE_MEMORY, 0x07000000,0x07000800,0},
	{"80 CART",       CPU_0|CPU_1, MRTYPE_MEMORY, 0x08000000,0x09000000,0},
	{"A0 CARTRAM",    CPU_0|CPU_1, MRTYPE_MEMORY, 0x0A000000,0x0A010000,0},
	{"BIOS/arm9_ffff.bin",CPU_0,   MRTYPE_ROM,    0xFFFF0000,0xFFFFFFFF,0},
};


const int numDSRegions = sizeof(DSregions)/sizeof(MemRegionInfo);


void DS_Init()
{
	cpus[0]=&arm9;
	cpus[1]=&arm7;

	numCPUs=2;
	
	currentSystem = &DSSystem;
	arm7.highVectors=true;
	arm9.highVectors=true;
	arm7.fakeBios=false;
	arm9.fakeBios=false;
	arm7.enabled=true;
	arm9.enabled=true;

	MemMap_Init(DSregions,numDSRegions,1,0);

	//WriteMem32(0x01ffafd4,0xe12fff1e); //BX LR into ITCM

	arm7.Reset();
	arm9.Reset();
	
	g2dCores[0].g2 = &ds9IO.gfxregs1;
	g2dCores[1].g2 = &ds9IO.gfxregs2;

	g2dCores[0].bgvram = arm9.memMap.GetMemPointer(0x06000000);
	g2dCores[1].bgvram = arm9.memMap.GetMemPointer(0x06200000);

	g2dCores[0].objvram = arm9.memMap.GetMemPointer(0x06400000);
	g2dCores[1].objvram = arm9.memMap.GetMemPointer(0x06600000);

	g2dCores[0].paletteram = arm9.memMap.GetMemPointer(0x05000000);
	g2dCores[1].paletteram = arm9.memMap.GetMemPointer(0x05000000); //???

	g2dCores[0].oam = arm9.memMap.GetMemPointer(0x07000000);
	g2dCores[1].oam = arm9.memMap.GetMemPointer(0x07000800);

	g2dCores[0].Init(256,192);
	g2dCores[1].Init(256,192);

	currentCPU = &arm7;

	DS9IO_SelfTest();
	DS9IO_Init();
	DS7IO_SelfTest();
	DS7IO_Init();
}

void DS_Shutdown()
{
	MemMap_Shutdown();
}

extern int curTimer;

void DS_HWAdvance(int cycles)
{
	curTimer-=cycles;
	if (curTimer<0)
	{
		curTimer+=8000;
		g2dCores[0].DrawLine(ds9IO.vcount, ds9IO.dispcnt, ds9IO.dispstat);
		g2dCores[1].DrawLine(ds9IO.vcount, ds9IO.dispcnt, ds9IO.dispstat);
		ds9IO.vcount++;
		if (ds9IO.vcount>192)
			ds9IO.dispstat|=1;
		else
			ds9IO.dispstat&=~1;
		if (ds9IO.vcount==200)
		{
			DSDisplay_Draw();
			if (ndslibHLE)
			{
				TransferRegion *rgn = (TransferRegion *)arm9.memMap.GetMemPointer(0x00800000);
				rgn->heartbeat++;
			}
			ds9IO.vcount=0;
		}
	}
}

void DS_SWI()
{
	LOG(INTC,"SWI");
	Core_EnableStepping(true);
	((ARMState*)currentCPU)->SWI();
}

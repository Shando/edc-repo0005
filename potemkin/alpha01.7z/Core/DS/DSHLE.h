#pragma once

// HLE card access? (a SWI call)

#define DS_ARM9_SVC_SOFT_RESET         0x00
#define DS_ARM9_SVC_WAIT_BY_LOOP       0x03
#define DS_ARM9_SVC_WAIT_INTR          0x04 //	MOV     R2, #0
#define DS_ARM9_SVC_WAIT_VBLANK_INTR   0x05 //	MOV     R2, #0
#define DS_ARM9_SVC_DIV                0x09
#define DS_ARM9_SVC_DIVREM             0x09 //	?
#define DS_ARM9_SVC_CPU_SET            0x0B
#define DS_ARM9_SVC_CPU_SET_FAST       0x0C
#define DS_ARM9_SVC_SQRT               0x0D
#define DS_ARM9_SVC_UNPACK_BITS        0x10
#define DS_ARM9_SVC_UNCOMP_LZ77_BYTE   0x11
#define DS_ARM9_SVC_UNCOMP_LZ77_SHORT  0x12
#define	DS_ARM9_SVC_UNCOMP_HUFFMAN     0x13
#define DS_ARM9_SVC_UNCOMP_RL_BYTE     0x14
#define DS_ARM9_SVC_UNCOMP_RL_SHORT    0x15


#define DS_ARM7_SVC_SOFT_RESET         0x00
//01,02 hangs
#define DS_ARM7_SVC_WAIT_BY_LOOP       0x03
#define DS_ARM7_SVC_WAIT_INTR          0x04 
#define DS_ARM7_SVC_WAIT_VBLANK_INTR   0x05 
#define DS_ARM7_SVC_HALT			   0x06 
#define DS_ARM7_SVC_SLEEP			   0x07 
#define DS_ARM7_SVC_CHANGESOUNDBIAS    0x08 //	?
#define DS_ARM7_SVC_SETSOUNDBIAS       0x08 //	?
#define DS_ARM7_SVC_RESETSOUNDBIAS     0x08 //	?
#define DS_ARM7_SVC_DIV                0x09 //	?
#define DS_ARM7_SVC_DIVREM             0x09 //	?
//0A hangs
#define DS_ARM7_SVC_CPU_SET            0x0B
#define DS_ARM7_SVC_CPU_SET_FAST       0x0C
#define DS_ARM7_SVC_SQRT               0x0D
#define DS_ARM7_SVC_GETCRC16           0x0E
#define DS_ARM7_SVC_UNKNOWN0F          0x0F //	returns r3=0x027FFFE0
#define DS_ARM7_SVC_UNPACK_BITS        0x10
#define DS_ARM7_SVC_UNCOMP_LZ77_BYTE   0x11
#define DS_ARM7_SVC_UNCOMP_LZ77_SHORT  0x12
#define	DS_ARM7_SVC_UNCOMP_HUFFMAN     0x13
#define DS_ARM7_SVC_UNCOMP_RL_BYTE     0x14
#define DS_ARM7_SVC_UNCOMP_RL_SHORT    0x15
//16,17,18,19 hangs
#define DS_ARM7_SVC_GETSINTABLE        0x1A
#define DS_ARM7_SVC_GETPITCHTABLE      0x1B
#define DS_ARM7_SVC_GETVOLUMETABLE     0x1C
#define DS_ARM7_SVC_UNKNOWN1D          0x1D
//1E hangs
#define DS_ARM7_SVC_UNKNOWN1F          0x1F

/*
unknows ARM7
01		hangs
02		hangs
0A		hangs
0F		something		returns r3=0x027FFFE0
16		hangs
17		hangs
18		hangs
19		hangs
1D		something
1E		hangs
1F		nothing happens

*/

void DS_HLE_ARM9SWI(int number);
void DS_HLE_ARM7SWI(int number);
#include "stdafx.h"

#include "../HW.h"
#include "DS7IO.h"
#include "DSGeom.h"
#include "DSFifo.h"
#include "DSTables.h"

#include "../GBA/GBAIO.h"


DS7IORegion ds7IO;



struct GX
{
	u32 dispCNT;
	u16 dispStat;
	u16 vcount;
};


void DS7IO_Init()
{
	//dsIO.keyinput = 0x3ff;
}


void DS7IO_SelfTest()
{

}



u8   MEMDECL ReadDS7IO8 (u32 address)
{
	address&=0xffff;
	LOG(IO,"Unknown 8-bit IO read: %04x",address);
	return 0;
}


u16  MEMDECL ReadDS7IO16(u32 address)
{
	address&=0xffff;
	switch(address)
	{
	case 0x180: 
		{
			u16 value = (rand()&0xFF) | 0xFF00;
			LOG(IO,"R16: MAINPINTF"); 
			return value;
		}

	case 0x208: LOG(INTC, "R16: IME"); break;


	default:
		LOG(IO,"Unknown 16-bit IO read: %04x",address);
		break;
	}
	return 0;
}

u32  MEMDECL ReadDS7IO32(u32 address)
{
	address&=0xffff;

	u32 value = *(u32*)(((u8*)&ds7IO)+address);

	switch(address)
	{
	case 0xB8: LOG(DMA,"R32 DMA0 count/control = %08x",value); break;
	case 0xC4: LOG(DMA,"R32 DMA1 count/control = %08x",value); break;
	case 0xD0: LOG(DMA,"R32 DMA2 count/control = %08x",value); break;
	case 0xDC: LOG(DMA,"R32 DMA3 count/control = %08x",value); break;

	case 0x210:	LOG(INTC,"R32: IE = %08x",value); break;
	case 0x214:	LOG(INTC,"R32: IF = %08x",value); break;

	case 0x600: //read
		{
			LOG(G3D,"R32 GXSTAT");
		}
		break;
	default:
		LOG(IO,"Unknown 32-bit IO read: %04x",address);
		break;
	}
	return value;
}

void MEMDECL WriteDS7IO8 (u32 address, u8  value)
{
	address&=0xffff;
	switch (address) {
	case 0x1A8: 
	case 0x1A9: 
	case 0x1AA: 
	case 0x1AB: 
	case 0x1AC: 
	case 0x1AD: 
	case 0x1AE: 
	case 0x1AF:
		LOG(IO,"Card command reg written: %04x <- %02x",address,value); 
		break;

	default:
		LOG(IO,"Unknown 8-bit IO write: %04x <- %02x",address,value);
	}
}
void MEMDECL WriteDS7IO16(u32 address, u16 value)
{
	address&=0xffff;
	switch (address) {
	case 0x060: //read
		{
			LOG(G3D,"W16 Disp3DCNT = %04x",value);
		}
		break;
	case 0xB8: LOG(DMA,"W16 DMA0 count = %d",value); break;
	case 0xBA: LOG(DMA,"W16 DMA0 control = %04x",value); DMAC_CntWrite16(&ds7IO.dmac,0,value); break;
	case 0xC4: LOG(DMA,"W16 DMA1 count = %d",value); break;
	case 0xC6: LOG(DMA,"W16 DMA1 control = %04x",value); DMAC_CntWrite16(&ds7IO.dmac,1,value); break;
	case 0xD0: LOG(DMA,"W16 DMA2 count = %d",value); break;
	case 0xD2: LOG(DMA,"W16 DMA2 control = %04x",value); DMAC_CntWrite16(&ds7IO.dmac,2,value); break;
	case 0xDC: LOG(DMA,"W16 DMA3 count = %d",value); break;
	case 0xDE: LOG(DMA,"W16 DMA3 control = %04x",value); DMAC_CntWrite16(&ds7IO.dmac,3,value); break;

	case 0x1B8:	LOG(IO,"W16: Card encryption reg 3 = %04x", value); break;
	case 0x1BA:	LOG(IO,"W16: Card encryption reg 4 = %04x", value); break;

	case 0x1C0:
		LOG(IO,"W16: SERIAL_CR = %08x", value); 
		break;

	case 0x180: LOG(IO,"W16: SUBPINTF = %04x", value); break;
	case 0x208: LOG(INTC, "W16: IME : %d",value&1); break;

	default:
		LOG(IO,"Unknown 16-bit IO write: %04x <- %08x",address,value);
	}
	*(u16*)(((u8*)&ds7IO)+address) = value;
}


/*
*	
 */


static u32 __declspec(align(16)) writeBlock[16];
static u32 *wbPtr;
static int wbCount;
static int x,y,z;

void MEMDECL WriteDS7IO32(u32 address, u32 value)
{
	address&=0xffffff;
	
	switch (address) {
	case 0x060:
		LOG(G3D,"Disp3DCNT %08x",value);
		break;

	case 0xB0: LOG(DMA,"W32 DMA0 source = %08x",value); break;
	case 0xB4: LOG(DMA,"W32 DMA0 dest = %08x",value); break;
	case 0xB8:
		LOG(DMA,"W32 DMA0 control = %08x",value); 
		DMAC_CntWrite32(&ds7IO.dmac, 0, value); 
		return; //can't have the write overwrite what we did
	case 0xBC: LOG(DMA,"W32 DMA1 source = %08x",value); break;
	case 0xC0: LOG(DMA,"W32 DMA1 dest = %08x",value); break;
	case 0xC4:
		LOG(DMA,"W32 DMA1 control = %08x",value); 
		DMAC_CntWrite32(&ds7IO.dmac, 1, value); 
		return;
	case 0xC8: LOG(DMA,"W32 DMA2 source = %08x",value); break;
	case 0xCC: LOG(DMA,"W32 DMA2 dest = %08x",value); break;
	case 0xD0: 
		LOG(DMA,"W32 DMA2 control = %08x",value);
		DMAC_CntWrite32(&ds7IO.dmac, 2, value); 
		return;
	case 0xD4: LOG(DMA,"W32 DMA3 source = %08x",value); break;
	case 0xD8: LOG(DMA,"W32 DMA3 dest = %08x",value); break;
	case 0xDC:
		LOG(DMA,"W32 DMA3 control = %08x",value); 
		DMAC_CntWrite32(&ds7IO.dmac, 3, value); 
		return;

	case 0x180: LOG(IO,"W32: MAINPINTF = %08x", value); break;
	case 0x184: LOG(IO,"W32: MAINP_FIFO_CNT = %08x", value); break;
	case 0x188: LOG(IO,"W32: SEND_FIFO_OFFSET = %08x", value); break;
	case 0x100000: LOG(IO,"W32: RECV_FIFO = %08x", value); break;

	case 0x1A0:
		MessageBox(0,"Card access",0,0);
		LOG(IO,"W32: MAINPINTF = %08x", value); 
		break;

	case 0x1B0:	LOG(IO,"W32: Card encryption reg 1 = %08x", value); break;
	case 0x1B4:	LOG(IO,"W32: Card encryption reg 2 = %08x", value); break;

	case 0x1C0:
		LOG(IO,"W32: SERIAL_CR = %08x", value); 
		break;

	case 0x204: LOG(MEMMAP,"W32: EXMEMCNT = %08x", value); break;
	case 0x208: LOG(INTC, "W32: IME : %d",value&1); break;
	case 0x210: LOG(INTC, "W32: IE = %08x",value); break;
	case 0x214: LOG(INTC, "W32: IF = %08x",value); break;

	case 0x240: LOG(MEMMAP,"W32: WVRAMSTAT = %08x",value); // ARM7 only!!

	default:
		LOG(IO,"Unknown 32-bit IO write: %04x <- %08x",address,value);
		break;
	}
	//*(u32*)(((u8*)&dsIO)+address) = value;
}



u32  MEMDECL ReadDS7IONoEffect(u32 address)
{
	return 0;
}


TCHAR* MEMDECL GetDS7IORegName(u32 address)
{
	/*
	if ((address&0xFFFFFF)<0x54)
	{
		return GBADispRegs[(address&0xFF) / 2].description;
	}
	else*/
		return "unknown";
}



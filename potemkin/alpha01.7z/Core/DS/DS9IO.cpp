#include "stdafx.h"
#include <math.h>


#include "../HW.h"
#include "DS9IO.h"
#include "DSGeom.h"
#include "DSFifo.h"
#include "DSTables.h"

#include "../GBA/GBAIO.h"


int lastFifoCmd=-1;


DS9IORegion ds9IO;


const char *matrixModeNames[4] = {"PROJ", "WORLD", "WORLD+NORMAL","TEXTURE"};


struct GX
{
	u32 dispCNT;
	u16 dispStat;
	u16 vcount;
};


void DS9IO_Init()
{
	memset(&ds9IO, 0, sizeof(ds9IO));

	//Setup default hw register values
	ds9IO.gfxregs1.bg2PA = 0x100; //1:1 scaling, no rotation
	ds9IO.gfxregs1.bg2PD = 0x100;
	ds9IO.gfxregs1.bg3PA = 0x100;
	ds9IO.gfxregs1.bg3PD = 0x100;

	ds9IO.gfxregs2.bg2PA = 0x100; //1:1 scaling, no rotation
	ds9IO.gfxregs2.bg2PD = 0x100;
	ds9IO.gfxregs2.bg3PA = 0x100;
	ds9IO.gfxregs2.bg3PD = 0x100;

	//ds9IO.keyinput = 0x3ff;
}


void DS9IO_SelfTest()
{
	//check so that i haven't messed up the struct :)
	_dbg_assert_msg_(IO,sizeof(DMACNT)==4,"ds9IO selftest 0");

	size_t offset = (((u8*)&ds9IO.dmac.channels[0].sourceAddr)-((u8*)&ds9IO));
	LOG(IO,"DMAC Offset: %04x",offset);
	_dbg_update_();
	_dbg_assert_msg_(IO,0xb0 == offset,"ds9IO selftest 1"); //, (char *)&ds9IO.dmacontroller.channels[0].sourceAddr - (char*)&ds9IO);

	offset = (((u8*)&ds9IO.coprocessor)-((u8*)&ds9IO));
	LOG(IO,"CP Offset: %04x",offset);
	_dbg_update_();
	_dbg_assert_msg_(IO,0x280 == offset,"ds9IO selftest 1"); //, (char *)&ds9IO.dmacontroller.channels[0].sourceAddr - (char*)&ds9IO);

	memset(&ds9IO,0,sizeof(ds9IO));
}



u8   MEMDECL ReadDS9IO8 (u32 address)
{
	address&=0xffff;
	LOG(IO,"Unknown 8-bit IO read: %04x",address);
	return 0;
}

u16  MEMDECL ReadDS9IO16(u32 address)
{
	address&=0xffff;
	switch(address) 
	{
	case 0x004:
		break;

	case 0x060: //read
		{
			LOG(G3D,"R16 Disp3DCNT");
		}
		break;

	case 0x0DE: //read dma status
		{

		}
		break;

	case 0x180: 
		{
			u16 value = (rand()&0xFF) | 0xFF00;
			LOG(IO,"R16: SUBPINTF"); 
			return value;
		}

	case 0x208: LOG(INTC, "R16: IME"); break;

	case 0x280:	
		LOG(COPROCESSOR,"R16: DIV_CNT - triggering computation!");	
		{
			// do the computation here!!
			double numer = (double)ds9IO.coprocessor.div_numer,
				denom = (double)ds9IO.coprocessor.div_denom;
			ds9IO.coprocessor.div_result = (u64)(numer/denom);
		}
		break;
	case 0x2B0:	
		{
			// do the computation here!!
			LOG(COPROCESSOR,"R16: SQRT_CNT - triggering computation!");	
			double val = (double)ds9IO.coprocessor.sqrt_param;
			ds9IO.coprocessor.sqrt_result = (u32)sqrt(val);
		}
		break;

	//604:LISTRAM_COUNT
	//606:VERTEXRAM_COUNT

	//630-634: VEC_RESULT_XYZW (16bit)

	default:
		LOG(IO,"Unknown 16-bit IO read: %04x",address);
		break;
	}
	if (address<sizeof(ds9IO))
		return ((u16 *)&ds9IO)[address>>1];
	else
		return 0;
}

u32  MEMDECL ReadDS9IO32(u32 address)
{
	address&=0xffff;
	u32 value = *(u32*)(((u8*)&ds9IO)+address);
	switch(address) 
	{
	case 0xB8: LOG(DMA,"R32 DMA0 count/control = %08x",value); break;
	case 0xC4: LOG(DMA,"R32 DMA1 count/control = %08x",value); break;
	case 0xD0: LOG(DMA,"R32 DMA2 count/control = %08x",value); break;
	case 0xDC: LOG(DMA,"R32 DMA3 count/control = %08x",value); break;

	case 0x210:	LOG(INTC,"R32: IE = %08x",value); break;
	case 0x214:	LOG(INTC,"R32: IF = %08x",value); break;

	case 0x2A0:	LOG(COPROCESSOR,"R32: DIV_RESULT_L %08x",value);	break;
	case 0x2A4:	LOG(COPROCESSOR,"R32: DIV_RESULT_H %08x",value);	break;
	case 0x2A8:	LOG(COPROCESSOR,"R32: DIV_REM_RESULT_L");	break;
	case 0x2AC:	LOG(COPROCESSOR,"R32: DIV_REM_RESULT_H");	break;
	case 0x2B4:	LOG(COPROCESSOR,"R32: SQRT_RESULT %08x",value);	break;
	case 0x600: //read
		{
			LOG(G3D,"R32 GXSTAT");
		}
		break;

	//620-62C: POS_RESULT_XYZW
	//640-67C: CLIPMTX
	//680-6a0: 3x3 VECMTX
	default:
		LOG(IO,"Unknown 32-bit IO read: %04x",address);
		break;
	}
	return value;
}

void MEMDECL WriteDS9IO8 (u32 address, u8  value)
{
	address&=0xffff;
	LOG(IO,"Unknown 8-bit IO write: %04x <- %02x",address,value);
	
}
void MEMDECL WriteDS9IO16(u32 address, u16 value)
{
	address&=0xffff;
	switch (address) {
	case 0x060: //read
		{
			LOG(G3D,"W16 Disp3DCNT = %04x",value);
		}
		break;
	case 0xB8: LOG(DMA,"W16 DMA0 count = %d",value); break;
	case 0xBA: LOG(DMA,"W16 DMA0 control = %04x",value); DMAC_CntWrite16(&ds9IO.dmac,0,value); break;
	case 0xC4: LOG(DMA,"W16 DMA1 count = %d",value); break;
	case 0xC6: LOG(DMA,"W16 DMA1 control = %04x",value); DMAC_CntWrite16(&ds9IO.dmac,1,value); break;
	case 0xD0: LOG(DMA,"W16 DMA2 count = %d",value); break;
	case 0xD2: LOG(DMA,"W16 DMA2 control = %04x",value); DMAC_CntWrite16(&ds9IO.dmac,2,value); break;
	case 0xDC: LOG(DMA,"W16 DMA3 count = %d",value); break;
	case 0xDE: LOG(DMA,"W16 DMA3 control = %04x",value); DMAC_CntWrite16(&ds9IO.dmac,3,value); break;

	case 0x180: LOG(IO,"W16: SUBPINTF = %04x", value); break;
	case 0x208: LOG(INTC, "W16: IME : %d",value&1); break;

	case 0x280:	LOG(COPROCESSOR,"W16: DIV_CNT: %04x",value);	break;
	case 0x2B0:	LOG(COPROCESSOR,"W16: SQRT_CNT: %04x",value);	break;


		//610: DISP_1DOT_DEPTH

	default:
		LOG(IO,"Unknown 16-bit IO write: %04x <- %08x",address,value);
	}
	*(u16*)(((u8*)&ds9IO)+address) = value;
}


/*
*	
 */


static u32 __declspec(align(16)) writeBlock[16];
static u32 *wbPtr;
static int wbCount;
static int x,y,z;

void MEMDECL WriteDS9IO32(u32 address, u32 value)
{
	address&=0xffffff;
	
	switch (address)
	{
	case 0x060:
		LOG(G3D,"Disp3DCNT %08x",value);
		break;

	case 0xB0: LOG(DMA,"W32 DMA0 source = %08x",value); break;
	case 0xB4: LOG(DMA,"W32 DMA0 dest = %08x",value); break;
	case 0xB8:
		LOG(DMA,"W32 DMA0 control = %08x",value); 
		DMAC_CntWrite32(&ds9IO.dmac, 0, value); 
		return; //can't have the write overwrite what we did
	case 0xBC: LOG(DMA,"W32 DMA1 source = %08x",value); break;
	case 0xC0: LOG(DMA,"W32 DMA1 dest = %08x",value); break;
	case 0xC4:
		LOG(DMA,"W32 DMA1 control = %08x",value); 
		DMAC_CntWrite32(&ds9IO.dmac, 1, value); 
		return;
	case 0xC8: LOG(DMA,"W32 DMA2 source = %08x",value); break;
	case 0xCC: LOG(DMA,"W32 DMA2 dest = %08x",value); break;
	case 0xD0: 
		LOG(DMA,"W32 DMA2 control = %08x",value);
		DMAC_CntWrite32(&ds9IO.dmac, 2, value); 
		return;
	case 0xD4: LOG(DMA,"W32 DMA3 source = %08x",value); break;
	case 0xD8: LOG(DMA,"W32 DMA3 dest = %08x",value); break;
	case 0xDC:
		LOG(DMA,"W32 DMA3 control = %08x",value); 
		DMAC_CntWrite32(&ds9IO.dmac, 3, value); 
		return;

	case 0x180: LOG(IO,"W32: SUBPINTF = %08x", value); break;
	case 0x184: LOG(IO,"W32: SUBP_FIFO_CNT = %08x", value); break;
	case 0x188: LOG(IO,"W32: SEND_FIFO_OFFSET = %08x", value); break;

	case 0x204: LOG(MEMMAP,"W32: EXMEMCNT = %08x", value); break;
	case 0x208: LOG(INTC, "W32: IME : %d",value&1); break;
	case 0x210: LOG(INTC, "W32: IE = %08x",value); break;
	case 0x214: LOG(INTC, "W32: IF = %08x",value); break;

	case 0x240: LOG(MEMMAP,"W32: WVRAMSTAT = %08x",value); // ARM7 only!!
	case 0x290:	LOG(COPROCESSOR,"W32: DIV_NUMER_L: %08x",value);	break;
	case 0x294:	LOG(COPROCESSOR,"W32: DIV_NUMER_H: %08x",value);	break;
	case 0x298:	LOG(COPROCESSOR,"W32: DIV_DENOM_L: %08x",value);	break;
	case 0x29C:	LOG(COPROCESSOR,"W32: DIV_DENOM_H: %08x",value);	break;
	case 0x2B8:	LOG(COPROCESSOR,"W32: SQRT_IN_L: %08x",value);	break;
	case 0x2BC:	LOG(COPROCESSOR,"W32: SQRT_IN_H: %08x",value);	break;

	
	case 0x340: LOG(G3D,"Alpha Ref %08x",value); break;
	case 0x350: LOG(G3D,"Clear Color %08x",value); break;
	case 0x354: LOG(G3D,"CLEAR_DEPTH / CLEAR_IMAGE_OFF %08x",value); break;

	case 0x358: LOG(G3D,"Fog color %08x",value); break;
	case 0x35C: LOG(G3D,"Fog offset %08x",value); break;

	case 0x360:
	case 0x364:
	case 0x368:
	case 0x36C:
	case 0x370:
	case 0x374:
	case 0x378:
	case 0x37C:
		LOG(G3D,"Fog table %08x",value); 
		break;

	case 0x380:
	case 0x384:
	case 0x388:
	case 0x38C:
	case 0x390:
	case 0x394:
	case 0x398:
	case 0x39C:
	case 0x3a0:
	case 0x3a4:
	case 0x3a8:
	case 0x3aC:
	case 0x3b0:
	case 0x3b4:
	case 0x3b8:
	case 0x3bC:
		LOG(G3D,"Toon table %08x",value); 
		break;

	case 0x400:
	case 0x404:
	case 0x408:
	case 0x40c:
	case 0x410:
	case 0x414:
	case 0x418:
	case 0x41c:
	case 0x420:
	case 0x424:
	case 0x428:
	case 0x42c:
	case 0x430:
	case 0x434:
	case 0x438:
	case 0x43c:
		LOG(G3D,"GX raw FIFO %08x",value); 
		//DSWriteFifo(value);
		DSRunFifo();
		break;

	case 0x600: 
		{
			LOG(G3D,"GXSTAT write",value);
		}
		break;
	case 0x540:
		//swapbuffers
		DSRunFifo();
		DSFifoReset();
		break;
	default:
		if (address>=0x440 && address <= 0x5FC)
		{
			int fifocmd = (address-0x400) >> 2;
			static int numParams=0;
			if (fifocmd != lastFifoCmd || numParams>=DSFifoNumParameters[fifocmd])
			{
				numParams=0;
				lastFifoCmd=fifocmd;
				DSWriteFifo(fifocmd);
				if (DSFifoNumParameters[fifocmd])
					DSWriteFifo(value);
			}
			else
				DSWriteFifo(value);
			numParams++;
			LOG(IO,"32-bit FIFO write: %04x <- %08x",address,value);
		}
		else
		{
			LOG(IO,"Unknown 32-bit IO write: %04x <- %08x",address,value);
		}
	}
	*(u32*)(((u8*)&ds9IO)+address) = value;
}



u32  MEMDECL ReadDS9IONoEffect(u32 address)
{
	return 0;
}


TCHAR* MEMDECL GetDS9IORegName(u32 address)
{
	if ((address&0xFFFFFF)<0x54)
	{
		return GBADispRegs[(address&0xFF) / 2].description;
	}
	else
		return "unknown";
}



#pragma once

#include "../MemMap.h"

#include "../Graphics/G2d.h"
#include "../Shared/N_DMA.h"

#include "DSIOCommon.h"

void DS9IO_SelfTest();
void DS9IO_Init();

u8   MEMDECL ReadDS9IO8 (u32 address);
u16  MEMDECL ReadDS9IO16(u32 address);
u32  MEMDECL ReadDS9IO32(u32 address);
u32  MEMDECL ReadDS9IONoEffect(u32 address);

TCHAR* MEMDECL GetDS9IORegName(u32 address);

void MEMDECL WriteDS9IO8 (u32 address, u8  value);
void MEMDECL WriteDS9IO16(u32 address, u16 value);
void MEMDECL WriteDS9IO32(u32 address, u32 value);



struct CP //start at 0x280, size = 0x40
{
	u16 divcnt;
	u16 pad;
	u32 pad2[3];
	union {
		struct {
			u32 div_numer_l;
			u32 div_numer_h;
		};
		s64 div_numer;
	};
	union {
		struct {
			u32 div_denom_l;
			u32 div_denom_h;
		};
		s64 div_denom;
	};
	union {
		struct {
			u32 div_result_l;
			u32 div_result_h;
		};
		s64 div_result;
	};
	u32 div_remainder_l;
	u32 div_remainder_h;
	u16 sqrtcnt;
	u16 pad3;
	u32 sqrt_result;
	union {
		struct {
			u32 sqrt_param_l;
			u32 sqrt_param_h;
		};
		u64 sqrt_param;
	};
};


struct G3X1 //start at 0x60
{
	u16 disp3dCNT;
};

struct G3X2 //start at 0x320
{
	int rdlines_count;
	int unused1;
	int unused2;
	int unused3;
	u32 edgeColor[4];
	u32 alphaTestRef;
	u32 unused4[3];
	u32 clearColor[4];
	u16 clearDepth;
	u16 clearImageOffset;
	u32 fogColor; //0x358
	u32 fogOffset;
	u16 fogTable[16]; //0x360
	u16 toonTable[32]; //0x380
};


struct DS9IORegion
{
	u32 dispcnt;
	u8 dispstat;
	u8 vcountline;
	u8 vcount;
	u8 unused;
	G2 gfxregs1;
	//0x56
	u32 unused1[3];
	//0x60
	u16 disp3dCNT;
	u16 unused2;
	u32 unused3[(0xb0-0x64) / 4];
	//0xb0 - DMAC
	DMAC dmac;
	u32 unused4[7];
	u32 unused5[(0x280-0x100)/4];
	//0x280
	CP coprocessor;
	//0x320
	G3X2 gfx3d;

	//0x400
	u32 gxFifoFiller[16];


	//TODO add filler here
	G2 gfxregs2;
};


extern DS9IORegion ds9IO;
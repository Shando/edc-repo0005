#pragma once

void DSDisplay_Init();
void DSDisplay_Draw();
void DSDisplay_Shutdown();
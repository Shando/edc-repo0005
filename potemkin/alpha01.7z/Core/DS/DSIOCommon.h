#pragma once

#include "../MemMap.h"

struct EXI
{
	u32 sioData32;
	u32 pad;
	u32 sioCNT;
	u32 sioSel;
};



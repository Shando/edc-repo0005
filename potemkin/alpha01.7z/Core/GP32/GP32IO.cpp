#include "stdafx.h"
#include "../HW.h"
#include "GP32IO.h"


//////////////////////////////////////////////////////////////////////////
/*
 *	


 LCDCON1: 0x14A00000
 LINECNT
 (read only)
 [27:18] These bits provide the status of the line counter.
 Down count from LINEVAL to 0
 0000000000
 CLKVAL [17:8] These bits determine the rates of VCLK and CLKVAL[9:0].
 STN: VCLK = HCLK / (CLKVAL x 2) ( CLKVAL � 2 )
 TFT: VCLK = HCLK / [(CLKVAL+1) x 2] ( CLKVAL � 1 )
 0000000000
 MMODE [7] This bit determines the toggle rate of the VM.
 0 = Each Frame, 1 = The rate defined by the MVAL
 0
 PNRMODE [6:5] These bits select the display mode.
 00 = 4-bit dual scan display mode(STN)
 01 = 4-bit single scan display mode(STN)
 10 = 8-bit single scan display mode(STN)
 11 = TFT LCD panel
 00
 BPPMODE [4:1] These bits select the BPP ( Bits Per Pixel) mode.
 0000 = 1 bpp for STN, Monochrome mode
 0001 = 2 bpp for STN, 4-level gray mode
 0010 = 4 bpp for STN, 16-level gray mode
 0011 = 8 bpp for STN, color mode
 0100 = 12 bpp for STN, color mode
 1000 = 1 bpp for TFT
 1001 = 2 bpp for TFT
 1010 = 4 bpp for TFT
 1011 = 8 bpp for TFT
 1100 = 16 bpp for TFT
 0000
 ENVID [0] LCD video output and the logic enable/disable.
 0 = Disable the video output and the LCD control signal.
 1 = Enable the video output and the LCD control signal.
 0

 LCDCON2: 0x14A00004
 VBPD [31:24] TFT: Vertical back porch is the number of inactive lines at the start
 of a frame, after vertical synchronization period.
 STN: These bits should be set to zero on STN LCD.
 0x00
 LINEVAL [23:14] TFT/STN: These bits determine the vertical size of LCD panel. 0000000000
 VFPD [13:6] TFT: Vertical front porch is the number of inactive lines at the end
 of a frame, before vertical synchronization period.
 STN: These bits should be set to zero on STN LCD.
 00000000
 VSPW [5:0] TFT: Vertical sync pulse width determines the VSYNC pulse's high
 level width by counting the number of inactive lines.
 STN: These bits should be set to zero on STN LCD.
 000000

 LCDCON3: 0x14A00008
 HBPD (TFT) [25:19] TFT: Horizontal back porch is the number of VCLK periods between
 the falling edge of HSYNC and the start of active data.
 0000000
 WDLY (STN) STN: WDLY[1:0] bits determine the delay between VLINE and
 VCLK by counting the number of the HCLK. WDLY[7:2] are
 reserved.
 00 = 16 HCLK, 01 = 32 HCLK, 10 = 64 HCLK, 11 = 128 HCLK
 HOZVAL [18:8] TFT/STN: These bits determine the horizontal size of LCD panel.
 HOZVAL has to be determined to meet the condition that total bytes
 of 1 line are 2n bytes. If the x size of LCD is 120 dot in mono mode,
 x=120 can not be supported because 1 line is consist of 15 bytes.
 Instead, x=128 in mono mode can be supported because 1 line is
 consisted of 16 bytes (2n). LCD panel driver will discard the
 additional 8 dot.
 00000000000
 HFPD (TFT) [7:0] TFT: Horizontal front porch is the number of VCLK periods between
 the end of active data and the rising edge of HSYNC.
 0X00
 LINEBLANK
 (STN)
 STN: These bits indicate the blank time in one horizontal line
 duration time. These bits adjust the rate of the VLINE finely.
 The unit of LINEBLANK is HCLK X 8.
 Ex) If the value of LINEBLANK is 10, the blank time is inserted to
 VCLK during 80 HCLKs.

 
 framebuffer:
 LCDSADDR1: 0x14A00014
 LCDSADDR2: 0x14A00018
 LCDSADDR3: 0x14A0001C

 REDLUT 0x14A00020
 GREENLUT 0x14A00024
 BLUELUT 0x14A00028

 DITHMODE 4c

 RTCCON 15700040
 TICNT  15700044 47byte


 Palette: 0x14A00400 - 0x14A007FC
 */




u8   MEMDECL ReadGP32IO8 (u32 address)
{
//	address&=0xFFFFFF;
	LOG(IO,"Unknown 8-bit IO read: %06x",address);
	return 0;
}

u16  MEMDECL ReadGP32IO16(u32 address)
{
//	address&=0xFFFFFF;
	LOG(IO,"Unknown 16-bit IO read: %06x",address);
	return 0;
}

u32  MEMDECL ReadGP32IO32(u32 address)
{
	switch (address) 
	{
	case 0x14000024: LOG(IO,"R32: REFRESH %08x"); break;

	case 0x14400000: LOG(IO,"R32: SRCPND %08x (interrupt request)"); break;
	case 0x14400004: LOG(IO,"R32: INTMOD %08x (interrupt mode)"); break;
	case 0x14400008: LOG(IO,"R32: INTMSK %08x (interrupt mask)"); break;
	case 0x1440000C: LOG(IO,"R32: PRIORITY %08x (irq priority)"); break;
	case 0x14400010: LOG(IO,"R32: INTPND %08x (interrupt request status)"); break;
	case 0x14400014: LOG(IO,"R32: INTOFFSET %08x (intterupt request source)"); break;
	}
//	address&=0xFFFFFF;
	LOG(IO,"Unknown 32-bit IO read: %06x",address);
	return 0;
}

u32  MEMDECL ReadGP32IONoEffect(u32 address)
{
	return 0;
}

TCHAR* MEMDECL GetGP32IORegName(u32 address){return "YO";}

void MEMDECL WriteGP32IO8 (u32 address, u8  value)
{
	LOG(IO,"Unknown 8-bit IO write: [%06x] = %02x",address,value);
}
void MEMDECL WriteGP32IO16(u32 address, u16 value)
{
	LOG(IO,"Unknown 16-bit IO write: [%06x] = %04x",address,value);

}
void MEMDECL WriteGP32IO32(u32 address, u32 value)
{
	switch (address) 
	{
	case 0x14000000: LOG(IO,"W32: BWSCON %08x",value); break;
	case 0x14000004: LOG(IO,"W32: BANKCON0 %08x",value); break;
	case 0x14000008: LOG(IO,"W32: BANKCON1 %08x",value); break;
	case 0x1400000C: LOG(IO,"W32: BANKCON2 %08x",value); break;
	case 0x14000010: LOG(IO,"W32: BANKCON3 %08x",value); break;
	case 0x14000014: LOG(IO,"W32: BANKCON4 %08x",value); break;
	case 0x14000018: LOG(IO,"W32: BANKCON5 %08x",value); break;
	case 0x1400001C: LOG(IO,"W32: BANKCON6 %08x",value); break;
	case 0x14000020: LOG(IO,"W32: BANKCON7 %08x",value); break;
	case 0x14000024: LOG(IO,"W32: REFRESH %08x",value); break;
	case 0x14000028: LOG(IO,"W32: BANKSIZE %08x",value); break;
	case 0x1400002C: LOG(IO,"W32: MRSRB6 %08x",value); break;
	case 0x14000030: LOG(IO,"W32: MRSRB7 %08x",value); break;

	//interrupt controller
	case 0x14400000: LOG(IO,"W32: SRCPND %08x (interrupt request)",value); break;
	case 0x14400004: LOG(IO,"W32: INTMOD %08x (interrupt mode)",value); break;
	case 0x14400008: LOG(IO,"W32: INTMSK %08x (interrupt mask)",value); break;
	case 0x1440000C: LOG(IO,"W32: PRIORITY %08x (irq priority)",value); break;
	case 0x14400010: LOG(IO,"W32: INTPND %08x (interrupt request status)",value); break;
	case 0x14400014: LOG(IO,"W32: INTOFFSET %08x (intterupt request source)",value); break;
		
	//clock
	case 0x14800000: LOG(IO,"W32: LOCKTIME %08x",value); break;
	case 0x14800004: LOG(IO,"W32: MPLLCON %08x",value); break;
	case 0x14800008: LOG(IO,"W32: UPLLCON %08x",value); break;
	case 0x1480000C: LOG(IO,"W32: CLKCON %08x",value); break;
	case 0x14800010: LOG(IO,"W32: CLKSLOW %08x",value); break;
	case 0x14800014: LOG(IO,"W32: CLKDIVN %08x",value); break;

	//LCD
	case 0x14a00000: LOG(IO,"W32: LCDCON1 %08x",value); break;
	case 0x14a00004: LOG(IO,"W32: LCDCON2 %08x",value); break;
	case 0x14a00008: LOG(IO,"W32: LCDCON3 %08x",value); break;
	case 0x14a0000C: LOG(IO,"W32: LCDCON4 %08x",value); break;
	case 0x14a00010: LOG(IO,"W32: LCDCON5 %08x",value); break;
	case 0x14a00014: LOG(IO,"W32: LCDSADDR1 %08x",value); break;
	case 0x14a00018: LOG(IO,"W32: LCDSADDR2 %08x",value); break;
	case 0x14a0001c: LOG(IO,"W32: LCDSADDR3 %08x",value); break;
	case 0x14a00020: LOG(IO,"W32: REDLUT %08x",value); break;
	case 0x14a00024: LOG(IO,"W32: GREENLUT %08x",value); break;
	case 0x14a00028: LOG(IO,"W32: BLUELUT %08x",value); break;
	case 0x14a0004c: LOG(IO,"W32: DITHMODE %08x",value); break;
	case 0x14a00050: LOG(IO,"W32: TPAL %08x",value); break;

	case 0x15100000: LOG(IO,"W32: TCFG0", value); break;
	case 0x15100004: LOG(IO,"W32: TCFG1", value); break;
	case 0x15100008: LOG(IO,"W32: TCON", value); break;
	case 0x1510000c: LOG(IO,"W32: TCNTB0", value); break;
	case 0x15100010: LOG(IO,"W32: TCMPB0", value); break;
	case 0x15100014: LOG(IO,"W32: TCNTO0", value); break;
	case 0x15100018: LOG(IO,"W32: TCNTB1", value); break;
	case 0x1510001c: LOG(IO,"W32: TCMPB1", value); break;
	case 0x15100020: LOG(IO,"W32: TCNTO1", value); break;
	case 0x15100024: LOG(IO,"W32: TCNTB2", value); break;
	case 0x15100028: LOG(IO,"W32: TCMPB2", value); break;
	case 0x1510002c: LOG(IO,"W32: TCNTO2", value); break;
	case 0x15100030: LOG(IO,"W32: TCNTB3", value); break;
	case 0x15100034: LOG(IO,"W32: TCMPB3", value); break;
	case 0x15100038: LOG(IO,"W32: TCNTO3", value); break;
	case 0x1510003c: LOG(IO,"W32: TCMPB4", value); break;
	case 0x15100040: LOG(IO,"W32: TCNTO4", value); break;

	case 0x15300000: LOG(IO,"W32: WTCON %08x",value); break;
	case 0x15300004: LOG(IO,"W32: WTDAT %08x",value); break;
	case 0x15300008: LOG(IO,"W32: WTCNT %08x",value); break;

	case 0x15600058:  //rw
	
	default:
		LOG(IO,"Unknown 32-bit IO write: [%06x] = %08x",address,value);
	}
}

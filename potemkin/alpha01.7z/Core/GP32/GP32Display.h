#pragma once

void GP32Display_Init();
void GP32Display_Draw();
void GP32Display_Shutdown();
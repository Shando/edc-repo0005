#pragma once

#include "../System.h"
#include "../MemMap.h"

extern System GP32System;

extern MemRegionInfo GP32regions[];

extern const int numGP32Regions;

void GP32_Init();
void GP32_Shutdown();
void GP32_HWAdvance(int cycles);
void GP32_SWI();

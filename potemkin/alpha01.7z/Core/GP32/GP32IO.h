#pragma once

#include "../MemMap.h"


u8   MEMDECL ReadGP32IO8 (u32 address);
u16  MEMDECL ReadGP32IO16(u32 address);
u32  MEMDECL ReadGP32IO32(u32 address);
u32  MEMDECL ReadGP32IONoEffect(u32 address);
TCHAR* MEMDECL GetGP32IORegName(u32 address);

void MEMDECL WriteGP32IO8 (u32 address, u8  value);
void MEMDECL WriteGP32IO16(u32 address, u16 value);
void MEMDECL WriteGP32IO32(u32 address, u32 value);

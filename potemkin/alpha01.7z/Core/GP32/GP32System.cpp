#include "stdafx.h"

#include "../MemMap.h"
#include "../Misc.h"

#include "../ARM/ARM.h"

#include "GP32System.h"
#include "GP32IO.h"
#include "GP32Display.h"

System GP32System = 
{
	"GP32",
	"some korean company",
	"*.g32;*.bin", //?
	1, //one cpus
	1, //one display
	1, //one controller
	0x0c000000, // ???????????
	{CPUTYPE_ARM9},
	{133*1024*1024},
	GP32_HWAdvance,
	GP32_SWI
};


MemRegionInfo GP32regions[] = {
	{"BIOS/fw157e.bin",CPU_0,  MRTYPE_ROM,    0x00000000,0x0003ffff},
	{"Work RAM 8MB",   CPU_0,  MRTYPE_MEMORY, 0x0c000000,0x0c7fffff},
	{"Hardware Regs",  CPU_0,  MRTYPE_SPECIAL,0x14000000,0x15a0003f,0,ReadGP32IO8,ReadGP32IO16,ReadGP32IO32,WriteGP32IO8,WriteGP32IO16,WriteGP32IO32,ReadGP32IONoEffect,GetGP32IORegName} //blah blah
};

const int numGP32Regions = sizeof(GP32regions)/sizeof(MemRegionInfo);



void GP32_Init()
{
	currentSystem = &GP32System;

	arm7.highVectors=false;
	arm7.enabled=true;
	arm9.enabled=false;
	cpus[0]=&arm7;
	numCPUs=1;
	MemMap_Init(GP32regions,numGP32Regions,1,0);
	arm7.Reset();
	arm7.r[ARM_REG_SP]=0x0C77FF00; //??

	GP32Display_Init();
}

void GP32_Shutdown()
{
	GP32Display_Shutdown();
	MemMap_Shutdown();
}

void GP32_HWAdvance(int cycles)
{

}

void GP32_SWI()
{
	ARMState *currentARM = static_cast<ARMState*>(currentCPU);
	currentARM->SWI();

}
#include "stdafx.h"

#include "../Globals.h"
#include "Core.h"
#include "MemMap.h"
#include "ARM/ARM.h"
#include "MIPS/MIPS.h"
#include "SH4/SH4.h"
#include "Loaders.h"
#include "Tests.h"

#include "Host.h"
#include "EmuThread.h"

#include "Debugger/Breakpoints.h"

HANDLE m_hStepEvent;

volatile CoreState coreState = CORE_STEPPING;
#define BREAKPOINTS

#ifdef _DEBUG
//#define VBATRACE
#endif

#ifdef VBATRACE
FILE *vbalog;
#endif

void Core_Init(EmuMode mode, TCHAR *file)
{
	m_hStepEvent = CreateEvent( NULL, FALSE, FALSE, NULL);
	coreState = CORE_STEPPING;

	Load_ROM(file);

#ifdef VBATRACE
	vbalog = fopen("C:\\gbatrace.bin","rb");
#endif
	//currentARM->r[15] = regions[0].start;
}

void Core_ErrorPause()
{
	coreState=CORE_ERROR;
}

void Core_CmdLine(TCHAR *text)
{
	if (Test(text))
		return;
}


void Core_Pause()
{
	Core_EnableStepping(true);
}

void Core_Shutdown()
{
	CloseHandle(m_hStepEvent);
	m_hStepEvent = NULL;
}


void Core_Stop()
{
	//PowerPC::Stop();
	coreState = CORE_POWERDOWN;
	SetEvent(m_hStepEvent);
}

bool Core_IsStepping()
{
	return coreState == CORE_STEPPING || coreState==CORE_POWERDOWN;
}

void Core_FastRun()
{
	currentCPU->FastRun();
}

void Core_DoSingleStep()
{
	SetEvent(m_hStepEvent);
}


u32 prevpc,pprevpc,ppprevpc;
int startCount = 0x0;
void Core_SingleStep()
{
	ppprevpc = pprevpc;
	pprevpc = prevpc;
	prevpc = currentCPU->GetPC();
	
	if (prevpc==0)
	{
		LOG(CPU,"OUCH PC = 0, last PC = %08x",pprevpc);
		Core_Pause();
	}
	currentCPU->SingleStep();

	return;
/*
	ARMState *currentARM = static_cast<ARMState*>(currentCPU);
#ifdef VBATRACE
	static int count = 0;
	if (count==startCount)
		Core_Pause();

	if (count>=startCount)
	{
		if (!feof(vbalog))
		{
			u32 temp[17];
			fread(temp,4*17,1,vbalog);

			temp[15] -= currentARM->thumb?2:4; //compensate for VBA oddity
			for (int i=0; i<16; i++)
			{
				if (currentARM->r[i] != temp[i])
				{
					LOG(CPU,"[%08x] Diff r%d  %08x(vba) vs %08x",currentARM->r[ARM_REG_PC],i,temp[i],currentARM->r[i]);
					Core_Pause();
				}
			}
			if (currentARM->GetCPSR() != temp[16])
			{
				LOG(CPU,"[%08x] Diff CPSR %08x(vba) vs %08x",currentARM->r[ARM_REG_PC],temp[16],currentARM->GetCPSR());
				Core_Pause();
			}
			_dbg_update_();
		}
		else
		{
			static bool firsteof=true;
			if (firsteof)
			{
				firsteof=false;
				LOG(CPU,"End of log.");
			}
		}
	}
	count++;
#endif
	currentARM->blockCache.SingleStep();
	*/

}

void Core_Run()
{
#if _DEBUG
	host->UpdateDisassembly();
#endif

	while (true)
	{
		switch(coreState) 
		{
		case CORE_RUNNING:
			//1: enter a fast runloop
			//Core_FastRun();
			//break;

		case CORE_RUNNINGDEBUG:
			//1: check for cpucompare
//			if (CPUCompare::IsEnabled() && g_Branch)
//			{
//				g_Branch = false;
//				CPUCompare::Sync();
//			}

			//2: check for breakpoint
#if defined(_DEBUG) && defined(BREAKPOINTS)
			if (CBreakPoints::IsAddressBreakPoint(currentCPU->GetPC()))
				//||
				//CBreakPoints::IsBreakOnCount(ppcState.DebugCount))
			{
				Core_Pause();
				if (CBreakPoints::IsTempBreakPoint(currentCPU->GetPC()))
					CBreakPoints::RemoveBreakPoint(currentCPU->GetPC());
				break;
			}
#endif


			//3: do a step
			/*
			if (arm7.enabled)
			{
				currentCPU=&arm7;
				Core_SingleStep();
			}
			if (arm9.enabled)
			{
				currentCPU=&arm9;
				Core_SingleStep();
			}*/
			//currentCPU = &mipsr4k;
			if (coreState == CORE_POWERDOWN)
				return;
			Core_SingleStep();
			break;

		case CORE_STEPPING:
			//1: wait for step command..
			WaitForSingleObject( m_hStepEvent, INFINITE );
			ResetEvent(m_hStepEvent);
			if (coreState == CORE_POWERDOWN)
				return;
			//2: check for cpu compare
			//if (CPUCompare::IsEnabled() && g_Branch)
			//{
			//	g_Branch = false;
			//	CPUCompare::Sync();
			//}

			//3: do a step
			/*
			if (arm7.enabled)
			{
				currentCPU=&arm7;
				Core_SingleStep();
			}
			if (arm9.enabled)
			{
				currentCPU=&arm9;
				Core_SingleStep();
			}*/

			currentCPU = &mipsr4k;
			Core_SingleStep();
			//4: update disasm dialog
#ifdef _DEBUG
			host->UpdateDisassembly();
			host->UpdateMemView();
#endif
			break;

		case CORE_POWERDOWN:
			//1: Exit loop!!
			return; 
		}
	}

}

void Core_EnableStepping(bool step)
{
	if (step)
	{
		//PowerPC::Pause();
		Sleep(1);
#if _DEBUG
		host->SetDebugMode(true);
#endif
		coreState=CORE_STEPPING;
	}
	else
	{
#if _DEBUG
		host->SetDebugMode(false);
#endif
		coreState=host->IsDebuggingEnabled() ? CORE_RUNNINGDEBUG : CORE_RUNNING;
		//PowerPC::Start();
		SetEvent(m_hStepEvent); //TODO: pulseevent is flawed and can be lost
	}

}



void IdealLoop()
{
	while (true)
	{
		currentCPU = &arm7;
		//int cyclesRun = arm9->RunCycles(slice[0]);
		//int cyclesRun2 = factor * arm7->RunCycles(slice[1]);
		//AdvanceTimersAndStuff(cyclesRun2);
	}
}





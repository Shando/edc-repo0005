#pragma once

#include "FileSystem.h"


class MetaFileSystem : public IHandleAllocator, IFileSystem
{
	u32 current;
	struct System
	{
		std::string prefix;
		IFileSystem *system;
	};
	std::vector<System> fileSystems;
	
	std::string currentDirectory;

public:
	MetaFileSystem() {current=6;}
	void Mount(std::string prefix, IFileSystem *system);

	void Unmount(IFileSystem *system);

	u32 GetNewHandle() {return current++;}
	void FreeHandle(u32 handle) {}

	IFileSystem *GetHandleOwner(u32 handle);
	bool MapFilePath(std::string inpath, std::string &outpath, IFileSystem **system);

	std::vector<FileInfo> GetDirListing(std::string path);
	u32      OpenFile(std::string filename, FileAccess access);
	void     CloseFile(u32 handle);
	size_t   ReadFile(u32 handle, u8 *pointer, s64 size);
	size_t   WriteFile(u32 handle, const u8 *pointer, s64 size);
	size_t   SeekFile(u32 handle, s32 position, FileMove type);
	FileInfo GetFileInfo(std::string filename);
	bool     OwnsHandle(u32 handle) {return false;}
	virtual void ChDir(std::string dir) {currentDirectory = dir;}
	inline size_t GetSeekPos(u32 handle)
	{
		return SeekFile(handle, 0, FILEMOVE_CURRENT);
	}
};

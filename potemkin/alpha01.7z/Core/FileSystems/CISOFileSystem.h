#pragma once

#include "FileSystem.h"

class CISOFileSystem : public IFileSystem
{
	std::string isoFile;
	FILE *iso;
	struct TreeEntry
	{
		TreeEntry(){}
		~TreeEntry()
		{
			for (unsigned int i=0; i<children.size(); i++)
				delete children[i];
			children.clear();
		}

		std::string name;
		u32 flags;
		u32 startingPosition;
		u32 size;
		bool isDirectory;

		std::vector<TreeEntry*> children;
	};

	struct OpenFileEntry
	{
		TreeEntry *file;
		unsigned int seekPos;
	};
	

	typedef std::map<u32,OpenFileEntry> EntryMap;
	EntryMap entries;
	IHandleAllocator *hAlloc;
	TreeEntry *treeroot;

	void ReadDirectory(u32 startsector, u32 dirsize, TreeEntry *root);
	TreeEntry *GetFromPath(std::string path);
public:
	CISOFileSystem(IHandleAllocator *_hAlloc, std::string _isoFile);
	~CISOFileSystem();
	std::vector<FileInfo> GetDirListing(std::string path);
	u32      OpenFile(std::string filename, FileAccess access);
	void     CloseFile(u32 handle);
	size_t   ReadFile(u32 handle, u8 *pointer, size_t size);
	size_t   WriteFile(u32 handle, const u8 *pointer, size_t size);
	size_t   SeekFile(u32 handle, s32 position, FileMove type);
	FileInfo GetFileInfo(std::string filename);
	bool     OwnsHandle(u32 handle);
};
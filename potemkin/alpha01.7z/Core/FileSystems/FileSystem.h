#pragma once


#include "../../Globals.h"



enum FileAccess
{
	FILEACCESS_NONE=0,
	FILEACCESS_READ=1,
	FILEACCESS_WRITE=2,
	FILEACCESS_APPEND=4,
	FILEACCESS_CREATE=8
};

enum FileMove
{
	FILEMOVE_BEGIN=0,
	FILEMOVE_CURRENT=1,
	FILEMOVE_END=2
};

enum FileType
{
	FILETYPE_NORMAL=1,
	FILETYPE_DIRECTORY=2
};


class IHandleAllocator 
{
public:
	virtual u32 GetNewHandle() = 0;
	virtual void FreeHandle(u32 handle) = 0;
};

struct FileInfo
{
	FileInfo() {size=0;access=0;type=FILETYPE_NORMAL;isOnSectorSystem=false;}
	std::string name;
	s64 size;
	u32 access; //unix 777
	FileType type;

	bool isOnSectorSystem;
	u32 startSector;
	u32 numSectors;
};



class IFileSystem
{
public:
	//utilities
	void RecurseAndLog();

	//Obligatory
	virtual std::vector<FileInfo> GetDirListing(std::string path) = 0;
	virtual u32      OpenFile(std::string filename, FileAccess access) = 0;
	virtual void     CloseFile(u32 handle) = 0;
	virtual size_t   ReadFile(u32 handle, u8 *pointer, s64 size) = 0;
	virtual size_t   WriteFile(u32 handle, const u8 *pointer, s64 size) = 0;
	virtual size_t   SeekFile(u32 handle, s32 position, FileMove type) = 0;
	virtual FileInfo GetFileInfo(std::string filename) = 0;
	virtual bool     OwnsHandle(u32 handle) = 0;

	//Optional
};


class EmptyFileSystem : public IFileSystem
{
public:
	std::vector<FileInfo> GetDirListing(std::string path) {std::vector<FileInfo> vec; return vec;}
	u32      OpenFile(std::string filename, FileAccess access) {return 0;}
	void     CloseFile(u32 handle) {}
	size_t   ReadFile(u32 handle, u8 *pointer, s64 size) {return 0;}
	size_t   WriteFile(u32 handle, const u8 *pointer, s64 size) {return 0;}
	size_t   SeekFile(u32 handle, s32 position, FileMove type) {return 0;}
	FileInfo GetFileInfo(std::string filename) {FileInfo f; return f;}
	bool     OwnsHandle(u32 handle) {return false;}
};



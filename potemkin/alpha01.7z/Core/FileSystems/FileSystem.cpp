#include "stdafx.h"
#include "FileSystem.h"


void IFileSystem::RecurseAndLog()
{
	
}

#pragma once

#include "FileSystem.h"

#include "BlockDevices.h"


class ISOFileSystem : public IFileSystem
{
	struct TreeEntry
	{
		TreeEntry(){}
		~TreeEntry()
		{
			for (unsigned int i=0; i<children.size(); i++)
				delete children[i];
			children.clear();
		}

		std::string name;
		u32 flags;
		u32 startingPosition;
		s64 size;
		bool isDirectory;

		std::vector<TreeEntry*> children;
	};

	struct OpenFileEntry
	{
		TreeEntry *file;
		unsigned int seekPos;
		bool isRawSector;
		u32 sectorStart;
		u32 openSize;
	};
	

	typedef std::map<u32,OpenFileEntry> EntryMap;
	EntryMap entries;
	IHandleAllocator *hAlloc;
	TreeEntry *treeroot;
	BlockDevice *blockDevice;

	TreeEntry entireISO;

	void ReadDirectory(u32 startsector, u32 dirsize, TreeEntry *root);
	TreeEntry *GetFromPath(std::string path);

public:
	ISOFileSystem(IHandleAllocator *_hAlloc, BlockDevice *_blockDevice);
	~ISOFileSystem();
	std::vector<FileInfo> GetDirListing(std::string path);
	u32      OpenFile(std::string filename, FileAccess access);
	void     CloseFile(u32 handle);
	size_t   ReadFile(u32 handle, u8 *pointer, s64 size);
	size_t   WriteFile(u32 handle, const u8 *pointer, s64 size);
	size_t   SeekFile(u32 handle, s32 position, FileMove type);
	FileInfo GetFileInfo(std::string filename);
	bool     OwnsHandle(u32 handle);
};
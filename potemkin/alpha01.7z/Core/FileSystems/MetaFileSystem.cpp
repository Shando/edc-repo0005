#include "stdafx.h"
#include "MetaFileSystem.h"


IFileSystem *MetaFileSystem::GetHandleOwner(u32 handle)
{
	for (unsigned int i=0; i<fileSystems.size(); i++)
	{
		if (fileSystems[i].system->OwnsHandle(handle))
			return fileSystems[i].system; //got it!
	}	
	//none found?
	return 0;
}

bool MetaFileSystem::MapFilePath(std::string inpath, std::string &outpath, IFileSystem **system)
{
	for (unsigned int i=0; i<fileSystems.size(); i++)
	{
		int prefLen = fileSystems[i].prefix.size();
		if (fileSystems[i].prefix == inpath.substr(0,prefLen))
		{
			outpath = inpath.substr(prefLen);
			*system = fileSystems[i].system;
			return true;
		}
	}
	return false;
}

void MetaFileSystem::Mount(std::string prefix, IFileSystem *system)
{
	System x;
	x.prefix=prefix;
	x.system=system;
	fileSystems.push_back(x);
}

u32 MetaFileSystem::OpenFile(std::string filename, FileAccess access)
{
	std::string of;
	if (filename.find(':') == std::string::npos)
	{
		filename = currentDirectory + "/" + filename;
		LOG(HLE,"Expanded path to %s",filename.c_str());
	}
	IFileSystem *system;
	if (MapFilePath(filename, of, &system))
	{
		return system->OpenFile(of, access);
	}
	else
	{
		return 0;
	}
}

FileInfo MetaFileSystem::GetFileInfo(std::string filename)
{
	std::string of;
	IFileSystem *system;
	if (MapFilePath(filename, of, &system))
	{
		return system->GetFileInfo(of);
	}
	else
	{
		FileInfo bogus; // TODO
		return bogus; 
	}
}

std::vector<FileInfo> MetaFileSystem::GetDirListing(std::string path)
{
	std::string of;
	IFileSystem *system;
	if (MapFilePath(path, of, &system))
	{
		return system->GetDirListing(of);
	}
	else
	{
		std::vector<FileInfo> empty;
		return empty;
	}
}


void MetaFileSystem::CloseFile(u32 handle)
{
	IFileSystem *sys = GetHandleOwner(handle);
	if (sys)
		sys->CloseFile(handle);
}

size_t MetaFileSystem::ReadFile(u32 handle, u8 *pointer, s64 size)
{
	IFileSystem *sys = GetHandleOwner(handle);
	if (sys)
		return sys->ReadFile(handle,pointer,size);
	else
		return 0;
}

size_t MetaFileSystem::WriteFile(u32 handle, const u8 *pointer, s64 size)
{
	IFileSystem *sys = GetHandleOwner(handle);
	if (sys)
		return sys->WriteFile(handle,pointer,size);
	else
		return 0;
}

size_t MetaFileSystem::SeekFile(u32 handle, s32 position, FileMove type)
{
	IFileSystem *sys = GetHandleOwner(handle);
	if (sys)
		return sys->SeekFile(handle,position,type);
	else
		return 0;
}


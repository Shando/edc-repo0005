#pragma once

#include "../../Globals.h"


class BlockDevice
{
public:
	virtual ~BlockDevice() {}
	virtual bool ReadBlock(int blockNumber, u8 *outPtr) = 0;
	int GetBlockSize() const { return 2048;} //implied, it cannot be changed
	virtual int GetNumBlocks() = 0;
};


class CISOFileBlockDevice : public BlockDevice
{
	std::string filename;
	FILE *f;
	u32 *index;
	int indexShift;
	u32 blockSize;
	int numBlocks;
public:
	CISOFileBlockDevice(std::string _filename);
	~CISOFileBlockDevice();
	bool ReadBlock(int blockNumber, u8 *outPtr);
	int GetNumBlocks() { return numBlocks;}
};



class FileBlockDevice : public BlockDevice
{
	std::string filename;
	FILE *f;
	size_t filesize;
public:
	FileBlockDevice(std::string _filename);
	~FileBlockDevice();
	bool ReadBlock(int blockNumber, u8 *outPtr);
	int GetNumBlocks() {return filesize/GetBlockSize();}
};


#include "stdafx.h"
#include "System.h"
#include "DS/DSSystem.h"
#include "GBA/GBASystem.h"
#include "PSP/PSPSystem.h"
#include "GP32/GP32System.h"

System *systems[4] = {&PSPSystem,&GBASystem,&GP32System,&DSSystem};
System *currentSystem;

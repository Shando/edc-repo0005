#include "stdafx.h"

#include "../Misc.h"
#include "../MemMap.h"
#include "../Core.h"

#include "../ARM/ARM.h"

#include "GBASystem.h"
#include "GBAIO.h"
#include "GBADisplay.h"

#include "../Graphics/G2D.h"

//ugly, remove
#include "../../Windows/WndMainWindow.h"


System GBASystem = 
{
	"Game Boy Advance",
	"Nintendo",
	"*.gba;*.bin;*.elf",
	1, //one cpu
	1, //one display
	1, //one controller

	0x08000000,
	{CPUTYPE_ARM7},
	{16*1024*1024},

	GBA_HWAdvance,
	GBA_SWI
};

void WriteVRAM8(u32 address, u8 value);

MemRegionInfo GBAregions[] =
{
	//rom first for easy access
	{"ROM ws 1",     CPU_0,       MRTYPE_MEMORY, 0x08000000,0x0A000000,0},
	{"ROM ws 2",     CPU_0,       MRTYPE_MIRROR, 0x0A000000,0x0C000000,0},
	{"ROM ws 3",     CPU_0,       MRTYPE_MIRROR, 0x0C000000,0x0E000000,0},

	{"BIOS/GBA.bios",CPU_0,       MRTYPE_ROM,    0x00000000,0x00004000,0,0,0,0,WriteIllegal8,WriteIllegal16,WriteIllegal32},
	{"WRAM",         CPU_0,       MRTYPE_MEMORY, 0x02000000,0x03000000,0x3ffff},
	{"IWRAM",        CPU_0,       MRTYPE_MEMORY, 0x03000000,0x04000000,0x7fff},
	{"IO",           CPU_0,       MRTYPE_SPECIAL,0x04000000,0x05000000,0,ReadGBAIO8,ReadGBAIO16,ReadGBAIO32,WriteGBAIO8,WriteGBAIO16,WriteGBAIO32,ReadGBAIONoEffect,GetGBAIORegName},
	{"Palettes",     CPU_0,       MRTYPE_MEMORY, 0x05000000,0x05000400,0},
	{"BG VRAM",      CPU_0,       MRTYPE_MEMORY, 0x06000000,0x06018000,0,0,0,0,WriteVRAM8,0,0}, //special write16 later
	//{"OBJ VRAM",     CPU_0,       MRTYPE_MEMORY, 0x06010000,0x06018000,0,0,0,0,WriteVRAM8,0,0}, //special write16 later
	{"OAM",          CPU_0,       MRTYPE_MEMORY, 0x07000000,0x07000400,0},
	{"SRAM",         CPU_0,       MRTYPE_MEMORY, 0x0E000000,0x0E010000,0},
};


void WriteVRAM8(u32 address, u8 value)
{
	u32 origAddress = address;
	address&=0x1ffff;
	if (address>0x18000)
		return;
	u16 db = value|(value<<8);
	WriteMem16(origAddress,db);
	//*(u16*)(arm7.memMap.regions[GBAREGION_VRAM].memPointer + (address&0x1fffe))=db;
}


const int numGBARegions = sizeof(GBAregions)/sizeof(MemRegionInfo);


void GBA_Init()
{
	currentSystem = &GBASystem;
	cpus[0] = &arm7;
	numCPUs=1;
	MemMap_Init(GBAregions,numGBARegions,16,0x10000000);

	currentCPU=&arm7;
	arm7.highVectors=false;
	arm7.fakeBios=true;
	arm7.Reset();
	arm7.r[15] = 0x08000000;

	arm7.enabled=true;
	arm9.enabled=false;

	g2dCores[0].g2 = &gbaIO.gfxregs;
	g2dCores[0].paletteram = arm7.memMap.GetMemPointer(0x05000000);
	g2dCores[0].bgvram     = arm7.memMap.GetMemPointer(0x06000000);
	g2dCores[0].objvram    = arm7.memMap.GetMemPointer(0x06010000);
	g2dCores[0].oam        = arm7.memMap.GetMemPointer(0x07000000);
	g2dCores[0].Init(240,160);


	GBAIO_SelfTest();
	GBAIO_Init();

	GBADisplay_Init();
}

void GBA_Shutdown()
{
	GBADisplay_Shutdown();
	MemMap_Shutdown();
}


int stepSize = 0;
int curTimer = 0;

int hblTimer = 960;


void GBA_UpdateInterrupts()
{
	if ((gbaIO.IF & gbaIO.IE)) //TODO: && (not in interrupt) ?
	{
		if (gbaIO.IME)
		{
			//for now let's break;
			//Core_EnableStepping(true);
			LOG(CPU,"IRQ! IE=%04x IF=%04x",gbaIO.IE,gbaIO.IF);
			//cause interrupt
			ARMState *currentARM = static_cast<ARMState*>(currentCPU);
			currentARM->Irq();
		}
	}
}


void GBA_SWI()
{
	//GBA_UpdateInterrupts();
	ARMState *currentARM = static_cast<ARMState*>(currentCPU);
	currentARM->SWI();
}

// TODO : turn inside out :)
void GBA_HWAdvance(int cycles)
{
	curTimer-=cycles;
	if (curTimer<0) //while?
	{
		int extraCycles = 0;
		hblTimer-=stepSize;
		if (hblTimer<=0)
		{
			gbaIO.dispstat ^= DISPSTAT_HBLANK;

			// Horizontal blank
			if (gbaIO.dispstat & DISPSTAT_HBLANK)
			{
				//render the line here
				if ((gbaIO.dispstat & DISPSTAT_VBLANK) == 0)
				{
					g2dCores[0].DrawLine(gbaIO.vcount, gbaIO.dispcnt, gbaIO.dispstat);

					//do DMAs only when not in vblank area!
					DMAC_HBlank(&gbaIO.dmac);
				}

				if (gbaIO.dispstat & DISPSTAT_HBLANKIRQE)
				{
					gbaIO.IF |= IE_HBLANK;
					GBA_UpdateInterrupts();
				}

				g2dCores[0].HBlank();
				hblTimer += 272; 
			}
			else //Horizontal draw
			{
				//ok we're done with this line
				gbaIO.vcount++;
				if (gbaIO.vcount == gbaIO.vcountline)
				{
					gbaIO.dispstat |= DISPSTAT_VCOUNT;
					if (gbaIO.dispstat & DISPSTAT_VCOUNTIRQE)
					{
						gbaIO.IF |= IE_VCOUNTMATCH;
						LOG(INTC,"Vcount match (%d)! Causing irq..",gbaIO.vcount);
						GBA_UpdateInterrupts();
					}
				}
				else
				{
					gbaIO.dispstat &= ~DISPSTAT_VCOUNT;
				}
				
				if (gbaIO.vcount == 160)
				{
					gbaIO.dispstat |= DISPSTAT_VBLANK;
					//entering VBLANK
					if (gbaIO.dispstat & DISPSTAT_VBLANKIRQE)
					{
						gbaIO.IF |= IE_VBLANK;
						GBA_UpdateInterrupts();
					}

					for (int i=0; i<3; i++)
					{
						DMAChan &chan = gbaIO.dmac.channels[i];
						if (chan.dmaCNT.startTiming == DMATIMING_VBLANK)
						{
							extraCycles += DMAC_DoDMA(&gbaIO.dmac,i);
						}
					}

					//do the screen blit here
					//MainWindow::Redraw();
					GBADisplay_Draw();
				}
				else if (gbaIO.vcount == 228)
				{
					g2dCores[0].VBlank();
					gbaIO.dispstat &= ~DISPSTAT_VBLANK;
					gbaIO.vcount = 0;
				}
			    hblTimer += 960; 
			}
			hblTimer = 960;
		}

		curTimer = hblTimer; // smallest of existing timers
		curTimer-=extraCycles;
		stepSize = curTimer;
	}
}

#pragma once

void GBADisplay_Init();
void GBADisplay_Draw();
void GBADisplay_Shutdown();
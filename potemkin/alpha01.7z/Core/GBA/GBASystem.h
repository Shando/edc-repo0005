#pragma once

#include "../System.h"
#include "../MemMap.h"

extern System GBASystem;

extern MemRegionInfo GBAregions[];

extern const int numGBARegions;

void GBA_Init();
void GBA_Shutdown();
void GBA_HWAdvance(int cycles);
void GBA_UpdateInterrupts();
void GBA_SWI();
#include "stdafx.h"

#include "../ARM/ARM.h"
#include "../HW.h"
#include "../Shared/N_Keypad.h"
#include "GBAIO.h"
#include "GBASystem.h"


RegInfo GBADispRegs[] = 
{   
	{true,true,     "DISPCNT",     "LCD Control"},                            //00h       
	{true,true,     "-",           "Undocumented - Green Swap"},			  //02h       
	{true,true,     "DISPSTAT",    "General LCD Status (STAT,LYC)"},		  //04h       
	{true,false,    "VCOUNT",      "Vertical Counter (LY)"},				  //06h       
	{true,true,     "BG0CNT",      "BG0 Control"},							  //08h       
	{true,true,     "BG1CNT",      "BG1 Control"},							  //0Ah       
	{true,true,     "BG2CNT",      "BG2 Control"},							  //0Ch       
	{true,true,     "BG3CNT",      "BG3 Control"},							  //0Eh       
	{false,true,    "BG0HOFS",     "BG0 X-Offset"},							  //10h       
	{false,true,    "BG0VOFS",     "BG0 Y-Offset"},							  //12h       
	{false,true,    "BG1HOFS",     "BG1 X-Offset"},							  //14h       
	{false,true,    "BG1VOFS",     "BG1 Y-Offset"},							  //16h       
	{false,true,    "BG2HOFS",     "BG2 X-Offset"},							  //18h       
	{false,true,    "BG2VOFS",     "BG2 Y-Offset"},							  //1Ah       
	{false,true,    "BG3HOFS",     "BG3 X-Offset"},							  //1Ch       
	{false,true,    "BG3VOFS",     "BG3 Y-Offset"},							  //1Eh       
	{false,true,    "BG2PA",       "BG2 Rot/Scale (dx)"},					  //20h       
	{false,true,    "BG2PB",       "BG2 Rot/Scale (dmx)"},					  //22h       
	{false,true,    "BG2PC",       "BG2 Rot/Scale (dy)"},					  //24h       
	{false,true,    "BG2PD",       "BG2 Rot/Scale (dmy)"},					  //26h       
	{false,true,    "BG2X",        "BG2 RefPoint X"},						  //28h       
	{false,true,    "BG2X",        "BG2 RefPoint X"},						  //2Ah       
	{false,true,    "BG2Y",        "BG2 RefPoint Y"},						  //2Ch       
	{false,true,    "BG2Y",        "BG2 RefPoint Y"},						  //2Eh       
	{false,true,    "BG3PA",       "BG3 Rot/Scale A (dx)"},					  //30h       
	{false,true,    "BG3PB",       "BG3 Rot/Scale B (dmx)"},				  //32h       
	{false,true,    "BG3PC",       "BG3 Rot/Scale C (dy)"},					  //34h       
	{false,true,    "BG3PD",       "BG3 Rot/Scale D (dmy)"},				  //36h       
	{false,true,    "BG3X",        "BG3 RefPoint X-Coordinate"},			  //38h       
	{false,true,    "BG3X",        "BG3 RefPoint X-Coordinate"},			  //3Ah       
	{false,true,    "BG3Y",        "BG3 RefPoint Y-Coordinate"},			  //3Ch       
	{false,true,    "BG3Y",        "BG3 RefPoint Y-Coordinate"},			  //3Eh       
	{false,true,    "WIN0H",       "Win0 HorizDim"},						  //40h       
	{false,true,    "WIN1H",       "Win1 HorizDim"},						  //42h       
	{false,true,    "WIN0V",       "Win0 VertDim"},							  //44h       
	{false,true,    "WIN1V",       "Win1 VertDim"},							  //46h       
	{true, true,    "WININ",       "CtrlIns of Win(s)"},					  //48h       
	{true, true,    "WINOUT",      "CtrlOuts of Win & Ins of OBJ Win"},		  //4Ah       
	{false,true,    "MOSAIC",      "Mosaic Size"},							  //4Ch       
	{false,false,   "-",           "Not used"},								  //4Eh       
	{true, true,    "BLDCNT",      "Color FX Selection"},					  //50h       
	{false,true,    "BLDALPHA",    "Alpha Blend Coefs"},					  //52h       
	{false,true,    "BLDY",        "Brightness Coef"},						  //54h       
};



GBAIORegion gbaIO;

void GBAIO_Init()
{
	memset(&gbaIO, 0, sizeof(gbaIO));

	//Setup default hw register values
	gbaIO.gfxregs.bg2PA = 0x100; //1:1 scaling, no rotation
	gbaIO.gfxregs.bg2PD = 0x100;
	gbaIO.gfxregs.bg3PA = 0x100;
	gbaIO.gfxregs.bg3PD = 0x100;
	gbaIO.dispcnt=0x80;
	gbaIO.keyinput = 0x3ff;
}

void GBAIO_SelfTest()
{
	//check so that i haven't messed up the struct :)
	_dbg_assert_msg_(IO,sizeof(DMACNT)==4,"GBAIO selftest 0");
	gbaIO.soundregs.sound1cnt_l=0xBAAD;
	_dbg_assert_msg_(IO,((u16*)&gbaIO)[0x60/2] == 0xBAAD,"GBAIO selftest 1"); //, (char *)&gbaIO.soundregs.sound1cnt_l - (char*)&gbaIO);
	gbaIO.dmac.channels[0].sourceAddr=0xBAADF00D;
	_dbg_assert_msg_(IO,((u32*)&gbaIO)[0xb0/4] == 0xBAADF00D,"GBAIO selftest 2"); //, (char *)&gbaIO.dmacontroller.channels[0].sourceAddr - (char*)&gbaIO);
	gbaIO.timers[0].cnt_l=0xBAAD;
	_dbg_assert_msg_(IO,((u16*)&gbaIO)[0x100/2] == 0xBAAD,"GBAIO selftest 3"); //, (char *)&gbaIO.timers[0].cnt_l - (char*)&gbaIO);
	gbaIO.keyinput=0xBAAD;
	_dbg_assert_msg_(IO,((u16*)&gbaIO)[0x130/2] == 0xBAAD,"GBAIO selftest 4"); //, (char *)&gbaIO.keyinput - (char*)&gbaIO);
	gbaIO.IE=0xBAAD;
	_dbg_assert_msg_(IO,((u16*)&gbaIO)[0x200/2] == 0xBAAD,"GBAIO selftest 5"); //, (char *)&gbaIO.IE - (char*)&gbaIO);

	memset(&gbaIO,0,sizeof(gbaIO));
}



u8   MEMDECL ReadGBAIO8 (u32 address)
{
	address&=0xfff;
	switch(address) {
	case 0x6:
		break;
		//seen ones:
	case 0x89: //TODO: fix
		break;
	case 0x300:
		break;
	default:
		LOG(DISPLAYREGS,"8-bit read from GBA IO?? %08x",address);
	}
	return ((u8 *)&gbaIO)[address];
}

u16  MEMDECL ReadGBAIO16(u32 address)
{
	address&=0xfff;
	switch(address) 
	{
	case 0x0:
		break;
	case 0x4:
		break;
	case 0x6:
		break;

	case 0x8:break; //bg control
	case 0xA:break;
	case 0xC:break;
	case 0xE:break;

	case 0xB8: LOG(DMA,"R16 DMA0 count"); break;
	case 0xBA: LOG(DMA,"R16 DMA0 control"); break;
	case 0xC4: LOG(DMA,"R16 DMA1 count"); break;
	case 0xC6: LOG(DMA,"R16 DMA1 control"); break;
	case 0xD0: LOG(DMA,"R16 DMA2 count"); break;
	case 0xD2: LOG(DMA,"R16 DMA2 control"); break;
	case 0xDC: LOG(DMA,"R16 DMA3 count"); break;
	case 0xDE: LOG(DMA,"R16 DMA3 control"); break;

	case 0x100: /*LOG(TIMER,"R16 Timer0 counter/reload read");*/ break;
	case 0x10c: //timer
		break;

	case 0x128:
		break;
	case 0x200:
		LOG(INTC,"R16: Interrupt Enable read (%04x)",gbaIO.IE);
		break;
	case 0x202:
		LOG(INTC,"R16: Interrupt Flags/Request read (%04x)",gbaIO.IF);
		break;
	case 0x204:
		LOG(INTC,"R16: WaitCNT read (%04x)",gbaIO.waitcnt);
		break;
	case 0x208:
		LOG(MEMMAP,"R16: Interrupt Master Enable read: %04x", gbaIO.IME);
		break;
	case 0x130:
		N_Keypad_UpdateKeys(gbaIO.keyinput);
		break;
	case 0x300:
		LOG(IO,"R16 HALTCNT");
		break;
	default:
		LOG(IO,"Unknown 16-bit IO read: %04x",address);
		break;
	}
	if (address<sizeof(gbaIO))
		return ((u16 *)&gbaIO)[address>>1];
	else
		return 0;
}

u32  MEMDECL ReadGBAIO32(u32 address)
{
	address&=0xfff;
	int rotate = 0;
	if (address & 3)
	{
		rotate = (address&3)*8;
		address &= ~3;
	}
	switch(address&0xFFF) 
	{
	case 0x000:
		break;
	case 0x004:
		//read dispstat
		break;

	case 0x0DC:
		LOG(DMA,"R32 DMA3 count/cnt : %08x",gbaIO.dmac.channels[3].dmaCNT.hex); break;
		break;
	case 0x120:
		//SIO 32 bit, need to handle separately
		break;
	case 0x130:
		N_Keypad_UpdateKeys(gbaIO.keyinput);
		break;
	case 0x200:
		LOG(INTC,"R32 IE/IF");
		break;
	case 0x204:
		LOG(MEMMAP,"R32 Interrupt Flags/Request read (%04x)", gbaIO.IME);
		break;
	case 0x208:
		LOG(MEMMAP,"R32 Interrupt Master Enable read: %04x", gbaIO.IME);
		break;
	default:
		LOG(IO,"Unknown 32-bit IO read: %04x",address);
		break;
	}
	if (address < sizeof(gbaIO))
		return _rotr(((u32 *)&gbaIO)[address>>2],rotate);
	else
		return 0;
}

void MEMDECL WriteGBAIO8 (u32 address, u8  value)
{
	address&=0xfff;
	//LOG(DISPLAYREGS,"8-bit write to GBA IO?? %08x = %02x",address,value);
	u16 valhere = ((u16 *)&gbaIO)[address>>1];
	if (address & 1)
		WriteGBAIO16(address&~1,(valhere&0xFF) | (value<<8));
	else
		WriteGBAIO16(address,(valhere&0xFF00) | (value));
}



void MEMDECL WriteGBAIO16(u32 address, u16 value)
{
	address&=0xfff;
	switch(address&0xFFF) 
	{
	case 0x0:
		LOG(G2D,"W16 DispCNT: Mode set: %i (%04x)", value&7, value);
		break;
	case 0x04:
		LOG(G2D,"W16 DispSTAT: %04x", value);
		break;
	case 0x08: //BG0CNT
	case 0x0A: //BG1CNT
	case 0x0C: //BG2CNT
	case 0x0E: //BG3CNT
	case 0x10: //BG2HOFS
	case 0x12: //BG2VOFS
	case 0x14: //BG3HOFS
	case 0x16: //BG3VOFS
	case 0x18: //BG2HOFS
	case 0x1A: //BG2VOFS
	case 0x1C: //BG3HOFS
	case 0x1E: //BG3VOFS

	case 0x20: //bg2 rotscale
	case 0x22: 
	case 0x24: 
	case 0x26: 
	
	case 0x28:
	case 0x2A:
	case 0x2C:
	case 0x2E:

	case 0x30: //bg3 rotscale
	case 0x32: 
	case 0x34: 
	case 0x36: 

	case 0x38:
	case 0x3A:
	case 0x3C:
	case 0x3E:

	case 0x40: //windows
	case 0x42: 
	case 0x44: 
	case 0x46: 
	case 0x48: 
	case 0x4A: 
	case 0x4C: 

	case 0x50: //color effect
	case 0x52: //blendalpha
	case 0x54: //brightness
		g2dCores[0].Write16Notify(address,value);
		break;

	case 0x80: LOG(SOUND,"W16 SOUNDCNT_L written"); break;
	case 0x82: LOG(SOUND,"W16 SOUNDCNT_H written"); break;
	case 0x84: LOG(SOUND,"W16 SOUNDCNT_X written"); break;

	case 0x100: LOG(TIMER,"W16 Timer0 counter/reload = %04x",value); break;
	case 0x102: LOG(TIMER,"W16 Timer0 control = %04x",value); break;
	case 0x104: LOG(TIMER,"W16 Timer1 counter/reload = %04x",value); break;
	case 0x106: LOG(TIMER,"W16 Timer1 control = %04x",value); break;
	case 0x108: LOG(TIMER,"W16 Timer2 counter/reload = %04x",value); break;
	case 0x10A: LOG(TIMER,"W16 Timer2 control = %04x",value); break;
	case 0x10C: LOG(TIMER,"W16 Timer3 counter/reload = %04x",value); break;
	case 0x10E: LOG(TIMER,"W16 Timer3 control = %04x",value); break;

	case 0x128:
		LOG(IO,"W16 SIOCNT: %04x", value);
		break;
	case 0x134:
		LOG(IO,"W16 RCNT (SIO mode): %04x", value);
		break;

	case 0x200:
		LOG(INTC,"W16 Interrupt Enable : %04x", value);
		break;
	case 0x202:
		LOG(INTC,"W16 Interrupt Acknowledged: %04x", value);
		gbaIO.IF &= ~value;  //acknowledge
		return; //don't allow the write
	case 0x204:
		LOG(MEMMAP,"W16 WaitCNT written: %04x", value);
		break;
	case 0x208:
		LOG(INTC,"W16 Interrupt Master Enable: %04x", value);
		break;
	case 0x300:
		//LOG(IO,"W16 (strange!!) HALTCNT: %04x",value);
		break;
	case 0xB8: LOG(DMA,"W16 DMA0 count = %d",value); break;
	case 0xBA: LOG(DMA,"W16 DMA0 control = %04x",value); DMAC_CntWrite16(&gbaIO.dmac,0,value); return;
	case 0xC4: LOG(DMA,"W16 DMA1 count = %d",value); break;
	case 0xC6: LOG(DMA,"W16 DMA1 control = %04x",value); DMAC_CntWrite16(&gbaIO.dmac,1,value); return;
	case 0xD0: LOG(DMA,"W16 DMA2 count = %d",value); break;
	case 0xD2: LOG(DMA,"W16 DMA2 control = %04x",value); DMAC_CntWrite16(&gbaIO.dmac,2,value); return;
	case 0xDC: LOG(DMA,"W16 DMA3 count = %d",value); break;
	case 0xDE: LOG(DMA,"W16 DMA3 control = %04x",value); DMAC_CntWrite16(&gbaIO.dmac,3,value); return;
	default:
		LOG(IO,"Unknown 16-bit IO write: %04x <- %04x",address,value);
		break;
	}

	if (address<sizeof(gbaIO))
		((u16 *)&gbaIO)[address>>1] = value;
}



void MEMDECL WriteGBAIO32(u32 address, u32 value)
{
	bool unknown = false;
	address&=0xfff;
	switch(address&0xFFF) 
	{
	case 0x0:
		LOG(G2D,"Mode set: %i (%08x)", value&7,value);
		break;
	case 0x10: 
	case 0x14:
	case 0x18:
	case 0x1C:

	case 0x20:  //bgplane 2 rotscale
	case 0x24:  //bgplane 2 rotscale
	case 0x28:  //bgplane 2 rotscale
	case 0x2C:  //bgplane 2 rotscale

	case 0x40:  //window 0
	case 0x44:  //window 1
	case 0x4C:  //mosaic

	case 0x50:  //color special fx
	case 0x52:  //!!! unaligned !!! wtf  .. alpha blend
		g2dCores[0].Write32Notify(address,value);
		break;

	case 0x80: LOG(SOUND,"W32 SOUNDCNT written"); break;
	case 0x84: LOG(SOUND,"W32 SOUNDCNT_X written"); break;

	case 0x100: LOG(TIMER,"Timer0 control = %08x",value); break;
	case 0x120:
		//SIO 32 bit, need to handle separately
	default:
		unknown=true;
		break;
	}
	switch (address&0xFFF) 
	{
	case 0xB0: LOG(DMA,"W32 DMA0 source = %08x",value);  DMAC_SrcWrite32(&gbaIO.dmac, 0, value); break;
	case 0xB4: LOG(DMA,"W32 DMA0 dest = %08x",value);    DMAC_DstWrite32(&gbaIO.dmac, 0, value); break;
	case 0xB8: LOG(DMA,"W32 DMA0 control = %08x",value); DMAC_CntWrite32(&gbaIO.dmac, 0, value); return;
	case 0xBC: LOG(DMA,"W32 DMA1 source = %08x",value);  DMAC_SrcWrite32(&gbaIO.dmac, 1, value); break;
	case 0xC0: LOG(DMA,"W32 DMA1 dest = %08x",value);	DMAC_DstWrite32(&gbaIO.dmac, 1, value); break;
	case 0xC4: LOG(DMA,"W32 DMA1 control = %08x",value); DMAC_CntWrite32(&gbaIO.dmac, 1, value); return;
	case 0xC8: LOG(DMA,"W32 DMA2 source = %08x",value);  DMAC_SrcWrite32(&gbaIO.dmac, 2, value); break;
	case 0xCC: LOG(DMA,"W32 DMA2 dest = %08x",value);	DMAC_DstWrite32(&gbaIO.dmac, 2, value); break;
	case 0xD0: LOG(DMA,"W32 DMA2 control = %08x",value); DMAC_CntWrite32(&gbaIO.dmac, 2, value); return;
	case 0xD4: LOG(DMA,"W32 DMA3 source = %08x",value);  DMAC_SrcWrite32(&gbaIO.dmac, 3, value); break;
	case 0xD8: LOG(DMA,"W32 DMA3 dest = %08x",value);	DMAC_DstWrite32(&gbaIO.dmac, 3, value); break;
	case 0xDC: LOG(DMA,"W32 DMA3 control = %08x",value); DMAC_CntWrite32(&gbaIO.dmac, 3, value); return;
	default:
		if (unknown)
			LOG(IO,"Unknown 32-bit IO write: %04x <- %08x",address,value);
		break;
	}

	if (address<sizeof(gbaIO))
		((u32 *)&gbaIO)[address>>2] = value;

}

u32  MEMDECL ReadGBAIONoEffect(u32 address)
{
	return 0;
}


TCHAR* MEMDECL GetGBAIORegName(u32 address)
{
	if ((address&0xFFFFFF)<0x54)
	{
		return GBADispRegs[(address&0xFF) / 2].description;
	}
	else
		return "unknown";
}



#pragma once

#include "../MemMap.h"
#include "../HW.h"
#include "../Shared/N_DMA.h"
#include "../Graphics/G2D.h"

void GBAIO_SelfTest();
void GBAIO_Init();

u8   MEMDECL ReadGBAIO8 (u32 address);
u16  MEMDECL ReadGBAIO16(u32 address);
u32  MEMDECL ReadGBAIO32(u32 address);
u32  MEMDECL ReadGBAIONoEffect(u32 address);
TCHAR* MEMDECL GetGBAIORegName(u32 address);

void MEMDECL WriteGBAIO8 (u32 address, u8  value);
void MEMDECL WriteGBAIO16(u32 address, u16 value);
void MEMDECL WriteGBAIO32(u32 address, u32 value);

extern RegInfo GBADispRegs[];



struct Timer
{
	u16 cnt_l;
	u16 cnt_h;
};


struct SIO1 //start at 120h
{
	u16 siomulti1; //same place as siodata32;
	u16 siomulti2;
	u16 siomulti3;
	u16 siomulti4;
	u16 siocnt;
	u16 siomlt_send; //same place as siodata8
	u16 unused1;
	u16 unused2;
};

struct SIO2 // start at 134h
{
	u16 rcnt;
	u16 irprototype;
	u16 unused[4];
	u16 joycnt; //140h
	u16 unused2[7]; 
	u32 joyrecv; //150h
	u16 joytrans; //
	u16 joystat;
	u16 unused3[3];
};

struct GBASound
{
	u16 sound1cnt_l; //60h
	u16 sound1cnt_h;
	u16 sound1cnt_x;
	u16 unused1;
	
	u16 sound2cnt_l; //68h
	u16 unused2;
	u16 sound2cnt_h;
	u16 unused3;
	
	u16 sound3cnt_l; //70h
	u16 sound3cnt_h;
	u16 sound3cnt_x;
	u16 unused4;
	
	u16 sound4cnt_l; //78h
	u16 unused5;
	u16 sound4cnt_h;
	u16 unused6;

	u16 soundcnt_l; //80h
	u16 soundcnt_h;
	u16 soundcnt_x;
	u16 unused7;

	u16 soundbias; //88h
	u16 unused8[3];

	u8 waveram[16]; //90h
	u16 channelAFifo[2];
	u16 channelBFifo[2];

	u16 unused9[4];
};

struct GBAIORegion
{
	u16 dispcnt;
	u16 greenswap;
	u8 dispstat;
	u8 vcountline;
	u8 vcount;
	u8 unused;
	//0008
	G2 gfxregs;
	//0056
	u16 temp;
	//0058
	u32 temp2[2];
	//0060
	GBASound soundregs;
	//00b0
	DMAC dmac;

	u32 temp3[8];
	//0100
	Timer timers[4];
	u32 temp4[4];
    //0120
	SIO1 sio1;
	//0130
	u16 keyinput;
	u16 keystatus;
	//0134
	SIO2 sio2;
	//0160h
    u32 pad[4*10];
	u16 IE; //interrupt enable 200h
	u16 IF; //interrupt request / ack
	u16 waitcnt; //waitstate control
	u16 pad2;
	u16 IME; //interrupt master enable
};


enum
{
	DISPSTAT_VBLANK = (1<<0),
	DISPSTAT_HBLANK = (1<<1),
	DISPSTAT_VCOUNT = (1<<2),

	DISPSTAT_VBLANKIRQE = (1<<3),
	DISPSTAT_HBLANKIRQE = (1<<4),
	DISPSTAT_VCOUNTIRQE = (1<<5),
};


enum
{
	IE_VBLANK=(1<<0),
	IE_HBLANK=(1<<1),
	IE_VCOUNTMATCH=(1<<2),
	IE_TIMER0=(1<<3),
	IE_TIMER1=(1<<4),
	IE_TIMER2=(1<<5),
	IE_TIMER3=(1<<6),
	IE_SIO=(1<<7),
	IE_DMA0=(1<<8),
	IE_DMA1=(1<<9),
	IE_DMA2=(1<<10),
	IE_DMA3=(1<<11),
	IE_KEYPAD=(1<<12),
	IE_EXTERNAL=(1<<13),
};


#define GBA_IO_DMASTART 00b0
#define GBA_IO_DMAEND 0FE

enum
{
	GBAKEY_A = 0,
	GBAKEY_B = 1,
	GBAKEY_SELECT = 2,
	GBAKEY_START = 3,
	GBAKEY_RIGHT= 4,
	GBAKEY_LEFT= 5,
	GBAKEY_UP= 6,
	GBAKEY_DOWN= 7,
	GBAKEY_R= 8,
	GBAKEY_L= 9,
};

extern GBAIORegion gbaIO;

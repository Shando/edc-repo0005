#include "stdafx.h"
#include "gl/glext.h"
#include "GBADisplay.h"

#include "../Graphics/G2D.h"
#include "../Host.h"

static GLuint backbufTex;

void GBADisplay_Init()
{
	glPolygonMode (GL_FRONT_AND_BACK, GL_FILL);
	
	glDisable(GL_CULL_FACE);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);

	glShadeModel(GL_SMOOTH);

	glEnable(GL_TEXTURE_2D);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	

	glGenTextures(1,&backbufTex);


	glBindTexture(GL_TEXTURE_2D,backbufTex);
	glPixelStorei(GL_UNPACK_ALIGNMENT,1);
	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	//initialize a texture
 	glTexImage2D(GL_TEXTURE_2D,0,GL_RGB5_A1,256,256,0, GL_RGBA,GL_UNSIGNED_SHORT_1_5_5_5_REV,0);
}

void GBADisplay_Draw()
{
	host->BeginFrame();

	glClearColor(0,0,0,0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D,backbufTex);

	glTexSubImage2D(GL_TEXTURE_2D,0,0,0,256, 256, GL_RGBA, GL_UNSIGNED_SHORT_1_5_5_5_REV, g2dCores[0].GetPointer());

	glColor3f(1,1,1);

	float u1 = 240.0f/256.0f;
	float v1 = 160.0f/256.0f;

	glBegin(GL_TRIANGLE_FAN);
	glTexCoord2f(0,0);
	glVertex3f(0,0,0);
	glTexCoord2f(u1,0);
	glVertex3f(2*240,0,0);
	glTexCoord2f(u1,v1);
	glVertex3f(2*240,2*160,0);
	glTexCoord2f(0,v1);
	glVertex3f(0,2*160,0);
	glEnd();

	glDisable(GL_TEXTURE_2D);

	host->EndFrame();
}

void GBADisplay_Shutdown()
{
	glDeleteTextures(1,&backbufTex);
}
#include "stdafx.h"
#include "../Globals.h"
#include "MemMap.h"
#include "Core.h"
#include "CPU.h"
#include "ARM/ARM.h"

#ifdef _DEBUG
#define MEMCHECKS
#endif

#if defined(MEMCHECKS)
#include "Debugger/Breakpoints.h"
#endif


int numRegions;
MemRegionInfo *regions;

static MemoryError memError;

void ResetMemError()
{
	memError = MEMERR_NONE;
}
MemoryError GetLastMemError()
{
	return memError;
}


u8  MEMDECL ReadIllegal8 (u32 address)
{
	LOG(MEMMAP,"Illegal 8-bit read at %08x",address);
	if (!g_Config.bIgnoreBadMemAccess)
	{
		_dbg_update_();
		_dbg_assert_msg_(MEMMAP,0,"Illegal 8-bit read, see log");
		Core_Pause();
	}
	memError = MEMERR_NOTHINGMAPPED;
	return 0;
}

u16 MEMDECL ReadIllegal16(u32 address)
{
	LOG(MEMMAP,"Illegal 16-bit read at %08x",address);
	if (!g_Config.bIgnoreBadMemAccess)
	{
		_dbg_update_();
		_dbg_assert_msg_(MEMMAP,0,"Illegal 16-bit read, see log");
		Core_Pause();
	}
	memError = MEMERR_NOTHINGMAPPED;
	return 0;
}

u32 MEMDECL ReadIllegal32(u32 address)
{
	LOG(MEMMAP,"Illegal 32-bit read at %08x",address);
	if (!g_Config.bIgnoreBadMemAccess)
	{
		_dbg_update_();
		_dbg_assert_msg_(MEMMAP,0,"Illegal 32-bit read, see log");
		Core_Pause();
	}
	memError = MEMERR_NOTHINGMAPPED;
	return 0;
}

void MEMDECL WriteIllegal8 (u32 address, u8 value)
{
	LOG(MEMMAP,"Illegal 8-bit write at %08x, value %02x",address,value);
	if (!g_Config.bIgnoreBadMemAccess)
	{
		_dbg_update_();
		_dbg_assert_msg_(MEMMAP,0,"Illegal 8-bit write, see log");
		Core_Pause();
	}
	memError = MEMERR_NOTHINGMAPPED;
}

void MEMDECL WriteIllegal16(u32 address, u16 value)
{
	LOG(MEMMAP,"Illegal 16-bit write at %08x, value %04x",address,value);
	if (!g_Config.bIgnoreBadMemAccess)
	{
		_dbg_update_();
		_dbg_assert_msg_(MEMMAP,0,"Illegal 16-bit write, see log");
		Core_Pause();
	}
	memError = MEMERR_NOTHINGMAPPED;
}
void MEMDECL WriteIllegal32(u32 address, u32 value)
{
	LOG(MEMMAP,"Illegal 32-bit write at %08x, value %08x",address,value);
	if (!g_Config.bIgnoreBadMemAccess)
	{
		_dbg_update_();
		_dbg_assert_msg_(MEMMAP,0,"Illegal 32-bit write, see log");
		Core_Pause();
	}
	memError = MEMERR_NOTHINGMAPPED;
}


u8* MemMap::GetMemPointer(u32 address)
{
	MemRegion &r = memTable[address>>MEMTABLE_SHIFT];
	return (u8*)(r.addrOffset + address);
}

u8* MEMDECL GetMemPointer(u32 address)
{
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	return (u8*)(r.addrOffset + address);
}

u8 MEMDECL ReadMem8(u32 address)
{
	u8 value;
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (r.read8)
		value = r.read8(address);
	else
		value = *(u8*)(address + r.addrOffset);

#if defined(MEMCHECKS)
	MemCheck *mc = CBreakPoints::GetMemCheck(address);
	if (mc)
	{
		if (mc)
		{
			mc->numHits++;
			mc->Action(value, address,false,1,currentCPU->GetPC()); //0 should be value
		}
	}
#endif
	return value;
}


u16 MEMDECL ReadMem16(u32 address)
{
	//int unalign = address&1;
	u16 value;
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (r.read16)
		value = r.read16(address);
	else
		value = *(u16*)(address + r.addrOffset);
#if defined(MEMCHECKS)
	MemCheck *mc = CBreakPoints::GetMemCheck(address);
	if (mc)
	{
		if (mc)
		{
			mc->numHits++;
			mc->Action(value, address,false,2,currentCPU->GetPC()); //0 should be value
		}
	}
#endif
	//if (unalign)
	//{
	//	value=(value<<8) | (value>>8);
	//}
	return value;
}

u32 MEMDECL ReadMem32(u32 address)
{
//	int unalign = address&3;

	u32 value;
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (r.read32)
		value = r.read32(address);
	else
		value = *(u32*)(address + r.addrOffset);
#if defined(MEMCHECKS)
	MemCheck *mc = CBreakPoints::GetMemCheck(address);
	if (mc)
	{
		if (mc)
		{
			mc->numHits++;
			mc->Action(value, address,false,4,currentCPU->GetPC()); //0 should be value
		}
	}
#endif

	//if (unalign)
//	{
//		value=_ror(value,8*unalign);
//	}
	return value;
}

u32 ReadMem32Unchecked(u32 address)
{
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (r.addrOffset)
		return *(u32*)(address + r.addrOffset);
	else
		return 0;
}

u16 ReadMem16Unchecked(u32 address)
{
//	if (address>=0x10000000)
//		return 0;
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (r.addrOffset)
		return *(u16*)(address + r.addrOffset);
	else
		return 0;
}

u32 MemMap::ReadMem32Unchecked(u32 address)
{
	MemRegion &r = memTable[address>>MEMTABLE_SHIFT];
	if (r.addrOffset)
		return *(u32*)(address + r.addrOffset);
	else
		return 0;
}

u16 MemMap::ReadMem16Unchecked(u32 address)
{
	MemRegion &r = memTable[address>>MEMTABLE_SHIFT];
	if (r.addrOffset)
		return *(u16*)(address + r.addrOffset);
	else
		return 0;
}

bool MemMap::IsExecutable(u32 address)
{
	MemRegion &r = memTable[address>>MEMTABLE_SHIFT];
	return (r.addrOffset)?true:false;
}


u16 ReadOp16(u32 address)
{
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (r.addrOffset)
		return *(u16*)(address + r.addrOffset);
	else
	{
		LOG(CPU,"Running from bad memory");
		_dbg_update_();
		Core_ErrorPause();
		return 0;
	}
}

u32 ReadOp32(u32 address)
{
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (r.addrOffset)
		return *(u32*)(address + r.addrOffset);
	else
	{
		LOG(CPU,"Running from bad memory! %08x", address);
		_dbg_update_();
		Core_ErrorPause();
		return 0;
	}
}

void MEMDECL WriteMem8(u32 address, u8 value)
{
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (r.write8)
		r.write8(address,value);
	else
		*(u8*)(address + r.addrOffset) = value;
#if defined(MEMCHECKS)
	MemCheck *mc = CBreakPoints::GetMemCheck(address);
	if (mc)
	{
		if (mc)
		{
			mc->numHits++;
			mc->Action(value,address,true,1,currentCPU->GetPC()); //0 should be value
		}
	}
#endif
}

void MEMDECL WriteMem16(u32 address, u16 value)
{
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (address & 1)
	{
		value=(value<<8)|(value>>8);
		address&=~1;
	}
	if (r.write16)
		r.write16(address,value);
	else
		*(u16*)(address + r.addrOffset) = value;
#if defined(MEMCHECKS)
	MemCheck *mc = CBreakPoints::GetMemCheck(address);
	if (mc)
	{
		if (mc)
		{
			mc->numHits++;
			mc->Action(value,address,true,2,currentCPU->GetPC()); //0 should be value
		}
	}
#endif
}

void MEMDECL WriteMem32(u32 address, u32 value)
{
	MemRegion &r = currentCPU->memMap.memTable[address>>MEMTABLE_SHIFT];
	if (address & 3)
	{
		int shift = (address&3)*8;
		value=_rotr(value,shift);
		address&=~3;
	}
	if (r.write32)
		r.write32(address,value);
	else
		*(u32*)(address + r.addrOffset) = value;

#if defined(MEMCHECKS)
	MemCheck *mc = CBreakPoints::GetMemCheck(address);
	if (mc)
	{
		if (mc)
		{
			mc->numHits++;
			mc->Action(value,address,true,4,currentCPU->GetPC()); //0 should be value
		}
	}
#endif
}


TCHAR *MemMap::GetAddressName(u32 address)
{
	MemRegion &r = memTable[(address>>MEMTABLE_SHIFT)&0x0FFFFFFF];
	if (r.getAddressName)
		return r.getAddressName(address);
	else
		return "";
}


// intricate system to setup memory tables according to the region tables
// DO NOT TOUCH unless you know what you are doing :/
void MemMap_Init(MemRegionInfo *_regions, int nRegions, int numMirrors, int mirrorAdd)
{
	
	for (int i=0; i<numCPUs; i++)
	{
		memset(cpus[i]->memMap.memTable,0,sizeof(cpus[i]->memMap.memTable));
		cpus[i]->memMap.numRegions=0;
	}

	numRegions = nRegions;
	regions=_regions;
	
	int numTableRegions   = 0;
	int numBytesWanted    = 0;
	int numBytesAllocated = 0;

	for (int i=0; i<numRegions; i++)
	{
		u64 regionSize = regions[i].end-regions[i].start;
		u64 actualStart = regions[i].start & MEMTABLE_MASK;
		u64 actualEnd   = (regions[i].end+~MEMTABLE_MASK)  & MEMTABLE_MASK;
		if (actualEnd == 0)//wrap
			actualEnd = 0x100000000;

		int actualSize  = (int)(actualEnd-actualStart);
		int memorySize  = regions[i].mirrorMask?(regions[i].mirrorMask+1):actualSize;
		int dataSize = (int)(regions[i].mirrorMask?(regions[i].mirrorMask+1):(regionSize));
		///LOG(MEMMAP,"Allocating for region %s: %08x-%08x actualSize: %08x)
		switch(regions[i].type) 
		{
		case MRTYPE_ROM:
			{
				regions[i].memPointer = new u8[memorySize]; //(u8*)VirtualAlloc(0,memorySize,MEM_COMMIT,PAGE_READWRITE);
				memset(regions[i].memPointer,0,memorySize);
				numBytesWanted += dataSize;
				numBytesAllocated += memorySize;
				FILE *f = fopen(regions[i].name,"rb");
				if (f)
				{
					fread(regions[i].memPointer+(regions[i].start-actualStart),dataSize,1,f);
					fclose(f);
					LOG(MEMMAP,"Successfully loaded %s into %08x:%08x",regions[i].name,regions[i].start,regions[i].end);
				}
				else
				{
					MessageBox(0,"Could not load file",regions[i].name,0);
				}
			}
			break;
		case MRTYPE_MEMORY:
			regions[i].memPointer = new u8[memorySize]; //(u8*)VirtualAlloc(0,memorySize,MEM_COMMIT,PAGE_READWRITE);
			memset(regions[i].memPointer,0,memorySize);
			numBytesWanted += dataSize;
			numBytesAllocated += memorySize;
			break;
		case MRTYPE_SPECIAL:
			regions[i].memPointer = 0;
			// no bytes allocated, the io handler gets to do that
			break;
		case MRTYPE_MIRROR:
			regions[i].memPointer = regions[i-1].memPointer;
			break;
		case MRTYPE_INVALID:
			MessageBox(0,"WTF",0,0);
			break;
		}

		for (int cp=0; cp<numCPUs; cp++)
		{
			if (regions[i].cpumask & (1<<cp))
			{
				//fill in fast memory table
				int mirMask = regions[i].mirrorMask ? regions[i].mirrorMask : 0xFFFFFFFF;		
				for (u64 j = actualStart>>MEMTABLE_SHIFT, x = 0; j<actualEnd>>MEMTABLE_SHIFT; j++, x++)
				{
					bool mp = regions[i].memPointer?true:false;
					//numMirrors=1;
					for (int k=0; k<numMirrors; k++)
					{
						int off = (mirrorAdd>>MEMTABLE_SHIFT) * k;
						cpus[cp]->memMap.memTable[j+off].read8   = (regions[i].read8   || mp) ? regions[i].read8   : ReadIllegal8;
						cpus[cp]->memMap.memTable[j+off].read16  = (regions[i].read16  || mp) ? regions[i].read16  : ReadIllegal16;
						cpus[cp]->memMap.memTable[j+off].read32  = (regions[i].read32  || mp) ? regions[i].read32  : ReadIllegal32;
						cpus[cp]->memMap.memTable[j+off].write8  = (regions[i].write8  || mp) ? regions[i].write8  : WriteIllegal8;
						cpus[cp]->memMap.memTable[j+off].write16 = (regions[i].write16 || mp) ? regions[i].write16 : WriteIllegal16;
						cpus[cp]->memMap.memTable[j+off].write32 = (regions[i].write32 || mp) ? regions[i].write32 : WriteIllegal32;
						cpus[cp]->memMap.memTable[j+off].getAddressName = regions[i].getAddressName;
						if (regions[i].memPointer)
						{
							u32 curAddr = (u32)((j+off) << MEMTABLE_SHIFT);
							u32 inOff= (u32)((x*(1<<MEMTABLE_SHIFT)&mirMask));
							//LOG(MEMMAP,"%s : %08x : %08x",regions[i].name,curAddr,inOff);
							cpus[cp]->memMap.memTable[j+off].addrOffset = (u32)regions[i].memPointer - curAddr + inOff;
						}
						cpus[cp]->memMap.memTable[j+off].initialized = true;
					}
					numTableRegions++;
				}

				memcpy(cpus[cp]->memMap.regions + cpus[cp]->memMap.numRegions, regions + i, sizeof(MemRegionInfo));
				cpus[cp]->memMap.numRegions++;
			}
		}
	}

	for (int i=0; i<MEMTABLE_SIZE; i++)
	{
		for (int cp=0; cp<numCPUs; cp++)
		{
			if (!cpus[cp]->memMap.memTable[i].initialized)
			{
				cpus[cp]->memMap.memTable[i].read8 = ReadIllegal8;
				cpus[cp]->memMap.memTable[i].read16 = ReadIllegal16;
				cpus[cp]->memMap.memTable[i].read32 = ReadIllegal32;
				cpus[cp]->memMap.memTable[i].write8 = WriteIllegal8;
				cpus[cp]->memMap.memTable[i].write16 = WriteIllegal16;
				cpus[cp]->memMap.memTable[i].write32 = WriteIllegal32;
				cpus[cp]->memMap.memTable[i].getAddressName = 0;

				cpus[cp]->memMap.memTable[i].addrOffset = 0;
			}
		}
	}
	LOG(MEMMAP,"Memory initialized - %i regions, %i memtableregions, %08x bytes",numRegions,numTableRegions,numBytesAllocated);
}



void MemMap_Shutdown()
{
	for (int i=0; i<numRegions; i++)
	{
		if (regions[i].memPointer!=0 && regions[i].type != MRTYPE_MIRROR)
			delete [] regions[i].memPointer;
            //VirtualFree(regions[i].memPointer,0,MEM_RELEASE);
		regions[i].memPointer=0;
	}
}


void MEMDECL WriteMemString(u32 address, const char *string)
{
	u8 *ptr = GetMemPointer(address);
	if (ptr)
		strcpy((char*)ptr,string);
}

#pragma once

#include "../Globals.h"
#include "CPU.h"
#define MAX_CPUCOUNT 2

struct System
{
	TCHAR *name;
	TCHAR *manufacturer;
	TCHAR *fileFilter;

	int numCPUs;
	int numScreens;
	int numControllers;
	
	u32 binaryLoadAddress;

	CPUType cpus[MAX_CPUCOUNT];
	int frequency[MAX_CPUCOUNT];

	void (*advance)(int cycles);
	void (*SWI)();
};


#define NUMSYSTEMS 4
extern System *systems[4];
extern System *currentSystem;

#include "stdafx.h"
#include "../Globals.h"
#include "EmuThread.h"
#include "HW.h"
#include "MemMap.h"
#include "Core.h"
#include "Host.h"
#include "Loaders.h"

// TODO: make Host.h take care of creating the thread
// so that core is completely portable (no windows calls)
// Other ports might not want to use threading at all,
// it would be good if this was possible

// Anyhow, in the future we will thread off the PSP graphics,
// taking full advantage of the now so popular dual core processors.

//bool bEmuThreadStarted = false;
bool bCoreRunning = false;
bool bStopCore = false;

TCHAR fileToStart[MAX_PATH];

static HANDLE emuThread;
HANDLE EmuThread_GetThreadHandle()
{
	return emuThread;
}

DWORD TheThread(LPVOID x);

void EmuThread_Start(const TCHAR *filename)
{
	_dbg_clear_();
	_tcscpy(fileToStart,filename);
	unsigned int i;
	EmuMode mode;
	switch (Identify_File(filename))
	{
	case FILETYPE_DS_BIN9:
	case FILETYPE_DS_ELF:
	case FILETYPE_DS_NDS:
	case FILETYPE_DS_EMPTY:
	case FILETYPE_DS_PASSTHRU:
		mode=MODE_DS;
		break;
	case FILETYPE_GBA_BIN:
	case FILETYPE_GBA_EMPTY:
	case FILETYPE_GBA_ELF:
		mode=MODE_GBA;
		break;
	case FILETYPE_GP32_BIN:
	case FILETYPE_GP32_EMPTY:
		mode=MODE_GP32;
		break;
	case FILETYPE_PSP_ELF:
	case FILETYPE_PSP_PBP:
	case FILETYPE_PSP_ISO:
		mode=MODE_PSP;
		break;
	default:
		//WTF
		return;
	}

//	emuThread = CreateThread(0,0,(LPTHREAD_START_ROUTINE)TheThread,(LPVOID)mode,0,&i);
	emuThread = (HANDLE)_beginthreadex(0,0,(unsigned int (__stdcall *)(void *))TheThread,(LPVOID)mode,0,&i);
}

void EmuThread_Stop()
{
//	DSound_UpdateSound();
	Core_Stop();
	if (WAIT_TIMEOUT == WaitForSingleObject(EmuThread_GetThreadHandle(),300))
	{
		//MessageBox(0,"Wait for emuthread timed out, please alert the developer to possible deadlock or infinite loop in emuthread :(.",0,0);
	}
	host->UpdateUI();
}


TCHAR *GetCurrentFilename()
{
	return fileToStart;
}

DWORD TheThread(LPVOID x)
{
	EmuMode mode = (EmuMode)(int)x;

	g_State.bEmuThreadStarted = true;

	host->UpdateUI();

	// The Emu i
	host->InitGL();

	// Init the Hardware


	LOG(MASTER_LOG,"Starting up hardware.");
	HW_Init(mode);
	LOG(MASTER_LOG,"Loading files and starting CPU cores...");
	Core_Init(mode,fileToStart); 
	LOG(MASTER_LOG,"Done.");
	_dbg_update_();

	//CPlugin_Video::LoadPlugin(g_Config.GFXPlugin);	

	if (g_Config.bAutoRun)
	{
#ifdef _DEBUG
		host->UpdateDisassembly();
#endif
		Core_EnableStepping(FALSE);
	}
	else
	{
#ifdef _DEBUG
		host->UpdateDisassembly();
#endif
		Core_EnableStepping(TRUE);
	}

	g_State.bBooted = true;
#ifdef _DEBUG
	host->UpdateMemView();
#endif

	host->BootDone();
	Core_Run();

	host->PrepareShutdown();

	Core_Shutdown();
	HW_Shutdown();


	host->ShutdownGL();
	//DSound::DSound_StopSound();  //should be stopped in wndmain before the window is destroyed?

	//The CPU should return when a game is stopped and cleanup should be done here, 
	//so we can restart the plugins (or load new ones) for the next game
	g_State.bEmuThreadStarted = false;
	LOG(MASTER_LOG,"EmuThread exited");
	_endthreadex(0);
	return 0;
}



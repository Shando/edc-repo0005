#pragma once

void EmuThread_Start(const TCHAR *filename);
void EmuThread_Stop();
HANDLE EmuThread_GetThreadHandle();

TCHAR *GetCurrentFilename();

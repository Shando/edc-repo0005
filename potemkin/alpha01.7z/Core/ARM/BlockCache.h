#pragma once

#include "../IR/IR.h"

#include <map>

u16 ReadRealOpTHUMB(u32 address);
u32 ReadRealOpARM(u32 address);


#define MAX_BLOCKS 16384


struct Block
{
	u32 address;
	u8 *code;
	IROp *ir; //for use with IR interpreter
	int armSize;
	int codeSize;
	int irSize;
	int cycles; // compiled x86 code will take care of decrementing but good to know when interpreting
	Block *next; //if fast lookup failed we put the blocks in a linked list
};

class ARMState;

class BlockCache
{
	Block blocks[MAX_BLOCKS];
	int numBlocks;
	std::map<u32,int> blockMap;
public:
	ARMState *armState;
	BlockCache() {}
	void SingleStep();
	void RunBlock();
};

//hacks :)
//#define BLOCK_CODEPTROFFSET (u32)(&((Block*)0)->address)
//#define BLOCK_ADDRESSOFFSET (u32)(&((Block*)0)->address)


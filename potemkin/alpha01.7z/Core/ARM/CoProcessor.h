#pragma once

/*
void CP_Write(u32 opcode);
void CP_Read(u32 opcode);
void CP_(u32 opcode);*/
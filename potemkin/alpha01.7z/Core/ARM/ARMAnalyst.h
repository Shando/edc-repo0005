#pragma	once

//Various ARM code analysis functions
#include "ARMTables.h"

u32 Analyst_FindEndOfBlock(u32 address, bool thumb);
int Analyst_GetPotentialDestinations(u32 address, bool thumb, u32 out[2]);
void Analyst_Analyze(u32 start, u32 end, bool thumb);

InstructionInfo &CurrentAnalysis();
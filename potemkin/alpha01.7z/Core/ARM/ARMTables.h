#pragma once

#include "../../Globals.h"

#define FL_C 1
#define FL_Z 2
#define FL_N 4
#define FL_V 8

#define END_BASIC_BLOCK 0x80
#define UNCONDITIONAL 0x40
#define BAD_INSTRUCTION 0x20

struct InstructionInfo
{
	u8 flagsIn;
	u8 flagsOut;
	u8 flags;
	u8 cond;
};

extern const TCHAR *conditionNames[16];
extern const u32 conditionOpposite[16];
extern const int relevantFlags[16];

void ARMCompileOp(u32 op);
void ARMDisAsm(u32 op, u32 pc, char *out);
InstructionInfo ARMGetInfo(u32 op);
void ARMInterpret(u32 op); //only for those rare ones

void THUMBCompileOp(u16 op);
void THUMBDisAsm(u16 op, u32 pc, char *out);
InstructionInfo THUMBGetInfo(u16 op);

void FillARMTables();
void FillThumbTables();

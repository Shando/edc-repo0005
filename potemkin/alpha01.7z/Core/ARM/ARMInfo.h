#pragma once

namespace ARMInstructions
{
	InstructionInfo Info_NN(u32 op);
	InstructionInfo Info_Unimpl(u32 op);
	InstructionInfo Info_DP(u32 op);
	InstructionInfo Info_LDM(u32 op);
	InstructionInfo Info_LDR(u32 op);

	InstructionInfo Info_T_NN(u16 op);
	InstructionInfo Info_T_Unimpl(u16 op);
	InstructionInfo Info_T_POP(u16 op);
	InstructionInfo Info_T_ADDhi(u16 op);
	InstructionInfo Info_T_MOVhi(u16 op);
}

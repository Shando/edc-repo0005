#pragma once

namespace ARMInstructions
{
	//Software interrupt
	void Comp_SWI(u32 op);  

	//Branch and link
	void Comp_B(u32 op);    
	void Comp_BL(u32 op);   
	void Comp_BLXr(u32 op); 
	void Comp_BXr(u32 op);  
}

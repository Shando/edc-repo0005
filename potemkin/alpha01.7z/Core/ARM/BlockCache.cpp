#include "stdafx.h"

#include "../../Globals.h"
#include "../MemMap.h"

#include "ARM.h"
#include "ARMAnalyst.h"
#include "ARMCompiler.h"
#include "BlockCache.h"
#include "../IR/IRInterpreter.h"
#include "../IR/IROptimizer.h"

#include "../GBA/GBAIO.h"	
#include "../GBA/GBASystem.h"	
#include "../Graphics/G2D.h"
#include "../Core.h"

IROp tempSpace[1024];

u16 ReadRealOpTHUMB(u32 address)
{
	//check if here is a block
	//if so, find out the real opcode
	//else just read from memory
	return ReadMem16Unchecked(address);
}

u32 ReadRealOpARM(u32 address)
{
	//check if here is a block
	//if so, find out the real opcode
	//else just read from memory
	return ReadMem32Unchecked(address);
}




void BlockCache::RunBlock()
{
	u32 pc = armState->r[15];
	std::map<u32,int>::iterator iter;
	iter = blockMap.find(pc);
	if (iter != blockMap.end())
	{
		int n = iter->second;
		Block &b = blocks[n];
		IR_Int_RunBlock(b.ir,b.irSize);
		currentSystem->advance(b.cycles);
	}
	else
	{
		u32 end = Analyst_FindEndOfBlock(pc, armState->thumb);
		Compiler_CompileRange(pc,end,armState->thumb);
		//optimize ..
		if (!IR_First())
		{
			//
			LOG(CPU,"Failed to compile block");
			_dbg_update_();
		}
		else
		{
			IR_Transform();
			IR_ConstantPropagate();
			IR_Optimize();
			blockMap[pc] = numBlocks;
			Block &b = blocks[numBlocks++];
			b.irSize = IR_Count();
			b.ir = new IROp[b.irSize];		
			b.cycles = IR_GetCycles();
			//if (GetAsyncKeyState(VK_CONTROL))
			{
				LOG(CPU,"IR for %08x",pc);
				IR_DisasmToLog();
			}
			IR_Linearize(b.ir);
			IR_Int_RunBlock(b.ir,b.irSize);
			currentSystem->advance(b.cycles);

		}
	}
}

void BlockCache::SingleStep()
{
	if (GetAsyncKeyState(VK_SHIFT))
	/*for (int i=0; i<32; i++)*/{RunBlock();return;}
	u32 pc = armState->r[15];
	Compiler_CompileRange(pc,pc,armState->thumb);
	if (!IR_First())
	{
		LOG(CPU,"Failed to compile instruction");
		_dbg_update_();
	}
	else
	{
		IR_Transform();
		IR_ConstantPropagate();
		IR_Optimize();
		int irSize = IR_Count();
		if (GetAsyncKeyState(VK_CONTROL))
			IR_DisasmToLog();
		IR_Linearize(tempSpace);
		IR_Int_RunBlock(tempSpace,irSize);
		currentSystem->advance(IR_GetCycles());
	}
}


#pragma once

namespace ARMInstructions
{
	void Comp_LDR(u32 op);
	void Comp_LDRB(u32 op); 
	void Comp_STR(u32 op);  
	void Comp_STRB(u32 op); 
	void Comp_LDRH(u32 op); 
	void Comp_STRH(u32 op); 
	void Comp_LDRSH(u32 op);
	void Comp_STRSH(u32 op);
	void Comp_LDRSB(u32 op);
	void Comp_STRSB(u32 op);

	void Comp_STM(u32 op);
	void Comp_LDM(u32 op);

	void Comp_MRS(u32 op);
	void Comp_MSRreg(u32 op);
	void Comp_MSRimm(u32 op);

	void Comp_MRC(u32 op);
	void Comp_MCR(u32 op);

	void Comp_STC(u32 op);
	void Comp_LDC(u32 op);

	void Comp_SWP(u32 op);
	void Comp_SWPB(u32 op);
}

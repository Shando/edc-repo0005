#pragma once


namespace THUMBInstructions
{

	void Comp_T_LDRB(u16 op);  
	void Comp_T_STRB(u16 op);  
	void Comp_T_LDRH(u16 op);  
	void Comp_T_STRH(u16 op);  
	void Comp_T_LDR(u16 op);
	void Comp_T_STR(u16 op);

	void Comp_T_LDRimm(u16 op);
	void Comp_T_LDRisp(u16 op);

	void Comp_T_STRrof(u16 op);
	void Comp_T_STRHro(u16 op);

	void Comp_T_LDRSB(u16 op); 
	void Comp_T_LDRrof(u16 op);
	void Comp_T_LDRHro(u16 op);
	void Comp_T_LDRBro(u16 op);
	void Comp_T_LDRSH(u16 op); 

	void Comp_T_STRBro(u16 op);
	void Comp_T_STRHio(u16 op);
	void Comp_T_STRisp(u16 op);

	void Comp_T_POP(u16 op);   
	void Comp_T_PUSH(u16 op);  

}

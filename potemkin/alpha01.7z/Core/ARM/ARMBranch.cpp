#include "stdafx.h"
#include "../../Globals.h"
#include "../MemMap.h"

#include "ARM.h"
#include "../IR/IR.h"

bool internalBackBranches = false;

namespace ARMInstructions
{

	//////////////////////////////////////////////////////////////////////////
	/// ARM
	//////////////////////////////////////////////////////////////////////////

	//Software i
	void Comp_SWI(u32 op)
	{
		IR_StartBranch(op>>28);
		IR_Add(IR_LEAVE,0,0,IRImm(compiler_pc + 4),IRL_SWI,IRImm(op&0xFFFFFF));
		if (!IR_IsInBranch())
			Compiler_ExitCompile();
		IR_EndBranch();
	}  



	//Branch and
	void Comp_B(u32 op)
	{
		IR_StartBranch(op>>28);
		u32 addr = compiler_pc+8+4*SEX24(op&0xFFFFFF);
		if (addr == Compiler_GetStart())
		{
			IR_Add(IR_LEAVE,0,0,IRImm(addr),IRL_BRARMSAMEBLOCK);
			if (!IR_IsInBranch())
				Compiler_ExitCompile();
		}
		else if (internalBackBranches && addr>=Compiler_GetStart() && addr<compiler_pc)
		{
			IR_InsertBranchTarget(addr,0,0xff);
			IR_Add(IR_BRANCH,0,0,COND_AL,0xFF);
		}
		else
		{
			IR_Add(IR_LEAVE,0,0,IRImm(addr),((op >> 28) == 0xf) ? IRL_BRTHUMB : IRL_BRARM);
			if (!IR_IsInBranch())
				Compiler_ExitCompile();
		}
		IR_EndBranch();
	}    

	void Comp_BL(u32 op)
	{
		IR_StartBranch(op>>28);
		u32 addr = compiler_pc+8+4*SEX24(op&0xFFFFFF);
		IR_Add(IR_MOV,0,ARM_REG_LR,IRImm(compiler_pc+(compiler_thumb?2:4)));
		IR_Add(IR_LEAVE,0,0,IRImm(addr),((op >> 28) == 0xf) ? IRL_BRTHUMB : IRL_BRARM);
		if (!IR_IsInBranch())
			Compiler_ExitCompile();
		IR_EndBranch();
	}

	void Comp_BXr(u32 op)
	{
		IR_StartBranch(op>>28);
		int rm = op&0xf;
		IR_Add(IR_LEAVE,0,0,rm,IRL_BRDEPENDS);
		if (!IR_IsInBranch())
			Compiler_ExitCompile();
		IR_EndBranch();
	}

	void Comp_BLXr(u32 op)
	{
		IR_StartBranch(op>>28);
		int rm = op&0xf;
		IR_Add(IR_MOV,0,ARM_REG_LR,IRImm(compiler_pc+(compiler_thumb?2:4)));
		IR_Add(IR_LEAVE,0,0,rm,IRL_BRDEPENDS);
		if (!IR_IsInBranch())
			Compiler_ExitCompile();
		IR_EndBranch();
	}
}
#include "stdafx.h"

#include "../../Globals.h"

#include "ARM.h"
#include "ARMCompiler.h"
#include "ARMTables.h"
#include "ARMAnalyst.h"
#include "../IR/IR.h"
#include "../MemMap.h"

#include "THUMBLoadStore.h"
#include "ARMCompiler.h"

//////////////////////////////////////////////////////////////////////////
// THUMB
//////////////////////////////////////////////////////////////////////////

namespace THUMBInstructions
{
	void Comp_T_PUSH(u16 op)
	{
		int count=0;
		if (op&(1<<8))
		{
			//LR
			IR_Add(IR_SUB,0,ARM_REG_SP,ARM_REG_SP,IRImm((u32)4));
			IR_Add(IR_STOREWORD,0,0,ARM_REG_SP,ARM_REG_LR,IRLS_ALIGNED);
			count++;
		}
		for (int i=7; i>=0; i--)
		{
			if (op&(1<<i))
			{
				IR_Add(IR_SUB,0,ARM_REG_SP,ARM_REG_SP,IRImm((u32)4));
				IR_Add(IR_STOREWORD,0,0,ARM_REG_SP,i,IRLS_ALIGNED);
				count++;
			}
		}
		Compiler_AddCycles(2<count?count:2);
	}	

	//stack
	void Comp_T_POP(u16 op)
	{
		int count=0;
		for (int i=0; i<8; i++)
		{
			if (op&(1<<i))
			{
				IR_Add(IR_LOADWORD,0,i,ARM_REG_SP,0,IRLS_ALIGNED);
				IR_Add(IR_ADD,0,ARM_REG_SP,ARM_REG_SP,IRImm((u32)4));
				count++;
			}
		}
		if (op&(1<<8))
		{
			//branch!
			IR_Add(IR_LOADWORD,0,IRTEMP0,ARM_REG_SP,0,IRLS_ALIGNED);
			IR_Add(IR_ADD,0,ARM_REG_SP,ARM_REG_SP,IRImm((u32)4));
			IR_Add(IR_LEAVE,0,0,IRTEMP0,IRImm((u32)IRL_BRDEPENDS));
			count++;
		}
		Compiler_AddCycles(2<count?count:2);
	} 

	void Comp_T_ldstMIA(u16 op, IROpID opid) 
	{
		int rn = (op>>8) & 7;
		IR_Add(IR_MOV,0,IRTEMP0,rn);
		u32 count=0;
		for (int i=0; i<8; i++)
		{
			if (op&(1<<i))
			{
				IR_Add(opid,0,i,IRTEMP0,i,IRLS_ALIGNED);
				IR_Add(IR_ADD,0,IRTEMP0,IRTEMP0,IRImm((u32)4));
				count++;
			}
		}
		IR_Add(IR_ADD,0,rn,rn,IRImm(4*count));
		Compiler_AddCycles(2<count?count:2);
	}

	void Comp_T_STMIA(u16 op) {Comp_T_ldstMIA(op,IR_STOREWORD);}
	void Comp_T_LDMIA(u16 op) {Comp_T_ldstMIA(op,IR_LOADWORD);}



	void Comp_T_LSImm5(u16 op, IROpID opid, u32 mul)
	{
		int rd=op&7;
		int rn=(op>>3)&7;
		u32 imm = (op>>6)&31;
		if (imm==0)
			IR_Add(opid,0,rd,rn,rd); //set as both out and in2, l/s will use/ignore
		else
		{
			IR_Add(IR_ADD,0,IRTEMP0,rn,IRImm(imm*mul));
			IR_Add(opid,0,rd,IRTEMP0,rd,IRLS_UNKNOWN); //set as both out and in2, l/s will use/ignore
		}
		Compiler_AddCycles(1);
	}

	void Comp_T_LSrof(u16 op, IROpID opid)
	{
		int rd=op&7;
		int rn=(op>>3)&7;
		int rm=(op>>6)&7;
		IR_Add(IR_ADD,0,IRTEMP0,rn,rm);
		IR_Add(opid,0,rd,IRTEMP0,rd,IRLS_UNKNOWN);
		Compiler_AddCycles(1);
	}

	void Comp_T_ldstisp(u16 op,IROpID opid) 
	{
		int rd = (op>>8)&7;
		u32 imm = op&0xff;
		int tempReg;
		if (imm==0)
			tempReg = ARM_REG_SP;
		else
		{
			tempReg = IRTEMP0;
			IR_Add(IR_ADD,0,tempReg,ARM_REG_SP,IRImm(imm*4));
		}
		IR_Add(opid,0,rd,tempReg,rd,IRLS_UNKNOWN); //todo : we may know something about alignment
		Compiler_AddCycles(1);
	}
	void Comp_T_LDRsex(u16 op, IROpID opid)  
	{
		int rd=op&7;
		int rn=(op>>3)&7;
		int rm=(op>>6)&7;
		IR_Add(IR_ADD,0,IRTEMP0,rn,rm);
		IR_Add(IR_LOADBYTE,0,rd,IRTEMP0,rd,IRLS_ALIGNED);
		IR_Add(opid,0,rd,rd);
		Compiler_AddCycles(1);
	}


	//loadstore
	void Comp_T_LDRB(u16 op)   {Comp_T_LSImm5(op,IR_LOADBYTE, 1);Compiler_AddCycles(1);}  
	void Comp_T_STRB(u16 op)   {Comp_T_LSImm5(op,IR_STOREBYTE,1);} // ?????
	void Comp_T_LDRH(u16 op)   {Comp_T_LSImm5(op,IR_LOADHALF, 2);Compiler_AddCycles(1);}  
	void Comp_T_STRH(u16 op)   {Comp_T_LSImm5(op,IR_STOREHALF,2);}  
	void Comp_T_STR(u16 op)    {Comp_T_LSImm5(op,IR_STOREWORD,4);}
	void Comp_T_LDR(u16 op)    {Comp_T_LSImm5(op,IR_LOADWORD, 4);Compiler_AddCycles(1);}

	void Comp_T_LDRBro(u16 op) {Comp_T_LSrof(op,IR_LOADBYTE );Compiler_AddCycles(1);}
	void Comp_T_STRBro(u16 op) {Comp_T_LSrof(op,IR_STOREBYTE);}  
	void Comp_T_LDRHro(u16 op) {Comp_T_LSrof(op,IR_LOADHALF );Compiler_AddCycles(1);}
	void Comp_T_STRHro(u16 op) {Comp_T_LSrof(op,IR_STOREHALF);}
	void Comp_T_LDRrof(u16 op) {Comp_T_LSrof(op,IR_LOADWORD );Compiler_AddCycles(1);}
	void Comp_T_STRrof(u16 op) {Comp_T_LSrof(op,IR_STOREWORD);}

	void Comp_T_LDRisp(u16 op) {Comp_T_ldstisp(op,IR_LOADWORD);Compiler_AddCycles(1);}
	void Comp_T_STRisp(u16 op) {Comp_T_ldstisp(op,IR_STOREWORD);}

	void Comp_T_LDRSB(u16 op) {Comp_T_LDRsex(op,IR_SEX8);Compiler_AddCycles(1);} 
	void Comp_T_LDRSH(u16 op) {Comp_T_LDRsex(op,IR_SEX16);Compiler_AddCycles(1);}

	void Comp_T_LDRimm(u16 op) 
	{
		u32 addr=(compiler_pc&~3)+(op&0xff)*4+4;
		if (0)
			IR_Add(IR_LOADWORD,0,(op>>8)&7,IRImm(addr),0,(addr&3) ? IRLS_UNALIGNED : IRLS_ALIGNED);
		else
			IR_Add(IR_MOV,0,(op>>8)&7,IRImm(ReadMem32Unchecked(addr)));
		Compiler_AddCycles(1);
	}
}

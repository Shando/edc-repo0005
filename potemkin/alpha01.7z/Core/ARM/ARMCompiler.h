#pragma	once

#include "../../Globals.h"
void Comp_Unimpl(u32 op);

void Comp_T_Unimpl(u16 op);

void Compiler_Init();
void Compiler_Shutdown();
void Compiler_SingleStep();
void Compiler_CompileBlock(u32 address);

void Compiler_CompileRange(u32 start, u32 end,bool thumb);
void Compiler_ExitCompile();
u32 Compiler_GetStart();
void Compiler_AddCycles(int num);
extern u32 compiler_pc;
extern bool compiler_thumb;
extern int curInstructionsCompiled;
#include "stdafx.h"
#include "ARM.h"
#include "ARMTables.h"
#include "ARMInfo.h"

namespace ARMInstructions
{
	InstructionInfo Info_NN(u32 op)
	{
		InstructionInfo info = {0};
		return info;
	}

	InstructionInfo Info_T_NN(u16 op)
	{
		InstructionInfo info = {0};
		return info;
	}

	InstructionInfo Info_Unimpl(u32 op)
	{
		InstructionInfo info = {0};
		info.flags|=BAD_INSTRUCTION;
		return info;
	}

	InstructionInfo Info_T_Unimpl(u16 op)
	{
		InstructionInfo info = {0};
		info.flags|=BAD_INSTRUCTION;
		return info;
	}

	InstructionInfo Info_DP(u32 op)
	{
		InstructionInfo info = {0};
		int cond = op>>28;
		int rd = (op>>12)&0xF;
		if (rd == ARM_REG_PC)
		{
			if (cond == COND_AL)
				info.flags |= END_BASIC_BLOCK;
		}
		// TODO : if shiftop == RRX, require a flag
		return info;
	}

	InstructionInfo Info_LDM(u32 op)
	{
		InstructionInfo info = {0};
		bool loadingPC = (op&(1<<15)) ? true : false;
		if (loadingPC)
			info.flags |= END_BASIC_BLOCK;
		return info;
	}

	InstructionInfo Info_LDR(u32 op)
	{
		InstructionInfo info = {0};
		int rd = ((op>>12)&0xF);
		if (rd == ARM_REG_PC)
			info.flags |= END_BASIC_BLOCK;
		return info;
	}

	InstructionInfo Info_T_POP(u16 op)
	{
		InstructionInfo info = {0};
		if (op&(1<<8)) //load pc
			info.flags |= END_BASIC_BLOCK;
		return info;
	}

	InstructionInfo Info_T_ADDhi(u16 op)
	{
		InstructionInfo info = {0};
		int rd = ((op>>4)&8)|(op&7);
		if (rd == ARM_REG_PC)
			info.flags |= END_BASIC_BLOCK;
		return info;
	}

	InstructionInfo Info_T_MOVhi(u16 op)
	{
		InstructionInfo info = {0};
		int rd = ((op>>4)&8)|(op&7);
		if (rd == ARM_REG_PC)
			info.flags |= END_BASIC_BLOCK;
		return info;
	}

}

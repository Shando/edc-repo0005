#pragma once

namespace THUMBInstructions
{
	//branch
	void Comp_T_Bcond(u16 op); 
	void Comp_T_B(u16 op);     
	void Comp_T_BX(u16 op);    
	void Comp_T_BLX(u16 op);   
	void Comp_T_BLbig(u16 op);    

	//Software int
	void Comp_T_SWI(u16 op);

}


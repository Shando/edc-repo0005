#include "stdafx.h"
#include "../Core.h"
#include "../MemMap.h"
#include "ARM.h"
#include "ARMCompiler.h"
#include "ARMTables.h"
#include "ARMAnalyst.h"
#include "../IR/IR.h"

u32 compiler_pc;
bool compiler_thumb;
u8 singleStepScratch[0x1000];
int curInstructionsCompiled;

static int curCycles;

void Comp_Unimpl(u32 op)
{
	LOG(CPU,"[%08x] Trying to compile unimplemented opcode %08x",compiler_pc,op);
	Core_Halt("-");
}


//////////////////////////////////////////////////////////////////////////
// THUMB
//////////////////////////////////////////////////////////////////////////

void Comp_T_Unimpl(u16 op)
{
	LOG(CPU,"[%08x] Trying to compile unimplemented opcode %04x",compiler_pc,op);
	Core_Halt("-");
}



void Compiler_Init()
{
	
}


void Compiler_Shutdown()
{

}

static bool exitCompile;
static u32 compstart;
void Compiler_CompileRange(u32 start, u32 end,bool thumb)
{
	if (!currentCPU->memMap.IsExecutable(start))
	{
		LOG(CPU,"Running from bad memory");
		_dbg_update_();
		Core_Pause();
		return;
	}

	Analyst_Analyze(start,end,thumb);
	exitCompile = false;
	compstart = start;
	curCycles=0;
	curInstructionsCompiled = 0;
	IR_Start();
	compiler_thumb = thumb;
	if (thumb)
	{
		if (start & 1)
		{
			_dbg_assert_msg_(CPU,0,"Compiling THUMB from address&1!=0");
			Core_Pause();
		}
		for (compiler_pc = start; compiler_pc <= end; compiler_pc += 2)
		{
			THUMBCompileOp(ReadOp16(compiler_pc));
			curInstructionsCompiled++;
			Compiler_AddCycles(1);
			if (exitCompile)
				break;
		}
		if (!exitCompile)
			IR_Add(IR_LEAVE,0,0,IRImm(compiler_pc),IRL_BRTHUMB);
	}
	else
	{
		if (start & 3)
		{
			_dbg_assert_msg_(CPU,0,"Compiling ARM from address&3!=0");
			Core_Pause();
		}
		for (compiler_pc = start; compiler_pc <= end; compiler_pc += 4)
		{
			ARMCompileOp(ReadOp32(compiler_pc));
			curInstructionsCompiled++;
			Compiler_AddCycles(1);
			if (IR_Count()>990)
			{
				IR_Add(IR_LEAVE,0,0,IRImm(compiler_pc+4),IRL_BRARM);
				exitCompile=true;
			}
			if (exitCompile)
				break;
		}
		if (!exitCompile)
			IR_Add(IR_LEAVE,0,0,IRImm(compiler_pc),IRL_BRARM);
	}
	IR_End(curCycles);
}

void Compiler_CompileBlock(u32 start, bool thumb)
{

}

u32 Compiler_GetStart()
{
	return compstart;
}

void Compiler_AddCycles(int num)
{
	curCycles+=num;
}

void Compiler_ExitCompile()
{
	exitCompile=true;
}

void Compiler_SingleStep()
{
	/*
	compiler_pc = currentARM->r[15];
	u8 *origptr = x86GetPtr();	
	x86SetPtr(singleStepScratch);
	// compile a single instruction
	bool thumb=false;
	Compiler_CompileRange(compiler_pc,compiler_pc,thumb);
	x86SetPtr(origptr);*/
}


#pragma once

namespace THUMBInstructions
{
	//Data process
	void Comp_T_AND(u16 op);   
	void Comp_T_EOR(u16 op);   
	void Comp_T_LSL(u16 op);   
	void Comp_T_LSR(u16 op);   
	void Comp_T_ASR(u16 op);   
	void Comp_T_ADC(u16 op);   
	void Comp_T_ROR(u16 op);   
	void Comp_T_SBC(u16 op);   
	void Comp_T_TST(u16 op);   
	void Comp_T_NEG(u16 op);   
	void Comp_T_CMP(u16 op);   
	void Comp_T_CMN(u16 op);   
	void Comp_T_ORR(u16 op);   
	void Comp_T_MUL(u16 op);   
	void Comp_T_BIC(u16 op);   
	void Comp_T_MVN(u16 op);   

	void Comp_T_ADDhi(u16 op); 
	void Comp_T_CMPhi(u16 op); 
	void Comp_T_MOVhi(u16 op); 

	void Comp_T_ADD(u16 op);   
	void Comp_T_SUB(u16 op);   
	void Comp_T_ADDimm(u16 op);
	void Comp_T_SUBimm(u16 op);

	void Comp_T_LSLimm(u16 op);
	void Comp_T_LSRimm(u16 op);
	void Comp_T_ASRimm(u16 op);
	void Comp_T_CMPimm(u16 op);
	void Comp_T_ADDlim(u16 op);
	void Comp_T_SUBlim(u16 op);
	void Comp_T_MOVimm(u16 op);
	void Comp_T_ADDpc(u16 op); 
	void Comp_T_ADDsp(u16 op); 
	void Comp_T_STMIA(u16 op); 
	void Comp_T_LDMIA(u16 op); 

	void Comp_T_ADDspi(u16 op);
	void Comp_T_SUBspi(u16 op);
}

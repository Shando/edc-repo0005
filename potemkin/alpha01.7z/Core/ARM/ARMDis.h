#pragma once

extern u32 disPC;

namespace ARMDis
{

	void Dis_Unknown(u32 op, char *out);
	void Dis_Unimpl(u32 op, char *out);

	void Dis_AND(u32 op, char *out);
	void Dis_EOR(u32 op, char *out);
	void Dis_SUB(u32 op, char *out);
	void Dis_RSB(u32 op, char *out);
	void Dis_ADD(u32 op, char *out);
	void Dis_ADC(u32 op, char *out);
	void Dis_SBC(u32 op, char *out);
	void Dis_RSC(u32 op, char *out);
	void Dis_TST(u32 op, char *out);
	void Dis_TEQ(u32 op, char *out);
	void Dis_CMP(u32 op, char *out);
	void Dis_CMN(u32 op, char *out);
	void Dis_ORR(u32 op, char *out);
	void Dis_MOV(u32 op, char *out);
	void Dis_BIC(u32 op, char *out);
	void Dis_MVN(u32 op, char *out);

	void Dis_CLZ(u32 op, char *out);

	void Dis_MRS(u32 op, char *out);

	void Dis_MSRimm(u32 op, char *out);
	void Dis_MSRreg(u32 op, char *out);

	void Dis_MRC(u32 op, char *out);
	void Dis_MCR(u32 op, char *out);

	void Dis_STC(u32 op, char *out);
	void Dis_LDC(u32 op, char *out);

	void Dis_SWP(u32 op, char *out);
	void Dis_SWPB(u32 op, char *out);

	void Dis_LDR(u32 op, char *out);
	void Dis_LDRB(u32 op, char *out); 
	void Dis_STR(u32 op, char *out);  
	void Dis_STRB(u32 op, char *out); 
	void Dis_LDRH(u32 op, char *out); 
	void Dis_STRH(u32 op, char *out); 
	void Dis_LDRSH(u32 op, char *out);
	//void Dis_STRSH(u32 op, char *out);
	void Dis_LDRSB(u32 op, char *out);
	//void Dis_STRSB(u32 op, char *out);

	void Dis_STM(u32 op, char *out);
	void Dis_LDM(u32 op, char *out);

	//Multiply
	void Dis_MUL(u32 op, char *out);  
	void Dis_MLA(u32 op, char *out);  
	void Dis_UMULL(u32 op, char *out);
	void Dis_UMLAL(u32 op, char *out);
	void Dis_SMULL(u32 op, char *out);
	void Dis_SMLAL(u32 op, char *out);

	//Software i
	void Dis_SWI(u32 op, char *out);  

	//Branch and
	void Dis_B(u32 op, char *out);    
	void Dis_BL(u32 op, char *out);   
	void Dis_BLXr(u32 op, char *out); 
	void Dis_BXr(u32 op, char *out);  

	//////////////////////////////////////////////////////////////////////////
	//THUMB
	//////////////////////////////////////////////////////////////////////////


	void Dis_T_Unimpl(u16 op, char *out);
	void Dis_T_Unknown(u16 op, char *out);

	//Data process
	void Dis_T_AND(u16 op, char *out);   
	void Dis_T_EOR(u16 op, char *out);   
	void Dis_T_LSL(u16 op, char *out);   
	void Dis_T_LSR(u16 op, char *out);   
	void Dis_T_ASR(u16 op, char *out);   
	void Dis_T_ADC(u16 op, char *out);   
	void Dis_T_ROR(u16 op, char *out);   
	void Dis_T_SBC(u16 op, char *out);   
	void Dis_T_TST(u16 op, char *out);   
	void Dis_T_NEG(u16 op, char *out);   
	void Dis_T_CMP(u16 op, char *out);   
	void Dis_T_CMN(u16 op, char *out);   
	void Dis_T_ORR(u16 op, char *out);   
	void Dis_T_MUL(u16 op, char *out);   
	void Dis_T_BIC(u16 op, char *out);   
	void Dis_T_MVN(u16 op, char *out);   

	void Dis_T_ADDhi(u16 op, char *out); 
	void Dis_T_CMPhi(u16 op, char *out); 
	void Dis_T_MOVhi(u16 op, char *out); 

	void Dis_T_ADD(u16 op, char *out);   
	void Dis_T_SUB(u16 op, char *out);   
	void Dis_T_ADDimm(u16 op, char *out);
	void Dis_T_SUBimm(u16 op, char *out);

	void Dis_T_LSLimm(u16 op, char *out);
	void Dis_T_LSRimm(u16 op, char *out);
	void Dis_T_ASRimm(u16 op, char *out);
	void Dis_T_CMPimm(u16 op, char *out);
	void Dis_T_ADDlim(u16 op, char *out);
	void Dis_T_SUBlim(u16 op, char *out);
	void Dis_T_MOVimm(u16 op, char *out);
	void Dis_T_ADDpc(u16 op, char *out); 
	void Dis_T_ADDsp(u16 op, char *out); 
	void Dis_T_STMIA(u16 op, char *out); 
	void Dis_T_LDMIA(u16 op, char *out); 

	void Dis_T_ADDspi(u16 op, char *out);
	void Dis_T_SUBspi(u16 op, char *out);

	//stack
	void Dis_T_POP(u16 op, char *out);   
	void Dis_T_PUSH(u16 op, char *out);  

	//branch
	void Dis_T_Bcond(u16 op, char *out); 
	void Dis_T_B(u16 op, char *out);     
	void Dis_T_BX(u16 op, char *out);    
	void Dis_T_BLX(u16 op, char *out);   
	void Dis_T_BLbig(u16 op, char *out);    
	void Dis_T_BLend(u16 op, char *out);
	//loadstore
	void Dis_T_LDRimm(u16 op, char *out);
	void Dis_T_LDR(u16 op, char *out);
	void Dis_T_LDRB(u16 op, char *out);  
	void Dis_T_LDRH(u16 op, char *out);  
	void Dis_T_LDRisp(u16 op, char *out);

	void Dis_T_STRrof(u16 op, char *out);
	void Dis_T_STRHro(u16 op, char *out);
	void Dis_T_STRBro(u16 op, char *out);  

	void Dis_T_LDRSB(u16 op, char *out); 
	void Dis_T_LDRrof(u16 op, char *out);
	void Dis_T_LDRHro(u16 op, char *out);
	void Dis_T_LDRBro(u16 op, char *out);
	void Dis_T_LDRSH(u16 op, char *out); 

	void Dis_T_STR(u16 op, char *out);
	void Dis_T_STRB(u16 op, char *out);
	void Dis_T_STRH(u16 op, char *out);
	void Dis_T_STRisp(u16 op, char *out);

	//Software int
	void Dis_T_SWI(u16 op, char *out);

}

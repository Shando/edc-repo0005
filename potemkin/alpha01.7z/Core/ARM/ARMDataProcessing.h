#pragma once

namespace ARMInstructions
{

	void Comp_AND(u32 op);
	void Comp_EOR(u32 op);
	void Comp_SUB(u32 op);
	void Comp_RSB(u32 op);
	void Comp_ADD(u32 op);
	void Comp_ADC(u32 op);
	void Comp_SBC(u32 op);
	void Comp_RSC(u32 op);
	void Comp_TST(u32 op);
	void Comp_TEQ(u32 op);
	void Comp_CMP(u32 op);
	void Comp_CMN(u32 op);
	void Comp_ORR(u32 op);
	void Comp_MOV(u32 op);
	void Comp_BIC(u32 op);
	void Comp_MVN(u32 op);

	void Comp_CLZ(u32 op);

	//Multiply
	void Comp_MUL(u32 op);  
	void Comp_MLA(u32 op);  
	void Comp_UMULL(u32 op);
	void Comp_UMLAL(u32 op);
	void Comp_SMULL(u32 op);
	void Comp_SMLAL(u32 op);

}
#pragma	once

#include "../../Globals.h"

void Int_MSRreg(u32 op);
void Int_MSRimm(u32 op);

void Int_MRS(u32 op);

void Int_LDC(u32 op);
void Int_STC(u32 op);
void Int_MRC(u32 op);
void Int_MCR(u32 op);

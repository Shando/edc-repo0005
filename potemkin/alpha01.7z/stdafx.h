#pragma once

#pragma warning(disable:4996)


//#ifdef WINDOWS

#define _WIN32_WINNT 0x501
#define WINVER 0x0500
#ifndef _WIN32_IE
#define _WIN32_IE 0x0501       // Default value is 0x0400
#endif
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1
//#define UNICODE

#if defined _M_IX86

#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")

#elif defined _M_IA64

#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='ia64' publicKeyToken='6595b64144ccf1df' language='*'\"")

#elif defined _M_X64

#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")

#else

#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

#endif

#include <windows.h>
#include <windowsx.h>
#include <process.h>
#include <tchar.h>
#include <stdio.h>
#include <gl/gl.h>
#include <gl/glu.h>
//#include <gl/glext.h>

#define _USE_MATH_DEFINES
#include <math.h>
#include <math.h>
#include <time.h>
#include <mmsystem.h>
#include <dsound.h>


#include <vector>
#include <map>
#include <string>
#include <fstream>

#include "mmgr.h"


#include "Core/Debugger/Logger.h"

#define THEMES

//#else


//#endif


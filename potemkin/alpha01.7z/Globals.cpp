/////////////////////////////////////////////////////////////////////////////////////////////////////
// M O D U L E  B E G I N ///////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Globals.h"
#include <time.h>
#include "Windows/W32Util/IniFile.h"

// Globals
HMENU g_hPopupMenus;

SState g_State;
CConfig g_Config;
W32Util::IniFile iniFile;
bool hasMMX=false;
bool hasSSE=false;
bool hasSSE2=false; 

/////////////////////////////////////////////////////////////////////////////////////////////////////
// CConfig //////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

// __________________________________________________________________________________________________
// constructor
//
CConfig::CConfig(void)
{
	iniFile.SetFile("DaSh");
}

// __________________________________________________________________________________________________
// destructor
//
CConfig::~CConfig(void)
{
}

// __________________________________________________________________________________________________
// Set_Boot_szFilename
//
void 
CConfig::Set_Boot_szFilename(const char* _szFilename)
{
	if (_szFilename == NULL)
		strcpy(Boot_szFilename, "none");
	else 
		strcpy(Boot_szFilename, _szFilename);
}

// __________________________________________________________________________________________________
// Get_Boot_szFilename
//
const char* 
CConfig::Get_Boot_szFilename(void)
{
	if (!strcmp(Boot_szFilename, "none"))
		return NULL;
	return Boot_szFilename;
}

// __________________________________________________________________________________________________
// Load
//
void 
CConfig::Load(void)
{
	bSaveSettings=true;

	iniFile.SetSection("General");
	bFirstRun = iniFile.ReadBool("FirstRun",true);
	bAutoLoadLast = iniFile.ReadBool("AutoLoadLast",false);
	bEnableDebugging = iniFile.ReadBool("EnableDebugging",false);
	bAutoRun = iniFile.ReadBool("AutoRun",false);
	bDynarec = iniFile.ReadBool("Dynarec",true);
	bConfirmOnQuit = iniFile.ReadBool("ConfirmOnQuit",false);
	bIgnoreUnemulatedOps = iniFile.ReadBool("IgnoreUnemulatedOps",true);
	bIgnoreBadMemAccess = iniFile.ReadBool("IgnoreBadMemAccess",true);

	iniFile.ReadString("LastExeFilename", "", Boot_szFilename, MAX_PATH);

	iniFile.SetSection("Plugins");
	iniFile.ReadString("VID","VideoPlugin.dll",GFXPlugin,MAX_PATH);
	iniFile.ReadString("PAD","PADPlugin.dll",PADPlugin,MAX_PATH);
	iniFile.ReadString("DVD","DVDPlugin.dll",DVDPlugin,MAX_PATH);

	iniFile.SetSection("Settings");
	iniFile.ReadStringList("GCMPaths", gcmPaths);

	iniFile.SetSection("Appearance");
	bannerBGColor = iniFile.ReadInt("BannerBGColor",0x180432);
}

// __________________________________________________________________________________________________
// constructor
//
void 
CConfig::Save(void)
{
	if (g_Config.bSaveSettings)
	{ 
		iniFile.SetSection("General");
		iniFile.WriteBool("FirstRun",           false);
		iniFile.WriteBool("AutoLoadLast",       bAutoLoadLast);
		iniFile.WriteBool("EnableDebugging",    bEnableDebugging);
		iniFile.WriteBool("AutoRun",			bAutoRun);
		iniFile.WriteBool("Dynarec",			bDynarec);
		iniFile.WriteBool("ConfirmOnQuit",bConfirmOnQuit);
		iniFile.WriteBool("IgnoreUnemulatedOps",bIgnoreUnemulatedOps);
		iniFile.WriteString("LastExecFilename", Boot_szFilename);
		iniFile.WriteBool("IgnoreBadMemAccess",bIgnoreBadMemAccess);

		iniFile.SetSection("Plugins");
		iniFile.WriteString("VID",GFXPlugin);
		iniFile.WriteString("PAD",PADPlugin);
		iniFile.WriteString("DVD",DVDPlugin);

		iniFile.SetSection("Settings");
		iniFile.WriteStringList("GCMPaths",    gcmPaths);

		iniFile.SetSection("Appearance");
		iniFile.WriteInt("BannerBGColor",      bannerBGColor);
	}
}


// __________________________________________________________________________________________________
// SetStatusBar
//
void SetStatusBar(const char *text)
{
	//MainWindow::SetStatusBar(text);	
}
/*
// __________________________________________________________________________________________________
// GetGCTime
//
_u32 GetGCTime(void)
{
	// get sram bias
	extern unsigned char sram_dump[64];
	_u32 Bias;

	for (int i=0; i<4; i++)
	{
		((_u8*)&Bias)[i] = sram_dump[0xc + (i^3)];
	}
	
	// get the time ... 
	const _u32 cJanuary2000 = 0x386d35a1;  // seconds between 1.1.1970 and 1.1.2000
	__int64 ltime;
	_time64( &ltime );
	return ((_u32)ltime - cJanuary2000 - Bias);
}*/
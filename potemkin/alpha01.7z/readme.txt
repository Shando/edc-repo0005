Potemkin (Codename DaSH)
Experimental HLE PSP Emulator
   
Henrik Rydg�rd  (aka ector)
hrydgard@gmail.com  (ONLY developer questions and similar)

Released under the GPL since I got bored of fixing stupid bugs and adding functionality to my HLE-simulated PSP OS.

Features:  (end-user point of view :)
  - Plays Puzzle Bobble Pocket JAP
  - Starts AI Go
  - Runs numerous demos from the PSP SDK
  
Technical Features:
  - Badly simulated PSP kernel
  - No VFPU emulation
  - Mounts ISOs and CSOs (no DAX!)
  - Mounts Windows directories (no good UI yet for this)
  - (FUTURE) Supports game-specific patching through UltraHLE-style INI file
  
HLE code structure:
  Internal functions begin with __Kernel. These are called when multiple real HLE functions
  share code, or when other code wants to affect the PSP kernel, such as loading modules, etc.
  
  
  
  TODO: 
    * Timing system
    * Investigate skinning sample
	* Eventflags (Gradius, locoroco, etc)
	* Proper sound
	* Proper FPL (spongebob)
    * DelayThread (bomberman)
    * Investigate bad ISO reading
    * Investigate raw sector reading (GTA for example)
    * Remaining VFPU instructions, for katamari and PQ
    * sceUtilitySaveData, MsgBox
    * Memstick Detection (2001: [R4 08971050 ]: HLE: sceIoDevctl("mscmhc0:", 02025806, 00000000, 0, 09fbbca0, 4) (z_un_0897101c)
	* Fake PSMF and MPEG
	* Atrac using the dll
    * ReferSemaStatus (outrun)
    * VBlank interrupt
    * Callbacks
    * Real thread ready queue
    
  
Compatibility List:

Playable:
  Pinball (breaks if I fix waitforvblank)
  Puzzle Bobble Pocket (some graphics missing)
  Puyo Puyo - Nearly perfect!
  [none]

Ingame:
  AI Go (AI hangs)

Title Screen / menus:
  Frantix - crashes the emu while loading
  Carol's Sudoku - title screen, waiting for callback? async io callback? (seems to work without)
  
Craps on the screen:
  Koloomn - seems to run, but only shows blank screen
  Wipeout Pure - Sector Reading 
  Namco Museum - Now Loading , DelayThread
  Namco Museum Battle Collection - Now Loading , DelayThread
  Star Soldier - Hudson logo
  EVery Extend Extra - ?
  
Not working primary reasons: 
  Astonishia Story - DelayThread
  BomberMan - DelayThread
  Dragon Ball - DelayThread
  Lumines - DelayThread
  Me and My Katamari - DelayThread or Vblank interrupt
  
  Outrun - PollSema, Sector Reading
  GTA LCS - Sector Reading //SavedataInit, Wakeup 
  Bust A Move Ghost - Sector Reading - 088ea0cc is value that gets added to lba
  Burnout - Sector Reading, Waitforvblank rotatequeue
  
  Dead To Rights - Just draws, no vsync :P
  Death Jr - Illegal reads, kaboom, self restarts
  Football Manager - Failing to alloc memory (slightly too much)
 
  
  Fifa Street - VFPU + the unknown SysMemUserForUser functions
  Gurumin - Unknown syscall, mailbox, infinite loop
  
  Mercury - Bizarre zero pointer -> failing internal allocs
  XI Colisseum - broken ISO code
  Pacman World Rally - broken ISO code, bizarre async issues
  
  MotoGP - sceUtilityMsgBox missing
  Kao - sceUtilityMsgBox missing    [DrawSync (hacked for now), GP relocs (dunno if important), ]
  Virtua Tennis - savedata getstatus
  Breath of Fire - SaveDataGetStatus, reading the smae file over and over???
  
  Tiger Woods - Bizarre memory problems
  
  Nana Subeta wa Daimaou no Omichibiki - VFPU, Blasts display lists full of zeroes Bad Semaphore
  
  Noryoko Trainer - Bad math, Tries to open files called (null)
  
  Practical Intelligence Quotitient : Draws black stuff
  
  Slotter Up Core - Semaphores, VFPU
  
  Smart Bomb - Jump to 0000000 088fbde4
  
  Spongebob - FPL
  
  Ultra Z fighting - Shuts down
  
  World Poker Tour - Needs MPEG / Atrac faking
  Go Sudoku - PSMF video
  
  Hot Shots Golf - need VBlank interrupt
  Capcom 3 in 1 Demo - EVentflags, unknown syscalls
  Loco Roco Full - WaitEventFlag, Vblank interrupt
  Loco Roco Demo - Vblank interrupt, sceDemoMod sceKernelGetThreadStackFreeSize 

  Formula One - Uses 4 new kernel functions
  Fired Up - bad semaphores
  
  Tony Hawk Underground Remix 2 - VFPU, illegal reads, kaboom
  
  Kuru - Illegal memory write 0888e9a8
  Need For Speed Most Wanted - Open UMD0: bizarre results, loop forever
  
  Exit - Semaphores
  
  Street Fighter - Font, wakeup stuff ?sceKernelCancelWakeupThread 
  Coded Arms - Callback? Scheduler? weird things + some unknown APIs
  Ape Escape 1 - ReferThreadStatus? SleepThread?
  Viewtiful Joe - Scheduling? vblank timing
  
  Mega Man Maverick Hunter X - lots of various problems. TODO: make allocations aligned!
  Dragon Quest And Final Fantasy - UmdActivate / UmdGeterrorStat
  
  Gradius - Async I/O  
  Lemmings - Async I/O (bizarre stuff, keeps retrying)
  Untold Legends - Async I/O
  Valkyrie Profile - Async I/O problem, 665: [MIPS32 R4K 088ca59c ]: MEM: Illegal 32-bit read at ffff84b0 (un_088ca594)
  Gripshift - Async I/O
  
  Monkey Ball - Thinks it's in Dev, Tries to read from host0: !  sceIoOpen 08a56000
  Pocket Racers - Thinks it's in Dev, Tries to read from host0: ! test at 089c2a7c, read from 090F93B8
  (30236)v1 90D761C v0 in initvarious, the key is in "InitUMD"
  Cars - BOOT.BIN was zeroed!
  X-Men 2 - BOOT.BIN was zeroed!
  Miami Vice - BOOT.BIN was zeroed!
  Mega Man Powered Up - BOOT.BIN was zeroed!
  
  Metal Gear Acid - seems to have custom PRX modules! Need to link them in or reverse engineer :(          
  Metal Gear Acid 2 - seems to have custom PRX modules! Need to link them in or reverse engineer :(          
  Ape Academy 2 - Semaphore, Custom prx?
    
TODO:
  * Investigate common looking bugs above


  
PSPSDK BSD-compatible copyright notice (Some parts of the PSPSDK were used in this emulator (defines, constants, headers))

Copyright (c) 2005  adresd
Copyright (c) 2005  Marcus R. Brown
Copyright (c) 2005  James Forshaw
Copyright (c) 2005  John Kelley
Copyright (c) 2005  Jesper Svennevid
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The names of the authors may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHORS ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.



#pragma once

enum EmuMode
{
	MODE_DS,
	MODE_GBA,
	MODE_GP32,
	MODE_PSP
};
enum SymbolType
{
	ST_FUNCTION=1,
	ST_DATA=2
};


#define MIPS_SUPPORT
#define ARM_SUPPORT


typedef unsigned __int64	u64;
typedef unsigned __int32    u32;
typedef unsigned __int16	u16;
typedef unsigned __int8     u8;

typedef signed __int64		s64;
typedef signed __int32		s32;
typedef signed __int16		s16;
typedef signed __int8		s8;

#ifdef VC6HACK
#define for if (false) ; else for
#endif

#ifdef _MSC_VER
#define ALIGN16 __declspec(align(16)) 
#else
#define ALIGN16
#endif


/////////////////////////////////////////////////////////////////////////////////////////////////////
// D E F I N E S ////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////
// S T R U C T //////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////

struct SState
{
	bool bEmuThreadStarted; //is anything loaded into the emulator?
	bool bBooted;
};

struct CConfig
{ 
public:
	// Boot
	char Boot_szFilename[MAX_PATH];

	CConfig(void);
	~CConfig(void);

	bool bAutoLoadLast;
	bool bEnableDebugging;
	bool bSaveSettings;
	bool bIgnoreUnemulatedOps;
	bool bFirstRun;
	bool bAutoRun;
	bool bSpeedLimit;
	bool bDynarec;
	bool bConfirmOnQuit;
	bool bIgnoreBadMemAccess;

	char DVDPlugin[MAX_PATH];
	char GFXPlugin[MAX_PATH];
	char PADPlugin[MAX_PATH];

	COLORREF bannerBGColor;

	std::vector<std::string> gcmPaths;

	void Load(void);
	void Save(void);

	void Set_Boot_szISOFilename(const char* _szFilename);
	const char* Get_Boot_szISOFilename(void);
	void Set_Boot_szFilename(const char* _szFilename);
	const char* Get_Boot_szFilename(void);
};
#ifdef WINDOWS
#include "Windows/W32Util/IniFile.h"
extern W32Util::IniFile iniFile;
extern HMENU g_hPopupMenus;
#endif 

void SetStatusBar(const char *text);

extern SState g_State;
extern CConfig g_Config;

extern bool hasMMX;
extern bool hasSSE;
extern bool hasSSE2; 



Vic20emu second beta release.

Installation:
-------------

Extract all files from the archive. 

Running:
--------

On windows just run vic20emu.exe in its directory.

On first start all application windows will have default
sizes & positions. Adjust them according to your needs and
end the program from the console file menu to make sure
your settings are saved.

On other platforms take a look at runme.bat to get a hint
for the necessary environment settings for java.


2011/07/30 A.M.

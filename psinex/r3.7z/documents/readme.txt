**************************************
------------------------------------ *
OFFICIAL � PSINEX PC EMULATOR MANUAL *
------------------------------------ *


Contents:

      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     |  * Section 1  |  Description       |
     |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
     |  * Section 2  |  Requirements      |
     |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
     |  * Section 3  |  Emulator Options  |
     |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
     |  * Section 4  |  F.A.Q.            |
     |~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|
     |  * Section 5  |  Credits           |
      ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~




* Section 1
-----------

� PSinex PC Emulator is a 'Sony PlayStation' emulator  program, coded  from scratch  and  exclusively in  MSVC++ 6.0. The
emulator is tested, and runs succesfully on all Microsoft� Windows Platforms, including: Win9x, Win2k, WinXP. It utilizes
the PSEmuPro plugin system for PSX emulators, giving the user a wide variety of options regarding the graphics, the sound
and the CD-ROM part of the emulator. The  user can have  an unlimited  number of memory cards  generated with the help of
the emulator. An easy to use  Graphical User Interface (GUI), can help the amateur user to navigate and alter the options
as he wish.



* Section 2
-----------

As Minimum Requirements I would suggest:


	* Pentium 2 @ 350 MHz
	* 8MB Graphics Card (D3D Capable)
	* 4x CD-ROM Drive
	* Sound Blaster Compatible
	* Microsoft� DirectX 6.1


For a descent experience, the Recommended Specifications would be:


	* Pentium 3 @ 850 MHz
	* 32MB Graphics Card with OpenGL Support
	* 32x CD-ROM Drive or DVD
	* Sound Blaster Live!
	* Microsoft� DirectX 8.1


Of course it applies on the above, that is for the best to have all the latest drivers for you system devices.



* Section 3
-----------

On this section I will analyze  the functions  of the  emulator  menu. Please  try to read  carefully before possing any
questions or sending any e-mails, asking for something that might be already analyzed here.

A. Action

On  this menu we  have gathered  the most  common options  that can  be found  on a PSX emulator  program. If you are an
impatient  party and  you want  to play a  game, put  the Game CD  into  your CD-ROM  drive  and push  'run game cd'  to
begin the process of the emulation. That implies that  you have configured the emulator before on the 'Emulator Options'
of  the  'customize'  menu,  which  is  reffered  on later. You can  also run a  PSX exe  file,  by selecting the second
option on the  menu, labeled 'open file ...'. A  dialog box will  appear, were you can select a PSX  specific executable
file  to  run. You can  acquire  those kind  of  demos on [http://www.cracktro.de]. It  is  possible  to customize  your
memory  cards by  pressing  the option  'goto bios shell'. When  the BIOS  Shell is  loaded simply  select 'MEMORY CARD'
option to  goto the memory card management  system. Of  course the option 'close' later  on as you can understand simply
exits the emulator and frees up the memory used by it.

B. Customize

First option  of the 'customize' menu is  the Graphical User Interface (GUI)  of the emulator's options. This is briefly
you control panel of the emulator. Every single change you wish to make  on its functions is done here. Main part  of it
is the  selection of the CPU mode. It  is recommended that you keep as your main CPU mode the Recompiler. It  is quite a
fast mode and the compatibility is the same as the Interpreter  which is much slower on its operation. Later on, we have
the BIOS file selection. � PSinex PC Emulator will use the internal BIOS functions if no BIOS  image is present. If  you
do have an  external BIOS  image simply  select the desired  one. Next 3 tabs, are the  PSEmuPro plugin  selections, for
Graphics, Sound and CD-ROM respectively. Simply select the desired plugin  for each part, and execute  an option for it,
such  as Test, Configure or About, on  your right. Next  two tabs  contain  the configuration of the controllers. If you
wish to reconfigure  the controls, press the desired  button, and right immediately the  desired button on the keyboard.
The new entry will be directly saved.

C. Help / Answers

The first  option 'show official manual'  simply opens this text file. You can reffer  later on to the  Frequently Asked
Questions for  any problems you might be experiencing  with  the emulator. You can read the credits for this emulator by
clicking the 'about emul8or ...' selection on the present menu.



* Section 4
-----------

Q: WHY I CANNOT GO TO THE BIOS SHELL?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: You will need to install an external BIOS image instead of using the internal BIOS functions to do that.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: HOW DO I MAKE NEW MEMORY CARDS?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Due to pre-release you cannot do it on the Configurator, so just copy & paste the existing memory cards.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: I CANNOT SEE ANY PLUGINS!
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Check the PLUGINS directory, all the plugins should be in that directory, and not on any other.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: THE EMULATOR SAIS ON THE TITLE 'UNUSABLE', WHY?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: That is because  some part failed to initialize. Check  if the minimun system requirements meet your system specs and
   if yes, try restarting your system.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: WHY DOESN'T MY FAVOURITE GAME WORK?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Obviously  the game is  incompatible with the current  release of the emulator. Simply wait for the next  release, or
   download another emulator to try. Alternatively if you use the internal BIOS functions, please try with a dumped BIOS
   image for better results on compatibility.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: I WANT A NEW BETA OF PSINEX, WHERE CAN I GET ONE?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Nowhere, for sure. Just wait for the next release, if any.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: WHERE CAN I FIND THE BIOS?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: If you have a PlayStation you can dump your own one. If not, have some imagination.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: ALL I GET IS BLACK SCREEN, WHY?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: First of all  check your graphics plugin, and check  if it is compatible with your current video card. If it is, make
   sure the settings  are normal (don't enable  any weird  stuff  for now), and  then try again. If still you get  black
   screen, check your CD-ROM plugin. Make  sure it points to the correct  CD-ROM drive, use a normal mode, such as 'scsi         commands' on Pete's  ASPI plugin  and  try again. If  you still  get black  screen then  the  answer is  surely  that
   the emulator is incompatible with that game.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: I CANNOT SEE ANY ISO SUPPORT, HOW CAN I RUN MY ISO GAME?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Get Daemon  Tools, it  is a CD-ROM  emulator which  is available  freely to use  through the official page, which is:
   [http://www.daemon-tools.com].
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: THE MOVIES ON MY GAME ARE CRAPPY, WHY?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Either your Game CD is scratched, or the emulator cannot decode the  movie correctly, there's not much option than to
   wait for an update of the emulator.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: WHY IS THE SOUND IN THE MOVIES JUMPY/WRONG/NOISY?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: CD-ROM XA is on the first stages of implementation. We didn't have much time to develop that part yet.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: THE CONTROLS DONT CORRESPOND, WHY?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: First  of  all, bare  in mind  that  the default controls  are:

   -----------------------------------------
   -     [Q]                       [T]     -
   -     [W]                       [R]     -
   -                                       -
   -                                       -
   -     [I]                       [E]     -
   -  [J]   [L]                 [S]   [F]  -
   -     [K]                       [D]     -
   -               [2]   [1]               -
   -----------------------------------------


   If you made any changes to  these controls  from the configurator make sure, you  remember what you  have entered. If
   the problem persists, then simply the SIO part of the emulator needs debugging.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: 3D GRAPHICS ON MY FAVOURITE GAME DISPLAY WRONG, WHAT CAN I DO?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Nothing at all. Obviously  this is a bug on the GTE  part of  the  emulator, which  is  getting better and  better on
   every release.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: WHAT ARE THOSE WHITE LINES WITH STRANGE LETTERS ON THE BACKGROUND, WHILE THE SOUND IS PLAYING 'BRITNEY SPEARS HIT'?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: No idea.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: WHAT IS INTERPRETER AND RECOMPILER, WHICH IS THE BEST OPTION?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Those are the 2 ways of  emulating  the PSX processor. The  first one is slower  but has  higher compatibility, while
   the second one is faster, but can be incompatible with some games. Try  Recompiler first, if it  doesn't work try the
   other one.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: WHICH BIOS SHOULD I USE ON PSINEX?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Psinex has been tested with almost all the available bios and it works with all of them. It only  has a small problem
   with SCPH1000.BIN, which works but has some unexpected glitches. The recommended BIOS file is SCPH1001.BIN.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: THE GAME I'M TRYING TO PLAY IS REALLY SLOW, WHAT CAN I DO?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: Check if the specifications of your PC match with the recommended specifications of  the emulator, which you can find
   in this file. If it doesn't just  stop being cheap and buy another PC. A less expensive option would be to enable the
   Recompiler  Engine on  the configurator. Try  also different  combination  of plugins  to achive  a  normal  level of
   gameplay. If nothing works, once again, just wait for the next release.
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------


Q: WHAT CAN I DO TO HELP YOU GUYS?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
A: You can  contribute by sending us on  e-mail various PSX documents, that are really not  common to the one's availabe
   on the internet. You  can also help us by  submitting compatibility reports to  various sites, one of  the best being
   [http://www.psxfanatics.com].
------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------



* Section 5
-----------

� PSinex PC Emulator is made by [pSyChOjAk & Shunt]

Previous Co-workers: ?????? & Neomax


I would like to thank many people for their  contribution on this project, without their help the emulator would lack of
some good code at some parts:

LDChen - Roor - calb - Galtor - Gavionne - lu_zero - linuzappz - Shadow - Sepiroth Angellus - D1Y - JNS - DoveBlack


And of course, millions of thanks to friends:

The usual company from Greece: Vicky my babe - Johnny - Adonis - Stam - Ramsis (the Staglianno) - Amerika (the Pr0n man)

IRC dudes & dudettes: YoD - CD - Exophase - Bobbi - EmuManiac - Sandie - Wormie - Thorgal - Phuzzi - Scar_T - HUB107!!!!


e-mail: psinex@europe.com | em00ddk@brunel.ac.uk | UIN: 96171885


------------------------------------------------------------------------------------------------------------------------
* any job offer would be highly appreciated, especially on the programing area, my location is UK (as well Greece, kthx)
------------------------------------------------------------------------------------------------------------------------